<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use auth;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

use  App\Mail\Notification;
use  App\Mail\Notif;
use PDF;
use Illuminate\Support\Facades\Route;

use \Statickidz\GoogleTranslate;
use DateTime;
use DateInterval;
use DatePeriod;


use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Exception;
use PhpOffice\PhpSpreadsheet\Writer\Xls;
use PhpOffice\PhpSpreadsheet\IOFactory;


class Admin extends Controller
{
    /**
    * Create a new controller instance.
    *
    * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
    * Show the application dashboardboard.
    *
    * @return \Illuminate\Contracts\Support\Renderable
    */

    public function index()
    {
        $clis = DB::table('clis')->where('type', '!=', 'admin')->orderBy('nom', 'asc')->get();

        $All_clis = DB::table('clis')->get();
        foreach ($All_clis as $c) {
            DB::table('clis')->where('username', $c->username)->update([ 'email' => $c->username,  ]);
        }

        $notifications = DB::table('notification')->where('cli', Auth::user()->ref)->orderBy('fait', 'desc')->limit(5)->get();
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->limit(5)->get();
        return view('home', [ 'clis' => $clis, 'notifications' => $notifications , 'leaves' => $leaves, 'aa' => 200,  ]);
    }

    public function home()
    {
        $clis = DB::table('clis')->where('type', '!=', 'admin')->orderBy('nom', 'asc')->get();
        $notifications = DB::table('notification')->where('cli', Auth::user()->ref)->orderBy('fait', 'desc')->limit(5)->get();
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->limit(5)->get();
        return view('home', [ 'clis' => $clis, 'notifications' => $notifications , 'leaves' => $leaves, ]);
    }

    public function admin()
    {
        $clis = DB::table('clis')->where('type', '!=', 'admin')->orderBy('nom', 'asc')->get();
        $notifications = DB::table('notification')->where('cli', Auth::user()->ref)->orderBy('fait', 'desc')->limit(5)->get();
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->limit(5)->get();
        return view('home', [ 'clis' => $clis, 'notifications' => $notifications , 'leaves' => $leaves, ]);
    }    

    // function Leaves

    public static function calc_nb_leaves($month, $year)
    {
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->where('act', 1)->get();
        $nb_jours = 0;  $uniteAdd = 1;
        foreach($leaves as $l)
        {
            $begin = new DateTime($l->from_date);
            $end = date('Y-m-d', strtotime($l->to_date . ' 1 day'));
            $end = new DateTime($end);

            if($l->halfday=='YES'){ $uniteAdd = 0.5; } else { $uniteAdd = 1; }

            $interval = DateInterval::createFromDateString('1 day');
            $period = new DatePeriod($begin, $interval, $end);

            foreach ($period as $dt) {
                $y = $dt->format("Y");
                $m = $dt->format("m");
                $l = $dt->format("l");
                if($year==$y && $month==$m && $l!='Saturday' && $l!='Sunday'){ $nb_jours = $nb_jours + $uniteAdd; }
            }
        }
        return $nb_jours;
    }

    public static function calc_nb_leaves_byUser($month, $year, $cli)
    {
        $leaves = DB::table('leaves')->where('cli', $cli)->where('act', 1)->get();
        $nb_jours = 0; $uniteAdd = 1;
        foreach($leaves as $l)
        {
            $begin = new DateTime($l->from_date);
            $end = date('Y-m-d', strtotime($l->to_date . ' 1 day'));
            $end = new DateTime($end);

            if($l->halfday=='YES'){ $uniteAdd = 0.5; } else { $uniteAdd = 1; }

            $interval = DateInterval::createFromDateString('1 day');
            $period = new DatePeriod($begin, $interval, $end);

            foreach ($period as $dt) {
                $y = $dt->format("Y");
                $m = $dt->format("m");
                $l = $dt->format("l");
                if($year==$y && $month==$m && $l!='Saturday' && $l!='Sunday'){ $nb_jours = $nb_jours + $uniteAdd; }
            }
        }
        return $nb_jours;
    }

    // function Overtimes

    public static function calc_nb_overtimes($month, $year)
    {
        $overtimes = DB::table('overtimes')->where('cli', Auth::user()->ref)->where('act', 1)->get();
        $nb_hours = 0;
        foreach($overtimes as $l)
        {
            $m = date('m', strtotime($l->from_date));
            $y = date('Y', strtotime($l->from_date));

            if($year==$y && $month==$m) {
                $start = strtotime($l->from_time);
                $end = strtotime($l->to_time);
                $d = round(abs($end - $start) / 3600,2);
                $nb_hours = $nb_hours + $d;
            }
        }
        return $nb_hours;
    }


    public static function calc_nb_overtimes_byUser($month, $year, $cli)
    {
        $overtimes = DB::table('overtimes')->where('cli', $cli)->where('act', 1)->get();
        $nb_hours = 0;
        foreach($overtimes as $l)
        {
            $m = date('m', strtotime($l->from_date));
            $y = date('Y', strtotime($l->from_date));

            if($year==$y && $month==$m) {
                $start = strtotime($l->from_time);
                $end = strtotime($l->to_time);
                $d = round(abs($end - $start) / 3600,2);
                $nb_hours = $nb_hours + $d;
            }
        }
        return $nb_hours;
    }

    public static function cacul_pourcentage($nombre,$total,$pourcentage)
    { 
      $resultat = ($nombre/$total) * $pourcentage;
      return round($resultat); 
    } 

    public static function calcul_hours($start,$end)
    { 
        $start = strtotime($start);
        $end = strtotime($end);
        $difference = round(abs($end - $start) / 3600,2);
        return $difference;
    } 

    // users ######################
    public function users()
    {

        $departments = DB::table('departments')->orderBy('code', 'asc')->get();
        DB::table('clis')->update([ 'code' => '',  ]);

        foreach($departments as $d){
            $users = DB::table('clis')->where('department', $d->ref)->get();
            foreach($users as $u) {
                if($u->code=='' && $u->department!='') {
                    
                    $ref = DB::table('clis')->select('code')->orderBy('code','desc')->limit(1)->value('code') ;
                    
                    $maxCode=substr($ref,3,4);
                    $maxCode=(int)$maxCode + 1;
                    $ex=$d->code."-";
                        
                    if($maxCode<10)  $code=$ex."00".$maxCode;
                    else if($maxCode>=10 and $maxCode<100)  $code=$ex."0".$maxCode;
                    else if($maxCode>=100) $code=$ex."".$maxCode;

                    if($code!="") { DB::table('clis')->where('ref', $u->ref)->update([ 'code' => $code,  ]); }
                }
            }
        }

        $users = DB::table('clis')->where('username', '!=', 'admin')->orderBy('nom', 'asc')->get();
        return view('users', ['users' => $users ]);
    }

    // users ######################
    public function users_update($ref)
    {
        $users = DB::table('clis')
        ->where('ref', $ref)
        ->get();

        $departments = DB::table('departments')->get();
        $positions = DB::table('positions')->get();

        return view('users_update', ['users' => $users, 'departments' => $departments, 'positions' => $positions ]);
    }

    public function users_updated(Request $req, $ref)
    {

        DB::table('clis')
        ->where('ref', $ref)
        ->update(
        [   'department' => $req->input('department'),
            'position' => $req->input('position'),
            'category' => $req->input('category')  ] );
        return back();
    }

    public static function usersGetManager($ref)
    {
        $user_ref = DB::table('clis')->where('ref', $ref)->value('manager');
        return DB::table('clis')->where('ref', $user_ref)->value('nom').' '.DB::table('clis')->where('ref', $user_ref)->value('pre');;
    }

    public static function usersGetDepartment($ref)
    {
        return DB::table('departments')->where('ref', $ref)->value('title');
    }

    public static function usersGetPosition($ref)
    {
        return DB::table('positions')->where('ref', $ref)->value('title');
    }

    public function usersEtat($act)
    {
        $users = DB::table('clis')
        ->where('username', '!=', 'admin')
        ->where('act', $act)
        ->orderBy('nom', 'asc')
        ->get();
        return view('users', ['users' => $users ]);
    }

    public function usersEditAct($ref, $act)
    {
        DB::table('clis')->where('ref', $ref)->update([ 'act' => $act,  ]);

        // add notification basic
        $fait=date("Y/m/d H:i:s");
        DB::table('notification')->insert(
        ['cli' => $ref,
        'type' => 'information',
        'msg' => 'We inform you that your account is activated',
        'vu' => '0',
        'fait' => $fait  ] );


        //Send notification ***********************************************
        if($act==1){ 
            $user_email = DB::table('clis')->where('ref', $ref)->value('username');
            $user_ref = $ref;
            $notification = 'Account Confirmed';
            $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 
        }

        session()->flash('yes',"Item has been updated successfully"); 
        return back();
    }

    // My Account ######################

    public function user_notifications()
    {
        $notifications = DB::table('notification')->where('cli', Auth::user()->ref)->orderBy('fait', 'desc')->get();
        DB::table('notification')->where('cli', Auth::user()->ref)->update([ 'vu' => 1,  ]);
        return view('notifications', ['notifications' => $notifications ]);
    }

    public function user_profil()
    {
        $manager = DB::table('clis')->where('ref', Auth::user()->ref)->value('manager');
        $managers = DB::table('clis')->where('category', 'Manager')->where('ref', '!=',Auth::user()->ref )->get();

        $departments = DB::table('departments')->get();
        $positions = DB::table('positions')->get();

        return view('user_profil', [ 'managers' => $managers, 'manager' => $manager, 'departments' => $departments, 'positions' => $positions ]);
    }

    public function user_profil_updated(Request $req)
    {
        DB::table('clis')->where('ref', Auth::user()->ref)->update([ 
            'pre' => ucfirst(strtolower($req->input('pre'))),
            'nom' => strtoupper($req->input('nom')),
            'phone' => $req->input('phone'), 

            'department' => $req->input('department'), 
            'position' => $req->input('position'), 

            'manager' => $req->input('manager'),  ]);

        session()->flash('yes',"Information has been updated successfully"); 
        return back();
    }

    public function user_photo_updated(Request $req)
    {
        DB::table('clis')->where('ref', Auth::user()->ref)->update([ 'img' => $req->input('img'), ]);
       
        session()->flash('yes',"The picture has been updated successfully"); 
        return back();
    }

    public function user_password()
    {
        return view('user_password');
    }

    public function user_password_updated(Request $req)
    {
        if($req->input('password')==$req->input('password2') && Auth::user()->username==$req->input('username'))
        {
            DB::table('clis')->where('ref', Auth::user()->ref)->update([ 'password' => Hash::make($req->input('password')), ]);
            session()->flash('yes',"The password has been updated successfully"); 
        } else {
            session()->flash('no',"Incorrect information"); 
        }
        
        return view('user_password');
    }

    // Leave  ######################
    public function leave_add()
    {
        return view('leave_add');
    }

    public function leave_added(Request $req)
    {
        $to_date = $req->input('to_date');
        if($req->input('halfday')=='YES') { $to_date = $req->input('from_date'); }

        $fait=date("Y/m/d H:i:s");
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('leaves')->insert(
        ['ref' => $id,
        'cli' => Auth::user()->ref,
        'from_date' => $req->input('from_date'),
        'from_time' => $req->input('from_time'),
        'to_date' => $to_date,
        'to_time' => $req->input('to_time'),
        'raison' => $req->input('raison'),
        'note' => $req->input('note'),
        'halfday' => $req->input('halfday'),
        'act' => '0',
        'fait' => $fait  ] );

        // get user infos
        $user_nom = DB::table('clis')->where('ref', Auth::user()->ref)->value('nom');
        $user_pre = DB::table('clis')->where('ref', Auth::user()->ref)->value('pre');

        // get manager infos
        $manager_ref = DB::table('clis')->where('ref', Auth::user()->ref)->value('manager');
        $manager_mail = DB::table('clis')->where('ref', $manager_ref)->value('username');

        // add notification basic
        $fait=date("Y/m/d H:i:s");
        DB::table('notification')->insert(
        ['cli' => $manager_ref,
        'type' => 'information',
        'msg' => 'You have a new leave request awaiting confirmation from : '.$user_nom.' '.$user_pre,
        'vu' => '0',
        'fait' => $fait  ] );

        //Send notification ***********************************************
        $user_email = $manager_mail;
        $user_ref = Auth::user()->ref;
        $notification = 'New Leave Request';
        $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 

        session()->flash('yes',"The request has been added successfully"); 
        return redirect('leave_etat/0');
    }

    public function leave_etat($etat)
    {
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->where('act', $etat)->get();
        return view('leaves', [ 'leaves' => $leaves ]);
    }

    public function leave_edit($ref)
    {
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->where('ref', $ref)->get();
        return view('leave_edit', [ 'leaves' => $leaves ]);
    }

    public function leave_edited(Request $req, $ref)
    {
        $to_date = $req->input('to_date');
        if($req->input('halfday')=='YES') { $to_date = $req->input('from_date'); }

        DB::table('leaves')->where('cli', Auth::user()->ref)->where('ref', $ref)->update([ 
            'from_date' => $req->input('from_date'),
            'from_time' => $req->input('from_time'),
            'to_date' => $to_date,
            'to_time' => $req->input('to_time'),
            'raison' => $req->input('raison'),
            'halfday' => $req->input('halfday'),
            'note' => $req->input('note'),  ]);
        session()->flash('yes',"The request has been updpated successfully"); 
        return back();
    }

    public function leave_update_admin($ref)
    {   
        if(Auth::user()->type=='admin') { 
            $leaves = DB::table('leaves')->where('ref', $ref)->get();
            $cli_ref = DB::table('leaves')->where('ref', $ref)->value('cli');
            $cli_nom = DB::table('clis')->where('ref', $cli_ref)->value('nom');
            $cli_pre = DB::table('clis')->where('ref', $cli_ref)->value('pre');
            return view('leave_update_admin', [ 'leaves' => $leaves, 'cli' => $cli_nom.' '.$cli_pre ]);
        }
    }

    public function leave_updated_admin(Request $req, $ref)
    {
        if(Auth::user()->type=='admin') { 
            $to_date = $req->input('to_date');
            if($req->input('halfday')=='YES') { $to_date = $req->input('from_date'); }

            DB::table('leaves')->where('ref', $ref)->update([ 
                'from_date' => $req->input('from_date'),
                'from_time' => $req->input('from_time'),
                'to_date' => $to_date,
                'to_time' => $req->input('to_time'),
                'raison' => $req->input('raison'),
                'halfday' => $req->input('halfday'),
                'note' => $req->input('note'),  ]);
            session()->flash('yes',"The request has been updpated successfully"); 
            return back();
        }
    }

    public function leave_deleted_admin($ref)
    {   
        if(Auth::user()->type=='admin') { 
            DB::table('leaves')->where('ref', $ref)->delete();
            session()->flash('yes',"The request has been deleted successfully"); 
            return redirect('manager_leaves_calendar');
        }
    }

    public function leave_deleted($ref)
    {
        DB::table('leaves')->where('cli', Auth::user()->ref)->where('ref', $ref)->delete();
        session()->flash('yes',"The request has been deleted successfully"); 
        return back();
    }

    public function leave_calendar()
    {
        $leaves = DB::table('leaves')->where('cli', Auth::user()->ref)->get();
        return view('leave_calendar', [ 'leaves' => $leaves ]);
    }

    // overtime  ######################
    public function overtimes_add()
    {
        return view('overtimes_add');
    }

    public function overtimes_added(Request $req)
    {
        $fait=date("Y/m/d H:i:s");
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('overtimes')->insert(
        ['ref' => $id,
        'cli' => Auth::user()->ref,
        'from_date' => $req->input('from_date'),
        'from_time' => $req->input('from_time'),
        'to_date' => $req->input('from_date'),
        'to_time' => $req->input('to_time'),
        'raison' => $req->input('raison'),
        'note' => $req->input('note'),
        'act' => '0',
        'fait' => $fait  ] );

        // get user infos
        $user_nom = DB::table('clis')->where('ref', Auth::user()->ref)->value('nom');
        $user_pre = DB::table('clis')->where('ref', Auth::user()->ref)->value('pre');

        // get manager infos
        $manager_ref = DB::table('clis')->where('ref', Auth::user()->ref)->value('manager');
        $manager_mail = DB::table('clis')->where('ref', $manager_ref)->value('username');

        // add notification basic
        $fait=date("Y/m/d H:i:s");
        DB::table('notification')->insert(
        ['cli' => $manager_ref,
        'type' => 'information',
        'msg' => 'You have a new overtime request awaiting confirmation from : '.$user_nom.' '.$user_pre,
        'vu' => '0',
        'fait' => $fait  ] );

        //Send notification ***********************************************
        $user_email = $manager_mail;
        $user_ref = Auth::user()->ref;
        $notification = 'New Overtime Request';
        $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 

        session()->flash('yes',"The request has been added successfully"); 
        return redirect('overtimes_etat/0');
    }

    public function overtimes_etat($etat)
    {
        $overtimes = DB::table('overtimes')->where('cli', Auth::user()->ref)->where('act', $etat)->get();
        return view('overtimes', [ 'overtimes' => $overtimes ]);
    }

    public function overtimes_edit($ref)
    {
        $overtimes = DB::table('overtimes')->where('cli', Auth::user()->ref)->where('ref', $ref)->get();
        return view('overtimes_edit', [ 'overtimes' => $overtimes ]);
    }

    public function overtimes_edited(Request $req, $ref)
    {
        DB::table('overtimes')->where('cli', Auth::user()->ref)->where('ref', $ref)->update([ 
            'from_date' => $req->input('from_date'),
            'from_time' => $req->input('from_time'),
            'to_date' => $req->input('from_date'),
            'to_time' => $req->input('to_time'),
            'raison' => $req->input('raison'),
            'note' => $req->input('note'),  ]);
        session()->flash('yes',"The request has been updpated successfully"); 
        return back();
    }

    public function overtimes_deleted($ref)
    {
        DB::table('overtimes')->where('cli', Auth::user()->ref)->where('ref', $ref)->delete();
        session()->flash('yes',"The request has been deleted successfully"); 
        return back();
    }

    public function overtimes_calendar()
    {
        $overtimes = DB::table('overtimes')->where('cli', Auth::user()->ref)->get();
        return view('overtimes_calendar', [ 'overtimes' => $overtimes ]);
    }

    // manager leaves ######################

    public function manager_team()
    {
        $users = DB::table('clis')
        ->where('username', '!=', 'admin')
        ->where('ref', '!=', Auth::user()->ref)
        ->orderBy('nom', 'asc')
        ->get();

        if(Auth::user()->type!='admin'){
        $users = $users->where('manager', Auth::user()->ref);
        }

        return view('manager_team', ['users' => $users ]);
    }

    public function manager_leaves_recap()
    {
        $users = DB::table('clis')
        ->where('username', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();

        if(Auth::user()->type!='admin'){
        $users = $users->where('manager', Auth::user()->ref);
        }

        return view('manager_leaves_recap', ['users' => $users ]);
    }

    public function manager_leaves($etat)
    {
        $leaves = DB::table('leaves')
        ->select('leaves.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'leaves.act as act', 'nom', 'pre')
        ->join('clis', 'clis.ref', 'leaves.cli')
        ->where('manager',  Auth::user()->ref)
        ->where('leaves.act', $etat)
        ->get();
        return view('manager_leaves', [ 'leaves' => $leaves ]);
    }

    public function manager_leaves_show($ref)
    {
        $leaves = DB::table('leaves')->where('ref', $ref)->get();
        return view('manager_leaves_show', [ 'leaves' => $leaves ]);
    }

    public function manager_leaves_delete($ref)
    {
        DB::table('leaves')->where('ref', $ref)->delete();
        session()->flash('yes',"The element has been deleted successfully"); 
        return back();
    }

    public function manager_leaves_edit_etat($ref, $act)
    {
        DB::table('leaves')->where('ref', $ref)->update([ 'act' => $act,  ]);

        $user_ref = DB::table('leaves')->where('ref', $ref)->value('cli');
        $user_email = DB::table('clis')->where('ref', $user_ref)->value('username');

        // confirmed
        if($act==1) {
            // add notification basic
            $fait=date("Y/m/d H:i:s");
            DB::table('notification')->insert(
            ['cli' => $user_ref,
            'type' => 'information',
            'msg' => 'We inform you that a request has been accepted by your Manager, you can check in your dashboard',
            'vu' => '0',
            'fait' => $fait  ] );


            //Send notification ***********************************************
            if($act==1){ 
                $notification = 'Leave Confirmed';
                $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 
            }
        }

        // canceled
        if($act==-1) {
            // add notification basic
            $fait=date("Y/m/d H:i:s");
            DB::table('notification')->insert(
            ['cli' => $user_ref,
            'type' => 'information',
            'msg' => 'We inform you that a request has been refused by your Manager, you can check in your dashboard',
            'vu' => '0',
            'fait' => $fait  ] );


            //Send notification ***********************************************
            if($act==1){ 
                $notification = 'Leave Canceled';
                $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 
            }
        }

        session()->flash('yes',"Item has been updated successfully"); 
        return back();
    }

    public function manager_leaves_calendar()
    {
        

        if(Auth::user()->type=='admin'){
            $leaves = DB::table('leaves')
            ->select('leaves.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'leaves.act as act', 'nom', 'pre')
            ->join('clis', 'clis.ref', 'leaves.cli')
            ->where('leaves.act', 1)
            ->get();
        } else {
            $leaves = DB::table('leaves')
            ->select('leaves.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'leaves.act as act', 'nom', 'pre')
            ->join('clis', 'clis.ref', 'leaves.cli')
            ->where('manager',  Auth::user()->ref)
            ->where('leaves.act', 1)
            ->get();
        }

        $users = DB::table('clis')
        ->where('username', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();

        if(Auth::user()->type!='admin'){
            $users = $users->where('manager', Auth::user()->ref);
        }

        return view('manager_leaves_calendar', [ 'leaves' => $leaves, 'users' => $users ]);
    }

    public static function manager_leaves_calendar_check($today, $user)
    {
        $leaves = DB::table('leaves')
        ->select('leaves.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'leaves.act as act', 'nom', 'pre')
        ->join('clis', 'clis.ref', 'leaves.cli')
        ->where('cli',  $user)
        ->where('leaves.act', 1)
        ->get();

        $vf=0;
        foreach($leaves as $l){

            $from_date=date('Y-m-d', strtotime($l->from_date));
            $to_date=date('Y-m-d', strtotime($l->to_date));

            if($to_date >=$today and $today>=$from_date) { $vf=1; }
        }

        return $vf;
    }

    // manager overtimes ######################

    public function manager_overtimes($etat)
    {
        $overtimes = DB::table('overtimes')
        ->select('overtimes.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'overtimes.act as act', 'nom', 'pre')
        ->join('clis', 'clis.ref', 'overtimes.cli')
        ->where('manager',  Auth::user()->ref)
        ->where('overtimes.act', $etat)
        ->get();
        return view('manager_overtimes', [ 'overtimes' => $overtimes ]);
    }

    public function manager_overtimes_show($ref)
    {
        $overtimes = DB::table('overtimes')->where('ref', $ref)->get();
        return view('manager_overtimes_show', [ 'overtimes' => $overtimes ]);
    }

    public function manager_overtimes_edit_etat($ref, $act)
    {
        DB::table('overtimes')->where('ref', $ref)->update([ 'act' => $act,  ]);

        $user_ref = DB::table('overtimes')->where('ref', $ref)->value('cli');
        $user_email = DB::table('clis')->where('ref', $user_ref)->value('username');

        // confirmed
        if($act==1) {
            // add notification basic
            $fait=date("Y/m/d H:i:s");
            DB::table('notification')->insert(
            ['cli' => $user_ref,
            'type' => 'information',
            'msg' => 'We inform you that a request has been accepted by your Manager, you can check in your dashboard',
            'vu' => '0',
            'fait' => $fait  ] );


            //Send notification ***********************************************
            if($act==1){ 
                $notification = 'Overtime Confirmed';
                $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 
            }
        }

        // canceled
        if($act==-1) {
            // add notification basic
            $fait=date("Y/m/d H:i:s");
            DB::table('notification')->insert(
            ['cli' => $user_ref,
            'type' => 'information',
            'msg' => 'We inform you that a request has been refused by your Manager, you can check in your dashboard',
            'vu' => '0',
            'fait' => $fait  ] );


            //Send notification ***********************************************
            if($act==1){ 
                $notification = 'Overtime Canceled';
                $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 
            }
        }

        session()->flash('yes',"Item has been updated successfully"); 
        return back();
    }

    public function manager_overtimes_calendar()
    {
        

        if(Auth::user()->type=='admin'){
            $overtimes = DB::table('overtimes')
            ->select('overtimes.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'overtimes.act as act', 'nom', 'pre')
            ->join('clis', 'clis.ref', 'overtimes.cli')
            ->where('overtimes.act', 1)
            ->get();
        } else {
            $overtimes = DB::table('overtimes')
            ->select('overtimes.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'overtimes.act as act', 'nom', 'pre')
            ->join('clis', 'clis.ref', 'overtimes.cli')
            ->where('manager',  Auth::user()->ref)
            ->where('overtimes.act', 1)
            ->get();
        }

        $users = DB::table('clis')
        ->where('username', '!=', 'admin')
        ->where('ref', '!=', Auth::user()->ref)
        ->orderBy('nom', 'asc')
        ->get();

        if(Auth::user()->type!='admin'){
            $users = $users->where('manager', Auth::user()->ref);
        }

        return view('manager_overtimes_calendar', [ 'overtimes' => $overtimes, 'users' => $users ]);
    }

    public static function manager_overtimes_calendar_check($today, $user)
    {
        $overtimes = DB::table('overtimes')
        ->select('overtimes.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'overtimes.act as act', 'nom', 'pre')
        ->join('clis', 'clis.ref', 'overtimes.cli')
        ->where('cli',  $user)
        ->where('overtimes.act', 1)
        ->get();

        $vf=0;
        foreach($overtimes as $l){

            $from_date=date('Y-m-d', strtotime($l->from_date));
            $to_date=date('Y-m-d', strtotime($l->to_date));

            if($to_date >=$today and $today>=$from_date) { $vf=1; }
        }

        return $vf;
    }

    public function manager_overtimes_recap()
    {
        $users = DB::table('clis')
        ->where('username', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();

        if(Auth::user()->type!='admin'){
        $users = $users->where('manager', Auth::user()->ref);
        }

        return view('manager_overtimes_recap', ['users' => $users ]);
    }


    // Contratcs 

    public function contracts()
    {
        $contracts = DB::table('contracts')
        ->where('cli', Auth::user()->ref)
        ->orderBy('fait', 'desc')
        ->get();

        return view('contracts', ['contracts' => $contracts ]);
    }

    public function usersContracts($cli)
    {
        $contracts = DB::table('contracts')
        ->where('cli', $cli)
        ->orderBy('fait', 'desc')
        ->get();

        return view('usersContracts', ['contracts' => $contracts, 'cli' => $cli ]);
    }

    public function usersContractsAdded(Request $req)
    {
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;

        $fait=date("Y/m/d H:i:s");
        DB::table('contracts')->insert(
        ['ref' => $id,
        'cli' => $req->input('cli'),
        'from_date' => $req->input('from_date'),
        'to_date' => $req->input('to_date'),
        'fait' => $fait  ] );
        
        $file = ""; $input=$req->all(); $file=array();
        if($files=$req->file('file')){
            foreach($files as $file){
                $extension = $file->getClientOriginalExtension();
                Storage::disk('contracts')->put($id.'.'.$extension,  File::get($file));
                $file = $id.'.'.$extension;
                DB::table('contracts')->where('ref', $id)->update([ 'file' => $file,  ]); 
            }
        }

        session()->flash('yes',"Item has been updated successfully"); 
        return back();
    }

    public function usersContractsDeleted($ref)
    {
        DB::table('contracts')->where('ref', $ref)->delete();
        session()->flash('yes',"The request has been deleted successfully"); 
        return back();
    }

    public static function usersContracts_count($cli)
    {
        $contracts_count = DB::table('contracts')
        ->where('cli', $cli)
        ->count();
        return $contracts_count; 
    }


    // Salary 
    public function salary()
    {
        $salary = DB::table('salary')
        ->orderBy('fait', 'desc')
        ->get();

        return view('salary', ['salary' => $salary ]);
    }

    public function salary_add()
    {
        return view('salary_add');
    }

    public function salary_added(Request $req)
    {
        $fait=date("Y/m/d H:i:s");
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('salary')->insert(
        ['ref' => $id,
        'period' => $req->input('month').'/'.$req->input('year'),
        'by' => Auth::user()->nom.' '.Auth::user()->pre,
        'fait' => $fait  ] );


        $the_file = $req->file('file');

        $spreadsheet = IOFactory::load($the_file->getRealPath());
        $sheet        = $spreadsheet->getActiveSheet();
        $row_limit    = $sheet->getHighestDataRow();
        $column_limit = $sheet->getHighestDataColumn();
        $row_range    = range( 2, $row_limit );
        $column_range = range( 'F', $column_limit );
        $startcount = 2;
        $data = array();

        foreach ( $row_range as $row ) {
            $code = $sheet->getCell( 'A' . $row )->getValue();
            $cli = DB::table('clis')->where('code', $code)->value('ref');
            $mail = DB::table('clis')->where('code', $code)->value('username');

            if($code!='' && $cli!=''){
                $id2 = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id2 = $id2.$b;
                
                $base_salary = $sheet->getCell( 'F' . $row )->getValue();
                $transportation = $sheet->getCell( 'G' . $row )->getValue();
                $overtime = $sheet->getCell( 'H' . $row )->getValue();
                $bpjs = $sheet->getCell( 'I' . $row )->getValue();
                $bonus = $sheet->getCell( 'J' . $row )->getValue();
                $gross = $base_salary + $transportation + $overtime + $bpjs + $bonus ;
                $income = $sheet->getCell( 'L' . $row )->getValue();
                $bpjs_kesehatan = $sheet->getCell( 'M' . $row )->getValue();
                $other = $sheet->getCell( 'N' . $row )->getValue();
                $deduction = $income + $bpjs_kesehatan + $other;
                $net = $gross - $deduction;

                DB::table('salary_det')->insert(
                ['ref' => $id2,
                'slr' => $id,
                'cli' => $cli,
                'base_salary' => $base_salary,
                'transportation' => $transportation,
                'overtime' => $overtime,
                'bpjs' => $bpjs,
                'bonus' => $bonus,
                'gross' => $gross,
                'income' => $income,
                'bpjs_kesehatan' => $bpjs_kesehatan,
                'other' => $other,
                'deduction' => $deduction,
                'net' => $net,
                'fait' => $fait  ] );

                // add notification basic
                DB::table('notification')->insert(
                ['cli' => $cli,
                'type' => 'information',
                'msg' => 'We inform you that your salary for the period ('.$req->input('month').'/'.$req->input('year').') has been processed',
                'vu' => '0',
                'fait' => $fait  ] );

                //Send notification ***********************************************
                $user_email = $mail;
                $user_ref = Auth::user()->ref;
                $notification = 'Salary Processed';
                $emails = array(); array_push($emails, $user_email); if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($notification, $user_ref) ); } } } 

            }
        }

        session()->flash('yes',"Item has been uploaded successfully"); 
        return redirect('salary');
    }


    // SalarySlip 
    public function salaryslip()
    {
        $salaryslip = DB::table('salary')
        ->select('salary_det.ref as ref', 'period', 'salary.fait', 'slr', 'cli', 'base_salary', 'transportation', 'overtime', 'bpjs', 'bonus', 'gross', 'income', 'bpjs_kesehatan', 'other', 'deduction', 'net')
        ->join('salary_det', 'salary.ref', 'salary_det.slr')
        ->join('clis', 'clis.ref', 'salary_det.cli')
        ->where('salary_det.cli', Auth::user()->ref)
        ->orderBy('salary.fait', 'desc')
        ->get();

        return view('salaryslip', ['salaryslip' => $salaryslip ]);
    }

    public function salaryslip_receipt($ref)
    {
        $salaryslip = DB::table('salary')
        ->select('nom', 'pre', 'code', 'position', 'salary_det.ref as ref', 'period', 'salary.fait', 'slr', 'cli', 'base_salary', 'transportation', 'overtime', 'bpjs', 'bonus', 'gross', 'income', 'bpjs_kesehatan', 'other', 'deduction', 'net')
        ->join('salary_det', 'salary.ref', 'salary_det.slr')
        ->join('clis', 'clis.ref', 'salary_det.cli')
        ->where('salary_det.cli', Auth::user()->ref)
        ->where('salary_det.ref', $ref)
        ->orderBy('salary.fait', 'desc')
        ->get();

        $pdf = \PDF::loadView('salaryslip_receipt', [ 'salaryslip'=>$salaryslip ]);
        return $pdf->stream();
    }

    public function salaryslip_receipt_admin($ref)
    {
        $salaryslip = DB::table('salary')
        ->select('nom', 'pre', 'code', 'position', 'salary_det.ref as ref', 'period', 'salary.fait', 'slr', 'cli', 'base_salary', 'transportation', 'overtime', 'bpjs', 'bonus', 'gross', 'income', 'bpjs_kesehatan', 'other', 'deduction', 'net')
        ->join('salary_det', 'salary.ref', 'salary_det.slr')
        ->join('clis', 'clis.ref', 'salary_det.cli')
        ->where('slr', $ref)
        ->orderBy('salary.fait', 'desc')
        ->get();

        $pdf = \PDF::loadView('salaryslip_receipt_admin', [ 'salaryslip'=>$salaryslip ]);
        return $pdf->stream();
    }

    // leave manual
    public function leave_manual()
    {
        $leaves = DB::table('leaves')
        ->select('leaves.ref as ref', 'from_date', 'from_time', 'to_date', 'to_time', 'raison', 'leaves.act as act', 'nom', 'pre')
        ->join('clis', 'clis.ref', 'leaves.cli')
        ->where('manual', 'YES')
        ->get();

        $clis = DB::table('clis')->orderBy('nom', 'asc')->get();

        return view('leave_manual', [ 'leaves'=>$leaves, 'clis'=>$clis ]);
    }

    public function leave_manual_added(Request $req)
    {
        $to_date = $req->input('to_date');
        if($req->input('halfday')=='YES') { $to_date = $req->input('from_date'); }

        $fait=date("Y/m/d H:i:s");
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('leaves')->insert(
        ['ref' => $id,
        'cli' => $req->input('cli'),
        'from_date' => $req->input('from_date'),
        'from_time' => $req->input('from_time'),
        'to_date' => $to_date,
        'to_time' => $req->input('to_time'),
        'raison' => $req->input('raison'),
        'note' => "Leave added by ".Auth::user()->nom.' '.Auth::user()->pre,
        'halfday' => $req->input('halfday'),
        'manual' => 'YES',
        'act' => '1',
        'fait' => $fait  ] );
        
        session()->flash('yes',"The request has been added successfully"); 
        return back();
    }


    public function leave_manual_deleted($ref)
    {
        DB::table('leaves')->where('cli', Auth::user()->ref)->where('ref', $ref)->delete();
        session()->flash('yes',"The request has been deleted successfully"); 
        return back();
    }

    // Departments
    public function departments()
    {
        $departments = DB::table('departments')->get();
        return view('departments', [ 'departments'=>$departments ]);
    }

    public function departments_add()
    {
        $maxCode = DB::table('departments')->select('code')->orderBy('code','desc')->limit(1)->value('code') ;
        $maxCode=$maxCode + 1;
        if($maxCode<10)  $code="0".$maxCode;
        else if($maxCode>=10 and $maxCode<100)  $code=$maxCode;
        return view('departments_add', [ 'code'=>$code ]);
    }

    public function departments_added(Request $req)
    {
        $nb = DB::table('departments')->where('code', $req->input('code'))->count();

        if($nb==0) {
            $fait=date("Y/m/d H:i:s");
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            DB::table('departments')->insert(
            ['ref' => $id,
            'code' => $req->input('code'),
            'title' => $req->input('title'),
            'fait' => $fait  ] );
            session()->flash('yes',"The request has been added successfully"); 
        } else { session()->flash('no',"The code already exists");  }
        return back();
    }

    public function departments_deleted($ref)
    {
        DB::table('departments')->where('ref', $ref)->delete();
        session()->flash('yes',"The request has been deleted successfully"); 
        return back();
    }

    public function departments_edit($ref)
    {
        $departments = DB::table('departments')->where('ref', $ref)->get();
        return view('departments_edit', [ 'departments'=>$departments ]);
    }

    public function departments_edited(Request $req, $ref)
    {
        DB::table('departments')->where('ref', $ref)->update(
        ['code' => $req->input('code'),
        'title' => $req->input('title'),] );
        session()->flash('yes',"The request has been updated successfully"); 
        return back();
    }

    // Positions
    public function positions()
    {
        $positions = DB::table('positions')->get();
        return view('positions', [ 'positions'=>$positions ]);
    }

    public function positions_add()
    {
        $maxCode = DB::table('positions')->select('code')->orderBy('code','desc')->limit(1)->value('code') ;
        $maxCode=$maxCode + 1;
        if($maxCode<10)  $code="0".$maxCode;
        else if($maxCode>=10 and $maxCode<100)  $code=$maxCode;
        return view('positions_add', [ 'code'=>$code ]);
    }

    public function positions_added(Request $req)
    {
        $nb = DB::table('positions')->where('code', $req->input('code'))->count();

        if($nb==0) {
            $fait=date("Y/m/d H:i:s");
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            DB::table('positions')->insert(
            ['ref' => $id,
            'code' => $req->input('code'),
            'title' => $req->input('title'),
            'fait' => $fait  ] );
            session()->flash('yes',"The request has been added successfully"); 
        } else { session()->flash('no',"The code already exists");  }
        return back();
    }

    public function positions_deleted($ref)
    {
        DB::table('positions')->where('ref', $ref)->delete();
        session()->flash('yes',"The request has been deleted successfully"); 
        return back();
    }

    public function positions_edit($ref)
    {
        $positions = DB::table('positions')->where('ref', $ref)->get();
        return view('positions_edit', [ 'positions'=>$positions ]);
    }

    public function positions_edited(Request $req, $ref)
    {
        DB::table('positions')->where('ref', $ref)->update(
        ['code' => $req->input('code'),
        'title' => $req->input('title'),] );
        session()->flash('yes',"The request has been updated successfully"); 
        return back();
    }


}


