<?php $__env->startSection('content'); ?>

<style type="text/css">
.holder {
    background-color: #4c474c;
    background-image: -webkit-gradient(linear, left bottom, left top, from(#4c474c), to(#141414));
    background-image: -o-linear-gradient(bottom, #4c474c 0%, #141414 100%);
    background-image: linear-gradient(0deg, #4c474c 0%, #141414 100%);
    border-radius: 50px;
}
[data-role="controls"] > button {
    margin: 50px auto;
    outline: none;
    display: block;
    border: none;
    background-color: #D9AFD9;
    background-image: -webkit-gradient(linear, left bottom, left top, from(#D9AFD9), to(#97D9E1));
    background-image: -o-linear-gradient(bottom, #D9AFD9 0%, #97D9E1 100%);
    background-image: linear-gradient(0deg, #D9AFD9 0%, #97D9E1 100%);
    width: 100px;
    height: 100px;
    border-radius: 50%;
    text-indent: -1000em;
    cursor: pointer;
    -webkit-box-shadow: 0px 5px 5px 2px rgba(0,0,0,0.3) inset, 
        0px 0px 0px 30px #fff, 0px 0px 0px 35px #333;
            box-shadow: 0px 5px 5px 2px rgba(0,0,0,0.3) inset, 
        0px 0px 0px 30px #fff, 0px 0px 0px 35px #333;
}
[data-role="controls"] > button:hover {
    background-color: #ee7bee;
    background-image: -webkit-gradient(linear, left bottom, left top, from(#ee7bee), to(#6fe1f5));
    background-image: -o-linear-gradient(bottom, #ee7bee 0%, #6fe1f5 100%);
    background-image: linear-gradient(0deg, #ee7bee 0%, #6fe1f5 100%);
}
[data-role="controls"] > button[data-recording="true"] {
    background-color: #ff2038;
    background-image: -webkit-gradient(linear, left bottom, left top, from(#ff2038), to(#b30003));
    background-image: -o-linear-gradient(bottom, #ff2038 0%, #b30003 100%);
    background-image: linear-gradient(0deg, #ff2038 0%, #b30003 100%);
}
[data-role="recordings"] > .row {
    width: auto;
    height: auto;
    padding: 20px;
}
[data-role="recordings"] > .row > audio {
    outline: none;
}
[data-role="recordings"] > .row > a {
    display: inline-block;
    text-align: center;
    font-size: 20px;
    line-height: 50px;
    vertical-align: middle;
    width: 50px;
    height: 50px;
    border-radius: 20px;
    color: #fff;
    font-weight: bold;
    text-decoration: underline;
    background-color: #0093E9;
    background-image: -webkit-gradient(linear, left bottom, left top, from(#0093E9), to(#80D0C7));
    background-image: -o-linear-gradient(bottom, #0093E9 0%, #80D0C7 100%);
    background-image: linear-gradient(0deg, #0093E9 0%, #80D0C7 100%);
    float: right;
    margin-left: 20px;
    cursor: pointer;
}
[data-role="recordings"] > .row > a:hover {
    text-decoration: none;
}
[data-role="recordings"] > .row > a:active {
    background-image: -webkit-gradient(linear, left top, left bottom, from(#0093E9), to(#80D0C7));
    background-image: -o-linear-gradient(top, #0093E9 0%, #80D0C7 100%);
    background-image: linear-gradient(180deg, #0093E9 0%, #80D0C7 100%);
}
.mb-10 { margin-bottom: 20px; }
.text-muted { font-weight: bold; }
.ms-1  { font-weight: bold; }
.me-1  { font-weight: bold; }
</style>

<style type="text/css">
  #kt_drawer_chat .accordion-button:not(.collapsed) { color:black !important;  }
  #kt_drawer_chat .accordion span {  margin-left: 10px; color: rgba(0,0,0,0.6)  }
  #kt_drawer_chat audio { border-radius: 5px; }
  #kt_drawer_chat .blue1 { color: #1DA2A4 !important; }
  #kt_drawer_chat .gray1 { color: gray !important; }
  #kt_drawer_chat .fa-check { font-size: 10px; }

  red {
    color: red;
}

.client-content #controls {
  display: flex;
  margin-top: 2rem;
  max-width: 28em;
} 

.client-content #controls button {
  flex-grow: 1;
  height: 30px;
  min-width: 30px;
  border: none;
  border-radius: 0.15rem;
  background: #ed341d;
  margin-left: 2px;
  box-shadow: inset 0 -0.15rem 0 rgba(0, 0, 0, 0.2);
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  color:#ffffff;
  font-weight: bold;
  font-size: 1rem;
}

.client-content #controls button:hover, button:focus {
  outline: none;
  background: #c72d1c;
}

.client-content #controls button::-moz-focus-inner {
  border: 0;
}

.client-content #controls button:active {
  box-shadow: inset 0 1px 0 rgba(0, 0, 0, 0.2);

}

.client-content #controls button:disabled {
  pointer-events: none;
  background: lightgray;
}
.client-content #controls button:first-child {
  margin-left: 0;
}

.client-content audio {
  display: block;
  width: 100%;
  margin-top: 0.2rem;
}

.client-content li {
  list-style: none;
  margin-bottom: 1rem;
}

.client-content #formats {
  margin-top: 0.5rem;
  font-size: 80%;
}

.client-content #recordingsList{
    max-width: 28em;
}
</style>


<?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-comment"></i> Chat : <span class="ref"><?php echo e($cli->username); ?></span></li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            
          </div>
      </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-12">
  <?php if(session()->has('yes')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('yes')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('no')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('no')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">

  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('chatAdded',[ 'ref' => $cli->ref ])); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-12">
              <h6><label for="msg" class="control-label form-label label01">Send your message</label></h6>
              <input type="hidden" name="to" id="to" value="<?php echo e($cli->ref); ?>">
              <textarea name="msg" id="msg" class="form-control" rows="6" placeholder="Message"></textarea>
          </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-4">
          <button type="submit" class="btn btn-default"><i class="fa fa-send" style="padding-right: 10px"></i>Send</button>
        </div>
        <div class="col-md-8">
            <div id="controls" style="float:right;">
                <button type="button" id="recordButton"><i class="fa fa-microphone" id='record' style="font-size: 16px; color: white;"></i></button>
                <button type="button" id="pauseButton" disabled><i class="fa fa-pause" id='pause' style="font-size: 16px; color: white;"></i></button>
                <button type="button" id="stopButton" disabled><i class="fa fa-stop" id='stop' style="font-size: 16px; color: white;"></i></button>
            </div>
            <div id="formats"></div>
            <p><strong></strong></p>
            <ol id="recordingsList"></ol>
        </div>
      </div>
    </form>
  </div>

  <div class="panel panel-default client-content" style="padding:20px 30px 20px">
      <div data-kt-drawer-direction="end" data-kt-drawer-toggle="#kt_drawer_chat_toggle" data-kt-drawer-close="#kt_drawer_chat_close" style="overflow-y: scroll; padding-right: 20px; padding-left: 20px;">
        <div class="card w-100 rounded-0 border-0" id="kt_drawer_chat_messenger">
            <div class="card-body" id="kt_drawer_chat_messenger_body">
                <div class="scroll-y me-n5 pe-5" data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_drawer_chat_messenger_header, #kt_drawer_chat_messenger_footer" data-kt-scroll-wrappers="#kt_drawer_chat_messenger_body" data-kt-scroll-offset="0px" style="height: 688px;">
                    <?php $__currentLoopData = $chat_msg2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($m->to==$cli->ref): ?>
                            <?php if($m->msg_typ!='audio'): ?>
                            <div class="row">
                                <div class="col-md-8 alert alert-info" style="float:right">
                                    <div class="d-flex justify-content-end mb-10 ">
                                        <div class="d-flex flex-column align-items-end">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="me-3">
                                                    <span class="fs-5 fw-bolder text-gray-900 ms-1">Magnitude </span> 
                                                    <span class="text-muted fs-7 mb-1"><?php echo e(date('d.m.Y H:i:s', strtotime($m->fait))); ?>  </span>
                                                    <?php if($m->vu==1): ?> <i class="fa fa-check"></i><?php else: ?>  <i class="fa fa-clock-o"></i> <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="p-5 rounded bg-light-primary text-dark fw-bold mw-lg-400px text-end" data-kt-element="message-text"><?php echo e($m->msg); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="row">
                                <div class="col-md-8 alert alert-info" style="float:right">
                                    <div class="d-flex justify-content-end mb-10">
                                        <div class="d-flex flex-column align-items-end">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="me-3">
                                                    <span href="#" class="fs-5 fw-bolder text-gray-900 ms-1">Magnitude </span> 
                                                    <span class="text-muted fs-7 mb-1"><?php echo e(date('d.m.Y H:i:s', strtotime($m->fait))); ?></span>
                                                    <?php if($m->vu==1): ?> <i class="fa fa-check"></i><?php else: ?>  <i class="fa fa-clock-o"></i> <?php endif; ?>
                                                </div>
                                            </div>
                                            <audio controls="" src="<?php echo e(url('media/audio/')); ?>/<?php echo e($m->audio); ?>"></audio>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php elseif($m->via==$cli->ref): ?>
                            <?php if($m->msg_typ!='audio'): ?>
                            <div class="row">
                                <div class="col-md-8 alert alert-warning">
                                    <div class="d-flex justify-content-start mb-10">
                                        <div class="d-flex flex-column align-items-start">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="ms-3">
                                                    <a href="#" class="fs-5 fw-bolder text-gray-900 ms-1"><?php echo e($m->nom); ?></a>
                                                    <span class="text-muted fs-7 mb-1"><?php echo e(date('d.m.Y H:i:s', strtotime($m->fait))); ?></span>
                                                </div>
                                            </div>
                                            <div class="p-5 rounded bg-light-info text-dark fw-bold mw-lg-400px text-start" data-kt-element="message-text"><?php echo e($m->msg); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="row">
                                <div class="col-md-8 alert alert-warning">
                                    <div class="d-flex justify-content-end mb-10">
                                        <div class="d-flex flex-column align-items-end">
                                            <div class="d-flex align-items-center mb-2">
                                                <div class="me-3">
                                                    <span href="#" class="fs-5 fw-bolder text-gray-900 ms-1"><?php echo e($m->nom); ?></span>
                                                    <span class="text-muted fs-7 mb-1"><?php echo e(date('d.m.Y H:i:s', strtotime($m->fait))); ?></span>
                                                </div>
                                            </div>
                                            <audio controls="" src="<?php echo e(url('media/audio/')); ?>/<?php echo e($m->audio); ?>"></audio>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('audio/recorder.js')); ?>"></script>
<script type="text/javascript">
URL = window.URL || window.webkitURL;

var gumStream; var rec; var input;                          

var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext 

var recordButton = document.getElementById("recordButton");
var stopButton = document.getElementById("stopButton");
var pauseButton = document.getElementById("pauseButton");

recordButton.addEventListener("click", startRecording);
stopButton.addEventListener("click", stopRecording);
pauseButton.addEventListener("click", pauseRecording);

function startRecording() {
    console.log("recordButton clicked");
    var constraints = { audio: true, video:false }
    recordButton.disabled = true;
    stopButton.disabled = false;
    pauseButton.disabled = false
    navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
        console.log("getUserMedia() success, stream created, initializing Recorder.js ...");
        audioContext = new AudioContext();
        gumStream = stream;
        input = audioContext.createMediaStreamSource(stream);
        rec = new Recorder(input,{numChannels:1})
        rec.record()
        console.log("Recording started");
    }).catch(function(err) {
        recordButton.disabled = false;
        stopButton.disabled = true;
        pauseButton.disabled = true
    });
}

function pauseRecording(){
    console.log("pauseButton clicked rec.recording=",rec.recording );
    if (rec.recording){
        rec.stop();
        pauseButton.innerHTML='<i class="fa fa-pause" id="play" style="font-size: 16px; color: white;"></i>';
    }else{
        rec.record()
        pauseButton.innerHTML='<i class="fa fa-pause" id="pause" style="font-size: 16px; color: white;"></i>';
    }
}

function stopRecording() {
    console.log("stopButton clicked");
    stopButton.disabled = true;
    recordButton.disabled = false;
    pauseButton.disabled = true;
    pauseButton.innerHTML='<i class="fa fa-pause" id="pause" style="font-size: 16px; color: white;"></i>';
    rec.stop();
    gumStream.getAudioTracks()[0].stop();
    rec.exportWAV(createDownloadLink);
}

function shuffle(string) {
    var parts = string.split('');
    for (var i = parts.length; i > 0;) {
        var random = parseInt(Math.random() * i);
        var temp = parts[--i];
        parts[i] = parts[random];
        parts[random] = temp;
    }
    return parts.join('');
}

function createDownloadLink(blob) {
    var url = URL.createObjectURL(blob);
    var au = document.createElement('audio');
    var li = document.createElement('li');
    var link = document.createElement('a');
    var filename = shuffle('1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890');
    au.controls = true;
    au.src = url;
    link.href = url;
    link.download = filename+".wav"; 
    filenameOk = filename+".wav"; 
      var xhr=new XMLHttpRequest();
      xhr.onload=function(e) {
          if(this.readyState === 4) {
              console.log("Server returned: ",e.target.responseText);
          }
      }; 
      var fd=new FormData();
      fd.append("audio_data",blob, filename);
      xhr.open("POST","../save_audio.php",true);
      xhr.send(fd);
      var to = $("#to").val();
      $.ajax({
        url: '../chatAudioAdmin/'+filenameOk+"/"+to,
        type: 'get',
        dataType: 'json',
        success: function(response){
            window.setTimeout(function(){ window.location.href = "https://villa.magnitudeconstruction.com/clientChat/"+to; }, 1000); 
        }
      });
}

document.querySelector('#last').scrollIntoView() ;
</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientChat.blade.php ENDPATH**/ ?>