<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">Des Nounous d’expérience et/ou diplômées   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">Du personnel fiable, de confiance et contrôlé par <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b></h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">
                            Vous avez besoin d’un service <b>de garde d’enfant à temps complet</b> ou <b>à temps partiel</b>?
                            <br/><br/>
                            Vous avez repris votre activité professionnelle ou vous êtes <b>en télétravail</b>? 
                            <br/><br/>
                            Vous êtes à la recherche d’une <b>nourrice compétente</b> pour garder votre enfant ?
                            <br/><br/>
                            Ne laissez pas vos enfants à <b>des personnes sans garanties</b>. <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous propose un <b>service de garde d’enfant à domicile à temps complet ou partiel</b>, assuré par des <b>nounous spécialistes de l’enfance</b>. Une garde complète et active.
                            <br/><br/>  
                            La préoccupation principale des <b>nourrices</b> <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> est <b>la sécurité</b> et <b>le bien-être</b> des enfants. 
                            <br/>
                            Elles participent activement au développement et à l’éveil de votre enfant tout en respectant <b>vos exigences</b>.
                            <br/><br/>
                            Les <b>Nannys</b> <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b>, sont de <b>vraies spécialistes</b> au service <b>des petits et des tout petits</b> : biberon, toilette, changes, préparation du dîner, jeux, lecture d’histoires ou même sorties au parc.
                            <br/><br/>
                            Nous avons également des <b>Baby Sitters spécialisées dans la petite enfance</b> mais aussi des <b>éducateurs (trices)</b> spécialisés pour les enfants <b>ayant un handicap.</b>
                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/nounous.png')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT</span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Avec <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> junior, vos enfants sont entre de bonnes mains.<br/>
                            Notre prestation vous garantit <b>la sécurité</b> et la garde de vos enfants dans <b>des conditions optimales</b>.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <b>Nos collaborateurs :</b>
                            <ul>
                              <li>• Font des jeux d’éveil avec l’enfant. </li>
                              <li>• Accompagnent aux activités extra-scolaires et rendez-vous médicaux</li>
                              <li>• Aident aux devoirs et soutien scolaire</li>
                              <li>• Effectuent la préparation de repas équilibrés</li>
                              <li>• Donnent des soins courants et coucher de l’'enfant</li>
                              <li>• Gèrent le linge de l'enfant</li>
                              <li> • Enseignent d'une langue (anglais, espagnol, Italien...)</li>
                              <li>• Déposent et récupèrent votre enfant de l'école</li>
                              <li>• Tiennent un cahier journalier pour vous tenir informé.</li>
                            </ul>
                            <br/><br/>
                            Contactez nos <b><span style="color:#EC008C;">Hel</span><span style="color:#00AEEF ">pers</span></b>, ils se feront un plaisir de vous dégoter <b>VOTRE</b> personne idéale.
                            </div>
                          </div>

                          

                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE NOUNOU DIPLÔMÉE ET/OU EXPÉRIMENTÉE</button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/nounous.blade.php ENDPATH**/ ?>