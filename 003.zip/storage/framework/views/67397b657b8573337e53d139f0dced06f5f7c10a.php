

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section>
    <div class="container">
        <h4 class="my-title"></h4>
        <div class="row" style="margin-top: 30px">
            <div class="col-md-4">
                <div class="thumbnail">
                    <a href=""><img src="<?php echo e(url('pro')); ?>/<?php echo e($prod->img); ?>" width="100%"></a>
                </div>

		        <div class="row" style="margin-top: 10px">
		        	<?php $__currentLoopData = $prodImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <div class="col-md-6">
		                <div class="thumbnail">
			                <a href="<?php echo e(url('pro-img')); ?>/<?php echo e($img->img); ?>" class="highslide" onclick="return hs.expand(this)">
			                	<img src="<?php echo e(url('pro-img')); ?>/<?php echo e($img->img); ?>" width="100%">
			                </a>
		               	</div>
		            </div>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </div>

            </div>
            <div class="col-md-1">
            	
            </div>
            <div class="col-md-7">
            	<h3 style="font-family: 'Changa'; font-weight: bold; margin-top: 0; font-size: 28px; margin-bottom: 30px"><?php echo e($prod->des); ?></h3>

            	

            	<table width="100%" class="table table-striped">
            		<tr>
            			<td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">1 Pack</h4></td>
            			<td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri1, 2)); ?> MAD</h4></td>
            			<td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; ">باقة واحدة</h4></td>
            		</tr>
            		<?php if($prod->pri2!=0): ?>
            		<tr>
            			<td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">2 Packs</h4></td>
            			<td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri2, 2)); ?> MAD</h4></td>
            			<td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">باقتين</h4></td>
            		</tr>
            		<?php endif; ?>
            		<?php if($prod->pri3!=0): ?>
            		<tr>
            			<td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">3 Packs</h4></td>
            			<td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri3, 2)); ?> MAD</h4></td>
            			<td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">ثلاث باقات</h4></td>
            		</tr>
            		<?php endif; ?>
            		<?php if($prod->pri4!=0): ?>
            		<tr>
            			<td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">4 Packs</h4></td>
            			<td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri4, 2)); ?> MAD</h4></td>
            			<td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">أربع باقات</h4></td>
            		</tr>
            		<?php endif; ?>
            		<?php if($prod->pri5!=0): ?>
            		<tr>
            			<td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">5 Packs</h4></td>
            			<td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri5, 2)); ?> MAD</h4></td>
            			<td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">خمس باقات</h4></td>
            		</tr>
            		<?php endif; ?>
            	</table>

            	<hr/>

            	<h6 style="font-family: 'Changa'; font-weight: bold; font-size: 26px; color: black; margin-bottom: 30px; ">للطلب المرجو ملئ الإستمارة التالية</h6>

            	<form method="POST" class="form1 mystore-form" action="<?php echo e(route('mystoreCmdAdd',[ 'mystore' => $u->store, 'ref' => $prod->ref ])); ?>">
      			<?php echo e(csrf_field()); ?>

            		<input type="hidden" name="proref" value="<?php echo e($prod->ref); ?>">
            		<input type="hidden" name="pro" value="<?php echo e($prod->des); ?>">

					<input type="hidden" name="ref" value="43350933">
				  	<div class="form-group">
				    	<input type="text" class="form-control" name="nom" placeholder="Nom : الاسم الكامل">
				  	</div>
				  	<div class="form-group">
				    	<input data-inputmask="'mask': '9999999999'" type="text" class="form-control" name="tel" placeholder="Téléphone : رقم الهاتف">
				  	</div>
				  	<div class="form-group">
                        <select class="form-control" name="vil">
                            <option>Ville : المدينة</option>
                            <option>Agadir</option>
                            <option>Aguelmouss</option>
                            <option>Ahfir</option>
                            <option>ain aouda</option>
                            <option>Ain Attig</option>
                            <option>Ait meloul</option>
                            <option>Al Hoceima</option>
                            <option>Anza</option>
                            <option>Aourir</option>
                            <option>Arfoud</option>
                            <option>Assilah</option>
                            <option>Azemmour</option>
                            <option>Azilal</option>
                            <option>Azrou</option>
                            <option>Azrou agadir</option>
                            <option>Ben Ahmed</option>
                            <option>Ben guerir</option>
                            <option>Benguerir base militaire</option>
                            <option>Beni Mellal</option>
                            <option>Benslimane</option>
                            <option>Berkane</option>
                            <option>Berrchid</option>
                            <option>Biougra</option>
                            <option>Boufakrane</option>
                            <option>Boujad</option>
                            <option>Boujdour</option>
                            <option>Boumalne Dadès</option>
                            <option>Bouskoura</option>
                            <option>Bouznika</option>
                            <option>Casablanca</option>
                            <option>Chefchaouen</option>
                            <option>Dakhla</option>
                            <option>Dar bouaza</option>
                            <option>Demnate</option>
                            <option>Deroua oulad ziane</option>
                            <option>El Attaouia</option>
                            <option>El Gara</option>
                            <option>El Hajeb</option>
                            <option>El jadida</option>
                            <option>El kelaa des sraghna</option>
                            <option>Errachidia</option>
                            <option>Errahma</option>
                            <option>Essaouira</option>
                            <option>Essmara</option>
                            <option>Fes</option>
                            <option>Fnideq</option>
                            <option>Fquih ben salah</option>
                            <option>Guelmim</option>
                            <option>Guercif</option>
                            <option>Had Soualem</option>
                            <option>ifran</option>
                            <option>Inzegane</option>
                            <option>Jamaat shaim</option>
                            <option>Kasba tadla</option>
                            <option>Kasbat lmzar</option>
                            <option>Kelaat M'Gouna</option>
                            <option>Kenitra</option>
                            <option>Khemis des zemamra</option>
                            <option>Khemisset</option>
                            <option>khenifra</option>
                            <option>Khouribga</option>
                            <option>Ksar El Kebir</option>
                            <option>Laayayda</option>
                            <option>Laayoune</option>
                            <option>Larache</option>
                            <option>M diq</option>
                            <option>Marrakech</option>
                            <option>Martil</option>
                            <option>Mediouna</option>
                            <option>Meknes</option>
                            <option>Merzouga</option>
                            <option>Midelt</option>
                            <option>Mohammedia</option>
                            <option>Moulay Abellah Amghar</option>
                            <option>Mrirt</option>
                            <option>Nador</option>
                            <option>Nouaceur</option>
                            <option>Ouarzazat</option>
                            <option>ouazzane</option>
                            <option>Oued zem</option>
                            <option>Oujda</option>
                            <option>Oulad teima</option>
                            <option>Oulad Yaich</option>
                            <option>Quliaa</option>
                            <option>Rabat</option>
                            <option>Rissani</option>
                            <option>safi</option>
                            <option>Saidia</option>
                            <option>Sale</option>
                            <option>Sale el jadida</option>
                            <option>Sebt el guerdane</option>
                            <option>Sebt Ouled Nemma</option>
                            <option>Sefrou</option>
                            <option>Settat</option>
                            <option>Sidi bennour</option>
                            <option>Sidi Bibi</option>
                            <option>Sidi Bouknadel</option>
                            <option>Sidi bouzid</option>
                            <option>Sidi Hajjaj</option>
                            <option>Sidi Ifni</option>
                            <option>Sidi kacem</option>
                            <option>Sidi sliman</option>
                            <option>Skhirat</option>
                            <option>Sidi Yahya du Rharb</option>
                            <option>Skhirat</option>
                            <option>Souk el arbaa du gharb</option>
                            <option>Taddart</option>
                            <option>Tagadirt</option>
                            <option>Tamait Izder</option>
                            <option>Tamansourt</option>
                            <option>Tamelelt</option>
                            <option>Tamesna</option>
                            <option>Tamraght</option>
                            <option>Tan Tan</option>
                            <option>Tanant</option>
                            <option>Tanger</option>
                            <option>Taounate</option>
                            <option>Taourirt</option>
                            <option>Tar</option>
                            <option>Tarfaaya</option>
                            <option>Taroudannt</option>
                            <option>Taza</option>
                            <option>Temara</option>
                            <option>Tetouan</option>
                            <option>Tiflet</option>
                            <option>Tinghir</option>
                            <option>Tit mellil</option>
                            <option>Tiznit</option>
                            <option>Youssoufia</option>
                            <option>Zagora</option>
                        </select>
				  	</div>
				  	<div class="form-group">
				    	<input type="text" class="form-control" name="adr" placeholder="Adresse : العنوان">
				  	</div>
				  	<div class="form-group">
				    	<select class="form-control" name="qte">
				    		<option value="1">1</option>
							<?php if($prod->pri2!=0): ?><option value="2">2</option><?php endif; ?>
							<?php if($prod->pri3!=0): ?><option value="3">3</option><?php endif; ?>
							<?php if($prod->pri4!=0): ?><option value="4">4</option><?php endif; ?>
							<?php if($prod->pri5!=0): ?><option value="5">5</option><?php endif; ?>
				 		</select>
				  	</div>
				  	<button type="submit" class="btn btn-success mystore-commander" style="background: <?php echo e($u->color3); ?>; border-color: <?php echo e($u->color3); ?>">اطلب الآن و التوصيل بالمجـــان</button>
				</form>

            </div>

            <div class="col-md-12">
            	
            </div>

            <div class="col-md-12">
            	
            </div>
        </div>
    </div>

    
    <div class="container">
        <h4 class="my-title"></h4>
        <div class="row" style="margin-top: 30px">
            <div class="col-md-12">
                <div class="thumbnail" style="padding: 30px 30px">
	                <?php echo $prod->dcr; ?>

               	</div>
            </div>
        </div>
    </div>

    <section style="margin-top: 30px">
        <div class="container">
            <h4 class="my-title">Produits Similaires</h4>
            <div class="row" style="margin-top: 30px">
                <?php $__currentLoopData = $prods_sim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-5 col-md-3">
                    <div class="thumbnail">
                        <a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>"><img src="<?php echo e(url('pro')); ?>/<?php echo e($prod->img); ?>" width="100%"></a>
                        <div class="caption">
                            <h3 class="my-product"><?php echo e($prod->des); ?></h3>
                            <p class="my-price" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri1, 2)); ?></p>
                            <p><a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>" class="btn btn-default my-view" role="button" style="background: <?php echo e($u->color2); ?>">Voir le produit</a>
                            <a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>" class="btn btn-primary my-cmd" role="button" style="background: <?php echo e($u->color3); ?>">Commander</a></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>



</section>

<script type="text/javascript" src="<?php echo e(url('bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js'></script><script  src="./script.js"></script>
<script type="text/javascript">
    $(":input").inputmask();
    $("#telephone").inputmask({"mask": "0000000000"});

    $('#store').keypress(function (e) {
       var regex = new RegExp("^[a-zA-Z0-9]+$");
       var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
       if (regex.test(str)) {
           return true;
       }
       e.preventDefault();
       return false;
});

</script>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.mystore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/mystoreProduit.blade.php ENDPATH**/ ?>