

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-spinner"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('progress')); ?>" class="btn-right "><i class="fa fa-list"></i> List of Worksites Progress </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('progressEdited',[ 'ref' => $item->ref ])); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="landname" class="control-label form-label label01">LandName  </label></h6>
              <input type="text" name="landname" id="landname" class="form-control" disabled style="font-weight: bold" value="<?php echo e($item->landname); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="dp" class="control-label form-label label01">DP Client </label></h6>
              <input type="text" name="dp" id="dp" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="costomer" class="control-label form-label label01">Name Costomer  </label></h6>
              <input type="text" name="costomer" id="costomer" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="respcomm" class="control-label form-label label01">Responsable Commercial  </label></h6>
              <select name="respcomm" id="respcomm" class="form-control">
                <option>value="<?php echo e($item->respcomm); ?>"</option>
                <option>Paul </option>
                <option>Thibaud</option>
                <option>Magali</option>
                <option>Nicolas</option>
                <option>Yann</option>
                <option>Marie</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="respwork" class="control-label form-label label01">Responsable WorkSite  </label></h6>
              <select name="respwork" id="respwork" class="form-control">
                <option>value="<?php echo e($item->respwork); ?>"</option>
                <option>Eloy</option>
                <option>Yannick </option>
                <option>Tom</option>
                <option>Edy</option>
               <option> Vivi</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="namesubkon" class="control-label form-label label01">Name Subkon  </label></h6>
              <select name="namesubkon" id="namesubkon" class="form-control">
                <option>value="<?php echo e($item->namesubkon); ?>"</option>
                <option>En cours</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="dpsubkon" class="control-label form-label label01">DP Subkon </label></h6>
              <input type="date" name="dpsubkon" id="dpsubkon" class="form-control" value="<?php echo e($item->dpsubkon); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="remarque" class="control-label form-label label01">Remarque  </label></h6>
              <input type="text" name="remarque" id="remarque" class="form-control" value="<?php echo e($item->remarque); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-2">
              <h6><label for="dp11" class="control-label form-label label01">DP 1.1  </label></h6>
              <label class="switch" for="dp11" >
                <input type="checkbox"  name="dp11" id="dp11" <?php if($item->dp11=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp21" class="control-label form-label label01">DP 1.2 </label></h6>
              <label class="switch" for="dp21" >
                <input type="checkbox"  name="dp21" id="dp21" <?php if($item->dp21=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp31" class="control-label form-label label01">DP 2.1 </label></h6>
              <label class="switch" for="dp31" >
                <input type="checkbox"  name="dp31" id="dp31" <?php if($item->dp31=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp32" class="control-label form-label label01">DP 3.1 </label></h6>
              <label class="switch" for="dp32" >
                <input type="checkbox"  name="dp32" id="dp32" <?php if($item->dp32=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp32" class="control-label form-label label01">DP 3.2  </label></h6>
              <label class="switch" for="final" >
                <input type="checkbox"  name="dp32" id="dp32" <?php if($item->dp32=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
        </div>

        <div class="row">
          <div class="col-md-2">
              <h6><label for="dp4" class="control-label form-label label01">DP 4  </label></h6>
              <label class="switch" for="dp4" >
                <input type="checkbox"  name="dp4" id="dp4" <?php if($item->dp4=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp45" class="control-label form-label label01">DP 4.5 </label></h6>
              <label class="switch" for="dp45" >
                <input type="checkbox"  name="dp45" id="dp45" <?php if($item->dp45=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp5" class="control-label form-label label01">DP 5 </label></h6>
              <label class="switch" for="dp5" >
                <input type="checkbox"  name="dp5" id="dp5" <?php if($item->dp5=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp51" class="control-label form-label label01">DP 5.1 </label></h6>
              <label class="switch" for="dp51" >
                <input type="checkbox"  name="dp51" id="dp51" <?php if($item->dp51=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp6" class="control-label form-label label01">DP 6  </label></h6>
              <label class="switch" for="dp6" >
                <input type="checkbox"  name="dp6" id="dp6" <?php if($item->dp6=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12">
              <h6><label for="dateend" class="control-label form-label label01">Date End  </label></h6>
              <input type="date" name="dateend" id="dateend" class="form-control" value="<?php echo e($item->dateend); ?>" />
          </div>
        </div>

        <div class="row">
          <div class="col-md-4">
              <h6><label for="cuisine" class="control-label form-label label01">Cuisine </label></h6>
              <label class="switch" for="cuisine" >
                <input type="checkbox"  name="cuisine" id="cuisine" <?php if($item->cuisine=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-4">
              <h6><label for="mat" class="control-label form-label label01">Furniture </label></h6>
              <label class="switch" for="mat" >
                <input type="checkbox"  name="mat" id="mat" <?php if($item->mat=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-4">
              <h6><label for="fur" class="control-label form-label label01">Meeting deco  </label></h6>
              <label class="switch" for="fur" >
                <input type="checkbox"  name="fur" id="fur" <?php if($item->fur=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
        </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/progressEdit.blade.php ENDPATH**/ ?>