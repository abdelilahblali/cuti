<?php $__env->startSection('content'); ?>

<style type="text/css">
  .c3_color { color: red !important; }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">PTPMA</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <?php echo $__env->make('master.aide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>

    <?php if(session()->has('no')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('no')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
 


<!-- Contrat #2 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('ptpma.a2')); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('ptpma.a1')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                <?php echo __('ptpma.a3'); ?>

              </p>
            </div>
          </div>

          <!-- <?php $__currentLoopData = $construction2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('ptpma.a4')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->

          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/pdf/PTPMA_BANQUE.pdf"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('ptpma.a4')); ?></button></a>
              </div>
            </div>
          </div>

         
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Name Villa & Name PTPMA ################## -->
<div id="Villa_PTPMA" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <?php if($confirmed!='on'): ?>
            <div class="row">
              <h3 class="card-title align-items-start flex-column" style="width: 100%">
                <span class="card-label fw-bolder text-dark"><?php echo e(__('ptpma.a5')); ?></span>
              </h3>
            </div>
            <?php endif; ?>
            <div class="card-toolbar" style="width: 100%">
              <form method="POST" action="<?php echo e(route('nameVillaPtpma')); ?>" enctype="multipart/form-data" style="width: 100%">
                <?php echo e(csrf_field()); ?>

                <div class="row" style="width: 100%; padding-bottom: 10px">
                    <div class="col-md-12">
                        <h6><label for="nom_villa" class="control-label form-label label01"><?php echo e(__('ptpma.a6')); ?> </label></h6>
                        <input type="text" name="nom_villa" id="nom_villa" class="form-control" value="<?php echo e($nom_villa); ?>" <?php if($confirmed=='on'): ?> disabled <?php endif; ?>/>
                    </div>

                    <div class="col-md-12" style="margin-top:10px">
                        <h6><label for="nom_ptpma" class="control-label form-label label01"><?php echo e(__('ptpma.a7')); ?> :  <i style="font-size:12px; font-weight:bold; color: red;">Au minimum de 3 (trois) mots et chaque mot se compose au minimum de 3 (trois) lettres</i></label></h6>
                        <input type="text" name="nom_ptpma" id="nom_ptpma" class="form-control" placeholder="PT. XXX YYY ZZZ (i.e. PT. BALI REAL ESTATE)"  value="<?php if($nom_ptpma!=''): ?> <?php echo e($nom_ptpma); ?> <?php else: ?> <?php echo 'PT. '; ?> <?php endif; ?>" <?php if($confirmed=='on'): ?> disabled <?php endif; ?> />
                    </div>
                </div>
                <?php if($confirmed!='on'): ?>
                <div class="row" style="margin-top: 20px; margin-bottom: 20px">
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i><?php echo e(__('ptpma.a8')); ?></button>
                  </div>
                </div>
                <?php endif; ?>
              </form>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Passport################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('ptpma.a9')); ?></span>
            </h3>
            <div class="card-toolbar">
              <form method="POST" action="<?php echo e(route('passportAdded')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-2">
                      <h6><label for="civ" class="control-label form-label label01"><?php echo e(__('ptpma.a10')); ?> <span class="c3_color">*</span></label></h6>
                      <select name="civ" id="civ" class="form-control form-select" required>
                        <option></option>
                        <option value="M.">M.</option>
                        <option value="Mme">Mme</option>
                        <option value="">Entreprise</option>
                      </select>
                    </div>
                    <div class="col-md-2">
                        <h6><label for="nationality" class="control-label form-label label01"><?php echo e(__('ptpma.a11')); ?> </label></h6>
                        <select name="nationality" name="nationality" class="form-control form-select" required>
                          <option></option>
                          <option value="french">French</option>
                          <option value="afghan">Afghan</option>
                          <option value="albanian">Albanian</option>
                          <option value="algerian">Algerian</option>
                          <option value="american">American</option>
                          <option value="andorran">Andorran</option>
                          <option value="angolan">Angolan</option>
                          <option value="antiguans">Antiguans</option>
                          <option value="argentinean">Argentinean</option>
                          <option value="armenian">Armenian</option>
                          <option value="australian">Australian</option>
                          <option value="austrian">Austrian</option>
                          <option value="azerbaijani">Azerbaijani</option>
                          <option value="bahamian">Bahamian</option>
                          <option value="bahraini">Bahraini</option>
                          <option value="bangladeshi">Bangladeshi</option>
                          <option value="barbadian">Barbadian</option>
                          <option value="barbudans">Barbudans</option>
                          <option value="batswana">Batswana</option>
                          <option value="belarusian">Belarusian</option>
                          <option value="belgian">Belgian</option>
                          <option value="belizean">Belizean</option>
                          <option value="beninese">Beninese</option>
                          <option value="bhutanese">Bhutanese</option>
                          <option value="bolivian">Bolivian</option>
                          <option value="bosnian">Bosnian</option>
                          <option value="brazilian">Brazilian</option>
                          <option value="british">British</option>
                          <option value="bruneian">Bruneian</option>
                          <option value="bulgarian">Bulgarian</option>
                          <option value="burkinabe">Burkinabe</option>
                          <option value="burmese">Burmese</option>
                          <option value="burundian">Burundian</option>
                          <option value="cambodian">Cambodian</option>
                          <option value="cameroonian">Cameroonian</option>
                          <option value="canadian">Canadian</option>
                          <option value="cape verdean">Cape Verdean</option>
                          <option value="central african">Central African</option>
                          <option value="chadian">Chadian</option>
                          <option value="chilean">Chilean</option>
                          <option value="chinese">Chinese</option>
                          <option value="colombian">Colombian</option>
                          <option value="comoran">Comoran</option>
                          <option value="congolese">Congolese</option>
                          <option value="costa rican">Costa Rican</option>
                          <option value="croatian">Croatian</option>
                          <option value="cuban">Cuban</option>
                          <option value="cypriot">Cypriot</option>
                          <option value="czech">Czech</option>
                          <option value="danish">Danish</option>
                          <option value="djibouti">Djibouti</option>
                          <option value="dominican">Dominican</option>
                          <option value="dutch">Dutch</option>
                          <option value="east timorese">East Timorese</option>
                          <option value="ecuadorean">Ecuadorean</option>
                          <option value="egyptian">Egyptian</option>
                          <option value="emirian">Emirian</option>
                          <option value="equatorial guinean">Equatorial Guinean</option>
                          <option value="eritrean">Eritrean</option>
                          <option value="estonian">Estonian</option>
                          <option value="ethiopian">Ethiopian</option>
                          <option value="fijian">Fijian</option>
                          <option value="filipino">Filipino</option>
                          <option value="finnish">Finnish</option>
                          <option value="french">French</option>
                          <option value="gabonese">Gabonese</option>
                          <option value="gambian">Gambian</option>
                          <option value="georgian">Georgian</option>
                          <option value="german">German</option>
                          <option value="ghanaian">Ghanaian</option>
                          <option value="greek">Greek</option>
                          <option value="grenadian">Grenadian</option>
                          <option value="guatemalan">Guatemalan</option>
                          <option value="guinea-bissauan">Guinea-Bissauan</option>
                          <option value="guinean">Guinean</option>
                          <option value="guyanese">Guyanese</option>
                          <option value="haitian">Haitian</option>
                          <option value="herzegovinian">Herzegovinian</option>
                          <option value="honduran">Honduran</option>
                          <option value="hungarian">Hungarian</option>
                          <option value="icelander">Icelander</option>
                          <option value="indian">Indian</option>
                          <option value="indonesian">Indonesian</option>
                          <option value="iranian">Iranian</option>
                          <option value="iraqi">Iraqi</option>
                          <option value="irish">Irish</option>
                          <option value="israeli">Israeli</option>
                          <option value="italian">Italian</option>
                          <option value="ivorian">Ivorian</option>
                          <option value="jamaican">Jamaican</option>
                          <option value="japanese">Japanese</option>
                          <option value="jordanian">Jordanian</option>
                          <option value="kazakhstani">Kazakhstani</option>
                          <option value="kenyan">Kenyan</option>
                          <option value="kittian and nevisian">Kittian and Nevisian</option>
                          <option value="kuwaiti">Kuwaiti</option>
                          <option value="kyrgyz">Kyrgyz</option>
                          <option value="laotian">Laotian</option>
                          <option value="latvian">Latvian</option>
                          <option value="lebanese">Lebanese</option>
                          <option value="liberian">Liberian</option>
                          <option value="libyan">Libyan</option>
                          <option value="liechtensteiner">Liechtensteiner</option>
                          <option value="lithuanian">Lithuanian</option>
                          <option value="luxembourger">Luxembourger</option>
                          <option value="macedonian">Macedonian</option>
                          <option value="malagasy">Malagasy</option>
                          <option value="malawian">Malawian</option>
                          <option value="malaysian">Malaysian</option>
                          <option value="maldivan">Maldivan</option>
                          <option value="malian">Malian</option>
                          <option value="maltese">Maltese</option>
                          <option value="marshallese">Marshallese</option>
                          <option value="mauritanian">Mauritanian</option>
                          <option value="mauritian">Mauritian</option>
                          <option value="mexican">Mexican</option>
                          <option value="micronesian">Micronesian</option>
                          <option value="moldovan">Moldovan</option>
                          <option value="monacan">Monacan</option>
                          <option value="mongolian">Mongolian</option>
                          <option value="moroccan">Moroccan</option>
                          <option value="mosotho">Mosotho</option>
                          <option value="motswana">Motswana</option>
                          <option value="mozambican">Mozambican</option>
                          <option value="namibian">Namibian</option>
                          <option value="nauruan">Nauruan</option>
                          <option value="nepalese">Nepalese</option>
                          <option value="new zealander">New Zealander</option>
                          <option value="ni-vanuatu">Ni-Vanuatu</option>
                          <option value="nicaraguan">Nicaraguan</option>
                          <option value="nigerien">Nigerien</option>
                          <option value="north korean">North Korean</option>
                          <option value="northern irish">Northern Irish</option>
                          <option value="norwegian">Norwegian</option>
                          <option value="omani">Omani</option>
                          <option value="pakistani">Pakistani</option>
                          <option value="palauan">Palauan</option>
                          <option value="panamanian">Panamanian</option>
                          <option value="papua new guinean">Papua New Guinean</option>
                          <option value="paraguayan">Paraguayan</option>
                          <option value="peruvian">Peruvian</option>
                          <option value="polish">Polish</option>
                          <option value="portuguese">Portuguese</option>
                          <option value="qatari">Qatari</option>
                          <option value="romanian">Romanian</option>
                          <option value="russian">Russian</option>
                          <option value="rwandan">Rwandan</option>
                          <option value="saint lucian">Saint Lucian</option>
                          <option value="salvadoran">Salvadoran</option>
                          <option value="samoan">Samoan</option>
                          <option value="san marinese">San Marinese</option>
                          <option value="sao tomean">Sao Tomean</option>
                          <option value="saudi">Saudi</option>
                          <option value="scottish">Scottish</option>
                          <option value="senegalese">Senegalese</option>
                          <option value="serbian">Serbian</option>
                          <option value="seychellois">Seychellois</option>
                          <option value="sierra leonean">Sierra Leonean</option>
                          <option value="singaporean">Singaporean</option>
                          <option value="slovakian">Slovakian</option>
                          <option value="slovenian">Slovenian</option>
                          <option value="solomon islander">Solomon Islander</option>
                          <option value="somali">Somali</option>
                          <option value="south african">South African</option>
                          <option value="south korean">South Korean</option>
                          <option value="spanish">Spanish</option>
                          <option value="sri lankan">Sri Lankan</option>
                          <option value="sudanese">Sudanese</option>
                          <option value="surinamer">Surinamer</option>
                          <option value="swazi">Swazi</option>
                          <option value="swedish">Swedish</option>
                          <option value="swiss">Swiss</option>
                          <option value="syrian">Syrian</option>
                          <option value="taiwanese">Taiwanese</option>
                          <option value="tajik">Tajik</option>
                          <option value="tanzanian">Tanzanian</option>
                          <option value="thai">Thai</option>
                          <option value="togolese">Togolese</option>
                          <option value="tongan">Tongan</option>
                          <option value="trinidadian or tobagonian">Trinidadian or Tobagonian</option>
                          <option value="tunisian">Tunisian</option>
                          <option value="turkish">Turkish</option>
                          <option value="tuvaluan">Tuvaluan</option>
                          <option value="ugandan">Ugandan</option>
                          <option value="ukrainian">Ukrainian</option>
                          <option value="uruguayan">Uruguayan</option>
                          <option value="uzbekistani">Uzbekistani</option>
                          <option value="venezuelan">Venezuelan</option>
                          <option value="vietnamese">Vietnamese</option>
                          <option value="welsh">Welsh</option>
                          <option value="yemenite">Yemenite</option>
                          <option value="zambian">Zambian</option>
                          <option value="zimbabwean">Zimbabwean</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <h6><label for="nom" class="control-label form-label label01"><?php echo e(__('ptpma.a12')); ?> <span class="c3_color">*</span></label></h6>
                        <input type="text" name="nom" id="nom" class="form-control" required />
                    </div>

                    <div class="col-md-5">
                        <h6><label for="pre" class="control-label form-label label01"><?php echo e(__('ptpma.a13')); ?> <span style="font-size:11px; color:black"><?php echo e(__('ptpma.a14')); ?> </span><span class="c3_color">*</span></label></h6>
                        <input type="text" name="pre" id="pre" class="form-control" required />
                    </div>
                </div>
                
                <div class="row" style="margin-top: 15px">
                    <div class="col-md-3">
                        <h6><label for="mail" class="control-label form-label label01"><?php echo e(__('ptpma.a15')); ?> </label></h6>
                        <input type="email" name="mail" id="mail" class="form-control" />
                    </div>
                    <div class="col-md-3">
                        <h6><label for="phone" class="control-label form-label label01"><?php echo e(__('ptpma.a16')); ?> <span class="c3_color">*</span></label></h6>
                        <input type="text" name="phone" id="phone" class="form-control" required />
                    </div>
                    <div class="col-md-3">
                      <h6><label for="adr" class="control-label form-label label01"><?php echo e(__('ptpma.a17')); ?> <span class="c3_color">*</span></label></h6>
                      <input type="text" name="adr" id="adr" class="form-control" required />
                    </div>
                    <div class="col-md-3">
                      <h6><label for="number" class="control-label form-label label01"><?php echo e(__('ptpma.a18')); ?> <span class="c3_color">*</span></label></h6>
                      <input type="text" name="number" id="number" class="form-control" required />
                    </div>
                </div>

                <div class="row" style="margin-top: 15px">
                  <div class="col-md-3">
                      <h6><label for="passport" class="control-label form-label label01"><?php echo e(__('ptpma.a19')); ?> <span class="c3_color">*</span></label></h6>
                      <input type="file" name="passport[]" id="passport" class="form-control" required  />
                  </div>
                  <div class="col-md-3">
                      <h6><label for="val" class="control-label form-label label01"><?php echo e(__('ptpma.a20')); ?> <span class="c3_color">*</span></label></h6>
                      <input type="date" name="val" id="val" class="form-control" required />
                    </div>
                  <div class="col-md-3">
                    <h6><label for="nai1" class="control-label form-label label01"><?php echo e(__('ptpma.a21')); ?> <span class="c3_color">*</span></label></h6>
                    <input type="date" name="nai1" id="nai1" class="form-control" required />
                  </div>
                  <div class="col-md-3">
                    <h6><label for="nai2" class="control-label form-label label01"><?php echo e(__('ptpma.a22')); ?> <span class="c3_color">*</span></label></h6>
                    <input type="text" name="nai2" id="nai2" class="form-control" required />
                  </div>
                </div>

                <div class="row" style="margin-top: 15px">
                  <div class="col-md-6">
                    <h6><label for="pos" class="control-label form-label label01"><?php echo e(__('ptpma.a23')); ?> <span class="c3_color">*</span></label></h6>
                    <select name="pos" id="pos" class="form-control form-select" required>
                      <option></option>
                      <option><?php echo e(__('ptpma.a24')); ?></option>
                      <option><?php echo e(__('ptpma.a25')); ?></option>
                      <option><?php echo e(__('ptpma.a26')); ?></option>
                    </select>
                  </div>
                  <div class="col-md-6">
                    <h6><label for="part" class="control-label form-label label01"><?php echo e(__('ptpma.a27')); ?> <span class="c3_color">*</span></label></h6>
                    <input type="number" name="part" id="part" class="form-control" required />
                  </div>
                </div>

                <div class="row" style="margin-top: 15px">
                  <div class="col-md-6">
                      <h6><label for="whatsapp" class="control-label form-label label01"><?php echo e(__('ptpma.a28')); ?> <span class="c3_color">*</span></label></h6>
                      <input type="text" name="whatsapp" id="whatsapp" class="form-control" required />
                    </div>
                  <div class="col-md-6">
                    <h6><label for="mere" class="control-label form-label label01"><?php echo e(__('ptpma.a29')); ?> <span class="c3_color">*</span></label></h6>
                    <input type="text" name="mere" id="mere" class="form-control" required />
                  </div>
                  <!-- <div class="col-md-3">
                    <h6><label for="fiscal" class="control-label form-label label01"><?php echo e(__('ptpma.a30')); ?> <span class="c3_color">*</span></label></h6>
                    <input type="text" name="fiscal" id="fiscal" class="form-control" required />
                  </div>
                  <div class="col-md-3">
                      <h6><label for="tin" class="control-label form-label label01"><?php echo e(__('ptpma.a31')); ?> <span class="c3_color">*</span></label></h6>
                      <input type="file" name="tin[]" id="tin" class="form-control"  required />
                  </div> -->
                </div>

                <div class="row" style="margin-top: 20px; margin-bottom: 20px">
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i><?php echo e(__('ptpma.a32')); ?></button>
                  </div>
                </div>
              </form>
            </div>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Passport################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page" >
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch" style="background: transparent !important;">

              <div class="row">
              <?php $__currentLoopData = $passport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xxl-6">
                  <div class="aa" style="margin-bottom:10px; border-radius: 5px; padding: 10px; <?php if($cli->act==0): ?> background: rgba(255,0,0,0.06); <?php else: ?> background: rgba(0,255,0,0.06); <?php endif; ?>" >
                    <span class="bold" ><?php echo e($cli->civ); ?> <?php echo e($cli->nom); ?> <?php echo e($cli->pre); ?></span>
                    <?php if($cli->act==0): ?>
                    <a style="color:black; font-weight: bold; float: right;" title="Delete" href="<?php echo e(route('passportDelete',[ 'ref' => $cli->ref ])); ?>" onclick="return confirm('Are you sure you want to delete this item?'); event.preventDefault(); document.getElementById('passportDelete').submit();"><i class="fa fa-trash a-icon"></i></a>
                    <form id="passportDelete" action="<?php echo e(route('passportDelete',[ 'ref' => $cli->ref ])); ?>" method="POST">
                      <?php echo e(method_field('DELETE')); ?>

                      <?php echo csrf_field(); ?>
                    </form> 
                    <?php endif; ?> 
                    <hr style="border-color: rgba(0,0,0,0.05);">
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a11')); ?> : <strong><?php echo e($cli->nationality); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a15')); ?> : <strong><?php echo e($cli->mail); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a16')); ?> : <strong><?php echo e($cli->phone); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a28')); ?> : <strong><?php echo e($cli->whatsapp); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a17')); ?> : <strong><?php echo e($cli->cli1); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a21')); ?> : <strong><?php echo date("d/m/Y", strtotime($cli->cli2)); ?> <?php echo e($cli->cli3); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a29')); ?> : <strong><?php echo e($cli->mere); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a19')); ?> : <strong><?php echo e($cli->cli4); ?></strong> <?php if($cli->passport!=""): ?> | <a href="https://sales.magnitudeconstruction.com/public/media/cli/<?php echo e($cli->passport); ?>" target="_">Voir</a>  <?php endif; ?></span></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a20')); ?> : <strong><?php echo date("d/m/Y", strtotime($cli->val)); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a23')); ?> : <strong><?php echo e($cli->pos); ?></strong></span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a27')); ?> : <strong><?php echo e($cli->part); ?></strong> %</span><br>
                    <span class="bold" style="color:black"><?php echo e(__('ptpma.a30')); ?> : <strong><?php echo e($cli->fiscal); ?></strong> <?php if($cli->tin!=""): ?> | <a href="https://sales.magnitudeconstruction.com/public/media/cli/<?php echo e($cli->tin); ?>" target="_">Voir</a>  <?php endif; ?></span></span><br>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
          
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body">
        <div class="card card-xxl-stretch" style="margin-top: 0 !important">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo __('ptpma.a33'); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('ptpma.a1')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                <?php echo __('ptpma.a34'); ?>

              </p>
            </div>
          </div>

          <?php $__currentLoopData = $reservation2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('ptpma.a35')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="card-body" <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> style="background-color: rgba(255,0,0,0.1)" <?php elseif($i->valid==1): ?> style="background-color: rgba(0,255,0,0.1)" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <h3>
              <span <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e(__('ptpma.a36')); ?></span>
              <p style="font-size: 13px"><?php echo e(__('ptpma.a37')); ?> <br><br> <i style="color:black; font-size:11px">Merci d'impérativement zipper les dossiers et de n'envoyer qu'un document (si plusieurs documents sont envoyés, nous ne recevrons que le dernier).</i></p>
              <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('ptpma.a38')); ?></span></span>
              <?php elseif($i->valid==1): ?>
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('ptpma.a39')); ?></span></span>
              <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
            <form method="POST" action="<?php echo e(route('ptpmaAdded')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="row" <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required />
                      <input type="hidden" name="type" value="reservation">
                      <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px"><i class="fa fa-eye" style="padding-right: 10px"></i><?php echo e(__('ptpma.a40')); ?></button></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-success" <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><i class="fa fa-upload" style="padding-right: 10px"></i><?php echo e(__('ptpma.a41')); ?></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #4 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body">
        <div class="card card-xxl-stretch" style="margin-top: 0 !important">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column" style="width: 100%">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('ptpma.a42')); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('ptpma.a43')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
              <?php echo e(__('ptpma.a44')); ?>

              </p>
            </div>
          </div>

          <?php $__currentLoopData = $acte2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('ptpma.a35')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #3 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('ptpma.a45')); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('ptpma.a1')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
              
              </p><?php echo __('ptpma.a46'); ?>

            </div>
          </div>

          <?php $__currentLoopData = $terrain2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('ptpma.a35')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="card-body" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> style="background-color: rgba(255,0,0,0.1)" <?php elseif($i->valid==1): ?> style="background-color: rgba(0,255,0,0.1)" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <h3>
              <span <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e(__('ptpma.a36')); ?></span>
              <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('ptpma.a38')); ?></span></span>
              <?php elseif($i->valid==1): ?>
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('ptpma.a39')); ?></span></span>
              <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
            <form method="POST" action="<?php echo e(route('ptpmaAdded')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="row" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required />
                      <input type="hidden" name="type" value="terrain">
                      <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px"><i class="fa fa-eye" style="padding-right: 10px"></i><?php echo e(__('ptpma.a40')); ?></button></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-success" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><i class="fa fa-upload" style="padding-right: 10px"></i><?php echo e(__('ptpma.a41')); ?></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/ptpma.blade.php ENDPATH**/ ?>