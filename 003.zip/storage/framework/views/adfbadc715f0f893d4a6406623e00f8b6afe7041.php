<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/histoire.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-12">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">NOUS AVONS L’EXPERIENCE DE VOS EXIGENCES </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="font-family: 'VINERITC', cursive;">Bienvenue dans la sphère <span style="color:#EC008C; padding-left: 5px">Bayti</span><span style="color:#00AEEF ">Help</span></h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify; font-family: VINERITC; font-size: 25px; color:black; font-weight: bold">
                                Il était une fois, en 2009, des familles submergées par leur travail à l’extérieur et celui que demandait leur domicile, trouver de l'aide comme une femme de ménage, une nounou ou une garde malade relevait du parcours du combattant!
                                <br/><br/>
                                La seule solution était de se rendre chez un Semsar, au coin de la rue, sans aucune garantie ni sélection!
                                <br/><br/>
                                Les familles n’avaient pas d’autre choix, que de se contenter de ce qui se présentait. Elles étaient désespérées et parfois même désabusées puis en parallèle des femmes de ménage, des cuisinières expérimentées ou des nounous honnêtes et qualifiées, dans l’anonymat le plus certain, cherchaient du travail et n'avaient pas la chance d’être protégées ni soutenues….
                                <br/><br/>
                                Toute nouvelle aventure naît de conviction et d'expérience personnelle et c'est ainsi qu'un soir d'automne, la créatrice de <span style="color:#EC008C; padding-left: 5px; display: contents;">Bayti</span><span style="color:#00AEEF; display: contents;">Help</span> s'est fiée à son intuition, s'est armée de son ambition et de son audace habituelle pour donner naissance à une entreprise sociale qui porte les valeurs d’humilité, respect, confidentialité et rigueur.
                                <br/><br/>
                                Passionnée par le travail communautaire, elle fut outrée par l'informalité du secteur de personnel de maison et par le manque de considération du travail fourni par ces femmes courageuses qui quittaient à l’aube leur vie de famille pour aller embellir celles de leurs employeurs.
                                <br/><br/>
                                La fondatrice de <span style="color:#EC008C; padding-left: 5px; display: contents;">Bayti</span><span style="color:#00AEEF; display: contents;">Help</span> a créé un espace sécuritaire pour offrir du travail à ses collaborateurs et fournir des prestations de qualité à ses clients marocains et internationaux.
                                <br/><br/>
                                ...c’est ainsi que <span style="color:#EC008C; padding-left: 5px; display: contents;">Bayti</span><span style="color:#00AEEF; display: contents;">Help</span> est née étant le fruit de passion et de valeurs évoluant chaque jour pour se hisser au premier rang et devenir ce qu’elle est aujourd’hui : un exemple suivi au Maroc et une référence à l’international.
                          </div>

                          <div class="row" style="font-family: VINERITC; font-size: 25px; color:black; font-weight: bold; float: right;">
                          <br/><br/>
                          To be continued
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/histoire.blade.php ENDPATH**/ ?>