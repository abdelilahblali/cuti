<?php $__env->startSection('content'); ?>





<div class="col-md-12">

  <div class="page-header">

    <ol class="breadcrumb">

      <li class="titrePage"><i class="fa fa-sitemap"></i> List of documents</li>

    </ol>

    <div class="right">

      <div class="btn-group" role="group">

        <a href="<?php echo e(route('docAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> New document </a>

      </div>

    </div>

  </div>

</div>





<div class="col-md-12">

  <?php if(session()->has('Suppression')): ?>

  <div class="alert alert-success">

    <?php echo e(session()->get('Suppression')); ?>


  </div>

  <?php endif; ?>







  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">

    <thead>

      <tr>

        <td>Designation</td>

        <td>Date</td>

        <td></td>

      </tr>

    </thead>

    <tbody>

      <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>

        <td><span class="bold"><?php echo e($doc->des); ?></span></td>

        <td><span class="bold"><?php echo e($doc->fait); ?></span></td>

        <td align="right">
    
            <a href="https://monprojetbali.com/media/doc/<?php echo e($doc->doc); ?>" target="_"><button class="btn btn-xs btn-default"><i class="fa fa-download a-icon"></i></button></a>

          	<a href="<?php echo e(route('docDelete',[ 'ref' => $doc->id ])); ?>" onclick="return confirm('Are you sure you delete this document?'); event.preventDefault(); document.getElementById('docDelete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>

	        <form id="docDelete" action="<?php echo e(route('docDelete',[ 'ref' => $doc->id ])); ?>" method="POST">
	            <?php echo e(method_field('DELETE')); ?>

	            <?php echo csrf_field(); ?>
	        </form>  

        </td>

      </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

  </table>

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/doc.blade.php ENDPATH**/ ?>