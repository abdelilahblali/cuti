<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-file"></i> Documents management for the client : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<!-- <div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('clientDocsAdd',[ 'ref' => $ref ])); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-12">
          <h6><label for="des" class="control-label form-label label01">Designation <span class="c3_color">*</span></label></h6>
          <input type="input" class="form-control" name="des" />
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <h6><label for="images" class="control-label form-label label01">Choose a file<span class="c3_color">*</span></label></h6>
          <input type="file" class="form-control" name="images[]" />
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-upload" style="padding-right: 10px"></i>Add</button>
        </div>
      </div>
    </form>
  </div>
</div> -->

<div class="col-md-12">
  <div class="">
    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3" style="margin-bottom: 30px; border:1px solid rgba(0,0,0,0.1)">
      <h4 style="font-size:12px"><?php echo e($doc->des); ?></h4>
      <a href="<?php echo e(url('media/clidoc')); ?>/<?php echo e($doc->doc); ?>"><img src="<?php echo e(url('imgs/pdf.png')); ?>" width="100px"></a>
      <a href="<?php echo e(route('clientDocsDelete',[ 'id' => $doc->id, 'ref' => $doc->cli  ])); ?>" onclick="return confirm('Are you sure you delete this document?'); event.preventDefault(); document.getElementById('clientDocsDelete').submit();"><i class="fa fa-times" style="color:red; position: absolute; right: 20px; top: 3px;"></i></a>
      <form id="clientDocsDelete" action="<?php echo e(route('clientDocsDelete',[ 'id' => $doc->id, 'ref' => $doc->cli  ])); ?>" method="POST">
        <?php echo e(method_field('DELETE')); ?>

        <?php echo csrf_field(); ?>
      </form>  
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>   

<div class="col-md-12">
  <div class="row">
    <?php echo e($docs->links()); ?>

  </div>
</div>  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientDocs.blade.php ENDPATH**/ ?>