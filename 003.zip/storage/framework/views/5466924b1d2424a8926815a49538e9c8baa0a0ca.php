

<?php $__env->startSection('content'); ?>


<!--Breadcrumb-->
<div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="breadcrumb_inner">
                    <h3>Recettes</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb_block">
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
            <li>Recettes</li>
        </ul>
    </div>
</div>






<?php $__currentLoopData = $vids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--Blog With Sidebar-->
        <div class="blog_sidebar_wrapper clv_section blog_single_wrapper">
            <div class="container">
                <div class="row">

                    <div class="col-md-1"></div>
                    <div class="col-lg-10 col-md-10">
                        <div class="blog_left_section">
                            <div class="blog_section">
                                <div class="agri_blog_image">
                                    <h3 style="margin-bottom: 20px"><a href=""><?php echo e($vid->des); ?></a></h3>
                                    
                                    <iframe width="100%" height="344" frameborder="0" src="https://www.youtube.com/embed/<?php echo e($vid->vid); ?>?wmode=transparent" allowfullscreen=""></iframe>
                                </div>
                                <div class="agri_blog_content">
                                    
                                    
                                    <?php echo $vid->dcr; ?>


                                </div>
                                
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\oeuf\resources\views/videoshow.blade.php ENDPATH**/ ?>