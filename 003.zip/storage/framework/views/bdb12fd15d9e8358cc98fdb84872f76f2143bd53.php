<?php use \Statickidz\GoogleTranslate; ?>
<html>
<head>
	<title>Magnitude</title>
</head>

<?php
	$notif_txt1 = "Nouvelle Notification";
	$notif_txt2 = "Cliquez ici pour consulter";
	$notif_txt3 = "L'équipe Magnitude";

	// if($langue=='FR') {
	// 	$notif_txt1 = "Nouvelle Notification";
	// 	$notif_txt2 = "Cliquez ici pour consulter";
	// 	$notif_txt3 = "L'équipe Magnitude";
	// } if($langue=='EN') {
	// 	$source = 'fr'; $target = 'en';
	// 	$trans = new GoogleTranslate();
	//	$notif_txt1 = $trans->translate($source, $target, $notif_txt1);
	//	$notif_txt2 = $trans->translate($source, $target, $notif_txt2);
	//	$notif_txt3 = $trans->translate($source, $target, $notif_txt3);
	//	$msg = $trans->translate($source, $target, $msg);
	// }

	if($langue!='FR') {
		$source = 'fr'; $target = $langue;
	   	$trans = new GoogleTranslate();
	   	$notif_txt1 = $trans->translate($source, $target, $notif_txt1);
	   	$notif_txt2 = $trans->translate($source, $target, $notif_txt2);
	   	$notif_txt3 = $trans->translate($source, $target, $notif_txt3);
	   	$msg = $trans->translate($source, $target, $msg);
	}

?>

<body style='font-family: arial '>
	<table style='border:1px solid #e2e2e2; padding: 10px; border-radius: 6px'>
		<tr >
			<td>
				<table width='' >
					<tr >
						<td><img src='https://villa.magnitudeconstruction.com/imgs/logo.png' width='200px'></td>
					</tr>
				</table>
				<table bgcolor='#0AA2A5' style='margin-top: 15px; padding: 6px'  width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td style='font-weight: bold; color: white; text-align: center;'><?php echo e($notif_txt1); ?></td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px '  bgcolor='#e2e2e2' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;'>
							          	<br/>
							          	<strong><?php echo e($msg); ?></strong>
							          	<?php if(Auth::user()->type=='admin') { ?>
							          	<br/><a href="https://villa.magnitudeconstruction.com/<?php echo e($page); ?>"><?php echo e($notif_txt2); ?></a>
							          	<?php } ?>
							          	<br/><br/>
							          	<?php echo e($notif_txt3); ?>

							          	<br/>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px' bgcolor='black' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;text-algin:center;'>
										<a href='https://villa.magnitudeconstruction.com' target="_" style='text-decoration: none; font-weight: bold; color: white '>villa.magnitudeconstruction.com</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='margin-top: 20px '>
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td width='40%' style='padding: 0px ; font-weight: normal'>
										<span style='text-decoration: none; font-weight: normal; color: gray '>Magnitude &copy;</span>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
<?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/mail/notif.blade.php ENDPATH**/ ?>