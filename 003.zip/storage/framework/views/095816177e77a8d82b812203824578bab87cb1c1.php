<?php $__env->startSection('content'); ?>

     <!--Banner Slider-->
    <div class="clv_banner_slider" style="margin-top: 169px;">
        <!-- Swiper -->
        <div class="swiper-container">
            <div class="swiper-wrapper"  >

                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld/slide2v2.jpg')); ?>');">
                        <div class="container" > 
                            <div class="offset-md-1 clv_slide_inner" style="text-align: center;">
                                <img src="<?php echo e(url('imgs/logo/logo-back.svg')); ?>" width="20%">
                            </div>
                        </div>
                    </div>
                </div>
                 <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld/sld01.jpg')); ?>');">
                        <div class="container"> 
                            <div class="offset-md-1 clv_slide_inner" style="background: rgba(0,0,0,0.1); padding:20px">
                                <h1 style="color:white">Cuisinières diplômées et expérimentées </h1>
                                <p style="color:white">Bayti Help vous offre des cuisinier(e)s à domicile, talentueux(e)s et expérimenté(e)s.</p>
                                <div class="banner_btn">
                                    <a href="<?php echo e(url('cuisine')); ?>" class="clv_btn">Réserver un service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld/sld02.jpg')); ?>');">
                        <div class="container"> 
        
        
                            <div class="offset-md-1 clv_slide_inner" style="background: rgba(0,0,0,0.1); padding:20px">
                                <h1 style="color:white">Chauffeurs de confiance</h1>
                                <p style="color:white; margin-bottom: 0px">Nos chauffeurs partenaires sont des personnes élégantes et responsables</p>
                                <div class="banner_btn">
                                    <a href="<?php echo e(url('chauffeur')); ?>" class="clv_btn">Réserver un service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld/sld03.jpg')); ?>');">
                        <div class="container"> 
                            <div class="offset-md-1 clv_slide_inner" style="background: rgba(0,0,0,0.1); padding:20px">
                                <h1 style="color:white">Jardinage</h1>
                                <p style="margin-bottom: 0px; color:white">Nos jardiniers prennent en charge les travaux d’entretien courant de votre jardin</p>
                                <div class="banner_btn">
                                    <a href="<?php echo e(url('jardinage')); ?>" class="clv_btn">Réserver un service</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <span class="slider_arrow banner_left left_arrow">
                <svg 
                 xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink"
                 width="10px" height="20px">
                <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                 d="M0.272,10.703 L8.434,19.703 C8.792,20.095 9.372,20.095 9.731,19.703 C10.089,19.308 10.089,18.668 9.731,18.274 L2.217,9.990 L9.730,1.706 C10.089,1.310 10.089,0.672 9.730,0.277 C9.372,-0.118 8.791,-0.118 8.433,0.277 L0.271,9.274 C-0.082,9.666 -0.082,10.315 0.272,10.703 Z"/>
                </svg>
            </span>
            <span class="slider_arrow banner_right right_arrow">
                <svg 
                 xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink"
                 width="10px" height="20px">
                <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                 d="M9.728,10.703 L1.566,19.703 C1.208,20.095 0.627,20.095 0.268,19.703 C-0.090,19.308 -0.090,18.668 0.268,18.274 L7.783,9.990 L0.269,1.706 C-0.089,1.310 -0.089,0.672 0.269,0.277 C0.627,-0.118 1.209,-0.118 1.567,0.277 L9.729,9.274 C10.081,9.666 10.081,10.315 9.728,10.703 Z"/>
                </svg>
            </span>
        </div>
    </div>
   

    <div class="garden_service2_wrapper  meil-service">
      <div class="container">
          <div class="row">
            <div class="col-md-12" style="text-align: center;">
                  <h2>HAUTE QUALITÉ ET MEILLEURS SERVICES DE NETTOYAGE</h2>
                  <h4>D'UNE ENTREPRISE DE NETTOYAGE DE CONFIANCE</h4>
            </div>

            <div class="col-md-6 offset-md-3" style="text-align: center;">
                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; margin: auto;left: 0;right: 0;"></div>
                  <div class="lin-blue" ></div>
            </div>

          </div>
        </div>
      </div>


   <div class="garden_service2_wrapper clv_section">
        <div class="container">
          
            
                <div class="row">



                    <div class="col-md-4 service" >
                        <div class="row">
                           <div class="col-md-2">
                              <div class="square">
                               <i class="fa fa-clock-o rotating" style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                              </div>
                              <div class="triangle-down"></div>
                           </div>
                           <div class="col-md-10">
                               <h1>Gain de temps</h1>
                               <p>Avec BaytiHelp demandez votre femme de ménage préférée pour les futures réservations et gagnez plus de temps.</p>
                           </div>
                        </div>
                      
                        <div class="row">
                          <div class="col-md-2">
                              <div class="square1">
                                <i class="fa fa-refresh rotating" style="font-size: 35px; color:white; margin-top: 8px;"></i>
                              </div>
                              <div class="triangle1-down"></div>
                           </div>
                           <div class="col-md-10">
                               <h1>Annulation gratuite</h1>
                               <p>Vous pouvez réserver à la dernière minute et reporter ou annuler votre séance en cas d'empêchement.</p>
                           </div>
                        </div>
                    </div>
                   <div class="col-md-4 info-bayti" style="text-align: center;">
                    <img src="<?php echo e(url('imgs/wos.png')); ?>" style="width: 90%">
                  </div>
                    <div class="col-md-4 service">
                         <div class="row">
                           <div class="col-md-2">
                              <div class="square1">
                                <i class="fa fa-thumbs-up vibrate " style="font-size: 35px; color:white; margin-top: 8px;"></i>
                              </div>
                              <div class="triangle1-down"></div>
                           </div>
                           <div class="col-md-10">
                               <h1>Service de qualité</h1>
                               <p>Nos années d’expériences nous ont permis de se hisser au premier rang et de s’exporter à l’international.</p>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-2">
                              <div class="square">
                                <i class="fa fa-certificate rotating" style="font-size: 35px; color:white; margin-top: 8px;"></i>
                              </div>
                              <div class="triangle-down"></div>
                           </div>
                           <div class="col-md-10">
                               <h1>Garantie</h1>
                               <p>Nous vous proposons des garanties exceptionnels sur touts nos services : Menage, Cuisine, Jardinage, Chauffeur...</p>
                           </div>
                        </div>
                    </div>
                   
                </div>
                  
              
           
        </div>
    </div>
    <!--Counter Section-->
    <div class="clv_counter_wrapper clv_section">
      <div class="container">
        <div class="counter_section">
          <div class="row">
            <div class="col-lg-3 col-md-3">
              <div class="counter_block">
                <div class="counter_img">
                  <span class="red_bg"><img src="images/counter_customer.png" alt="image" class="img-fluid" /></span>
                </div>
                <div class="counter_text">
                  <h4><span class="count_no" data-to="26" data-speed="3000">26</span><span>k+</span></h4>
                  <h5>happy customers</h5>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-3">
              <div class="counter_block">
                <div class="counter_img">
                  <span class="yellow_bg"><img src="images/counter_project.png" alt="image" class="img-fluid" /></span>
                </div>
                <div class="counter_text">
                  <h4><span class="count_no" data-to="700" data-speed="3000">700</span><span>+</span></h4>
                  <h5>project complete</h5>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-3">
              <div class="counter_block">
                <div class="counter_img">
                  <span class="orange_bg"><img src="images/counter_branch.png" alt="image" class="img-fluid" /></span>
                </div>
                <div class="counter_text">
                  <h4><span class="count_no" data-to="200" data-speed="3000">200</span><span>+</span></h4>
                  <h5>world wide branch</h5>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-3">
              <div class="counter_block">
                <div class="counter_img">
                  <span class="blue_bg"><img src="images/counter_winner.png" alt="image" class="img-fluid" /></span>
                </div>
                <div class="counter_text">
                  <h4><span class="count_no" data-to="6" data-speed="3000">6</span><span>k+</span></h4>
                  <h5>award winner</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="garden_service2_wrapper  meil-service">
        <div class="container">
            <div class="row">
              <div class="col-md-8">

                    <h2>NOS CHIFFRES PARLENT D’EUX-MÊMES</h2>
                    <h4 style="text-align: justify;">Notre agence est spécialisée dans le placement du personnel de maison de différentes nationalités au Maroc et à l’Étranger.</h4>
                    <div class="lin-pink"></div>
                    <div class="lin-blue"></div>
                    <p>
                      Depuis nos débuts, nous avons priorisé la satisfaction de nos clients, en leur offrant une qualité de travail de premier ordre, d’une grande efficacité et répondant aux standards les plus élevés, le tout combiné à des économies de coûts.
                      <br/>
                      Notre expérience et nos connaissances sont essentielles pour y parvenir, mais le savoir-faire, le travail sans relâche et la fiabilité de nos employés sont encore plus importants. Nous investissons donc dans la formation de notre main-d’œuvre et à sa motivation. Nous en tirons profit tout autant que nos précieux employés et clients.
                    </p>
                    
               

              </div>
              <div class="col-md-4  meil-service-img" style="text-align: center;">
                  <img src="<?php echo e(url('imgs/wo.jpg')); ?>">
              </div>
            </div>
        </div>
    </div>
    <!--Service 2-->
     
    <div class="garden_service2_wrapper back-img">
            
        <div class="row">

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/01.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/09.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/03.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/04.jpg')); ?>" width="100%">
          </div>

        </div>

        <div class="row">

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/05.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/06.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/07.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/08.jpg')); ?>" width="100%">
          </div>

        </div>

    </div>
  


    <div class="dairy_about_wrapper clv_section" style="">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8 col-md-8">
            <div class="clv_heading">
              <h3 style="color: black">Téléchargez l'application mobile</h3>
                <div class="row justify-content-center" style="padding: 50px 0">
                    <div class="col-lg-6 col-md-6">
                        <div class="text-center">
                            <div class="separ_blue"></div>
                            <div class="separ_pink"></div>
                        </div>
                    </div>
                </div>
              
            </div>
          </div>
        </div>
        <div class="dairy_about_inner">
          <div class="row">
            <div class="col-md-8">
              <div class="about_img">
                <img src="<?php echo e(url('imgs/phone.png')); ?>" alt="image" width="100%" />
              </div>
            </div>
            <div class="col-md-4">
              <div class="about_content" style="margin-top: 100px">
                <div class="about_heading">
                  <h2>A propos</h2>
                  <hr/>
                </div>
                <p>Réservez et gérez les rendez-vous, envoyez un message à votre femme de méange, affichez les profils et les notes des professionnels, voyez l'emplacement en temps réel de votre femme de ménage et bien plus encore.</p>
                
                <a target="_blank" href="https://play.google.com/store/apps/details?id=com.agency.app_2bcom"><img src="<?php echo e(url('imgs/store.png')); ?>" width="60%"></a>
                
              </div>
            </div>
          </div>
        </div>
      </div>
     </div>

      <!--Blog-->
   
    <!--Shop-->
    <div class="garden_shop_wrapper srvc-details" style="background: rgba(0,0,0,0.05)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-6">
                    <div class="text-center">
                        <h3>AUTRES SERVICES D'ENTRETIEN</h3>
                        <h4>CE QUE NOUS OFFRONS</h4>
                        <div class="separ_blue"></div>
                        <div class="separ_pink"></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="garden_shop_slider ">
                        <div class="swiper-container ">
                            <div class="swiper-wrapper ">
                             
                                <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('imgs/ser/001.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>Electricité</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('imgs/ser/002.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>Plomberie</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('imgs/ser/003.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>Climatisation</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('imgs/ser/004.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>Poignets et serrures</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     






<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\baytihelp\resources\views/home.blade.php ENDPATH**/ ?>