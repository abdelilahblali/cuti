<?php $__env->startSection('content'); ?>

<style type="text/css">
  .bs-stepper-label { color:rgba(0,0,0,0.2) }
  .bgCyrcle { background:rgba(0,0,0,0.2) !important } 
  .bs-stepper-line { margin-left: 15px !important; flex: 1 0 16px !important }
  .activeClas { font-weight: bold; color :#1da2a4 !important; }
  .activeClasBg { background :#1da2a4 !important; }
  .activeClasAlready { font-weight: bold; color :rgba(0,0,0,0.6) !important; }
  .activeClasAlreadyBg { background :rgba(0,0,0,0.6) !important; }
</style>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>
<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5"><?php echo e(__('dashboard.a1')); ?></h3>
    <div class="d-flex align-items-center flex-wrap py-2">

      <?php echo $__env->make('master.aide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <a href="https://magnitudeconstruction.com/contactez-nous/" target="_blank" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6"><?php echo e(__('dashboard.a2')); ?></a>
      <a href="#" class="btn btn-success my-2" data-bs-toggle="modal" data-bs-target="#rendez-vous"><?php echo e(__('dashboard.a3')); ?></a>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <?php if(session()->has('yes')): ?>
     <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">
      <div class="col-xxl-7"> 

        <div class="card card-page">
          <div class="card-body">

            <div class="card-header border-0 pt-5 pb-3">
              <h3 class="card-title fw-bolder text-gray-800 fs-2"><?php echo e(__('dashboard.a4')); ?></h3>
            </div>
            
            <div class="card card-xxl-stretch">
              <div class="card-header">
                  
                  <?php $steps = array(
                    1 =>  __('dashboard.a5') ,
                    2 =>  __('dashboard.a6') ,
                    3 =>  __('dashboard.a7') ,
                    4 =>  __('dashboard.a8') ,
                    5 => __('dashboard.a9'),
                    6 => __('dashboard.a10'),
                    7 => __('dashboard.a11'),
                    8 => __('dashboard.a12'),
                    9 => __('dashboard.a13'),
                    10 => __('dashboard.a14'),
                    11 => __('dashboard.a15'),
                    12 => __('dashboard.a16'),
                    13 => __('dashboard.a17'),
                    14 => __('dashboard.a18'),
                    15 => __('dashboard.a19'),
                    16 => __('dashboard.a20'),
                    17 => __('dashboard.a21'),
                    18 => __('dashboard.a22'),
                    19 => __('dashboard.a23'),
                    20 => __('dashboard.a24'),
                    21 => __('dashboard.a25'),
                    22 => __('dashboard.a26'),
                    23 => __('dashboard.a27'),
                    24 => __('dashboard.a28'),
                    25 => __('dashboard.a29'),
                    26 => __('dashboard.a30'),
                    27 => __('dashboard.a31'),
                    28 => __('dashboard.a32'),
                    29 => __('dashboard.a33'),
                    30 => __('dashboard.a34'),
                    31 => __('dashboard.a35'),
                    32 => __('dashboard.a36'),
                    33 => __('dashboard.a37'),
                    34 => __('dashboard.a38'),
                    35 => __('dashboard.a39'),
                    36 => __('dashboard.a40')
                  ); ?>
                  
                  <div id="stepper4" class="bs-stepper vertical linear">
                    <div class="bs-stepper-header" role="tablist">
                      
                      <?php $i=1; ?>
                      <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="bs-stepper-line"></div>
                      <div class="step">
                          <span class="bs-stepper-circle  <?php if($i==$etape): ?> activeClasBg <?php elseif($i<$etape): ?> activeClasAlreadyBg <?php else: ?> bgCyrcle  <?php endif; ?>" ><?php echo e($i); ?></span><span class="bs-stepper-label <?php if($i==$etape): ?> activeClas <?php elseif($i<$etape): ?> activeClasAlready <?php endif; ?>"><?php echo e($s); ?></span>
                      </div>
                       <?php $i+=1; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                  </div>

              </div>
            </div>
          </div>
        </div>

      </div>

      <div class="col-xxl-5">
          <div class="card card-page">
            <div class="card-body">
              <div class="card-header border-0 pt-5 pb-3">
                <h3 class="card-title fw-bolder text-gray-800 fs-2"><?php echo e(__('dashboard.a41')); ?> </h3>
              </div>
              <?php $__currentLoopData = $pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($img->dat<'2022-01-10 00:00:00'): ?>
              <div class="card-header border-0 pt-5 pb-3"  style="margin-bottom: 5px">
      			     <a href="<?php echo e($urlWebSite2); ?>/media/cli/<?php echo e($img->img); ?>" onclick="return hs.expand(this)">
                	<img src="<?php echo e($urlWebSite2); ?>/media/cli/<?php echo e($img->img); ?>" width="100%">
                </a>
              </div>
              <?php else: ?>
              <div class="card-header border-0 pt-5 pb-3"  style="margin-bottom: 5px">
                 <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($img->img); ?>" onclick="return hs.expand(this)">
                  <img src="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($img->img); ?>" width="100%">
                </a>
              </div>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <div class="card-header border-0 pt-5 pb-3"  style="margin-bottom: 5px">
              	<a href="<?php echo e(route('getPhotosAll')); ?>" class="btn btn-light-dark" >Voir toutes les photos </a>
              </div>
            </div>
          </div>
       </div> 

    </div>
  </div>
</div>


<script type="text/javascript" src="<?php echo e(url('highslide/highslide-with-gallery.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('highslide/highslide.css')); ?>" />
<script type="text/javascript">



  hs.graphicsDir = 'highslide/graphics/';

  hs.align = 'center';

  hs.transitions = ['expand', 'crossfade'];

  hs.wrapperClassName = 'dark borderless floating-caption';

  hs.fadeInOut = true;

  hs.dimmingOpacity = .75;



  // Add the controlbar

  if (hs.addSlideshow) hs.addSlideshow({

    //slideshowGroup: 'group1',

    interval: 5000,

    repeat: false,

    useControls: true,

    fixedControls: 'fit',

    overlayOptions: {

      opacity: .6,

      position: 'bottom center',

      hideOnMouseOut: true

    }

  });

</script>
          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/dashboard.blade.php ENDPATH**/ ?>