

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Gestion des catégories des produits</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('categoriesAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> Nouvelle Catégorie</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-9">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

    <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
      <thead>
        <tr>
          <td width="40">désignation</td>
          <td width="40"></td>
        </tr>
      </thead>
      <tbody>
          <tr >
            <td></td>
            <td></td>
          </tr>
      </tbody>
    </table>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/categories.blade.php ENDPATH**/ ?>