<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-edit"></i> Edit : <span class="ref"><?php echo e($cli->username); ?></span></li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
        <a href="<?php echo e(route('client')); ?>" class="btn-right "><i class="fa fa-list"></i> List </a>
            
          </div>
      </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('clientEdited',[ 'ref' => $cli->ref ])); ?>">
      <?php echo e(csrf_field()); ?>


      <div class="row">
        <div class="col-md-3">
              <h6><label for="code" class="control-label form-label label01">Code <span class="c3_color">*</span></label></h6>
              <input type="text" name="code" id="code" class="form-control" required value="<?php echo e($cli->code); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="civ" class="control-label form-label label01">Civility <span class="c3_color">*</span></label></h6>
              <select name="civ" id="civ" class="form-control">
                <option value="<?php echo e($cli->civ); ?>"><?php echo e($cli->civ); ?></option>
                <option value="M.">M.</option>
                <option value="Mme">Mme</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="nom" class="control-label form-label label01">Last name <span class="c3_color">*</span></label></h6>
              <input type="text" name="nom" id="nom" class="form-control" required value="<?php echo e($cli->nom); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="pre" class="control-label form-label label01">First name <span class="c3_color">*</span></label></h6>
              <input type="text" name="pre" id="pre" class="form-control" required value="<?php echo e($cli->pre); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="tel" class="control-label form-label label01">Phone <span class="c3_color"></span></label></h6>
              <input type="text" name="tel" id="tel" class="form-control"  value="<?php echo e($cli->tel); ?>" />
          </div>
          <div class="col-md-6">
              <h6><label for="mail" class="control-label form-label label01">Email <span class="c3_color">*</span></label></h6>
              <input type="email" name="mail" id="mail" class="form-control" required  value="<?php echo e($cli->mail); ?>" />
          </div>
      </div>
      
      <div class="row">
      	  <div class="col-md-3">
              <h6><label for="langue" class="control-label form-label label01">Langue</label></h6>
              <select id="langue" name="langue" class="form-control" style="font-weight: bold;">
                <option value="<?php echo e($cli->langue); ?>"><?php echo e($cli->langue); ?></option>
                <option value="FR">Français</option>
                <option value="EN">English</option>
                <option value="IN">Bahasa Indo</option>
                <option value="ES">Spanyol</option>
                <option value="AR">العربية</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="username" class="control-label form-label label01">Login</label></h6>
              <input type="text" name="username" id="username" class="form-control" value="<?php echo e($cli->username); ?>"  />
          </div>
          <div class="col-md-3">
              <h6><label for="pas1" class="control-label form-label label01">New password </label></h6>
              <input type="password" name="pas1" id="pas1" class="form-control"   />
          </div>
          <div class="col-md-3">
              <h6><label for="pas2" class="control-label form-label label01">Confirmation </label></h6>
              <input type="password" name="pas2" id="pas2" class="form-control"   />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Update</button>
        </div>
      </div>
    </form>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientEdit.blade.php ENDPATH**/ ?>