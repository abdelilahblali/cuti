<?php $__env->startSection('content'); ?>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="<?php echo e(url('chosen2/chosen.css')); ?>">

<style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
</style>

<div class="container" style="padding-top: 30px;">
    <center><img alt="Logo" src="<?php echo e(url('imgs/logo_noel.png')); ?>" style="width:260px;" /></center>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>

    <?php if(session()->has('no')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('no')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
 




<div id="">
  <div class="content flex-row-fluid" id="kt_content">
      <div class="card card-page">
        <div class="card-body" style="padding: 0px 38px 30px 33px">
          <div class="col-md-8 col-md-offset-2">
          <div class="card card-xxl-stretch">
            <p style="padding: 20px 20px 10px 20px; text-align: center; ">

              <br><br>
              <strong>Félicitation pour l'acquisition de votre terrain, nous pouvons dès à présent commencer la conception architecturale de votre projet d’investissement à Bali !</strong>
              <br><br>
              Pour ce faire, vous trouverez ici notre catalogue “Finitions et Équipements" qui illustre les choix esthétiques et d’usage inclus dans votre template de villa, mais également les possibilités hors standard que vous pouvez ajouter à votre projet.
              <br><br>
              Nous vous prions donc de remplir le formulaire ci-dessous, puis de l’envoyer par mail à votre référent communication qui le transmettra à notre département Architecture. 
              <br>  
              Lors de cet envoi, n’hésitez pas à compléter votre courrier de toutes remarques ou photos d’inspiration, qui pourront alors être prises en compte par notre équipe pour concevoir un projet personnalisé. 
              <br><br>
              Dès que votre modèle 3D sera prêt, nous vous contacterons pour organiser votre premier rendez-vous avec notre architecte (via réunion Zoom), où vous pourrez discuter des améliorations et personnalisations à apporter à votre projet.
              <br><br>
              A très bientot,
              <br><br>
              L’equipe Magnitude
              <br><br>
              <br>
              <span style="font-weight: bold; color: #07153A"> - Cliquez sur l'image pour consulter notre catalogue - </span>
              <br>
              <br>
              <a href="https://villa.magnitudeconstruction.com/pdf/catalog.pdf" target="_"><img src="https://villa.magnitudeconstruction.com/imgs/catalog.jpg" width="100%"></a>
            </p>
          </div>
          </div>
        </div>
      </div> 
  </div>
</div>

<!-- Form ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl" style="margin-top: 0px">
  <div class="content flex-row-fluid" id="kt_content">
      <div class="card card-page">
        <div class="card-body" style="padding-top: 0;">
          <div class="card card-xxl-stretch">
           
            <form method="POST" action="<?php echo e(route('catalogForm_add')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


              <div class="imgShow"></div>

              <h1>INFORMATIONS PERSONNELLES</h1>

              <div class="mb-5">
                <label for="v76" class=" form-label">Nom</label>
                <input type="text" class="form-control" name="v76" placeholder="Nom" value="" required>
              </div>

              <div class="mb-5">
                <label for="v77" class=" form-label">Prénom</label>
                <input type="text" class="form-control" name="v77" placeholder="Prénom" value="" required>
              </div>

              <div class="mb-5">
                <label for="v78" class=" form-label">Email</label>
                <input type="text" class="form-control" name="v78" placeholder="Email" value="" required>
              </div>

              <br>

              <h1><?php echo e(__('design0.a6')); ?></h1>
              <h2><?php echo e(__('design0.a7')); ?></h2>

              <div class="mb-5">
                <label for="v1" class=" form-label"><?php echo e(__('design0.a8')); ?></label>
                <select class="form-select" aria-label="Select example" name="v1">
                  <option><?php echo e(__('design0.a9')); ?></option>
                  <option><?php echo e(__('design0.a10')); ?></option>
                </select>
              </div>

              <div class="mb-5">
                <label for="v2" class=" form-label"><?php echo e(__('design0.a11')); ?> </label>
                <select class="form-select" aria-label="Select example" name="v2">
                  <option><?php echo e(__('design0.a9')); ?></option>
                  <option><?php echo e(__('design0.a10')); ?></option>
                </select>
              </div>

              <h3>P05 -  Porte d'entrée</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v3" class=" form-label"><?php echo e(__('design0.a12')); ?></label>
                   <select class="form-select"  id="select1"  name="v3">
                      <option>Porte simple 1.0m sur charnières - image 1</option>
                      <option>Porte simple 1.4m sur charnières - image 3</option>
                      <option>Porte simple 1.4m sur pivot - image 3</option>
                      <option>Porte double 1.4m sur charnières - image 2</option>
                      <option>Porte double 2.5m sur charnière - image 4 (prix calculé sur mesure)</option>
                   </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v4" class=" form-label"><?php echo e(__('design0.a17')); ?> </label>
                <select class="form-select" aria-label="Select example" name="v4">
                  <option>Oui (à partir de 1032€ / 1143$)</option>
                  <option><?php echo e(__('design0.a10')); ?></option>
                </select>
              </div>

              <h3><?php echo e(__('design0.a21')); ?></h3>

              <div class="mb-5">
                <label for="v5" class=" form-label"><?php echo e(__('design0.a19')); ?> </label>
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v5">
                    <option>Pierre naturelle Palimanan beige - image 5 </option>
                    <option>Pierre naturelle Batu Candi noire </option>
                    <option>Autre</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v6" class=" form-label"><?php echo e(__('design0.a22')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v6">
                    <option>Bois Ulin - image 6 (102/m² - 113$/m²)</option>
                    <option>Béton bouchardé - image 7 (54/m² - 59$/m²) </option>
                    <option>Béton désactivé - image 10 (54/m² - 59$/m²)</option>
                    <option>Opus grande taille - image 8 (31€/m² - 34$/m²)</option>
                    <option>Opus petite taille - image 9 (40€/m² - 45$/m²)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v79" class=" form-label">Quelle finition souhaitez vous pour les plateformes bois ? </label>
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v79">
                    <option>Bois Ulin lazuré - image 6 (lazure à renouveler tous les ans) </option>
                    <option>Bois Ulin naturel (se grise après quelques mois)</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v7" placeholder="Autres" value="">
              </div>

              <h3>P10 -  Toitures </h3>

              <div class="mb-5">
                <label for="v8" class=" form-label"><?php echo e(__('design0.a29')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v8">
                    <option>Tuile terre cuite naturelle (orange) </option>
                    <option>Tuile terre cuite peinte - image 14 (peinture à renouveler)</option>
                    <option>Bardeau d’asphalte - image 11</option>
                    <option>Autre</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v9" class=" form-label">Souhaitez vous un autre type de couverture avec un coût supplémentaire ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v9">
                    <option>Toiture plate avec finition gazon synthétique - image 12 (52€/m² - 57$/m²)</option>
                    <option>Toiture plate avec finition galet (52€/m² - 57$/m²)</option>
                    <option>Sirap / tuile en bois de fer - image 13 (66€/m² - 73$/m²)</option>
                    <option>Alang-alang / chaume de Bali - page 9 (52€/m² - 57$/m²)</option>
                    <option>Décoration sculptée sur toiture en tuile (13€/unité -15$/unité) </option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <h3><?php echo e(__('design0.a37')); ?></h3>

              <div class="mb-5">
                <label for="v10" class=" form-label">Quelle touche de parement décoratif souhaitez-vous appliquer sur vos façades (à raison de 30%)?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v10">
                    <option>Parement bois - image 19</option>
                    <option>Pierre Palimanan beige  - image 16</option>
                    <option>Pierre Limestone beige - image 20</option>
                    <option>Pierre Kerobokan grise - image 18</option>
                    <option>Pierre Batu Candi noire</option>
                    <option>Uniquement peinture</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v11" class=" form-label"><?php echo e(__('design0.a44')); ?> </label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v11">
                    <option><?php echo e(__('design0.a45')); ?> </option>
                    <option><?php echo e(__('design0.a46')); ?> </option>
                    <option>Bois (139€/m² - 154$/m²) </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v12" class=" form-label"><?php echo e(__('design0.a48')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v12">
                    <option><?php echo e(__('design0.a9')); ?></option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v13" placeholder="Autres" value="">
              </div>

              <h3>P13 - Jardin </h3>

              <!-- <div class="mb-5">
                <label for="v14" class=" form-label"><?php echo e(__('design0.a50')); ?> </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v14">
                    <option><?php echo e(__('design0.a51')); ?> </option>
                    <option><?php echo e(__('design0.a52')); ?></option>
                  </select>
                </div>
              </div> -->

              <div class="mb-5">
                <label for="v15" class=" form-label"><?php echo e(__('design0.a53')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v15">
                    <option><?php echo e(__('design0.a54')); ?> </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v16" placeholder="Autres" value="">
              </div>


              <h3>P14 - Statues</h3>

              <div class="mb-5">
                <label for="v18" class=" form-label">Quelle statue souhaitez vous intégrer dans votre villa ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v18">
                    <option>Ganesh - image 24</option>
                    <option>Tête de Bouddha - image 28</option>
                    <option>Bouddha couché</option>
                    <option>Bouddha méditant - image 25</option>
                    <option>Bouddha debout</option>
                    <option>Tête de Dewi Sri</option>
                    <option>Dewi Sri debout</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v19" class=" form-label"><?php echo e(__('design0.a68')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v19">
                    <option><?php echo e(__('design0.a9')); ?></option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v20" placeholder="Autres" value="">
              </div>

              <h3>P15 - Salon extérieur </h3>

              <div class="mb-5">
                <label for="v21" class=" form-label"><?php echo e(__('design0.a70')); ?> </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v21">
                    <option><?php echo e(__('design0.a71')); ?></option>
                    <option><?php echo e(__('design0.a72')); ?> </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v22" class=" form-label"><?php echo e(__('design0.a73')); ?> </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v22">
                    <option><?php echo e(__('design0.a9')); ?></option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v23" placeholder="Autres" value="">
              </div>

              <h3>P18 - Gardes-corps </h3>

              <div class="mb-5">
                <label for="v24" class=" form-label"><?php echo e(__('design0.a75')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v24">
                    <option>Acier - image 32</option>
                    <option>Acier + cordage - page 18</option>
                    <option>Acier + bois - image 31</option>
                    <option>Acier + filin  (75€/m² - 83$/m²)</option>
                    <option>Acier + verre - image 33 (136€/m² - 151$/m²)</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v25" class=" form-label"><?php echo e(__('design0.a76')); ?> ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v25">
                    <option>Acier </option>
                    <option>Bois </option>
                    <option>Sans main-courante</option>
                  </select>
                </div>
              </div>

              <h3>P20 - Espace de baignade  </h3>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a78')); ?> ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v26">
                    <option>Oui (à partir de 394€/m² / 437$/m²)</option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a79')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control chosen-select" multiple aria-label="Select example" name="v27[]">
                    <option>Douche de piscine - page 22 (534€ - 591$)</option>
                    <option>Vitre plexiglass - page 20 (3195€ - 3537$)</option>
                    <option>Banquette relaxante (sans bulles) - page 21 (à partir de 8450€ / 7345$)</option>
                  </select>
                </div>
              </div>

              <h2><?php echo e(__('design0.a80')); ?> </h2>

              <h3>P24 - Les sols</h3>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a82')); ?> ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v28">
                    <option>Carrelage Cemento (lisse) 60x60cm gris - image 37</option>
                    <option>Carrelage Cemento (lisse) 60x60cm gris foncé  - image 52</option>
                    <option>Carrelage Cemento (lisse) 60x60cm noir  - image 39</option>
                    <option>Carrelage Cemento (lisse) 60x60cm beige - image 38</option>
                    <option>Carrelage Piacenza (effet pierre) 60x60cm gris - image 35</option>
                    <option>Carrelage Piacenza (effet pierre) 60x60cm beige</option>
                    <option>Carrelage Piacenza (effet pierre) 60x60cm blanc</option>
                    <option>Autre</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a83')); ?> ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v29">
                    <option>Carrelage Cement 100x100cm gris (43€/m² - 47$/m²)</option>
                    <option>Carrelage Serene 60x120cm gris (24€/m² - 27$/m²)</option>
                    <option>Carrelage Serene 60x120cm beige (24€/m² - 27$/m²)</option>
                    <option>Terrazzo 100x100cm beige - image 41 (26€/m² - 29$/m²)</option>
                    <option>Terrazzo 100x100cm gris - image 42 (26€/m² - 29$/m²)</option>
                    <option>Terrazzo 100x100cm noir - image 43 (26€/m² - 29$/m²)</option>
                    <option>Béton bouchardé 100x100cm (49€/m² - 54$/m²)</option>
                    <option>Parquet - image 40 (88€/m² - 97$/m²)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v30" placeholder="Autres" value="">
              </div>

              <h3>P26 - Les murs</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter un autre revêtement mural que la peinture pour vos intérieurs ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v31">
                    <option>Lambris de bois (112€/m² - 124$/m²)</option>
                    <option>Pierre Palimanan beige (29€/m² - 34$/m²)</option>
                    <option>Pierre Limestone beige (69€/m² - 76$/m²)</option>
                    <option>Pierre Kerobokan grise - image 44 (46€/m² - 51$/m²)</option>
                    <option>Pierre Batu Candi noire (33€/m² - 36$/m²)</option>
                    <option>Pierre Susun Siri (67€/m² - 74$/m²)</option>
                    <option>Marbre (100€/m² - 110$/m²)</option>
                    <option>Terrazzo (48€/m² - 53$/m²)</option>
                    <option>Zelige (29€/m² - 32$/m²)</option>
                    <option>Papier peint (44€/m² - 49$/m²)</option>
                    <option>Autre</option>
                    <option>Uniquement peinture</option>
                  </select>
                </div>
              </div>

              <h3>P27 - Les portes</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous conserver le type de porte sur charnières standard ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v32">
                    <option>Porte bois 80x230cm graphisme losange - image 49</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Dans le cas cas contraire vous pouvez choisir d’autres designs de porte avec supplément :</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v33">
                    <option>Porte sur charnière métal+bois 80x230cm graphisme horizontal - image 48 (589€/unité - 653$/unité)</option>
                    <option>Porte coulissante - design au choix (852€/unité - 943$/unité)</option>
                    <option>Porte à galandage - design au choix (983€/unité - 1088$/unité)  </option>
                    <option>Double porte coulissante - design au choix (959€/unité - 1062$/unité)</option>
                    <option>Double porte à galandage - design au choix (1090€/unité - 1207$/unité)  </option>
                    <option>Panneau de bois sculpté sur charnière - design au choix (745€/unité - 825$/unité) </option>
                    <option>Non </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v34" placeholder="Autres" value="">
              </div>

              <h3>P29 - Les plafonds </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez vous conserver le modèle standard de plafond blanc ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v35">
                    <option>Plafond de 3m20 dans le séjour et de 2m80 dans les chambres   </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a91')); ?> : </label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v36">
                    <option>Plafond plat en lambris - image 51 (67€/m² - 74$/m²)</option>
                    <option>Plafond “cathédrale” blanc (22€/m² - 24$/m²)</option>
                    <option>Plafond “cathédrale” lambris - image 52 (74€/m² - 82$/m²)</option>
                    <option>Charpente bois “cathédrale” apparente - image 52 (prix calculé sur mesure)</option>
                    <option>Charpente bois plate apparente - image 54 (prix calculé sur mesure)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v37" placeholder="Autres" value="">
              </div>

              <h3>P30 - L’espace de vie </h3>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a93')); ?>  ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v38">
                    <option>Oui </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v39" placeholder="Autres" value="">
              </div>

              <h3>P32 - La cuisine</h3>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a95')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v40">
                    <option>Agencement fermé (tout en placard) </option>
                    <option>Agencement semi fermé (placard + étagères avec fond en bois) </option>
                    <option>Agencement semi ouvert (placard + étagères sans fond avec mur apparent) </option>
                    <option>Agencement ouvert (tout en étagère sans fond avec mur apparent) </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a96')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v41">
                    <option>Teck foncé - image 55</option>
                    <option>Teck clair - image 56</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a97')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v42">
                    <option>Marbre noir - image 57</option>
                    <option>Marbre blanc - image 60</option>
                    <option>Granit noir - image 58</option>
                    <option>Composite blanc - image 59</option>
                    <option>Terrazzo - couleur au choix (prix calculé sur mesure)</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.a98')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v43">
                    <option>Oui </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v44" placeholder="Autres" value="">
              </div>

              <h3>P34 - Les chambres  </h3>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b1')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v45">
                    <option>Oui </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v46" placeholder="Autres" value="">
              </div>

              <h3>P36 - La salle de bain </h3>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b3')); ?> </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v47">
                    <option>Oui </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b4')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v48">
                    <option>Agencement maçonné avec plateau en marbre - page 36 (prix calculé sur mesure)</option>
                    <option>Agencement maçonné avec finition terrazzo - image 62 (prix calculé sur mesure)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b5')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v49">
                    <option>Céramique rectangulaire - image 61</option>
                    <option>Céramique circulaire - image 66</option>
                    <option>Pierre de rivière - image 65</option>
                    <option>Pierre onix - image 63</option>
                    <option>Terrazzo rectangulaire - image 62</option>
                    <option>Marbre poli circulaire - image 69</option>
                  </select>
                </div>
              </div> 

               <div class="mb-5">
                <label for="" class=" form-label">Concernant la finition murale, il est prévu un mélange de peinture et de carrelage, mais avec un surcoût seriez vous intéressé par des touches de finitions différentes ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v50">
                    <option>Pierre Palimanan beige (29€/m² - 32$/m²)</option>
                    <option>Pierre Limestone beige - image 67 (69€/m² - 76$/m²)</option>
                    <option>Pierre Kerobokan grise - image 44 (46€/m² - 51$/m²)</option>
                    <option>Pierre Batu Candi noire (33€/m² - 36$/m²)</option>
                    <option>Pierre Susun Siri - image 58 (67€/m² - 74$/m²)</option>
                    <option>Marbre - page 36 (100€/m² - 110$/m²)</option>
                    <option>Terrazzo - image 69 (48€/m² - 53$/m²)</option>
                    <option>Zelige (29€/m² - 32$/m²)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter des douches extérieures dans des jardins privatifs ( 534€/unité / 591$/unité) ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v63">
                    <option>Oui, au nombre de  </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v64" placeholder="Autres" value="">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter des baignoires intérieures ou extérieures ? (1065€/unité / 1179$/unité)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v65">
                    <option>Baignoire en terrazzo - image 71 (1065€/unité - 1179$/unité)</option>
                    <option>Baignoire en céramique (rectangulaire ou ovale) - image 70 (1206€/unité - 1335$/unité)</option>
                    <option>Non</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v66" placeholder="Autres" value="">
              </div>  

              <h2><?php echo e(__('design0.b7')); ?></h2>

              <h3>P42 - Salle de massage </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une salle de massage sur mesure au sein de votre villa ? (à partir de 11700€ / 12954$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v51">
                    <option>Deux tables de massage </option>
                    <option>Deux tables de massage et un lavabo </option>
                    <option>Deux tables de massage, un lavabo et une douche </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>P43 - Salle de sports</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une salle de sport sur mesure au sein de votre villa ? (à partir de 11700€ / 12954$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v52">
                    <option>Oui </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Si oui, quels sont les 3 éléments que vous souhaitez pour l’équiper ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control chosen-select" multiple aria-label="Select example" name="v53[]">
                    <option>A Vélo </option>
                    <option>B Vélo elliptique</option>
                    <option>C Tapis de course</option>
                    <option>D Machine de musculation</option>
                    <option>E Banc de musculation</option>
                    <option>F Ballon de gym</option>
                    <option> G Demi ballon de gym</option>
                    <option>H Poids fitness</option>
                    <option>I Step de fitness</option>
                    <option>J Tapis de gym</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b13')); ?> </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v54">
                    <option>Oui  </option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v55" placeholder="Autres" value="">
              </div>

              <h3>P45 - Yoga shala</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une structure pour espace yoga au sein de votre villa ? (à partir de 2600€)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v56">
                    <option>Toiture avec plafond en lambris  </option>
                    <option>Toiture avec charpente bois apparente</option>
                    <option>Structure en bambou</option>
                    <option>Pergola</option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>P46 - Pergola </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter une pergola au sein de votre villa ? (à partir de 3250€ / 3598$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v57" id="v57">
                    <option>Oui</option>
                    <option><?php echo e(__('design0.a10')); ?></option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b18')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v58" id="v58">
                    <option>Béton finition peinture ou pierre </option>
                    <option>Bois - image 75</option>
                    <option>Acier - image 76</option>
                    <option>Non</option>
                  </select>
                </div>
              </div> 

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b19')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v59" id="v59">
                    <option>Bois manufacturé - image 75-76</option>
                    <option>Bois flotté - image 77</option>
                    <option>Métal - page 47 </option>
                    <option>Non </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b20')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" >
                  <select class="form-select" aria-label="Select example" name="v60" id="v60">
                    <option>Polycarbonate transparent</option>
                    <option>Polycarbonate fumé - image 76</option>
                    <option>Verre - page 47</option>
                    <option>Sans protection</option>
                  </select>
                </div>
              </div>  

              <h3>P48 - Gazebo  </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter un gazebo au sein de votre jardin ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v61">
                    <!-- <option>Gazebo 2x2m bois + alang-alang - page 48 (2364€/unité - 2671$/unité)</option> -->
                    <option>Gazebo 2x2m bois + alang-alang - page 48 (3483€/unité - 3856$/unité)</option>
                    <option>Gazebo personnalisé (prix calculé sur mesure)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v62" placeholder="Autres" value="">
              </div>

              

              <h3>P49 - Éléments décoratifs </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous décorer votre villa de murs végétaux ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v68">
                    <option>Mur végétal intérieur - image 81 (210€/m² / 232$/m²)</option>
                    <option>Mur végétal extérieur - image 88 (229€/m² / 254$/m²)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous décorer votre villa de bassin d’agrément - image 80 (244€ / 276$) ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v69">
                    <option>Oui  </option>
                    <option><?php echo e(__('design0.a10')); ?> </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous décorer votre villa d’une fontaine (prix calculé sur mesure) ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v70">
                    <option>Sculpture - page 14  </option>
                    <option>Mur d’eau - image 80 </option>
                    <option>Cascade - image 83</option>
                    <option>Non</option>
                    </option>
                  </select>
                  </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter à votre villa un temple à offrandes (361€/unité / 400$/unité) ?  </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v71">
                    <option><?php echo e(__('design0.a10')); ?></option>
                    <option>Oui</option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>P50 - Jacuzzi</h3>
              
              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter un jacuzzi dans un espace privé ou public de la villa ? (à partir de 13000€ / 14390$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v67">
                    <option>Jacuzzi construit - image 81</option>
                    <option>Jacuzzi manufacturé 2 places</option>
                    <option>Jacuzzi manufacturé 4 places - image 82</option>
                    <option>Jacuzzi manufacturé 6 places </option>
                    <option>Non</option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>Additionnel divers</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Aimeriez-vous ajouter des éléments de détentes photogéniques  (prix calculé sur mesure) ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control chosen-select" multiple aria-label="Select example" name="v72[]">

                    <?php $array_v72=array('Hamac','Filet hamac sur structure construite','Balançoire','Structure Coeur','Structure Nid','Autre',__('design0.a10'),); ?>

                    <?php $__currentLoopData = $array_v72; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($i); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v73" placeholder="Autres" value="">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label"><?php echo e(__('design0.b33')); ?></label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control chosen-select" multiple aria-label="Select example" name="v74[]">

                    <?php $array_v74=array('Écran TV 55” dans le séjour', 'Écran TV 43” dans les chambres (au lieu de 33”)', 'Vidéo projecteur', 'Ecran motorisé pour projection', 'Enceinte Sonos bluetooth au nombre de',
                      'Machine-à-laver', 'Machine-à-laver / sécher', 'Lave-vaisselle', 'Lumière RVB dans la piscine', 'Autre', ); ?>

                    <?php $__currentLoopData = $array_v74; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option><?php echo e($i); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v75" placeholder="Autres" value="">
              </div>



              <div class="mb-5">
                  <button class="btn btn-success" style="margin-top: 10px"><i class="fa fa-save"></i>Entegistrer & Télécharger le formulaire</button>
              </div>

            </form>
          </div>
        </div>
      </div>
  </div>
</div>



<script src="<?php echo e(url('chosen2/jquery-3.2.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('chosen2/chosen.jquery.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('chosen2/init.js')); ?>" type="text/javascript" charset="utf-8"></script>

<script type="text/javascript">
  $("#v57").change(function() {
    if($("#v57").val()=='Non'){
      $("#v58").val(""); $( "#v58" ).prop( "disabled", true ); 
      $("#v59").val(""); $( "#v59" ).prop( "disabled", true );
      $("#v60").val(""); $( "#v60" ).prop( "disabled", true );
    }
    if($("#v57").val()=='Oui'){
      $( "#v58" ).prop( "disabled", false ); $("#v58").val($("#v58 option:first").val());
      $( "#v59" ).prop( "disabled", false ); $("#v59").val($("#v59 option:first").val());
      $( "#v60" ).prop( "disabled", false ); $("#v60").val($("#v60 option:first").val());
    }
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.themeCatalogForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/catalogForm.blade.php ENDPATH**/ ?>