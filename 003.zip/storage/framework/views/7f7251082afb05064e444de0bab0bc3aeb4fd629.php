<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">Les bons petits plats de notre enfance.   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">Une cuisine raffinée ou familiale? <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> a la personne que vous recherchez.</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">
                            <b>Votre maison ou appartement a besoin d’être nettoyé de fond en comble?</b>
                            <br/><br/>
                            Vous recherchez un <b>chef à domicile? Un(e) cuisinier(e) ? </b>
                            <br/>
                            Nos <b><span style="color:#EC008C;">hel</span><span style="color:#00AEEF ">pers</span></b> sont à votre disposition pour vous proposer <b>des collaborateurs dotés d’une cuisine raffinée et de qualité.</b> 
                            <br/><br/>
                            En fonction de <b>vos souhaits</b>, nous sélectionnons des cuisinier(e)s spécialisés en <b>cuisine Française</b>, Italienne, Russe, Japonaise, Chinoise, etc.… ou tout simplement une <b>cuisine traditionnelle</b> familiale.
                            <br/><br/>
                            <b>Nos cuisinier(e)s</b> respectent vos goûts et vos restrictions alimentaires. 
                            <br/>
                            Vous êtes à la diète?
                            <br/>
                            Sans problème, prévenez votre <b>chef à domicile</b>, il élaborera votre menu de la semaine en prenant en considération vos demandes mais aussi en mettant en place les menus de votre famille.
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous offre des cuisinier(e)s à domicile, <b>talentueux(e)s et expérimenté(e)s.</b>
                            <br/><br/>
                            Des personnes qualifiées pour vous préparer des repas variés d'une cuisine <b><span style="color:#EC008C;">traditionnelle</span> ou <span style="color:#00AEEF ">internationale.</span></b>
                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/cuisinieres.png')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT </span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>

                          

                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE CUISINIÈRE DIPLÔMÉE ET EXPÉRIMENTÉE</button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/cuisinieres.blade.php ENDPATH**/ ?>