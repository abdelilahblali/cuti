<?php $__env->startSection('content'); ?>

<style type="text/css">
  .accordion-button:not(.collapsed) { color:black !important;  }
  .accordion span {  margin-left: 10px; color: rgba(0,0,0,0.6)  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Documentation</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>

    <?php if(session()->has('no')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('no')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
 
<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">



    <div class="card card-page">
      <div class="card-body">
        <div class="card card-xxl-stretch">
          
          <div class="accordion" id="kt_accordion_1">
            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a1" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a1'); ?>

                    </button>
                </h2>
                <div id="a1" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/KTgxDUmuevc" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a2" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a2'); ?>

                    </button>
                </h2>
                <div id="a2" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/bKcM0a2TkHQ" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a3" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a3'); ?>

                    </button>
                </h2>
                <div id="a3" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/8-HqPruuiSI" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a4" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a4'); ?>

                    </button>
                </h2>
                <div id="a4" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/YogPi2sRryY" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a5" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a5'); ?>

                    </button>
                </h2>
                <div id="a5" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/8AxNY8eh3Qg" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a6" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a6'); ?>

                    </button>
                </h2>
                <div id="a6" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/VH_Np6CwEGI" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a7" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a7'); ?>

                    </button>
                </h2>
                <div id="a7" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/mVx95XajRG8" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a8" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a8'); ?>

                    </button>
                </h2>
                <div id="a8" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/jKZpoRoSv2c" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a9" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a9'); ?>

                    </button>
                </h2>
                <div id="a9" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/y9vWfPCapZk" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a10" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a10'); ?>

                    </button>
                </h2>
                <div id="a10" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/jMNG5BKUiKE" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a11" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a11'); ?>

                    </button>
                </h2>
                <div id="a11" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/pYOOe0w0Oz8" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="kt_accordion_1_header_1">
                    <button class="accordion-button fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#a12" aria-expanded="true" aria-controls="kt_accordion_1_body_1">
                      <?php echo __('documentation.a12'); ?>

                    </button>
                </h2>
                <div id="a12" class="accordion-collapse collapse " aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                    <div class="accordion-body">
                        <iframe width="100%" height="600" src="https://www.youtube.com/embed/xbzCGTOpkJk" title="Magnitude Construction" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>


          </div>

        </div>
      </div>
    </div>



  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/documentation.blade.php ENDPATH**/ ?>