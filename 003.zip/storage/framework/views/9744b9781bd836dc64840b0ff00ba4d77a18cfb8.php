
<?php if( Auth::user()->type=='admin' ): ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title>Magnitude Construction : MY PROJECT BALI</title>
    <link href="<?php echo e(url('dash/css/root.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('dash/style.css')); ?>">
    <link rel="icon" href="<?php echo e(url('imgs/logo.png')); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('dash/css/font-awesome.min.css')); ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <style type="text/css">
    .right a { color:gray; font-weight: bold;  }
    .right .active {  background: rgba(0,0,0,0.2) }
    </style>
</head>
<body>
    <div id="top" class="clearfix" style="background: black !important">
        <div class="applogo" style="width: 650px !important; padding-top: 9px, color:white; font-size: 20px; padding-top: 15px">
            <span style="font-weight: bold">MY PROJECT BALI</span> : WORKSITE
        </div>
        <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-bars"></i></a>
        <div class="col-md-2"></div>
        <ul class="top-right" style="background-color: #0AA2A5; padding:10px 8px">
            <li class=" link">
                <a href="#" style="padding-top: 2px; padding-right: 20px; padding-left: 20px">Welcome <b><?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></b></a>
            </li>
        </ul>
    </div>
    <div class="sidebar clearfix">
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Customers</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('clientAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">New customer</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('client')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">All customers</span></a>
          </li>
        </ul>
        <!-- <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Documents</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('docAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">Add new</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('doc')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">List</span></a>
          </li>
        </ul> -->

        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Bases</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('days', ['typ' => 'Rainy days' ])); ?>"><span class="icon color5"><i class="fa fa-umbrella"></i></span>
            <span class="panel_menu">Rainy days</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('days', ['typ' => 'Ceremony days' ])); ?>"><span class="icon color5"><i class="fa fa-moon-o"></i></span>
            <span class="panel_menu">Ceremony days</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('days', ['typ' => 'Public Holidays' ])); ?>"><span class="icon color5"><i class="fa fa-birthday-cake"></i></span>
            <span class="panel_menu">Public Holidays</span></a>
          </li>
        </ul>

        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Account</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('password')); ?>"><span class="icon color5"><i class="fa fa-unlock"></i></span>
            <span class="panel_menu">Password</span></a>
          </li>
        </ul>
        <ul class="sidebar-panel nav" style="position: fixed; bottom: 0; background-color: red; width: 195px; margin-left: 0; padding-left: 20px">
          <li>
            <a href="<?php echo e(route('logout' )); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span class="icon color5"><i class="fa fa-power-off" style="color: white"></i></span>
            <span class="panel_menu" style="color: white">Sign Out</span></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>   
          </li>
        </ul>
    </div>
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?> 
    </div>
    <script src="<?php echo e(url('dash/js/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('dash/js/datatables/datatables.min.js')); ?>"></script>
    <script> $(document).ready(function() { $('#tab').DataTable( { "order": [[ 1, "asc" ]] } ); } ); </script>
</body>
</html>
<?php endif; ?>
<?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/master/admin.blade.php ENDPATH**/ ?>