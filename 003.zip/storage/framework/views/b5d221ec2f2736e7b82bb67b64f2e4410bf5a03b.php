<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>