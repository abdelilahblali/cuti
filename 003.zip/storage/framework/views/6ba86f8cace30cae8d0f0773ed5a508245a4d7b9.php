<?php $__env->startSection('content'); ?>

<style type="text/css">
  .w-5 { display: none  }
  .text-gray-700 { text-align: right;  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Construction / All Pictures </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">



    <div class="card card-page">
      <div class="card-body">
        <?php $__currentLoopData = $pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card card-xxl-stretch" style="margin-bottom: 20px">
            <img src="http://localhost/monProjetBali/public/imgs/a.jpg">
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    <div class="card card-page">
      <div class="card-body">
        <?php echo e($pics->links()); ?>

      </div>
    </div>



  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/getPhotosAll.blade.php ENDPATH**/ ?>