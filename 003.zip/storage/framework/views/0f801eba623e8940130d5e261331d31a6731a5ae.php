

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('etapes')); ?>" class="btn-right "><i class="fa fa-list"></i> List of steps </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Erreur')): ?>
  <div class="alert alert-danger">
    <?php echo e(session()->get('Erreur')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $etapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('etapesEdited',[ 'ref' => $etape->ref ])); ?>">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="vente" class="control-label form-label label01">Select a client<span class="c3_color">*</span></label></h6>
              <select name="vente" id="vente" class="form-control chzn-select">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vente->ref); ?>" <?php if($vente->ref==$etape->vente): ?> selected <?php endif; ?> ><?php echo e($vente->cod); ?> | <?php echo e($vente->civ); ?> <?php echo e($vente->nom); ?> <?php echo e($vente->pre); ?> | <?php echo e($vente->mail); ?> | <?php echo e($vente->tel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="etape" class="control-label form-label label01">STEP  </label></h6>
              <input type="text" name="etape" id="etape" class="form-control" value="<?php echo e($etape->etape); ?>"  />
          </div>
          <div class="col-md-3">
              <h6><label for="res1" class="control-label form-label label01">CONTRAT DE RESERVATION</label></h6>
              <select name="res1" id="res1" class="form-control">
                <option value="<?php echo e($etape->res1); ?>"><?php echo e($options[$etape->res1]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="res2" class="control-label form-label label01">CONTRAT DE RESERVATION "DATE"</label></h6>
              <input type="date" name="res2" id="res2" class="form-control" value="<?php echo e($etape->res2); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="part" class="control-label form-label label01">CONTRAT DE PARTENARIAT</label></h6>
              <select name="part" id="part" class="form-control">
                <option value="<?php echo e($etape->part); ?>"><?php echo e($options[$etape->part]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="fifty" class="control-label form-label label01">5000 </label></h6>
              <select name="fifty" id="fifty" class="form-control">
                <option value="<?php echo e($etape->fifty); ?>"><?php echo e($options[$etape->fifty]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="land1" class="control-label form-label label01">LAND : PROCURATION TERRAIN LEGALISÉE </label></h6>
              <select name="land1" id="land1" class="form-control">
                <option value="<?php echo e($etape->land1); ?>"><?php echo e($options[$etape->land1]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="land2" class="control-label form-label label01">LAND : LEASE AGREEMENT</label></h6>
              <select name="land2" id="land2" class="form-control">
                <option value="<?php echo e($etape->land2); ?>"><?php echo e($options[$etape->land2]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="land3" class="control-label form-label label01">LAND : PAIMENT TERRAIN</label></h6>
              <select name="land3" id="land3" class="form-control">
                <option value="<?php echo e($etape->land3); ?>"><?php echo e($options[$etape->land3]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="ptpma1" class="control-label form-label label01">PTPMA : NAMA PTPMA </label></h6>
              <input type="text" name="ptpma1" id="ptpma1" class="form-control" value="<?php echo e($etape->ptpma1); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="ptpma2" class="control-label form-label label01">PTPMA : PROCURATION LEGALISE </label></h6>
              <select name="ptpma2" id="ptpma2" class="form-control">
                <option value="<?php echo e($etape->ptpma2); ?>"><?php echo e($options[$etape->ptpma2]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
                <option value="2">Signe</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="ptpma3" class="control-label form-label label01">AKTA</label></h6>
              <select name="ptpma3" id="ptpma3" class="form-control">
                <option value="<?php echo e($etape->ptpma3); ?>"><?php echo e($options[$etape->ptpma3]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="ptpma4" class="control-label form-label label01">IMB </label></h6>
              <select name="ptpma4" id="ptpma4" class="form-control">
                <option value="<?php echo e($etape->ptpma4); ?>"><?php echo e($options[$etape->ptpma4]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="cons1" class="control-label form-label label01">CONTRAT CONSTRUCTION : DESIGN </label></h6>
              <input type="text" name="cons1" id="cons1" class="form-control" value="<?php echo e($etape->cons1); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="cons2" class="control-label form-label label01">CONTRAT CONSTRUCTION : NUMERO</label></h6>
              <input type="text" name="cons2" id="cons2" class="form-control" value="<?php echo e($etape->cons2); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="cons3" class="control-label form-label label01">CONTRAT CONSTRUCTION : DATE SIGNE</label></h6>
              <input type="date" name="cons3" id="cons3" class="form-control" value="<?php echo e($etape->cons3); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="buil" class="control-label form-label label01">BUILDING </label></h6>
              <input type="text" name="buil" id="buil" class="form-control" value="<?php echo e($etape->buil); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="meet" class="control-label form-label label01">MEETING DECO</label></h6>
              <select name="meet" id="meet" class="form-control">
                <option value="<?php echo e($etape->meet); ?>"><?php echo e($options[$etape->meet]); ?></option>
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-4">
              <h6><label for="loca" class="control-label form-label label01">LOCATION</label></h6>
              <input type="text" name="loca" id="loca" class="form-control" value="<?php echo e($etape->loca); ?>" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save </button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/etapesEdit.blade.php ENDPATH**/ ?>