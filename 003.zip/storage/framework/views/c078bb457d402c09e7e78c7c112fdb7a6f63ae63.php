

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Bient être</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style type="text/css">.fa-angle-right { color:#FEC007; padding-right: 8px  }</style>
        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 40px">
                            <img src="<?php echo e(url('imgs2/adult.jpg')); ?>" alt="image" width="90%" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Pour les <span>adultes</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Puisqu’ils contiennent 6 grammes de protéines de première qualité et 14 éléments nutriments clés, les œufs vous procurent l’énergie dont vous avez besoin. Ils représentent un excellent choix nutritif pour les gens qui mènent une vie active.
                            <br/>
                            Les œufs comptent parmi les rares aliments considérés comme une protéine complète, car ils contiennent tous les neuf (9) acides aminés essentiels. Les acides aminés servent essentiellement « d’éléments constitutifs pour le corps » puisqu’ils aident à former des protéines.
                            <br/>
                            En plus de vous donner de l’énergie, votre corps utilise également les protéines que l’on retrouve dans les œufs pour des fonctions particulières :

                            <ul>
                            <li><i class="fa fa-angle-right"></i> Construire et réparer les tissus et les cellules de l’organisme</li>
                            <li><i class="fa fa-angle-right"></i> Renforcer les cheveux et les ongles</li>
                            <li><i class="fa fa-angle-right"></i> Développer et entretenir des muscles en santé</li>
                            <li><i class="fa fa-angle-right"></i> Contribuer à combattre les infections</li>
                            <li><i class="fa fa-angle-right"></i> Equilibrer les liquides organiques</li>
                            </ul>
                            </p>

                            <p>
                                Selon le Guide alimentaire canadien, une alimentation saine et équilibrée passe par la consommation d’une à trois portions de Viandes et substituts par jour, selon l’âge et le sexe. Ces portions doivent inclure diverses sources de protéines, dont la viande, la volaille, le poisson, les légumineuses et les œufs.
                                <br/><br/>
                                <b>Les œufs = des protéines = de l’énergie durable</b>
                                <br/><br/>
                                Les protéines donnent l’impression de calmer la faim plus longtemps.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section" style="padding-top: -100px !important; background: rgba(0,0,0,0.04)" >
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Pourquoi ?</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p style="text-align: justify;">
                            Ceci est dû au fait que les protéines aident votre corps à régulariser la vitesse par laquelle l’énergie alimentaire (les calories) est absorbée. Par conséquent, consommer une bonne source de protéines au déjeuner, telle que des œufs, vous fournira l’énergie nécessaire pour rester actif(ve) et attentif(ve) plus longtemps.
                            <br/><br/>
                            Il est donc important de consommer plusieurs nutriments essentiels au déjeuner pour commencer la journée du bon pied. Le dîner et le souper sont également très importants puisqu’ils vous permettent de maintenir votre niveau d’énergie toute la journée.
                            <br/><br/>
                            Les aliments que vous consommez vous procurent l’énergie nécessaire pour poursuivre vos activités quotidiennes. C’est pourquoi vous devez manger à intervalles réguliers durant la journée. Pour vous aider à choisir des bons aliments pour votre style de vie et pour d’autres conseils sur des façons de maintenir votre niveau d’énergie pendant toute la journée.
                            <br/><br/>
                            Pour mener un style de vie sain, il faut d’abord commencer par bien s’alimenter. L’œuf est un aliment santé qui peut faire partie de n’importe quel repas. Il déborde de protéines pour vous donner de l’énergie durable, et il est aussi rempli de vitamines et de minéraux qui sont clés au bon fonctionnement de votre organisme.
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Vous pouvez probablement consommer plus <span>d’œufs que vous le pensez!</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Si vous évitiez de manger des œufs en raison de vos préoccupations liant le cholestérol à la maladie cardio-vasculaire, ravisez-vous. Les dernières recherches démontrent que les adultes en bonne santé peuvent consommer un œuf par jour sans augmenter leurs risques de maladie cardiovasculaire.
                            </p>

                            <div class="about_heading">
                                <h2>Les œufs : un élément important dans <span>un régime alimentaire sain …</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Les œufs figurent parmi les aliments les plus sains. Ils contiennent des protéines de qualité de même que des vitamines essentielles et des minéraux, dont l’acide folique, la vitamine B12, le zinc, le fer et le phosphore. L’élimination des œufs d’un régime alimentaire réduit considérablement les possibilités de choix de repas et empêche de bénéficier des nombreux avantages alimentaires qu’ils fournissent. Si vous croyez que vous ou votre enfant allergique ne retirez pas tous les nutriments dont vous avez besoin, renseignez-vous auprès de votre médecin où l’on pourra vous référer à un diététiste
                            </p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 20px">
                            <img src="<?php echo e(url('imgs2/diet.jpg')); ?>" alt="image" width="100%" />
                        </div>
                        <div class="about_img" style="margin-top: 20px">
                            <img src="<?php echo e(url('imgs2/i06.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/bien.blade.php ENDPATH**/ ?>