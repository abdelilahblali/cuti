<?php $__env->startSection('content'); ?>

<style type="text/css">
  .redBG { background: rgba(255, 0, 0, 0.3); !important; color: red !important; font-weight: bold; }
  .greenBG { background: rgba(0, 255, 0, 0.3); !important; color: green !important; font-weight: bold; }
</style>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> Steps  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">

  <table id="tableExport" class="cell-border display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Full name</td>

        <td>Reservation Contrat (MC)</td>
        <td>Reservation Contrat (Client)</td>
        <td>Rendering (MC)</td>
        <td>Rendering (Client)</td>
        <td>Upload Rendering Quotation (MC)</td>
        <td>Upload Rendering Quotation (Client)</td>
        <td>Construction Contrat (MC)</td>
        <td>Construction Contrat (Client)</td>

        <td>Name PTPMA & Name Villa (MC)</td>
        <td>Name PTPMA & Name Villa (Client)</td>
        <td>Procuration PTPMA (MC)</td>
        <td>Procuration PTPMA (Client)</td>
        <td>Acte Constitutif de Société (MC)</td>
        <td>Acte Constitutif de Société (Client)</td>
        <td>Bank Document (MC)</td>
        <td>Bank Document (Client)</td>

        <td>Power of attorney (MC)</td>
        <td>Power of attorney (Client)</td>
        <td>Lease agreement (MC)</td>
        <td>Lease agreement (Client)</td>
        <td>Neighborhood (MC)</td>
        <td>Neighborhood (Client)</td>

        <td>Design D1</td>
        <td>Design D1 Devis</td>
        <td>Photos D1</td>
        <td>Design D2</td>
        <td>Design D2 Devis</td>
        <td>Photos D2</td>
        <td>Design D3</td>
        <td>Design D3 Devis</td>
        <td>Photos D3</td>

        <td>Construction Drawing (MC)</td>
        <td>Construction Drawing (Client)</td>
        <td>MEP Drawing (MC)</td>
        <td>MEP Drawing (Client)</td>
        <td>Structure Drawing (MC)</td>
        <td>Structure Drawing (Client)</td>

        <td>1.1 (DP, START) </td>
        <td>1.2 (Foundation) </td>
        <td>2 (Structure) </td>
        <td>2.5 (Wall) </td>
        <td>3 (Roof) </td>
        <td>4 (Plester aci) </td>
        <td>4.5 (Ceiting) </td>
        <td>5 (Granit) </td>
        <td>5.1 (Stone) </td>
        <td>Finition </td>
        <td>6 (End) </td>

        <td>Deposit Amount</td>
        <td>Deposit Invoice</td>
        <td>Deposit Paid Invoice</td>
        <td>Deposit Proof document </td>
        <td>Land Amount</td>
        <td>Land Invoice</td>
        <td>Land Paid Invoice</td>
        <td>Land Proof document </td>
        <td>40% (1) Amount</td>
        <td>40% (1) Invoice</td>
        <td>40% (1) Paid Invoice</td>
        <td>40% (1) Proof document </td>
        <td>40% (2) Amount</td>
        <td>40% (2) Invoice</td>
        <td>40% (2) Paid Invoice</td>
        <td>40% (2) Proof document </td>
        <td>15% Amount</td>
        <td>15% Invoice</td>
        <td>15% Paid Invoice</td>
        <td>15% Proof document </td>
        <td>5% Amount</td>
        <td>5% Invoice</td>
        <td>5% Paid Invoice</td>
        <td>5% Proof document </td>

      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $recaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><span class="ref bold" style="color:black"><?php echo e($i['a1']); ?></span></td>
        <td><span class="bold" style="color:black"><?php echo e($i['a2']); ?> <?php echo e($i['a3']); ?> <?php echo e($i['a4']); ?></span></td>

        <td class="<?php if($i['b1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b1']); ?></td>
        <td class="<?php if($i['b2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b2']); ?></td>
        <td class="<?php if($i['b3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b3']); ?></td>
        <td class="<?php if($i['b4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b4']); ?></td>
        <td class="<?php if($i['b5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b5']); ?></td>
        <td class="<?php if($i['b6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b6']); ?></td>
        <td class="<?php if($i['b7']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b7']); ?></td>
        <td class="<?php if($i['b8']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['b8']); ?></td>

        <td class="<?php if($i['c1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c1']); ?></td>
        <td class="<?php if($i['c2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c2']); ?></td>
        <td class="<?php if($i['c3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c3']); ?></td>
        <td class="<?php if($i['c4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c4']); ?></td>
        <td class="<?php if($i['c5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c5']); ?></td>
        <td class="<?php if($i['c6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c5']); ?></td>
        <td class="<?php if($i['c7']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c7']); ?></td>
        <td class="<?php if($i['c8']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['c8']); ?></td>

        <td class="<?php if($i['d1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['d1']); ?></td>
        <td class="<?php if($i['d2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['d2']); ?></td>
        <td class="<?php if($i['d3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['d3']); ?></td>
        <td class="<?php if($i['d4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['d4']); ?></td>
        <td class="<?php if($i['d5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['d5']); ?></td>
        <td class="<?php if($i['d6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['d6']); ?></td>

        <td class="<?php if($i['e1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e1']); ?></td>
        <td class="<?php if($i['e2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e2']); ?></td>
        <td class="<?php if($i['e3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e3']); ?></td>
        <td class="<?php if($i['e4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e4']); ?></td>
        <td class="<?php if($i['e5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e5']); ?></td>
        <td class="<?php if($i['e6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e6']); ?></td>
        <td class="<?php if($i['e7']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e7']); ?></td>
        <td class="<?php if($i['e8']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e8']); ?></td>
        <td class="<?php if($i['e9']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['e9']); ?></td>

        <td class="<?php if($i['f1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['f1']); ?></td>
        <td class="<?php if($i['f2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['f2']); ?></td>
        <td class="<?php if($i['f3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['f3']); ?></td>
        <td class="<?php if($i['f4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['f4']); ?></td>
        <td class="<?php if($i['f5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['f5']); ?></td>
        <td class="<?php if($i['f6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['f6']); ?></td>

        <td class="<?php if($i['g1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g1']); ?></td>
        <td class="<?php if($i['g2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g2']); ?></td>
        <td class="<?php if($i['g3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g3']); ?></td>
        <td class="<?php if($i['g4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g4']); ?></td>
        <td class="<?php if($i['g5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g5']); ?></td>
        <td class="<?php if($i['g6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g6']); ?></td>
        <td class="<?php if($i['g7']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g7']); ?></td>
        <td class="<?php if($i['g8']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g8']); ?></td>
        <td class="<?php if($i['g9']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g9']); ?></td>
        <td class="<?php if($i['g10']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g10']); ?></td>
        <td class="<?php if($i['g11']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['g11']); ?></td>

        <td class="<?php if($i['h1']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h1']); ?></td>
        <td class="<?php if($i['h2']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h2']); ?></td>
        <td class="<?php if($i['h3']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h3']); ?></td>
        <td class="<?php if($i['h4']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h4']); ?></td>
        <td class="<?php if($i['h5']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h5']); ?></td>
        <td class="<?php if($i['h6']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h6']); ?></td>
        <td class="<?php if($i['h7']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h7']); ?></td>
        <td class="<?php if($i['h8']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h8']); ?></td>
        <td class="<?php if($i['h9']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h9']); ?></td>
        <td class="<?php if($i['h10']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h10']); ?></td>
        <td class="<?php if($i['h11']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h11']); ?></td>
        <td class="<?php if($i['h12']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h12']); ?></td>
        <td class="<?php if($i['h13']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h13']); ?></td>
        <td class="<?php if($i['h14']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h14']); ?></td>
        <td class="<?php if($i['h15']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h15']); ?></td>
        <td class="<?php if($i['h16']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h16']); ?></td>
        <td class="<?php if($i['h17']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h17']); ?></td>
        <td class="<?php if($i['h18']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h18']); ?></td>
        <td class="<?php if($i['h19']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h19']); ?></td>
        <td class="<?php if($i['h20']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h20']); ?></td>
        <td class="<?php if($i['h21']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h21']); ?></td>
        <td class="<?php if($i['h22']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h22']); ?></td>
        <td class="<?php if($i['h23']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h23']); ?></td>
        <td class="<?php if($i['h24']=='YES'): ?> greenBG <?php else: ?> redBG <?php endif; ?>"><?php echo e($i['h24']); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.min.js')); ?>"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/recap.blade.php ENDPATH**/ ?>