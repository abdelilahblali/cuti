<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <title>femmes de ménage et cuisinières à Casablanca et au Maroc | BAYTI HELP</title>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <meta name="description" content="">

        <meta name="keywords" content="">

        <meta name="author" content="kamleshyadav">

        <meta name="MobileOptimized" content="320">

        <!--Start Style -->

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/swiper.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/magnific-popup.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/layers.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/navigation.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/settings.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/range.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/nice-select.css')); ?>" >

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/style.css')); ?>">

        <link rel="shortcut icon" type="image/png" href="<?php echo e(url('assets/images/icon.svg')); ?>">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">

    </head>

    <body>
   

<div class="clv_main_wrapper index_v4">
    <div class="header3_wrapper">
        <div class="clv_header3" >
            <div class="row nave-top  d-none d-xl-block "  >
              <div class="container" >
                <div class="row ">
                    <div class="col-md-4 top-adrs" >
                     <h5>8 RUE D'ARMÉNIE, RÉSIDENCE ANAS - 2 MARS -CASABLANCA</h5>   
                    </div>

                    <div class="col-md-4 icon-top" >
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                        <i class="fa fa-skype" aria-hidden="true"></i>   
                        <img src="<?php echo e(url('assets/images/fig.svg')); ?>" width="25px">        
                    </div>
                    <div class="col-md-4 contact-top" >
                        <div class="row">
                            <div class="col-md-6">
                                <p><img src="<?php echo e(url('assets/images/phone.svg')); ?>" > <span style="font-size: 13px">+212  5 22 86 39 51</span></p>
                            </div>
                            <div class="col-md-6" style="border-left: 2px solid rgba(0,0,0,0.05);padding-right: 0px !important;">
                                <p><i class="fa fa-envelope-o" aria-hidden="true"></i><span style="font-size: 13px">contact@baytihelp.com</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
            <div class=" container" >
                <div class="row">
                    <div class="col-lg-2 col-md-2">
                        <div class="clv_left_header">
                            <div class="clv_logo">
                                <a href="index.html"><img src="<?php echo e(url('assets/images/logo.svg')); ?>" alt="Cultivation" width="106px" /></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-10">
                        <div class="clv_right_header">
                            <div class="clv_menu">
                                <div class="clv_menu_nav">
                                    <ul>
                                        <li><a href="about.html">Accueil</a></li>
                                        <li>
                                            <a href="javascript:;">Nos prestations</a>
                                            <ul>
                                                <li><a href="index.html">Ménage</a></li>
                                                <li><a href="index2.html">Cuisiniér</a></li>
                                                <li><a href="index3.html">Baby Sitter</a></li>
                                                <li><a href="index4.html">Chauffeur</a></li>
                                                <li><a href="index5.html">Agent de sécurité</a></li>
                                                <li><a href="index6.html">Formateur</a></li>
                                                <li><a href="index4.html">Coach sportif</a></li>
                                                <li><a href="index5.html">Grand Nettoyage</a></li>
                                                <li><a href="index6.html">Africaines subsahariennes</a></li>
                                                <li><a href="index6.html">Les asiatiques</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="<?php echo e(url('about')); ?>">Prestations à l'étranger</a></li>
                                        <li><a href="service.html">Réclamation et suggestion</a></li>
                                        <li><a href="gallery.html">Charte</a></li>
                                        <li><a href="gallery.html">Partenaires</a></li>
                                        <li><a href="gallery.html">Contact</a></li>
                                    </ul>
                                </div>
                                <div class="cart_nav">
                                    <ul>
                                        <li class="menu_toggle">
                                            <span>
                                                <?xml version="1.0" encoding="iso-8859-1"?>
                                                <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                     viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve" width="20px" height="20px">
                                                <g>
                                                    <g>
                                                        <path d="M2,13.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,13.5,2,13.5z"/>
                                                        <path d="M2,28.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,28.5,2,28.5z"/>
                                                        <path d="M2,43.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,43.5,2,43.5z"/>
                                                    </g>
                                                </g>
                                                </svg>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
  
   <?php echo $__env->yieldContent('content'); ?>  

  
 
    
    <div class="garden_service_about_wrapper  resrv">
        <div class="container">
            <div class="row ">
                <div class="col-md-3" style="text-align: center;">
                    <img src="<?php echo e(url('assets/images/logo-white.svg')); ?>" width="170px" >
                </div>
                <div class="col-md-9 resrv-form">
                    <form>
                        <h4>Réservez une femme de ménage près de chez vous en seulement 3 clics</h4>
                      <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Nom & prénom">
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="Téléphone">
                      </div>
                       <div class="form-group">
                        <input type="Email" class="form-control" id="formGroupExampleInput2" placeholder="Email">
                      </div>
                      <div class="form-group">
                        <button class="btn ">ok</button>
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="garden_shop_wrapper srvc-details">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-6">
                    <div class="text-center">
                        <h3>MEILLEURS SERVICES DE NETTOYAGE</h3>
                        <h4>CE QUE NOUS OFFRONS</h4>
                        <div class="separ_blue"></div>
                        <div class="separ_pink"></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="garden_shop_slider ">
                        <div class="swiper-container ">
                            <div class="swiper-wrapper ">
                             
                                <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('assets/img/9.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>NETTOYAGE COMMERCIAL</h5>
                                                <p>SERVICES DE NETTOYAGE PROFESSIONNELS DONT VOUS FAITES CONFIANCE</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('assets/img/9.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>ENTRETIEN DES TERRAINS</h5>
                                                <p>SERVICES DE NETTOYAGE PROFESSIONNELS DONT VOUS FAITES CONFIANCE</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                     <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <img src="<?php echo e(url('assets/img/9.jpg')); ?>" alt="image" class="img-fluid" />
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5>NETTOYAGE MAISON</h5>
                                                <p>SERVICES DE NETTOYAGE PROFESSIONNELS DONT VOUS FAITES CONFIANCE</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
    <!--Footer-->
    <div class="clv_footer_wrapper  footer-bayti">
        <div class="container">
            <div class=" return-haut text-center">
                <i class="fa fa-chevron-up" aria-hidden="true"></i> 
                <h4>RETOUR EN HAUT</h4>
            </div>
            <div class="row">
                    <div class="text-center nav-footer-menu" style="padding-left: 0px; padding-right: 0px">
                        <div class="clv_right_header">
                            <div class="clv_menu">
                                <div class="clv_menu_nav">
                                    <ul>
                                        <li><a href="about.html">Accueil</a></li>
                                        <li>
                                            <a href="javascript:;">Nos prestations</a>
                                            <ul>
                                                <li><a href="index.html">Ménage</a></li>
                                                <li><a href="index2.html">Cuisiniér</a></li>
                                                <li><a href="index3.html">Baby Sitter</a></li>
                                                <li><a href="index4.html">Chauffeur</a></li>
                                                <li><a href="index5.html">Agent de sécurité</a></li>
                                                <li><a href="index6.html">Formateur</a></li>
                                                <li><a href="index4.html">Coach sportif</a></li>
                                                <li><a href="index5.html">Grand Nettoyage</a></li>
                                                <li><a href="index6.html">Africaines subsahariennes</a></li>
                                                <li><a href="index6.html">Les asiatiques</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="about.html">Prestations à l'étranger</a></li>
                                        <li><a href="service.html">Réclamation et suggestion</a></li>
                                        <li><a href="gallery.html">Charte</a></li>
                                        <li><a href="gallery.html">Partenaires</a></li>
                                        <li><a href="gallery.html">Contact</a></li>
                                    </ul>
                                </div>
                                <div class="cart_nav">
                                    <ul>
                                        <li class="menu_toggle">
                                            <span>
                                                <?xml version="1.0" encoding="iso-8859-1"?>
                                                <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                     viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve" width="20px" height="20px">
                                                <g>
                                                    <g>
                                                        <path d="M2,13.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,13.5,2,13.5z"/>
                                                        <path d="M2,28.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,28.5,2,28.5z"/>
                                                        <path d="M2,43.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,43.5,2,43.5z"/>
                                                    </g>
                                                </g>
                                                </svg>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="row" style="margin-top: 40px">

                <div class="col-md-4 col-lg-4">
                  <div class="footer_block aprps aprps-footer">
                    <h4>A PROPOS</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in </p>
                      <a href="" class="btn btn-footer-aprps">Plus de détails </a>
                  </div>
                </div>

                 <div class="col-md-4 col-lg-4 ">
                  <div class="footer_block aprps ">
                    <h4>NOS SERVICES</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <div class="footer-services">
                        <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Ménage</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Cuisinière</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Baby Sitter</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Chauffeur</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Agent de sécurité</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Formateur</h6>
                      </div>
                      </div>
                  </div>
                </div>

                 <div class="col-md-4 col-lg-4">

                  <div class="footer_block aprps footer-cntct">
                    <h4>Contactez-nous</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <h6>Adresse</h6>
                      <p>8 RUE D’ARMÉNIE, RÉSIDENCE ANAS - 2 MARS  - CASABLANCA</p>
                      <h6>Téléphone</h6>
                      <p>+212 5 22 86 39 51</p>
                      <h6>Email</h6>
                      <p>contact@baytihelp.com</p>
                  </div>

                </div>

            </div>
            </div>
        </div>
    </div>
    <!--Copyright-->
    <div class="clv_copyright_wrapper">
      <div class="container">
        <p> &copy;  <a href="javascript:;">2BCOM .</a> 2020</p>
      </div>
    </div>
    <!--Popup-->
    <div class="search_box">
        <div class="search_block">
            <h3>Explore more with us</h3>
            <div class="search_field">
                <input type="search" placeholder="Search Here" />
                <a href="javascript:;">search</a>
            </div>
        </div>
        <span class="search_close">
            <?xml version="1.0" encoding="iso-8859-1"?>
            <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                 viewBox="0 0 47.971 47.971" style="enable-background:new 0 0 47.971 47.971;" xml:space="preserve"  width="30px" height="30px">
            <g>
                <path style="fill:#2a7d2e;" d="M28.228,23.986L47.092,5.122c1.172-1.171,1.172-3.071,0-4.242c-1.172-1.172-3.07-1.172-4.242,0L23.986,19.744L5.121,0.88
                    c-1.172-1.172-3.07-1.172-4.242,0c-1.172,1.171-1.172,3.071,0,4.242l18.865,18.864L0.879,42.85c-1.172,1.171-1.172,3.071,0,4.242
                    C1.465,47.677,2.233,47.97,3,47.97s1.535-0.293,2.121-0.879l18.865-18.864L42.85,47.091c0.586,0.586,1.354,0.879,2.121,0.879
                    s1.535-0.293,2.121-0.879c1.172-1.171,1.172-3.071,0-4.242L28.228,23.986z"/>
            </g>
            </svg>
        </span>
    </div>
    <!--Payment Success Popup-->
    <div class="success_wrapper">
        <div class="success_inner">
            <div class="success_img"><img src="images/success.png" alt=""></div>
            <h3>payment success</h3>
            <img src="images/clv_underline.png" alt="">
            <p>Your order has been successfully processed! Please direct any questions you have to the store owner. Thanks for shopping</p>
            <a href="javascript:;" class="clv_btn">continue browsing</a>
            <span class="success_close">
                <?xml version="1.0" encoding="iso-8859-1"?>
                <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        viewBox="0 0 212.982 212.982" style="enable-background:new 0 0 212.982 212.982;" xml:space="preserve" width="11px" height="11px" >
                <g>
                    <path fill="#fec007" style="fill-rule:evenodd;clip-rule:evenodd;" d="M131.804,106.491l75.936-75.936c6.99-6.99,6.99-18.323,0-25.312
                        c-6.99-6.99-18.322-6.99-25.312,0l-75.937,75.937L30.554,5.242c-6.99-6.99-18.322-6.99-25.312,0c-6.989,6.99-6.989,18.323,0,25.312
                        l75.937,75.936L5.242,182.427c-6.989,6.99-6.989,18.323,0,25.312c6.99,6.99,18.322,6.99,25.312,0l75.937-75.937l75.937,75.937
                        c6.989,6.99,18.322,6.99,25.312,0c6.99-6.99,6.99-18.322,0-25.312L131.804,106.491z"/>
                </g>
                </svg>
            </span>
        </div>
    </div>
    <!--Thank You Popup-->
    <div class="thankyou_wrapper">
        <div class="thankyou_inner">
            <div class="thankyou_img"><img src="images/thankyou.png" alt=""></div>
            <h3>your order is being processed</h3>
            <h5>We Have Just Sent You An Email With Complete Information About Your Booking</h5>
            <div class="download_button">
                <a href="javascript:;" class="clv_btn">download PDF</a>
                <a href="index.html" class="clv_btn">back to site</a>
            </div>
            <span class="success_close">
                <?xml version="1.0" encoding="iso-8859-1"?>
                <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        viewBox="0 0 212.982 212.982" style="enable-background:new 0 0 212.982 212.982;" xml:space="preserve" width="11px" height="11px" >
                <g>
                    <path fill="#fec007" style="fill-rule:evenodd;clip-rule:evenodd;" d="M131.804,106.491l75.936-75.936c6.99-6.99,6.99-18.323,0-25.312
                    c-6.99-6.99-18.322-6.99-25.312,0l-75.937,75.937L30.554,5.242c-6.99-6.99-18.322-6.99-25.312,0c-6.989,6.99-6.989,18.323,0,25.312
                    l75.937,75.936L5.242,182.427c-6.989,6.99-6.989,18.323,0,25.312c6.99,6.99,18.322,6.99,25.312,0l75.937-75.937l75.937,75.937
                    c6.989,6.99,18.322,6.99,25.312,0c6.99-6.99,6.99-18.322,0-25.312L131.804,106.491z"/>
                </g>
                </svg>
            </span>
        </div>
    </div>
    <!--SignUp Popup-->
    <div class="signup_wrapper">
        <div class="signup_inner">
            <div class="signup_details">
                <div class="site_logo">
                    <a href="index.html"> <img src="images/logo_white.png" alt="image"></a>
                </div>
                <h3>welcome to cultivation!</h3>
                <p>Consectetur adipisicing elit sed do eiusmod por incididunt uttelabore et dolore magna aliqu.</p>
                <a href="javascript:;" class="clv_btn white_btn pop_signin">sign in</a>
                <ul>
                    <li><a href="javascript:;"><span><i class="fa fa-facebook" aria-hidden="true"></i></span></a></li>
                    <li><a href="javascript:;"><span><i class="fa fa-twitter" aria-hidden="true"></i></span></a></li>
                    <li><a href="javascript:;"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a></li>
                    <li><a href="javascript:;"><span><i class="fa fa-youtube-play" aria-hidden="true"></i></span></a></li>
                </ul>
            </div>
            <div class="signup_form_section">
                <h4>create account</h4>
                <img src="images/clv_underline.png" alt="image">
                <div class="form_block">
                    <input type="text" class="form_field" placeholder="Name">
                </div>
                <div class="form_block">
                    <input type="text" class="form_field" placeholder="Email">
                </div>
                <div class="form_block">
                    <input type="text" class="form_field" placeholder="Password">
                </div>
                <a href="javascript:;" class="clv_btn">sign up</a>
                <div class="social_button_section">
                    <a href="javascript:;" class="fb_btn">
                        <span><img src="images/fb.png" alt="image"></span>
                        <span>facebook</span>
                    </a>
                    <a href="javascript:;" class="google_btn">
                        <span><img src="images/google.png" alt="image"></span>
                        <span>google+</span>
                    </a>
                </div>
                <span class="success_close">
                    <?xml version="1.0" encoding="iso-8859-1"?>
                    <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                            viewBox="0 0 212.982 212.982" style="enable-background:new 0 0 212.982 212.982;" xml:space="preserve" width="11px" height="11px" >
                    <g>
                        <path fill="#fec007" style="fill-rule:evenodd;clip-rule:evenodd;" d="M131.804,106.491l75.936-75.936c6.99-6.99,6.99-18.323,0-25.312
                        c-6.99-6.99-18.322-6.99-25.312,0l-75.937,75.937L30.554,5.242c-6.99-6.99-18.322-6.99-25.312,0c-6.989,6.99-6.989,18.323,0,25.312
                        l75.937,75.936L5.242,182.427c-6.989,6.99-6.989,18.323,0,25.312c6.99,6.99,18.322,6.99,25.312,0l75.937-75.937l75.937,75.937
                        c6.989,6.99,18.322,6.99,25.312,0c6.99-6.99,6.99-18.322,0-25.312L131.804,106.491z"/>
                    </g>
                    </svg>
                </span>
            </div>
        </div>
    </div>
    <!--SignIn Popup-->
    <div class="signin_wrapper">
        <div class="signup_inner">
            <div class="signup_details">
                <div class="site_logo">
                    <a href="index.html"> <img src="images/logo_white.png" alt="image"></a>
                </div>
                <h3>welcome to cultivation!</h3>
                <p>Consectetur adipisicing elit sed do eiusmod por incididunt uttelabore et dolore magna aliqu.</p>
                <a href="javascript:;" class="clv_btn white_btn pop_signup">sign up</a>
                <ul>
                    <li><a href="javascript:;"><span><i class="fa fa-facebook" aria-hidden="true"></i></span></a></li>
                    <li><a href="javascript:;"><span><i class="fa fa-twitter" aria-hidden="true"></i></span></a></li>
                    <li><a href="javascript:;"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a></li>
                    <li><a href="javascript:;"><span><i class="fa fa-youtube-play" aria-hidden="true"></i></span></a></li>
                </ul>
            </div>
         
            <div class="signup_form_section">
                <h4>sign in account</h4>
                <img src="images/clv_underline.png" alt="image">
                <div class="form_block">
                    <input type="text" class="form_field" placeholder="Email">
                </div>
                <div class="form_block">
                    <input type="text" class="form_field" placeholder="Password">
                </div>
                <a href="javascript:;" class="clv_btn">sign up</a>
                <div class="social_button_section">
                    <a href="javascript:;" class="fb_btn">
                        <span><img src="images/fb.png" alt="image"></span>
                        <span>facebook</span>
                    </a>
                    <a href="javascript:;" class="google_btn">
                        <span><img src="images/google.png" alt="image"></span>
                        <span>google+</span>
                    </a>
                </div>
                <span class="success_close">
                    <?xml version="1.0" encoding="iso-8859-1"?>
                    <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                            viewBox="0 0 212.982 212.982" style="enable-background:new 0 0 212.982 212.982;" xml:space="preserve" width="11px" height="11px" >
                    <g>
                        <path fill="#fec007" style="fill-rule:evenodd;clip-rule:evenodd;" d="M131.804,106.491l75.936-75.936c6.99-6.99,6.99-18.323,0-25.312
                        c-6.99-6.99-18.322-6.99-25.312,0l-75.937,75.937L30.554,5.242c-6.99-6.99-18.322-6.99-25.312,0c-6.989,6.99-6.989,18.323,0,25.312
                        l75.937,75.936L5.242,182.427c-6.989,6.99-6.989,18.323,0,25.312c6.99,6.99,18.322,6.99,25.312,0l75.937-75.937l75.937,75.937
                        c6.989,6.99,18.322,6.99,25.312,0c6.99-6.99,6.99-18.322,0-25.312L131.804,106.491z"/>
                    </g>
                    </svg>
                </span>
            </div>
        </div>
    </div>
    <!--Profile Toggle-->
</div>


       


    <script src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/swiper.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/magnific-popup.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.themepunch.tools.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.themepunch.revolution.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.appear.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.countTo.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/isotope.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/nice-select.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/range.js')); ?>"></script>



    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    

    <script src="<?php echo e(url('assets/js/revolution.extension.actions.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.kenburn.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.layeranimation.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.migration.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.parallax.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.slideanims.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.video.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>

    </body>





</html>

<?php /**PATH I:\Wamp\www\baytihelp\resources\views/master/pagess.blade.php ENDPATH**/ ?>