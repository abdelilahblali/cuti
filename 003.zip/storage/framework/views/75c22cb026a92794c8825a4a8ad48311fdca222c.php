

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-bell"></i> New marketing</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('marketing')); ?>" class="btn-right "><i class="fa fa-list"></i> List of marketings </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('marketingAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="villaname" class="control-label form-label label01">Villa name  </label></h6>
              <input type="text" name="villaname" id="villaname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-3">
              <h6><label for="landsize" class="control-label form-label label01">Land size  </label></h6>
              <input type="text" name="landsize" id="landsize" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-3">
              <h6><label for="buildingsize" class="control-label form-label label01">Building size </label></h6>
              <input type="text" name="buildingsize" id="buildingsize" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-3">
              <h6><label for="poolsize" class="control-label form-label label01">Pool Size   </label></h6>
              <input type="text" name="poolsize" id="poolsize" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="bankname" class="control-label form-label label01">Bank Name  </label></h6>
              <input type="text" name="bankname" id="bankname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="banknumber" class="control-label form-label label01">Bank Number  </label></h6>
              <input type="text" name="banknumber" id="banknumber" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="bank" class="control-label form-label label01">bank</label></h6>
              <input type="text" name="bank" id="bank" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="calendareu" class="control-label form-label label01">Calendar Eu  </label></h6>
              <input type="text" name="calendareu" id="calendareu" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="calendar" class="control-label form-label label01">Calendar  </label></h6>
              <input type="text" name="calendar" id="calendar" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="online" class="control-label form-label label01">Online  </label></h6>
              <input type="text" name="online" id="online" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="airbnb" class="control-label form-label label01">Airbnb Link  </label></h6>
              <input type="text" name="airbnb" id="airbnb" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="facebook" class="control-label form-label label01">Facebook Link  </label></h6>
              <input type="text" name="facebook" id="facebook" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="photo" class="control-label form-label label01">Photo Link  </label></h6>
              <input type="text" name="photo" id="photo" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="virtualtour" class="control-label form-label label01">Virtual Tour</label></h6>
              <input type="text" name="virtualtour" id="virtualtour" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="px" class="control-label form-label label01">PX  </label></h6>
              <input type="text" name="px" id="px" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="bop" class="control-label form-label label01">BOP Commun  </label></h6>
              <input type="text" name="bop" id="bop" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="aka" class="control-label form-label label01">AKA Comission</label></h6>
              <input type="text" name="aka" id="aka" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="magnitude" class="control-label form-label label01">Magnitude Web  </label></h6>
              <input type="text" name="magnitude" id="magnitude" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="where" class="control-label form-label label01">Where  </label></h6>
              <input type="text" name="where" id="where" class="form-control" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add Marketing</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#villaname").val(""); 
    $("#landsize").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'landGetInfo/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#villaname").val(response['data'][0].villaname); 
        $("#landsize").val(response['data'][0].ares); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#buildingsize").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'marketingGetBuilding/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#buildingsize").val(response['data'][0].buildingm2); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#bankname").val(""); 
    $("#banknumber").val(""); 
    $("#bank").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'taxeGetBank/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#bankname").val(response['data'][0].bankname);
        $("#banknumber").val(response['data'][0].banknumber); 
        $("#bank").val(response['data'][0].bank); 
       }
    });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/marketingAdd.blade.php ENDPATH**/ ?>