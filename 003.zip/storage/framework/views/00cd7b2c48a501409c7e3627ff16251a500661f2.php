

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $cmds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Détails de la commmande N° <span class="bold ref"><?php echo e($cmd->cod); ?></span></li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <div class="container-widget ">

    <div class="miniHeight">
      <div class="col-md-8">
        <div class="panel panel-default pad01">
            <div class="panel-body">
              <h5>Informations de la commande</h5>
              <div class="col-md-8">
                <div class="row">
                  <div class="col-md-4">
                      <h6><label for="dat" class="control-label form-label label01">Date : <span class="cmd-show"><?php echo e($cmd->dat); ?></span></label></h6>
                  </div>
                  <div class="col-md-8">
                      <h6><label for="pro" class="control-label form-label label01">Produit : <span class="cmd-show"><?php echo e($cmd->pro); ?></span></label></h6>
                  </div>
              </div>
              <div class="row">
                  <div class="col-md-4">
                      <h6><label for="pri" class="control-label form-label label01">Prix : <span class="cmd-show"><?php echo e(number_format($cmd->pri, 2)); ?> MAD</span></label></h6>
                  </div>
                  <div class="col-md-6">
                      <h6><label for="qte" class="control-label form-label label01">Quantité : <span class="cmd-show"><?php echo e($cmd->qte); ?></span></label></h6>
                  </div>
              </div>
            </div>
          </div>
        </div>

        <div class="panel panel-default pad01" style="margin-top: 20px">
          <div class="panel-body">
              <h5>Informations du client</h5>
              <div class="row">
                <div class="col-md-4">
                    <h6><label for="nom" class="control-label form-label label01">Nom : <span class="cmd-show"><?php echo e($cmd->nom); ?></span></label></h6>
                </div>
                <div class="col-md-8">
                    <h6><label for="tel" class="control-label form-label label01">Téléphone : <span class="cmd-show"><?php echo e(Str::limit($cmd->tel, 7, '###')); ?></span></label></h6>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <h6><label for="vil" class="control-label form-label label01">Ville : <span class="cmd-show"><?php echo e($cmd->vil); ?></span></label></h6>
                </div>
                <div class="col-md-8">
                    <h6><label for="adr" class="control-label form-label label01">Adresse : <span class="cmd-show"><?php echo e($cmd->adr); ?></span></label></h6>
                </div>
            </div>
          </div>
        </div>

        <div class="panel panel-default pad01" style="margin-top: 20px">
            <div class="panel-body">
              <h5>Informations Supplémentaires</h5>
            <div class="row">
                <div class="col-md-12">
                    <h6><label for="obs" class="control-label form-label label01">Observations : <span class="cmd-show"><?php echo e($cmd->obs); ?></span></label></h6>
                </div>
            </div>
            </div>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="panel panel-default pad01 etat" style="padding-top: 10px">
          <div class="panel-body etat ">
            <span class="etat<?php echo e($cmd->etat); ?>">L'état actuel de la commande : <?php echo e($etats[$cmd->etat]); ?></span></h5>
          </div>

          <div class="panel panel-default pad01 ">
            <div class="panel-body " style="padding-top: 5px">
              <span class="">Commander : <b><?php echo e($cmd->fait); ?></b></span><br/>
              <?php $__currentLoopData = $dats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class=" col-md-12 " style="width: 100%; background-color: rgba(0,0,0,0.1); margin-bottom: 2px">
                  <span style="width: 20px; margin-right: 15px" class="etat<?php echo e($dat->eta); ?>" ></span>
                  <?php echo e($etats[$dat->eta]); ?> : <b><?php echo e($dat->dat); ?></b>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

            <div class="panel-body">
              <h5>Commentaires</h5>
            </div>

          <div class="panel panel-default pad01" style="margin-top: 20px">
            <div class="panel-body" style="padding-top: 15px">
            <div class="row" id="msgbox2">
              <table data-page-length='40' class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
                <tbody>
                  <?php $__currentLoopData = $cmts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr >
                    <td>
                      <span style="font-size: 10px"><?php echo e($cmt->fait); ?></span><br/>
                      <span class="bold"><?php echo $cmt->cmt; ?></span>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            </div>
          </div>


        </div>
      </div>



        

      </div>

    </div>

  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/cmdShow.blade.php ENDPATH**/ ?>