

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
     <div class="clv_banner_slider" style="margin-top: 169px;">
        <!-- Swiper -->
        <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('../assets/img/11.jpg')); ?>');background-position: center;">
            <div class="container">
              <div class="row justify-content-center">
                <div class="col-md-4">
                  <div class="breadcrumb_inner">
                    <h3>Prestations à l'étranger</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
    </div>

    <div class="clv_about_wrapper clv_section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 img-about">
                    <div class="row">
                        <div class="col-md-6">
                           <div class="">
                                <img src="<?php echo e(url('assets/img/handsome-business-man-by-white-car.jpg')); ?>" alt="image" width="100%" />
                            </div>
                        </div>
                        <div class="col-md-6">
                           <div class="">
                                <img src="<?php echo e(url('assets/img/close-up-security-man-using-equipment.jpg')); ?>" alt="image" width="100%" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                           <div class="">
                                <img src="<?php echo e(url('assets/img/9.jpg')); ?>" alt="image" width="100%" />
                            </div>
                        </div>
                        <div class="col-md-6">
                           <div class="">
                                <img src="<?php echo e(url('assets/img/11.jpg')); ?>" alt="image" width="100%" />
                            </div>
                        </div>
                    </div>
                 
                </div>
                <div class="col-md-6">
                    <div class="about_content">
                        <div class="about_heading">
                            <h2 style="font-size: 28px;">Prestations à l'étranger <span style="color: #EC008C !important">Bayti Help</span></h2>
                        </div>
                        <p>Bayti Help jouit d’une expérience riche à l’étranger puisqu’elle opère dans tous les pays Arabe ainsi que quelques pays de l’Etat européen.</p>
                        <p>Notre agence vous offre une multitude de services mise à votre disposition tels que :</p>
                         
                        <div class=" meil-service-about">
                            <div class="row" >
                                 <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                                <h5>Femme de ménage polyvalente</h5>
                            </div>
                            <div class="row" >
                                 <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                                <h5>Cuisinière</h5>
                            </div>
                            <div class="row" >
                                 <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                                <h5>Nounou</h5>
                            </div>
                            <div class="row" >
                                 <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                                <h5>Agent de sécurité</h5>
                            </div>
                             <div class="row" >
                                 <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                                <h5>Gardien</h5>
                            </div>
                            
                        </div>
                        <p>Des profils complètement fiables, qualifiés et recommandés tout en respectant vos traditions et vos exigences.</p>
                        <p>Des agents envoyés sous forme d’un contrat à durée déterminée à votre disposition pour satisfaire vos besoins à temps plein.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.pagess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\baytihelp\resources\views/about.blade.php ENDPATH**/ ?>