<span style="background:white; padding-left: 20px; border-radius: 4px 4px 4px 4px; margin-right: 20px;">
<a href="<?php echo e(route('documentation')); ?>" style="font-weight: bold; color:black"><?php echo e(__('header.a17')); ?></a>
<a href="<?php echo e(route('documentation')); ?>" class="btn btn-icon btn-light pulse pulse-success" style="background:transparent !important;">
  <span class="svg-icon svg-icon-1"><svg></svg></span>
  <span class="pulse-ring"> </span> 
</a>
</span><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/master/aide.blade.php ENDPATH**/ ?>