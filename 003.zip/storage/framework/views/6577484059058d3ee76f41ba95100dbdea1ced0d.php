

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cogs"></i> Mise à jour les options de la boutique</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            <!-- <a href="<?php echo e(route('edition')); ?>" class="btn-right "><i class="fa fa-undo"></i> Retour</a> -->
          </div>
      </div>
  </div>
</div>



<div class="col-md-9">
  <?php if(session()->has('Modification')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Modification')); ?>

  </div>
  <?php endif; ?>

  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('pixelEdited')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        	<div class="col-md-12">
            	<h6><label for="head" class="control-label form-label label01">Code pixel "Open Page" <span class="c3_color">*</span></label></h6>
             <textarea name="head" class="form-control" placeholder="" rows="10" id="head"><?php echo e($head); ?></textarea>
        	</div>
      </div>
      <div class="row">
          <div class="col-md-12">
              <h6><label for="foot" class="control-label form-label label01">Code pixel "Achat" <span class="c3_color">*</span></label></h6>
             <textarea name="foot" class="form-control" placeholder="" rows="10" id="foot"><?php echo e($foot); ?></textarea>
          </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Sayvegarder </button>
        </div>
      </div>
    </form>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/pixel.blade.php ENDPATH**/ ?>