

<?php $__env->startSection('content'); ?>


<!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Actualités</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>Actualités</li>
                </ul>
            </div>
        </div>


        <div class="clv_blog_wrapper clv_section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading">
                            <h3>Actualités</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline3.png')); ?>" alt="image" /></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="blog_slider">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">

                                    <?php $__currentLoopData = $vids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide ">
                                        <div class="blog_slide">
                                            <div class="blog_image">
                                                <a href="<?php echo e(route('actualiteshow',[ 'ref' => $vid->ref ])); ?>"><img src="<?php echo e(url('actualites')); ?>/<?php echo e($vid->img); ?>" alt="image" class="img-fluid" /></a>
                                            </div>
                                            <div class="blog_content">
                                                <h6 class="blog_date"><?php echo e($vid->fait); ?></h6>
                                                <h4 class="blog_title"><a href="<?php echo e(route('actualiteshow',[ 'ref' => $vid->ref ])); ?>"><?php echo e($vid->des); ?></a></h4>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                            <!-- Add Arrows -->
                            <span class="slider_arrow blog_left left_arrow">
                                <svg 
                                 xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink"
                                 width="10px" height="20px">
                                <path fill-rule="evenodd"  fill="rgb(226, 226, 226)"
                                 d="M0.272,10.703 L8.434,19.703 C8.792,20.095 9.372,20.095 9.731,19.703 C10.089,19.308 10.089,18.668 9.731,18.274 L2.217,9.990 L9.730,1.706 C10.089,1.310 10.089,0.672 9.730,0.277 C9.372,-0.118 8.791,-0.118 8.433,0.277 L0.271,9.274 C-0.082,9.666 -0.082,10.315 0.272,10.703 Z"/>
                                </svg>
                            </span>
                            <span class="slider_arrow blog_right right_arrow">
                                <svg 
                                 xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink"
                                 width="10px" height="20px">
                                <path fill-rule="evenodd"  fill="rgb(226, 226, 226)"
                                 d="M9.728,10.703 L1.566,19.703 C1.208,20.095 0.627,20.095 0.268,19.703 C-0.090,19.308 -0.090,18.668 0.268,18.274 L7.783,9.990 L0.269,1.706 C-0.089,1.310 -0.089,0.672 0.269,0.277 C0.627,-0.118 1.209,-0.118 1.567,0.277 L9.729,9.274 C10.081,9.666 10.081,10.315 9.728,10.703 Z"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/twobcom/glurivd.com/om/resources/views/allacts.blade.php ENDPATH**/ ?>