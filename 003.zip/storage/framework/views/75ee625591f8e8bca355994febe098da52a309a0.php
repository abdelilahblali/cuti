

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>FISA</h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                   
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="about_content" style="text-align: center;">
                            <div class="about_heading">
                                <h2 style="font-weight: bold">Association National des Producteurs de Poules</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            L’ANPO est une association professionnelle au service des éleveurs de poules au Maroc.
                            <br/><br/>
                            Représenter la filière dans les situations locales, régionales, nationales et internationales. 
                            <br/><br/>
                            Améliorer les conditions techniques et sanitaires de production.
                            <br/><br/>
                            Contribuer à l'organisation de la production et la commercialisation d’œufs. Promouvoir la consommation d’œufs. 
                            <br/><br/>
                            Organiser et participer aux rencontres nationales et internationales traitant des thèmes en relation avec le secteur avicole.

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/fisa.blade.php ENDPATH**/ ?>