<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <title>BAYTI HELP : LAISSEZ TOMBER, ON RAMASSE LES PROBLÈMES !  </title>

        <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"  />

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <meta name="description" content="">

        <meta name="keywords" content="">

        <meta name="author" content="kamleshyadav">

        <meta name="MobileOptimized" content="320">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
        <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"  />
        <link rel="stylesheet" href="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link  rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"  />

        <!--Start Style -->

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/swiper.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/magnific-popup.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/layers.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/navigation.css')); ?>">
        

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/settings.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/range.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/nice-select.css')); ?>" >

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/style.css')); ?>">

        <link rel="shortcut icon" type="image/png" href="<?php echo e(url('assets/images/icon.svg')); ?>">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/sass" href="<?php echo e(url('assets/css/shar.sass')); ?>">

        <script type="text/javascript">
          function clos()
          {
            document.getElementById('covid').style.display='none';
          }
        </script>

        <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;500;600;700&display=swap" rel="stylesheet">


        <style type="text/css">
          .consultation {
            color: white;
            animation: wheelHueColor 10s infinite;
            background-color: currentColor;
          }
          @supports (background-blend-mode: overlay) {
            .consultation {
              background-image: linear-gradient(45deg, white 10%, black 90%);
              background-blend-mode: overlay;
            }
          }
          @keyframes  wheelHueColor {
            from, to { color: hsl(324, 100%, 46%); }
            10%      { color: hsl(206, 85%, 63%); }
            20%      { color: hsl(324, 100%, 46%); }
            30%      { color: hsl(206, 85%, 63%); }
            40%      { color: hsl(324, 100%, 46%); }
            50%      { color: hsl(206, 85%, 63%); }
            60%      { color: hsl(324, 100%, 46%); }
            70%      { color: hsl(206, 85%, 63%); }
            80%      { color: hsl(324, 100%, 46%); }
            90%      { color: hsl(206, 85%, 63%); }
          }
          * { margin: 0; padding: 0; }
          .consultation {
            display: flex;
          }
        </style>

    </head>

    
    <body>


<form method="POST" action="<?php echo e(route('search')); ?>">  
<?php echo e(csrf_field()); ?> 
<div class="sreach-nav-top" id="barrsaerch">
 <div class="center-div" style="">
  <i class="fa fa-times" onclick="barserch();" style="cursor: pointer;"></i>
    <div class="col-md-8 offset-md-2">
      <div class="row">
        <input type="text" name="search" class="form-control" placeholder="RECHERCHE" >
        <button class="btn btn-searsh-nav" style=""><i class="fa fa-search searsh" aria-hidden="true"></i> </button>
      </div>
    </div>
 </div>
</div>
</form>


<a href="#toptop" title="Retour en haut">
<button class="btn btn" style="position: fixed; left: 40px;  bottom: 40px; z-index: 9999 !important; background-color: #EC008C">
  <i class="fa fa-angle-up" style="color: white; font-size: 30px"></i>
</button>
</a>

<div class="clv_main_wrapper index_v4" id="toptop">
    <div class="header3_wrapper">
        <div class="clv_header3" >
            <div class="row nave-top  d-none d-xl-block "  >
              <div class="container" >
                <div class="row ">
                    <div class="col-md-4 top-adrs" >
                     <h5>8 RUE D'ARMÉNIE, RÉS. ANAS - 2 MARS -CASABLANCA</h5>   
                    </div>

                    <div class="col-md-3 icon-top" >
                        <a href="https://www.facebook.com/Bayti-Help-officiel-1708473266054530/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="https://www.facebook.com/Bayti-Help-officiel-1708473266054530/" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <a href="https://ma.linkedin.com/pub/bayti-help/60/400/367" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        <a href="https://wa.me/212649757540" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                    </div>
                    <div class="col-md-5 contact-top" >
                        <div class="row">
                            <div class="col-md-5" style="padding-left: 0">
                                <i style="font-size: 20px ;float: left; margin-top: 17px;margin-left: 18px;" class="fa fa-phone" ></i>
                                <a href="tel:+212522863951"><p style="    margin-top: 10px;"> <span style="font-size: 17px; color: #00aeef; font-weight: bold">+212  5 22 86 39 51 </span></p></a>
                                <a href="tel:+212649757540"><p style=" margin-top: -22px;margin-left: 0px;"><span style="font-size: 17px; color: #00aeef; font-weight: bold">+212 6 49 75 75 40 </span></p></a>
                            </div>
                            <div class="col-md-5" style="padding-left:0; border-left: 2px solid rgba(0,0,0,0.05);padding-right: 0px !important;">
                                <p><span style="font-size: 17px; color: #EC008C; font-weight: bold">contact@baytihelp.com</span></p>
                            </div>
                           <div class="col-md-2" style="padding-left:0; border-left: 2px solid rgba(0,0,0,0.05);padding-right: 0px !important;">
                              <div class="" style="background-color: black; z-index: 9999 !important;">
                                <input type="checkbox" id="click">
                                <label for="click" class="share-btn">
                                  <span class="fa fa-share-alt"><i class="fa fa-share-alt" style="color:white"></i></span>
                                  <a target="_blank" href="https://wa.me/212649757540"><span class="fa fa-whatsapp"><i class="fa fa-whatsapp" style="color:white"></i></span></a>
                                  <a target="_blank" href="https://www.facebook.com/Bayti-Help-officiel-1708473266054530/"><span class="fa fa-instagram"><i class="fa fa-instagram" style="color:white"></i></span></a>
                                  <a target="_blank" href="https://www.facebook.com/Bayti-Help-officiel-1708473266054530/"><span class="fa fa-facebook"><i class="fa fa-facebook" style="color:white"></i></span></a>
                                  <a target="_blank" href="https://ma.linkedin.com/pub/bayti-help/60/400/367"><span class="fa fa-linkedin"><i class="fa fa-linkedin" style="color:white"></i></span></a>
                                </label>
                              </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
          <div class=" container" >
              <div class="row" style="    background: white;">
                  <div class="col-lg-1 col-md-1">
                      <div class="clv_left_header">
                          <div class="clv_logo">
                              <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('imgs/logo/logo.svg')); ?>" alt="Cultivation" width="106px" /></a>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-5">
                    <h2 style="padding-top:23px; padding-left: 30px; font-size: 25px; font-weight: bold; color:black">
                    <span style="color:#ec008c">LAISSEZ TOMBER,</span><br/><span style="color:#00AEEF">ON RAMASSE LES PROBLÈMES !</span></h2>
                  </div>
                  <div class="col-lg-6 col-md-6">
                      <div class="clv_right_header">
                          <div class="clv_menu">
                              <div class="clv_menu_nav">
                                  <ul>
                                      <li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
                                      <li>
                                          <a href="javascript:;">A propos</a>
                                          <ul>
                                              <li><a href="<?php echo e(url('histoire')); ?>">Notre histoire</a></li>
                                              <li><a href="<?php echo e(url('pourquoi')); ?>">Pourquoi nous choisir?</a></li>
                                              <li><a href="<?php echo e(url('equipe')); ?>">Notre équipe </a></li>
                                              <li><a href="<?php echo e(url('partenaires')); ?>">Partenaires</a></li>
                                          </ul>
                                      </li>

                                      <li>
                                          <a href="<?php echo e(url('services')); ?>">Services</a>
                                          <ul>
                                              <li><a href="#">Femme de ménage</a></li>
                                              <li style="padding-left: 10px"><a href="<?php echo e(url('marocaines')); ?>"><i class="fa fa-angle-right" aria-hidden="true" style="padding-right: 10px"></i> Les marocaines </a></li>
                                              <li style="padding-left: 10px"><a href="<?php echo e(url('africaines')); ?>"><i class="fa fa-angle-right" aria-hidden="true" style="padding-right: 10px"></i> Les africaines subsahariennes  </a></li>
                                              <li style="padding-left: 10px"><a href="<?php echo e(url('asiatiques')); ?>"><i class="fa fa-angle-right" aria-hidden="true" style="padding-right: 10px"></i> Les asiatiques  </a></li>
                                              <li style="padding-left: 10px"><a href="<?php echo e(url('printemps')); ?>"><i class="fa fa-angle-right" aria-hidden="true" style="padding-right: 10px"></i> Ménage de printemps </a></li>

                                              <li><a href="<?php echo e(url('cuisinieres')); ?>">Cuisinières diplômées et expérimentées</a></li>

                                              <li><a href="<?php echo e(url('nounous')); ?>">Nounous diplômées et/ou expérimentées</a></li>

                                              <li><a href="<?php echo e(url('noubonnes')); ?>">Noubonnes</a></li>

                                              <li><a href="<?php echo e(url('dame')); ?>">Dame de Compagnie</a></li>

                                              <li><a href="<?php echo e(url('chauffeurs')); ?>">Chauffeurs </a></li>

                                              <li><a href="<?php echo e(url('coach')); ?>">Des coachs sportifs et diététiciens </a></li>

                                              <li><a href="<?php echo e(url('aide')); ?>">Aides aux devoirs et remises à niveau </a></li>

                                              <li><a href="<?php echo e(url('jardiniers')); ?>">Jardiniers/Paysagiste  </a></li>

                                              <li><a href="<?php echo e(url('securite')); ?>">Agent de sécurité  </a></li>

                                              <li><a href="<?php echo e(url('gardiens')); ?>">Couple de gardiens  </a></li>

                                              <li><a href="<?php echo e(url('majordome')); ?>">Majordome/Gouvernante  </a></li>

                                          </ul>
                                      </li>

                                      <li>
                                          <a href="javascript:;">Blog / Astuces</a>
                                          <ul>
                                              <li><a href="<?php echo e(url('blog1')); ?>">Astuces Ménage</a></li>
                                              <li><a href="<?php echo e(url('blog2')); ?>">Astuces santé</a></li>
                                          </ul>
                                      </li>
                                      <li><a href="<?php echo e(url('contacts')); ?>">Contact</a></li>

                                      <li><i class="fa fa-search searsh" aria-hidden="true" onclick="barserch();" style="cursor: pointer;"></i></li>
                                  </ul>
                                  <script type="text/javascript">
                                      document.getElementById('barrsaerch').style.display="none";
                                      var etat="true";
                                      function barserch(){
                                          if ( etat=="true") {
                                            document.getElementById('barrsaerch').style.display="block";
                                            etat='false';
                                          }
                                           else if ( etat=="false") {
                                            document.getElementById('barrsaerch').style.display="none";
                                            etat="true";
                                          }
                                      };
                                  </script>
                              </div>
                              <div class="cart_nav">
                                  <ul>
                                      <li class="menu_toggle">
                                          <span>
                                              <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                   viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve" width="20px" height="20px">
                                              <g>
                                                  <g>
                                                      <path d="M2,13.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,13.5,2,13.5z"/>
                                                      <path d="M2,28.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,28.5,2,28.5z"/>
                                                      <path d="M2,43.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,43.5,2,43.5z"/>
                                                  </g>
                                              </g>
                                              </svg>
                                          </span>
                                      </li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              
          </div>
        </div>
    </div>
    
    <?php echo $__env->yieldContent('content'); ?>  
    
    <!--Footer-->
    <div class="clv_footer_wrapper  footer-bayti">
        <div class="container">
            <div class=" return-haut text-center" style="padding-top: 30px">
                <a href="#"><i class="fa fa-chevron-up" aria-hidden="true" style="font-size: 15px !important"></i> 
                <h4 style="font-size: 14px; font-weight:bold">RETOUR EN HAUT</h4></a>
            </div>
            <div class="row">
                    <div class="text-center nav-footer-menu" style="padding-left: 0px; padding-right: 0px">
                        <div class="clv_right_header">
                            <div class="clv_menu">
                                <div class="clv_menu_nav">
                                    
                                </div>
                                <div class="cart_nav">
                                    <ul>
                                        <li class="menu_toggle">
                                            <span>
                                                <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                     viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve" width="20px" height="20px">
                                                <g>
                                                    <g>
                                                        <path d="M2,13.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,13.5,2,13.5z"/>
                                                        <path d="M2,28.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,28.5,2,28.5z"/>
                                                        <path d="M2,43.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,43.5,2,43.5z"/>
                                                    </g>
                                                </g>
                                                </svg>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="row" style="margin-top: 40px">

                <div class="col-md-4 col-lg-4">
                  <div class="footer_block aprps aprps-footer">
                    <h4>BaytiHelp</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <p>Notre expérience et nos connaissances sont essentielles pour y parvenir, mais le savoir-faire, le travail sans relâche et la fiabilité de nos employés sont encore plus importants. Nous investissons donc dans la formation de notre main-d’œuvre et à sa motivation. Nous en tirons profit tout autant que nos précieux employés et clients.</p>
                      <a href="<?php echo e(url('about')); ?>" class="btn btn-footer-aprps">Plus de détails </a>
                  </div>
                </div>

                






                 <div class="col-md-4 col-lg-4 ">
                  <div class="footer_block aprps ">
                    <h4>NOS SERVICES</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <div class="footer-services">
                        <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Femme de ménage</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Les africaines subsahariennes</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Ménage de printemps</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Les marocaines</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Cuisinières diplômées et expérimentées</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Nounous diplômées et/ou expérimentées</h6>
                      </div>
                      </div>
                  </div>
                </div>

                 <div class="col-md-4 col-lg-4">

                  <div class="footer_block aprps footer-cntct">
                    <h4>Contactez-nous</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <h6>Adresse</h6>
                      <p>8 RUE D’ARMÉNIE, RÉSIDENCE ANAS - 2 MARS  - CASABLANCA</p>
                      <h6>Téléphone</h6>
                      <p>+212 5 22 86 39 51 | +212 6 49 75 75 40</p>
                      <h6>Email</h6>
                      <p>contact@baytihelp.com</p>
                  </div>

                </div>

            </div>
            </div>
        </div>
    </div>

    <div class="clv_copyright_wrapper">
      <div class="container">
        <p> &copy;  <a href="javascript:;">2BCOM .</a> 2020</p>
      </div>
    </div>
    
    <!-- <a href="tel:+212 5 22 86 39 51">
      <div class="telephone animate__animated animate__jello animate__bounce animate__infinite">
        <i class="fa fa-phone"></i>
      </div>
    </a> -->


    <div class="phonering-alo-phone phonering-alo-green phonering-alo-show" id="phonering-alo-phoneIcon" style="position: fixed;  bottom: 200px; right: 250px; z-index: 9999 !important">
    <div class="phonering-alo-ph-circle"></div>
     <div class="phonering-alo-ph-circle-fill"></div>
    <a href="tel:+212522863951" class="pps-btn-img" title="Appelez-nous">
     <div class="phonering-alo-ph-img-circle"></div>
     </a>
    </div>





   <!--  <div style=" position: fixed;bottom: 10px; right: 30px;z-index: 100">
      
      <div class="chat" style="" id="chat">
        <div class="info-chat">

            <div class="col-md-10 " >

                <div class="row">

                  <img src="<?php echo e(url('imgs/logo/logo.svg')); ?>" width="18%">
                  <h1 > TCHAT BAYTI</h1>

                </div>

                <div class="row">

                  <p >Pour toute question, échangez directement avec notre équipe de concierges.</p>

                </div>

            </div>

        </div>

        <div class="dsecu" >
        

          <div class="col-md-12" style="" >

            <div class="message1"  >Lorem Ipsum</div>
            <div class="msg2" >message <span style="">11:00</span></div>
         
          </div>
            <div class="col-md-12" style="" >

            <div class="message1"  >Lorem Ipsum</div>
            <div class="msg2" >message <span style="">11:00</span></div>
         
          </div>
             
          
        </div>

         <div class="row">
              <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Tapez votre message ">
              <button class="btn btn-chat">ENVOYER</button>
         </div>

       </div>

        <div class="row info_chat_text" style=""> 

            <div class="col-md-8">
                  <h6>Pour toute question, échangez directement avec notre équipe de BaytiHelp.</h6>
            </div> 

        </div>

      <div class="closeed animate__animated  animate__headShake animate__infinite"  id="closed" onclick="chatt();">
        <img src="<?php echo e(url('imgs/logo/logo-white.svg')); ?>" id="imglogo">
        <i class="fa fa-times "  id="iconclose" style="cursor: pointer;"></i>
      </div>


      <script type="text/javascript">
        var cosed =document.getElementById('closed');
        var imglogo =document.getElementById('imglogo');
        var iconclose =document.getElementById('iconclose');
        var chat  =document.getElementById('chat');

        chat.style.display='none';
        iconclose.style.display='none';

        var eta='true';

       function  chatt(){

         if (eta=='true') {

          imglogo.style.display='block';
          iconclose.style.display='none';
          chat.style.display='none';

          eta='false';

        }
        else if (eta=='false') {
          imglogo.style.display='none';
          iconclose.style.display='block';
          chat.style.display='block';
          eta='true';

        }
       }

      </script>

    </div> -->

    
  

    


   

</div>


       


    <script src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/swiper.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/magnific-popup.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.themepunch.tools.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.themepunch.revolution.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.appear.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.countTo.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/isotope.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/nice-select.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/range.js')); ?>"></script>



    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    

    <script src="<?php echo e(url('assets/js/revolution.extension.actions.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.kenburn.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.layeranimation.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.migration.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.parallax.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.slideanims.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.video.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>



    </body>





</html>

<?php /**PATH I:\Wamp\www\monprojetbali\admin\resources\views/master/page.blade.php ENDPATH**/ ?>