<?php $__env->startSection('content'); ?>

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">Construction</h4>
<div class="col-md-12">
  <div class="panel panel-default client-content">
    <form method="POST" action="<?php echo e(route('clientFolder_construction_updated',[ 'cli' => $ref ] )); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
      <div class="row" style="margin-top: 0px">
        <div class="col-md-2">
          <h6><label for="a0" class="control-label form-label label01">1.1 (DP, START) </label></h6>
          <input type="date" name="a0" class="form-control" value="<?php echo e($a0); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a1" class="control-label form-label label01">1.2 (Foundation) </label></h6>
          <input type="date" name="a1" class="form-control" value="<?php echo e($a1); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a2" class="control-label form-label label01">2 (Structure) </label></h6>
          <input type="date" name="a2" class="form-control" value="<?php echo e($a2); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a3" class="control-label form-label label01">2.5 (Wall) </label></h6>
          <input type="date" name="a3" class="form-control" value="<?php echo e($a3); ?>">
        </div>

        <div class="col-md-2">
          <h6><label for="a4" class="control-label form-label label01">3 (Roof) </label></h6>
          <input type="date" name="a4" class="form-control" value="<?php echo e($a4); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a5" class="control-label form-label label01">4 (Plester aci)  </label></h6>
          <input type="date" name="a5" class="form-control" value="<?php echo e($a5); ?>">
        </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-2">
          <h6><label for="a6" class="control-label form-label label01">4.5 (Ceiting)  </label></h6>
          <input type="date" name="a6" class="form-control" value="<?php echo e($a6); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a7" class="control-label form-label label01">5 (Granit)  </label></h6>
          <input type="date" name="a7" class="form-control" value="<?php echo e($a7); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a8" class="control-label form-label label01">5.1 (Stone) </label></h6>
          <input type="date" name="a8" class="form-control" value="<?php echo e($a8); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a9" class="control-label form-label label01">Finition  </label></h6>
          <input type="date" name="a9" class="form-control" value="<?php echo e($a9); ?>">
        </div>
        <div class="col-md-2">
          <h6><label for="a10" class="control-label form-label label01">6 (End)  </label></h6>
          <input type="date" name="a10" class="form-control" value="<?php echo e($a10); ?>">
        </div>
      </div>
      <!-- <div class="row" style="margin-top: 20px">
        <div class="col-md-12">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div> -->
    </form>
  </div>
</div>

<script type="text/javascript">
    document.querySelectorAll('input[type="text"]').forEach(e => {
      e.addEventListener('focusout', setInputBackground)
    });
    document.querySelectorAll('input[type="date"]').forEach(e => {
      e.addEventListener('focusout', setInputBackground)
    });

    document.querySelectorAll('select').forEach(e => {
      e.addEventListener('focusout', setInputBackground)
    });

    function setInputBackground() {
      this.style.backgroundColor = !!this.value ? "#e0ffef" : "#ffe8e5";
    }

    var inputs, index;
    inputs = document.getElementsByTagName('input');
    for (index = 0; index < inputs.length; ++index) {
      // deal with inputs[index] element.
      inputs[index].style.backgroundColor = !!inputs[index].value ? "#e0ffef" : "#ffe8e5";
    }

    var inputs2, index2;
    inputs2 = document.getElementsByTagName('select');
    for (index2 = 0; index2 < inputs2.length; ++index2) {
      inputs2[index2].style.backgroundColor = !!inputs2[index2].value ? "#e0ffef" : "#ffe8e5";
    }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientFolder_construction.blade.php ENDPATH**/ ?>