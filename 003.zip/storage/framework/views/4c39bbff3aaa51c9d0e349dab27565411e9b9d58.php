<?php echo e($slot); ?>

<?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>