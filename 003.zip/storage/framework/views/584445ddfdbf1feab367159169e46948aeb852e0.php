

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>L'élevage des poules pondeuses</h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: -40px">
                            <img src="<?php echo e(url('pages/oeuf.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Le marché marocain <span>des œufs</span> en chiffres </h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Le Maroc dispose d’un nombre total de fermes de production d’œufs de consommation estimé à 500 fermes et comportant près de 14 millions de poules pondeuses qui donnent lieu à une production totale d’environ 2.5 milliards d’œufs par an.
                            <br/><br/>
                            Malgré la progression remarquable de la consommation moyenne d’œufs par habitant et par an enregistrée durant la dernière décennie, le Maroc demeure sous la barre de consommation mondiale moyenne des œufs. Une consommation qui a pris un coup dur à cause de la pandémie du Coronavirus.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section" style="padding-top: -100px !important; background: rgba(0,0,0,0.04)" >
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Élevages de  <span>reproducteurs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Une bonne descendance commence par un bon élevage de reproducteurs qui sont les parents des poules pondeuses élevées dans nos fermes. Ces reproducteurs sont choisis minutieusement par des experts et selon différents critères dont la viabilité, la conformation, le poids vif et la quantité alimentaire nécessaire pour produire un œuf. 
                            <br/><br/>
                            Le processus de l’élevage des reproducteurs passe par différentes étapes allant de la phase élevage, qui débute du premier jour à la 16ème semaine, à la phase reproduction qui commence dès la 14ème semaine allant jusqu’à la fin de la 80ème semaine.
                            <br/><br/>
                            Lors de la phase d’élevage, l’éleveur peut procéder de deux manières différentes : 
                            </p>
                            <ul style="font-weight: bold ">
                                <li>Une conduite séparée qui consiste à isoler les mâles et les femelles jusqu’à la phase de reproduction où ils sont mis dans l’espace dédié à cette opération.</li>
                                <li>Une conduite mélangée qui consiste à élever les deux sexes dans le même endroit, sauf que dans ce cas il est impératif que le poids vif des mâles mélangés dépasse celui des femelles de 40%, et la nourriture distribuée doit être basée sur le poids des femelles et non celui des mâles.</li>
                            </ul>
                            <br/><br/>
                            <p>
                                L’objectif de la reproduction est donc des œufs destinés à être mis au couvoir.
                            </p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 140px">
                            <img src="<?php echo e(url('pages/oeuf1.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 40px">
                            <img src="<?php echo e(url('imgs2/i03.jpg')); ?>" alt="image" width="80%" />
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Au niveau des   <span>couvoirs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Les couvoirs représentent un maillon important de la chaine de production des œufs, c’est là où les œufs prélevés auprès des reproducteurs sont incubés pour donner lieu à des poussins. Ces couvoirs sont équipés de systèmes de chauffage, ventilation, climatisation, d’incubateurs, d’éclosoirs etc… nécessaires pour une bonne portée de poussins conçus avec attention dans des conditions exemplaires et semblables à la couvaison naturelle des mamans poules.
                            <br/><br/>
                            L’opération d’éclosion prend généralement 21 jours. Une fois effectuée, les poussins sont immédiatement transférés dans les espaces dédiés à l’élevage des poules pondeuses.
                            <br/><br/>
                            A leur arrivée, une opération massive de désinfection et de dératisation est appliquée à l’ensemble de la ferme et des espaces dédiés à l’élevage des poussins vu leur vulnérabilité et leur condition fragile. Cette opération concerne également l’ensemble du matériel utilisé dans les poulaillers afin de réduire le plus possible le risque d’exposition à des infections chez les poussins.
                            <br/><br/>
                            Une fois adultes, les poussins commencent à remplir leur rôle de poule pondeuse. Ainsi, une alimentation saine et équilibrée est indispensable pour avoir des œufs de bonne qualité. 
                            <br/><br/>
                            Il est nécessaire de varier l’alimentation des poules pondeuses et d’opter pour une composition de produits naturels énergétiques du type maïs, orge,… et riches en protéines (tourteaux de soja et de tournesol, farine de poissons,…), ainsi que des compléments d’acides aminés essentiels, minéraux et vitamines, broyés et mélangés dans des proportions équilibrées pour des œufs de qualité.
                            </p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section" style="padding-top: -100px !important; background: rgba(0,0,0,0.04)" >
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Collecte et classement <span>des œufs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p style="text-align: justify; padding-right: 30px">
                            Une fois les conditions réunies, les poules commencent à prendre leurs marques dans le poulailler et donc à pondre.  La ponte est généralement faite le matin, mais ça reste une variable non systématique qui dépend de multiples facteurs dont l’âge des poules, la saison, la qualité de la nourriture et de la poule elle-même. 
                            <br/><br/>
                            La collecte des œufs est une opération qui doit se faire à deux reprises par jour, un premier ramassage vers midi et un autre le soir pour éviter que les œufs se salissent ou soient cassés. 
                            <br/><br/>                            
                            </p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 70px">
                            <img src="<?php echo e(url('imgs2/i04.jpg')); ?>" alt="image" width="80%" />
                        </div>
                    </div>

                    <div class="col-md-11">
                        <div class="about_content">
                            <p style="font-weight: bold;">
                            Les œufs cassés ou fêlés sont immédiatement écartés lors du tri. Les autres sont triés selon leur poids en quatre catégories :
                            </p>
                            <br/>
                            <table class="table table-bordered">
                                <tr>
                                    <td>Petit calibre </td>
                                    <td style="background: #FEC007; color:white; font-weight: bold"><50 gr </td>
                                </tr>
                                <tr>
                                    <td>Moyen calibre </td>
                                    <td style="background: #FEC007; color:white; font-weight: bold">50 à 58 gr</td>
                                </tr>
                                <tr>
                                    <td>Gros calibre </td>
                                    <td style="background: #FEC007; color:white; font-weight: bold">58 à 68 gr</td>
                                </tr>
                                <tr>
                                    <td>Extra gros </td>
                                    <td style="background: #FEC007; color:white; font-weight: bold">>68 gr</td>
                                </tr>
                            </table>
                            <br/>
                            <p>
                                Les œufs sont ensuite stockés dans des boites cartonnées ou plastifiées de 6, 9, 12, 16, 24 ou 30 unités. 
                                <br/>
                                Les œufs doivent être transportés dans des conteneurs lisses, facilement lavables, désinfectables et étanches réservés à cet effet.
                                <br/>
                                Tout au long du circuit, les œufs doivent être conservés propres et secs, à l’abri des nuisibles, des odeurs, et bien protégés du soleil et des chocs. 
                                <br/>
                                En vente, il est recommandé de placer les œufs dans vitrines réfrigérées à une température qui varie entre 4° et 5° 
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\baytihelp\resources\views/about1.blade.php ENDPATH**/ ?>