<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-12">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">NOS CHIFFRES PARLENT D’EUX-MÊMES </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                  <div class="garden_service2_wrapper  meil-service">
                    <div class="container">
                        <div class="row" style="margin-bottom: 50px">
                          <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                <h2 style=""><span style="color:#EC008C; padding-left: 5px">Bayti</span><span style="color:#00AEEF ">Help</span> TOUJOURS IMITÉE, JAMAIS ÉGALÉE </h2>
                          </div>
                          <div class="col-md-6">
                                <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                <div class="lin-blue" ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class=" ">
                  <div class="container">

                <div class="row">
                  <div class="col-md-4">

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-rocket " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Plus de 12 ans d’expérience </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-check" style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Vérification des références des anciens employeurs </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-cog " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>SAH : Service après Help </span>
                        </div>
                      </div>


                  </div>
                  <div class="col-md-4">

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-clock-o " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Une entreprise PIONNIÈRE </span>
                          <p>Un réseau riche et fiable étendu sur tout le royaume marocain depuis plus de 12 ans.<br/>Il est bien connu que c’est dans les vieux pots que l’on fait les meilleures confitures.</p>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-tag " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Des garanties administratives certifiées </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-sign-language " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>De solides partenaires </span>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-4">

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-university " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Vérification des antécédents judiciaires </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-diamond" style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Plus que des employés de maison, une communauté de Helpers </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-lock " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>La sécurité de nos Helpers et nos clients est la première priorité de BAYTIHELP </span>
                        </div>
                      </div>

                  </div>
                </div>
           
        </div>
    </div>

  </div>

  <div class="clv_counter_wrapper clv_section">
                                  <div class="container">
                                    <div class="counter_section">
                                      <div class="row">
                                        <div class="col-lg-3 col-md-3">
                                          <div class="counter_block">
                                            <div class="counter_img">
                                              <span class="red_bg"><i class="fa fa-street-view" style="transform: rotate(45deg); color:white; font-size: 30px; padding: 24px;"></i></span>
                                            </div>
                                            <div class="counter_text">
                                              <h4><span class="count_no" data-to="8200" data-speed="3000">8200</span><span>+</span></h4>
                                              <h5>Foyers Helpés</h5>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3">
                                          <div class="counter_block">
                                            <div class="counter_img">
                                              <span class="yellow_bg"><i class="fa fa-check" style="transform: rotate(45deg); color:white; font-size: 30px; padding: 24px;"></i></span>
                                            </div>
                                            <div class="counter_text">
                                              <h4><span class="count_no" data-to="98" data-speed="3000">98</span><span>%</span></h4>
                                              <h5>Familles Satisfaites </h5>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3">
                                          <div class="counter_block">
                                            <div class="counter_img">
                                              <span class="orange_bg"><i class="fa fa-sign-language" style="transform: rotate(45deg); color:white; font-size: 30px; padding: 24px;"></i></span>
                                            </div>
                                            <div class="counter_text">
                                              <h4><span class="count_no" data-to="5496" data-speed="3000">5496</span><span>+</span></h4>
                                              <h5>Helpers Marocains</h5>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-lg-3 col-md-3">
                                          <div class="counter_block">
                                            <div class="counter_img">
                                              <span class="blue_bg"><i class="fa fa-users" style="transform: rotate(45deg); color:white; font-size: 30px; padding: 24px;"></i></span>
                                            </div>
                                            <div class="counter_text">
                                              <h4><span class="count_no" data-to="4245" data-speed="3000">4245 </span><span>+</span></h4>
                                              <h5>Helpers Étrangers </h5>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                <div class="col-md-12 img-about" style="margin-top: -140px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container-fluid">
                                

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: -10px">
                                    Depuis nos débuts, nous avons priorisé la satisfaction de nos clients, en leur offrant <span style="color:#EC008C; font-weight: bold">une qualité de travail</span> de premier ordre, <span style="color:#00AEEF; font-weight: bold">d’une grande efficacité</span> répondant aux standards les plus élevés, le tout combiné à 
                                    <span style="color:#EC008C; font-weight: bold">des économies de coûts</span>. Notre <span style="color:#EC008C; font-weight: bold">expérience</span> et nos <span style="color:#00AEEF; font-weight: bold">connaissances</span> sont essentielles pour y parvenir, mais le <span style="color:#EC008C; font-weight: bold">savoir-faire</span>, le travail sans relâche et <span style="color:#00AEEF; font-weight: bold">la fiabilité de nos employés de maison</span> sont encore plus importants. Nous investissons donc dans la <span style="color:#EC008C; font-weight: bold">formation de notre main-d’œuvre</span> et à <span style="color:#00AEEF; font-weight: bold">sa motivation</span>. Nous en tirons profit tout autant que nos précieux employés et clients.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: -10px">
                                <span style="color:#EC008C; ">Bayti</span><span style="color:#00AEEF ">Help</span> est une agence spécialisée d’employés de maison qui propose des :
                            </div>
                          </div>

                          <div class="row" style="text-align: center;  color:black; margin-top: 30px;">
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('marocaines')); ?>"><img src="<?php echo e(url('imgs/ul/01.png')); ?>"></a>
                                <br/>
                                Femmes de ménage ÉTRANGÈRES (indonésiennes, Philippinos, Sénégalaises, Ivoiriennes, Camerounaises, Gambiennes...) ainsi que des MAROCAINES
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('cuisinieres')); ?>"><img src="<?php echo e(url('imgs/ul/02.png')); ?>"></a>
                                <br/>
                                Cuisinières diplômées et expérimentées
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('nounous')); ?>"><img src="<?php echo e(url('imgs/ul/03.png')); ?>"></a>
                                <br/>
                                Nounous diplômées et expérimentées
                            </div>
                          </div>

                          <div class="row" style="text-align: center;  color:black; margin-top: 30px;">
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('noubonnes')); ?>"><img src="<?php echo e(url('imgs/ul/04.png')); ?>"></a>
                                <br/>
                                Noubonnes
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('dame')); ?>"><img src="<?php echo e(url('imgs/ul/05.png')); ?>"></a>
                                <br/>
                                Dame de compagnie
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('chauffeurs')); ?>"><img src="<?php echo e(url('imgs/ul/06.png')); ?>"></a>
                                <br/>
                                Chauffeurs FEMMES et HOMMES AVEC ou sans leurs propres véhicules.
                            </div>
                          </div>

                          <div class="row" style="text-align: center;  color:black; margin-top: 30px;">
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('coach')); ?>"><img src="<?php echo e(url('imgs/ul/07.png')); ?>"></a>
                                <br/>
                                Des coachs sportifs et diététiciens
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('aide')); ?>"><img src="<?php echo e(url('imgs/ul/08.png')); ?>"></a>
                                <br/>
                                Aides aux devoirs et remise à niveau
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('jardiniers')); ?>"><img src="<?php echo e(url('imgs/ul/09.png')); ?>"></a>
                                <br/>
                                Jardiniers
                            </div>
                          </div>

                          <div class="row" style="text-align: center;  color:black; margin-top: 30px;">
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('securite')); ?>"><img src="<?php echo e(url('imgs/ul/10.png')); ?>"></a>
                                <br/>
                                Agent de sécurité
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('gardiens')); ?>"><img src="<?php echo e(url('imgs/ul/11.png')); ?>"></a>
                                <br/>
                                Couples de gardiens
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: -10px; font-weight: bold; border: 1px solid rgba(0,0,0,0.05); padding: 15px">
                                <a href="<?php echo e(url('majordome')); ?>"><img src="<?php echo e(url('imgs/ul/12.png')); ?>"></a>
                                <br/>
                                Gouvernante/Majordome
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: -10px">
                                Notre savoir-faire et nos années d’expérience nous ont permis de se hisser au premier rang et de <b>s’exporter à l’international.</b>
                                <br/>
                                Notre agence est spécialisée dans <b>le recrutement et placement du personnel de maison de différentes nationalités au Maroc et à l’Étranger.</b>
                            </div>
                          </div>

                        </div>
                    </div>
                </div>




                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/pourquoi.blade.php ENDPATH**/ ?>