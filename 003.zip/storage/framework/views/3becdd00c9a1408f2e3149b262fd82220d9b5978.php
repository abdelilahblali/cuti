<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">FEMMES et HOMMES AVEC ou sans leurs PROPRES VOITURES   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">VOUS AVEZ BESOIN D’UN CHAUFFEUR DE CONFIANCE ET QUI CONNAIT LA VILLE COMME SA POCHE ?</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">
                            Nos chauffeurs partenaires sont des personnes <b>responsables</b>, de <b>confiance</b>, <b>élégantes</b> et ayant une <b> très bonne connaissance de toutes les régions marocaines.</b>
                            <br/><br/>
                            <b>Vous préférez une femme qui vous conduit ?</b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> met à votre disposition <b>des chauffeurs Homme ou Femme véhiculés qui mettent à votre disposition leur propre véhicule. </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous fait bénéficier d’une <b>recommandation des anciens employeurs</b>, des références contrôlées et  <b>un suivi disponible</b> jusqu’à chez vous après embauche de votre employé.
                            <br/><br/>
                            <b>Solution idéale</b> pour notre clientèle d’affaire, vous êtes en déplacement au Maroc pour affaire?
                            <br/><br/>
                            Plusieurs déplacements sont en vus dans votre planning et ceci aux quatre coins de la ville?
                            <br/><br/>
                            Sans parler des taxis bondés ou qui s’arrêtent une fois sur trois !!!
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous offre un service <b>chauffeur</b> sans tracas sur simple réservation. Vous disposerez d’un chauffeur <b> ayant son propre véhicule</b>, vous récupérant le jour de votre arrivée directement à l’aéroport, il vous accompagnera là ou vous le souhaiterez et ceci tout au long de votre séjour.
                            <br/><br/>
                            Vous pourrez également profiter de la vie nocturne de la ville de votre séjour, Casablanca, Marrakech, Tanger…Vous êtes la seule priorité de votre chauffeur durant votre temps au Maroc.
                            <br/><br/>
                            <b>Optez pour un de nos chauffeurs muni de son propre véhicule.</b>
                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/chauffeur1.png')); ?>" style="width: 100% !important">
                              <br/>
                              <img src="<?php echo e(url('imgs/pages/chauffeur2.png')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT</span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>


                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE CHAUFFEUR EXPÉRIMENTÉ</button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/chauffeurs.blade.php ENDPATH**/ ?>