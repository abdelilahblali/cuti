<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 15px">Invoice</h4>

<form method="POST" action="<?php echo e(route('clientFolder_factures_updated',[ 'cli' => $ref ])); ?>" enctype="multipart/form-data" class="inline">
<?php echo e(csrf_field()); ?>


<input type="hidden" name="cli" value="<?php echo e($ref); ?>">

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Deposit</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="a1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="a1" value="<?php echo e($a1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur1" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur1">
            <option><?php echo e($cur1); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="a2" class="control-label form-label label01">Invoice <?php if($a2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $a2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 1 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="a2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="a3" class="control-label form-label label01">Paid Invoice <?php if($a3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $a3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 1 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="a3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="a4" class="control-label form-label label01"><?php if($a4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $a4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Land</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="b1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="b1" value="<?php echo e($b1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur2" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur2">
            <option><?php echo e($cur2); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="b2" class="control-label form-label label01">Invoice <?php if($b2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $b2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 2 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="b2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="b3" class="control-label form-label label01">Paid Invoice <?php if($b3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $b3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 2 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="b3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="b4" class="control-label form-label label01"><?php if($b4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $b4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Bank</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="k1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="k1" value="<?php echo e($k1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur11" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur11">
            <option><?php echo e($cur11); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="k2" class="control-label form-label label01">Invoice <?php if($k2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $k2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 2 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="k2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="k3" class="control-label form-label label01">Paid Invoice <?php if($k3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $k3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 2 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="k3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="k4" class="control-label form-label label01"><?php if($k4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $k4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">40% (1)</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="c1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="c1"  value="<?php echo e($c1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur3" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur3">
            <option><?php echo e($cur3); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="f2" class="control-label form-label label01">Invoice <?php if($c2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $c2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 3 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="c2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="c3" class="control-label form-label label01">Paid Invoice <?php if($c3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $c3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 3 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="c3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="c4" class="control-label form-label label01"><?php if($c4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $c4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">40% (2)</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="d1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="d1"  value="<?php echo e($d1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur4" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur4">
            <option><?php echo e($cur4); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="d2" class="control-label form-label label01">Invoice <?php if($d2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $d2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 4 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="d2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="d3" class="control-label form-label label01">Paid Invoice <?php if($d3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $d3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 4 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="d3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="d4" class="control-label form-label label01"><?php if($d4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $d4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">15%</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="e1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="e1"  value="<?php echo e($e1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur5" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur5">
            <option><?php echo e($cur5); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="e2" class="control-label form-label label01">Invoice <?php if($e2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $e2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 5 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="e2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="e3" class="control-label form-label label01">Paid Invoice <?php if($e3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $e3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 5 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="e3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="e4" class="control-label form-label label01"><?php if($e4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $e4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">5%</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="f1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="f1"  value="<?php echo e($f1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur6" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur6">
            <option><?php echo e($cur6); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="f2" class="control-label form-label label01">Invoice <?php if($f2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $f2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 6 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="f2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="f3" class="control-label form-label label01">Paid Invoice <?php if($f3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $f3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 6 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="f3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="f4" class="control-label form-label label01"><?php if($f4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $f4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<?php if($airbnb!=""): ?>
<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Airbnb</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="g1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="g1"  value="<?php echo e($g1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur7" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur7">
            <option><?php echo e($cur7); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="g2" class="control-label form-label label01">Invoice <?php if($g2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $g2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 7 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="g2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="g3" class="control-label form-label label01">Paid Invoice <?php if($g3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $g3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 7 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="g3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="g4" class="control-label form-label label01"><?php if($g4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $g4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>
<?php endif; ?>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Extra 1</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="h1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="h1"  value="<?php echo e($h1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur8" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur8">
            <option><?php echo e($cur8); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="h2" class="control-label form-label label01">Invoice <?php if($h2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $h2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 8 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="h2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="h3" class="control-label form-label label01">Paid Invoice <?php if($h3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $h3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 8 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="h3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="h4" class="control-label form-label label01"><?php if($h4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $h4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Extra 2</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="i1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="i1"  value="<?php echo e($i1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur9" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur9">
            <option><?php echo e($cur9); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="i2" class="control-label form-label label01">Invoice <?php if($i2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $i2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 9 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="i2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="i3" class="control-label form-label label01">Paid Invoice <?php if($i3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $i3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 9 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="i3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="i4" class="control-label form-label label01"><?php if($i4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $i4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05); font-weight: bold">Extra 3</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-2">
          <h6><label for="j1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="j1"  value="<?php echo e($j1); ?>" />
        </div>
        <div class="col-md-1">
          <h6><label for="cur10" class="control-label form-label label01">Currency </label></h6>
          <select class="form-control" name="cur10">
            <option><?php echo e($cur10); ?></option>
            <option>€</option>
            <option>$</option>
            <option>IDR</option>
          </select>
        </div>
        <div class="col-md-3">
          <h6><label for="j2" class="control-label form-label label01">Invoice <?php if($j2!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $j2; ?>" target="_">View</a> | <a href="<?php echo e(route('deleteInvoice', [ 'cli'=> $ref, 'inv'=> 10 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="j2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="j3" class="control-label form-label label01">Paid Invoice <?php if($j3!=""): ?><span style="margin:0 10px"> | </span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $j3; ?>" target="_">View</a> | <a href="<?php echo e(route('deletePaid', [ 'cli'=> $ref, 'inv'=> 10 ])); ?>" style="color:#1da2a4">Delete</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="j3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="j4" class="control-label form-label label01"><?php if($j4!=""): ?><span>Proof document <br></span><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $j4; ?>" target="_">View</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2"></div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row" style="margin-top: 20px">
        <div class="col-md-3">
          <button type="submit" class="btn btn-default btn-block">Save</button>
        </div>
      </div>
  </div>
</div>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientFolder_factures.blade.php ENDPATH**/ ?>