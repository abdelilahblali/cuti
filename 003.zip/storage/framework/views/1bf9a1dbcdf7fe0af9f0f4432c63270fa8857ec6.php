<!DOCTYPE html>
<html>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <title>Commande bien effectuée</title>
    <?php echo $u->head; ?>

    <?php echo $u->foot; ?>

    <link href="<?php echo e(url('imgs/icon.png')); ?>" rel="icon">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/fonts/font-awesome.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
    	<section>
		    <div class="container">
		        <div class="row" style="margin-top: 30px;">
		            <div class="col-md-12">
						<div class="alert alert-success" style="padding: 60px 40px">
							<center><img src="<?php echo e(url('imgs/ok.svg')); ?>" width="100px; padding-top:30px"></center>
							<h5 style="font-size: 38px; font-family: 'Changa'; font-weight: bold; text-align: center; margin: 32px 10px; background: rgba(0,255,0,0.3); padding: 14px 5px">لقد تم تسجيل طلبكم بنجاح</h5>
							<div class="mystore-msg ">شكرا على ثقتكم. سوف تتوصلون بإتصال هاتفي من طرف فريق عملنا لتأكيد طلبكم مرة ثانية. المرجوا الانتباه إلى هاتفكم لكي نقوم بتأكيد طلبكم و توصيل طلبكم في أقرب وقت ممكن.</div>
							<br>
							<div class="mystore-msg ">Merci pour votre confiance. Notre équipe va vous contacter pour une deuxième confirmation avant de vous envoyer votre commande. Veuillez faire attention à votre téléphone pour qu’on puisse confirmer votre commande et vous faire la livraison.</div>
							<br>
							<center><img src="<?php echo e(url('imgs/points.png')); ?>" width="50%" style="margin-bottom: 10px"></center>
						</div>
					</div>
		        </div>
		    </div>
		</section>
    </div>
</body>
</html>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH I:\Wamp\www\ecombladi\resources\views/mystoreCmdAddedLP.blade.php ENDPATH**/ ?>