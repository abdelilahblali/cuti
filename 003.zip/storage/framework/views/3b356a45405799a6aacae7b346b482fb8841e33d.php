

<?php $__env->startSection('content'); ?>
<section class="home page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Accès Refusé</h1>
                <br/>
                Vous n'avez pas l'autorisation pour accèder à cette page pour la raison suivante : <br/>
                <div class="msg-note"><?php echo e(session('msg')); ?></div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/denied.blade.php ENDPATH**/ ?>