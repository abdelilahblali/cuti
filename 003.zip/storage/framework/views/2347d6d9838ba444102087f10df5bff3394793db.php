<?php $__env->startSection('content'); ?>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5"><?php echo e(__('travaux.a1')); ?> </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>

    <?php if(session()->has('no')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('no')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
 
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl" >
  <div class="content flex-row-fluid" id="kt_content" >
      <div class="card card-page">
        <div class="card-body" style="padding: 0px 38px 30px 33px">
          <?php $__currentLoopData = $pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card card-xxl-stretch" style=" <?php if($i->valid==0): ?> background:#ffdbdb <?php else: ?> background:#afedba <?php endif; ?>">
            <div class="" style="margin-top: 10px; padding-left: 0; padding: 10px">
              <p><?php echo $i->dcr; ?></p>
              <a target="_blank" href="<?php echo e($urlWebSite); ?>/media/d/<?php echo e($i->url); ?>"><button class="btn btn-xs btn-success"><?php echo e(__('travaux.a2')); ?></button></a>

              <?php if($i->valid==0): ?>
              <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $i->ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'design_pdf' ])); ?>" ><button type="button" class="btn btn-xs btn-danger" title="click to validate"><?php echo e(__('travaux.a3')); ?></button></a>
              <?php elseif($i->valid==1): ?>
              <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $i->ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'design_pdf' ])); ?>" ><button type="button" class="btn btn-xs btn-success" title="click to cancel validation"><?php echo e(__('travaux.a4')); ?></button></a>
              <?php endif; ?>

            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
      </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/travaux.blade.php ENDPATH**/ ?>