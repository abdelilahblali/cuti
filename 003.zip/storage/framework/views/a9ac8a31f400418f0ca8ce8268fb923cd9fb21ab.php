<html>
<head>
	<title>Magnitude</title>
</head>

<body style='font-family: arial '>
	<table style='border:1px solid #e2e2e2; padding: 10px; border-radius: 6px;' >
		<tr >
			<td>
			
				
				<table style='padding: 6px; padding-top: 10px;'  width='400px'>
					<tr>
						<td>
							<table width='400px' style='background: black;'>
								<tr >
									<td width='40%' style='padding: 10px 6px; text-align: center;'>
							          	<img src='https://magnitudeconstruction.com/wp-content/uploads/2020/04/logo.png' width='130px'>
									</td>
								</tr>
							</table>
						</td>
					</tr>

					<tr>
						<td>
							<table width='400px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal; font-size: 13px;'>
							          	<p style='text-align: justify !important; margin-top: 30px;'>
							          		<br>
							          		<!-- New Account -->
								          	<?php if($notification=='New Account'): ?>
									          	Hello,
									          	<br>
									          	New account awaiting confirmation, you can log into the administration to activate the account
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- Account Confirmed-->
								          	<?php if($notification=='Account Confirmed'): ?>
									          	Hello,
									          	<br>
									          	We inform you that your account is activated, you can connect to your account using your email and your password.
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- New Leave Request-->
								          	<?php if($notification=='New Leave Request'): ?>
									          	Hello,
									          	<br>
									          	You have a new leave request awaiting confirmation
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- Leave Confirmed-->
								          	<?php if($notification=='Leave Confirmed'): ?>
									          	Hello,
									          	<br>
									          	We inform you that a request has been accepted by your Manager, you can check in your dashboard
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- Leave Canceled-->
								          	<?php if($notification=='Leave Canceled'): ?>
									          	Hello,
									          	<br>
									          	We inform you that a request has been refused by your Manager, you can check in your dashboard
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- New Overtime Request-->
								          	<?php if($notification=='New Overtime Request'): ?>
									          	Hello,
									          	<br>
									          	You have a new leave request awaiting confirmation
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- Overtime Confirmed-->
								          	<?php if($notification=='Overtime Confirmed'): ?>
									          	Hello,
									          	<br>
									          	We inform you that a request has been accepted by your Manager, you can check in your dashboard
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- Overtime Canceled-->
								          	<?php if($notification=='Overtime Canceled'): ?>
									          	Hello,
									          	<br>
									          	We inform you that a request has been refused by your Manager, you can check in your dashboard
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

								          	<!-- Overtime Canceled-->
								          	<?php if($notification=='Salary Processed'): ?>
									          	Hello,
									          	<br>
									          	We inform you that your salary has been processed
									          	<br>
									          	<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>You can click here to go to the authentication page</u></a>
									          	<br><br>
									          	Thank You
									          	<br>
								          	<?php endif; ?>

											<br>
											<a href='https://cuti.magnitudeconstruction.com' target='_' style='text-decoration: none; font-weight: bold; '><u>Magnitude</u></a>
							          	</p>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table>
					<tr>
						<td>
							<table width='400px' >
								<tr>
									<td width='40%' style='padding: 15px 6px 15px 12px ; font-weight: normal'>
										<i style='font-size: 10px;'>Ce courriel vous est envoyé automatiquement, merci de ne pas utiliser la fonction 'répondre à l'expéditeur'.</i>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
<?php /**PATH /homepages/43/d729370671/htdocs/cuti.magnitudeconstruction.com/resources/views/mail/notif.blade.php ENDPATH**/ ?>