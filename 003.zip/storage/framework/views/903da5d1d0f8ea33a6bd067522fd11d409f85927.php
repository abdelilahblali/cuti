<?php $__env->startSection('content'); ?>

<style type="text/css">
  hr { margin-bottom: 5px }
  h4 { font-size: 13px !important; font-weight: bold }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Client : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('yes')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('yes')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('no')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('no')); ?>

  </div>
  <?php endif; ?>
</div>


<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px; ">PTPMA</h4>

<div class="">
  

<!-- Contrat 2 -->
<div class="col-md-6">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Name PTPMA & Name Villa</h4>
    <form method="POST" action="<?php echo e(route('ptpmaAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-8">
          <input type="file" class="form-control" name="url[]" multiple required />
          <input type="hidden" name="type" value="construction2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
        <div class="col-md-4">
          <table>
            <tr>
              <td><input type="checkbox" name="signed" value="1"></td>
              <td style="font-weight: bold; padding: 2px 0 0 5px">Already signed</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $ptpma_construction2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>File uploaded</button></a>
          <a onclick="return confirm('Are you sure you want to delete this element?')" href="<?php echo e(route('deleteFile', [ 'ref'=> $i->ref, 'table'=> 'ptpma',  'champ'=> 'url' ])); ?>" style="color:#1da2a4">Delete</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-xs btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>


    <?php $__currentLoopData = $ptpma_construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    File imported by the client
    <div class="row" style="margin-top: 5px">
      <div class="col-md-8">
        <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-block btn-default btn-block" style="background-color: gray">Document uploaded</button></a>
      </div>
      <div class="col-md-4">
        <?php if($i->valid==0): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'ptpma' ])); ?>" ><button type="button" class="btn btn-xs btn-block btn-danger" title="click to validate">No Valide</button></a>
        <?php elseif($i->valid==1): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'ptpma' ])); ?>" ><button type="button" class="btn btn-xs btn-block btn-success" title="click to cancel validation">Valide</button></a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>

<!-- Contrat 1 -->
<div class="col-md-6">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Procuration PTPMA</h4>
    <form method="POST" action="<?php echo e(route('ptpmaAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-8">
          <input type="file" class="form-control" name="url[]" multiple required />
          <input type="hidden" name="type" value="reservation2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
        <div class="col-md-4">
          <table>
            <tr>
              <td><input type="checkbox" name="signed" value="1"></td>
              <td style="font-weight: bold; padding: 2px 0 0 5px">Already signed</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $ptpma_reservation2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>File uploaded</button></a>
          <a onclick="return confirm('Are you sure you want to delete this element?')" href="<?php echo e(route('deleteFile', [ 'ref'=> $i->ref, 'table'=> 'ptpma',  'champ'=> 'url' ])); ?>" style="color:#1da2a4">Delete</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-xs btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>


    <?php $__currentLoopData = $ptpma_reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    File imported by the client
    <div class="row" style="margin-top: 5px">
      <div class="col-md-8">
        <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-block btn-default btn-block" style="background-color: gray">Document uploaded</button></a>
      </div>
      <div class="col-md-4">
        <?php if($i->valid==0): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'ptpma' ])); ?>" ><button type="button" class="btn btn-xs btn-block btn-danger" title="click to validate">No Valide</button></a>
        <?php elseif($i->valid==1): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'ptpma' ])); ?>" ><button type="button" class="btn btn-xs btn-block btn-success" title="click to cancel validation">Valide</button></a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>

</div>

<div class="">

<!-- Contrat 4 -->
<div class="col-md-6">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Acte Constitutif de Société</h4>
    <form method="POST" action="<?php echo e(route('ptpmaAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-8">
          <input type="file" class="form-control" name="url[]" multiple required />
          <input type="hidden" name="type" value="acte2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
        <div class="col-md-4">
          <table>
            <tr>
              <td><input type="checkbox" name="signed" value="1"></td>
              <td style="font-weight: bold; padding: 2px 0 0 5px">Already signed</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $ptpma_acte2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>File uploaded</button></a>
          <a onclick="return confirm('Are you sure you want to delete this element?')" href="<?php echo e(route('deleteFile', [ 'ref'=> $i->ref, 'table'=> 'ptpma',  'champ'=> 'url' ])); ?>" style="color:#1da2a4">Delete</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-xs btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>

  </div>
</div>


<!-- Contrat 3 -->
<div class="col-md-6">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Bank Document</h4>
    <form method="POST" action="<?php echo e(route('ptpmaAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-8">
          <input type="file" class="form-control" name="url[]" multiple required />
          <input type="hidden" name="type" value="terrain2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
        <div class="col-md-4">
          <table>
            <tr>
              <td><input type="checkbox" name="signed" value="1"></td>
              <td style="font-weight: bold; padding: 2px 0 0 5px">Already signed</td>
            </tr>
          </table>
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $ptpma_terrain2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>File uploaded</button></a>
          <a onclick="return confirm('Are you sure you want to delete this element?')" href="<?php echo e(route('deleteFile', [ 'ref'=> $i->ref, 'table'=> 'ptpma',  'champ'=> 'url' ])); ?>" style="color:#1da2a4">Delete</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-xs btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>


    <?php $__currentLoopData = $ptpma_terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    File imported by the client
    <div class="row" style="margin-top: 5px">
      <div class="col-md-8">
        <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-xs btn-block btn-default btn-block" style="background-color: gray">Document uploaded</button></a>
      </div>
      <div class="col-md-4">
        <?php if($i->valid==0): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'ptpma' ])); ?>" ><button type="button" class="btn btn-xs btn-block btn-danger" title="click to validate">No Valide</button></a>
        <?php elseif($i->valid==1): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'ptpma' ])); ?>" ><button type="button" class="btn btn-xs btn-block btn-success" title="click to cancel validation">Valide</button></a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientFolder_ptpma.blade.php ENDPATH**/ ?>