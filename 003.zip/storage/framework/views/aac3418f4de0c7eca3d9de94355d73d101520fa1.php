


<?php $__env->startSection('content'); ?>
	
<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-dashboard"></i> Statistiques des commandes</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
	<div class="container-widget ">
	    <div class="miniHeight dashboard">
	      	<div class="col-md-3">
		        <div class="panel panel-default pad01">
		            <div class="panel-body">
		            	<center><i class="fa fa-clock-o ico" style="color:orange"></i></center>
			          	<h5>Commandes en cours</h5>
			            <div class="row">
			                <h6><?php echo e($cmd0); ?></h6>
			          	</div>
		          	</div>
		        </div>
	       	</div>
	       	<div class="col-md-3">
		        <div class="panel panel-default pad01">
		            <div class="panel-body">
		            	<center><i class="fa fa-check ico" style="color:blue"></i></center>
			          	<h5>Commandes confirmées</h5>
			            <div class="row">
			                <h6><?php echo e($cmd1); ?></h6>
			          	</div>
		          	</div>
		        </div>
	       	</div>
	       	<div class="col-md-3">
		        <div class="panel panel-default pad01">
		            <div class="panel-body">
		            	<center><i class="fa fa-send ico" style="color:green"></i></center>
			          	<h5>Commandes envoyées</h5>
			            <div class="row">
			                <h6><?php echo e($cmd4); ?></h6>
			          	</div>
		          	</div>
		        </div>
	       	</div>
	       	<div class="col-md-3">
		        <div class="panel panel-default pad01">
		            <div class="panel-body">
		            	<center><i class="fa fa-trash ico" style="color:red"></i></center>
			          	<h5>Commandes annulées</h5>
			            <div class="row">
			                <h6><?php echo e($cmd_1); ?></h6>
			          	</div>
		          	</div>
		        </div>
	       	</div>
	    </div>
	</div>
</div>

<div class="col-md-12" style="margin-top: 30px">
  <div class="page-">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-dashboard"></i> Statistiques de l'année courante <?php echo e(date('Y')); ?></li>
      </ol>
  </div>
</div>

<div class="col-md-12">
	<div class="container-widget ">
	    <div class="miniHeight dashboard">
        	<table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
        		<thead>
			        <tr>
			          <td>Mois</td>
			          <td align="center">Toutes les commandes</td>
			          <td align="center">Envoyées</td>
			          <td align="center">Annulées</td>
			        </tr>
			    </thead>
			    <tbody>
        		<?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<tr>
        			<td><?php echo e($mois[$mon->month]); ?></td>
        			<td class="dash-td"><span class="orn"><?php echo e($mon->tout); ?></span></td>
        			<td class="dash-td"><span class="prix"><?php echo e($mon->envoyee); ?></span></td>
        			<td class="dash-td"><span class="reste"><?php echo e($mon->annulee); ?></span></td>
        		</tr>
        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</tbody>
        	</table>
		</div>
	</div>
</div>

<?php $mois_current = date('m'); ?>
<h2><?php use App\Http\Controllers\Store; ?> </h2>

<div class="col-md-12" style="margin-top: 30px">
  <div class="page-">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-dashboard"></i> Diagrammes du mois courant : <?php echo e($mois[$mois_current]); ?> </li>
      </ol>
  </div>
</div>

<div class="col-md-4">
	<div class="panel panel-default pad01">
		<div class="panel-body">
			<div class="container-widget ">
			    <div class="miniHeight dashboard">
		        	<div class="col-md-12">
						<canvas id="eta1"></canvas>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="col-md-4">
	<div class="panel panel-default pad01">
		<div class="panel-body">
			<div class="container-widget ">
			    <div class="miniHeight dashboard">
		        	<div class="col-md-12">
						<canvas id="eta2"></canvas>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="col-md-4">
	<div class="panel panel-default pad01">
		<div class="panel-body">
			<div class="container-widget ">
			    <div class="miniHeight dashboard">
		        	<div class="col-md-12">
						<canvas id="eta3"></canvas>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="col-md-12" style="margin-top: 30px">
  <div class="page-">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-dashboard"></i> Statistiques des commandes par produit</li>
      </ol>
  </div>
</div>

<div class="col-md-12">
	<div class="container-widget ">
	    <div class="miniHeight dashboard">
        	<table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
        		<thead>
			        <tr>
			          <td>Produit</td>
			          <td align="center">Toutes les commandes</td>
			          <td align="center">Envoyées</td>
			          <td align="center">Annulées</td>
			        </tr>
			    </thead>
			    <tbody>
        		<?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<tr>
        			<td><?php echo e($pro->produit); ?></td>
        			<td class="dash-td"><span class="orn"><?php echo e($pro->tout); ?></span></td>
        			<td class="dash-td"><span class="prix"><?php echo e($pro->envoyee); ?></span></td>
        			<td class="dash-td"><span class="reste"><?php echo e($pro->annulee); ?></span></td>
        		</tr>
        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</tbody>
        	</table>
		</div>
	</div>
</div>


<script src="<?php echo e(url('chart.js')); ?>"></script>

<script type="text/javascript">
    var ctx = document.getElementById('eta1').getContext('2d');
	var chart = new Chart(ctx, {
	    type: 'line',
	    data: {
	        labels: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10','11', '12', '13', '14', '15', '16', '17', '18', '19', '20','21', '22', '23', '24', '25', '26', '27', '28', '29', '30','31',],
	        datasets: [{
	            label: 'Toutes les commandes',
	            backgroundColor: 'orange',
	            borderColor: 'orange',
	            data: [  <?php for($i = 1; $i <= 31; $i++): ?> <?php echo e(Store::calcall($i, $mois_current)); ?>   <?php endfor; ?> ]
	        }]
	    },
	    options: {}
	});
</script>

<script type="text/javascript">
    var ctx = document.getElementById('eta2').getContext('2d');
	var chart = new Chart(ctx, {
	    type: 'line',
	    data: {
	        labels: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10','11', '12', '13', '14', '15', '16', '17', '18', '19', '20','21', '22', '23', '24', '25', '26', '27', '28', '29', '30','31',],
	        datasets: [{
	            label: 'Commandes Envoyées',
	            backgroundColor: '#19aba4',
	            borderColor: '#19aba4',
	            data: [  <?php for($i = 1; $i <= 31; $i++): ?> <?php echo e(Store::calc($i, $mois_current, 4)); ?>   <?php endfor; ?> ]
	        }]
	    },
	    options: {}
	});
</script>

<script type="text/javascript">
	    var ctx = document.getElementById('eta3').getContext('2d');
		var chart = new Chart(ctx, {
		    type: 'line',
		    data: {
		        labels: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10','11', '12', '13', '14', '15', '16', '17', '18', '19', '20','21', '22', '23', '24', '25', '26', '27', '28', '29', '30','31',],
		        datasets: [{
		            label: 'Commades Annulées',
		            backgroundColor: 'red',
		            borderColor: 'red',
		            data: [  <?php for($i = 1; $i <= 31; $i++): ?> <?php echo e(Store::calc($i, $mois_current, -1)); ?>   <?php endfor; ?> ]
		        }]
		    },
		    options: {}
		});
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/store.blade.php ENDPATH**/ ?>