

<?php $__env->startSection('content'); ?>
<section class="home">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Vous souhaitez créer une boutique en ligne ?</h2>
                <h2 style="margin-top: 18px">
                    <span style="color:#0d3a5d;">Avec nous, tout est facile !</span> 
                </h2>
                <button class="btn btn-default deposer">Créer votre store immédiatement<i class="fa fa-send"></i> </button>
            </div>
            <div class="col-md-6">
                <img src="<?php echo e(url('imgs/home.png')); ?>" width="100%">
            </div>
        </div>
    </div>
</section>

<section class="how">
    <div class="container">
        <div class="title">Pourquoi <b>nous choisir ?</b></div>
        <div class="col-md-1">
            <div class="icon1"><i class="fa fa-check" aria-hidden="true"></i></div>
        </div>
        <div class="col-md-3">
            <h3>Compte Gratuit</h3>
            <p>Avec EcomBladi vous bénéficiez de touts les outils gratuitement et sans engagement.</p>
        </div>

        <div class="col-md-1">
            <div class="icon1"><i class="fa fa-globe" aria-hidden="true"></i></div>
        </div>
        <div class="col-md-3">
            <h3>Stock & Livraison</h3>
            <p>Vous pouvez gérer votre stock et vos produits chez vous sans avoir déplacer.</p>
        </div>

        <div class="col-md-1">
            <div class="icon1"><i class="fa fa-file" aria-hidden="true"></i></div>
        </div>
        <div class="col-md-3">
            <h3>Landing Page</h3>
            <p>Créer facilement vos landings pages et intégrer les codes de suivi de vos achats.</p>
        </div>
    </div>  
</section>

<section class="why">
    <div class="container">
        <div class="title">Comment <b>ça marche ?</b></div>
        <div class="col-md-4"> 
            <div class="icon" style="padding-left: 28px; padding-top: 18px"><i class="fa fa-user blue"></i></div>
            <h4>#1 Inscription</h4>
            <p>Inscrivez-vous sur EcomBladi gratuitement et connectez-vous facilement</p>
        </div>
        <div class="col-md-4"> 
            <div class="icon" style="padding-left: 23px; padding-top: 18px"><i class="fa fa-cog orange"></i></div>
            <h4>#2 Dashboard</h4>
            <p>Gérez les différentes configurations de votre boutique en quelques clics</p>
        </div>
        <div class="col-md-4"> 
            <div class="icon" style="padding-left: 17px; padding-top: 22px"><i class="fa fa-send blue"></i></div>
            <h4>#4 Store</h4>
            <p>Gérez vos produits, consultez votre stock et suivez l état de vos commandes</p>
        </div>      
    </div>
    <div class="container" style="margin-top: 40px">
        <div class="col-md-4"> 
            <div class="icon" style="padding-left: 25px; padding-top: 19px"><i class="fa fa-file orange"></i></div>
            <h4>#4 Landing Page</h4>
            <p>Créez vos landings pages facilement et liéez-les avec les outils d' 'achat</p>
        </div>
        <div class="col-md-4"> 
            <div class="icon" style="padding-left: 17px; padding-top: 19px"><i class="fa fa-truck blue"></i></div>
            <h4>#5 Livraison</h4>
            <p>Choisissez votre société de la livraison préférable.</p>
        </div>
        <div class="col-md-4"> 
            <div class="icon" style="padding-left: 13px; padding-top: 22px"><i class="fa fa-bar-chart orange"  ></i></div>
            <h4>#6 Statistiques</h4>
            <p>Consultez les statistiques de vos achats, recettes et l état de vos commandes</p>
        </div>      
    </div>
</section>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/home.blade.php ENDPATH**/ ?>