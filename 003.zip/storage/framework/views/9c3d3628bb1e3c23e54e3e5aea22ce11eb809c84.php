<?php $__env->startSection('content'); ?>

<div class="col-lg-12 grid-margin stretch-card">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Notifications</h4>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Message</th>
              <th>Sent</th>
            </tr>
          </thead>
          <tbody>
          	<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr <?php if($item->vu==0): ?> style="background: rgba(255, 0, 0, 0.05);" <?php endif; ?>>
              <td class="bold"><?php echo e($item->msg); ?></td>
              <td><?php echo date('m/d/Y H:i:s', strtotime($item->fait)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/cuti.magnitudeconstruction.com/resources/views/notifications.blade.php ENDPATH**/ ?>