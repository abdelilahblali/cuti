<?php $__env->startSection('content'); ?>

<style type="text/css">
  .bs-stepper-label { color:rgba(0,0,0,0.2) }
  .bgCyrcle { background:rgba(0,0,0,0.2) !important } 
  .bs-stepper-line { margin-left: 15px !important; flex: 1 0 16px !important }
  .activeClas { font-weight: bold; color :#1da2a4 !important; }
  .activeClasBg { background :#1da2a4 !important; }
  .activeClasAlready { font-weight: bold; color :rgba(0,0,0,0.6) !important; }
  .activeClasAlreadyBg { background :rgba(0,0,0,0.6) !important; }


</style>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>
<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5"><?php echo e(__('invoices.a1')); ?></h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <?php echo $__env->make('master.aide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <a href="https://magnitudeconstruction.com/contactez-nous/" target="_blank" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6"><?php echo e(__('invoices.a2')); ?></a>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <form method="POST" action="<?php echo e(route('clientFolder_factures_updated_byClient',[ 'cli' => Auth::user()->ref ])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">

    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">
      <div class="col-xxl-12"> 

        <div class="card card-page">
          <div class="card-body">

            <div class="card-header border-0 pt-5 pb-3">
              <h3 class="card-title fw-bolder text-gray-800 fs-2"><?php echo e(__('invoices.a3')); ?></h3>
            </div>
            
            <div class="card card-xxl-stretch">
              <div class="card-header">
                  <div style="overflow-x:auto; width: 100%;">
                  <table class="table table-rounded table-striped border gy-7 gs-7 tableInvoices" >
                    <thead>
                      <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
                          <th></th>
                          <th><?php echo e(__('invoices.a4')); ?></th>
                          <th><?php echo e(__('invoices.a5')); ?></th>
                          <th><?php echo e(__('invoices.a6')); ?></th>
                          <th><?php echo e(__('invoices.a7')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e(__('invoices.a12')); ?></td>
                            <td><?php echo e(number_format($a1, 2)); ?> <?php echo e($cur1); ?></td>
                            <td><?php if($a2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $a2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($a4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="a4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $a4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 1 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($a3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $a3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td scope="row" data-label=""><?php echo e(__('invoices.a11')); ?></td>
                            <td><?php echo e(number_format($b1, 2)); ?> <?php echo e($cur2); ?></td>
                            <td><?php if($b2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $b2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($b4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="b4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $b4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 2 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($b3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $b3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>

                        <tr>
                            <td scope="row" data-label="">Banque</td>
                            <td><?php echo e(number_format($k1, 2)); ?> <?php echo e($cur11); ?></td>
                            <td><?php if($k2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $k2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($k4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="k4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $k4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 11 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($k3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $k3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>

                        <tr>
                            <td scope="row" data-label="">40% (1)</td>
                            <td><?php echo e(number_format($c1, 2)); ?> <?php echo e($cur3); ?></td>
                            <td><?php if($c2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $c2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($c4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="c4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $c4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 3 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($c3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $c3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td scope="row" data-label="">40% (2)</td>
                            <td><?php echo e(number_format($d1, 2)); ?> <?php echo e($cur4); ?></td>
                            <td><?php if($d2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $d2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($d4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="d4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $d4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 4 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($d3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $d3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td scope="row" data-label="">15%</td>
                            <td data-label="col1"><?php echo e(number_format($e1, 2)); ?> <?php echo e($cur5); ?></td>
                            <td><?php if($e2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $e2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($e4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="e4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $e4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 5 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($e3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $e3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td scope="row" data-label="">5%</td>
                            <td><?php echo e(number_format($f1, 2)); ?> <?php echo e($cur6); ?></td>
                            <td><?php if($f2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $f2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($f4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="f4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $f4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 6 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($f3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $f3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>

                        <?php if($airbnb!=""): ?>
                        <tr>
                            <td scope="row" data-label="">Airbnb</td>
                            <td><?php echo e(number_format($g1, 2)); ?> <?php echo e($cur7); ?></td>
                            <td><?php if($g2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $g2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($g4==""): ?><input type="file" class="form-control" style="width: 100% !important" name="g4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $g4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 7 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($g3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $g3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($h1!=""): ?>
                        <tr>
                            <td scope="row" data-label="">Extra 1</td>
                            <td><?php echo e(number_format($h1, 2)); ?> <?php echo e($cur6); ?></td>
                            <td><?php if($h2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $h2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($h4==""): ?><input type="file" class="horm-control" style="width: 100% !important" name="h4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $h4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 8 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($h3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $h3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($i1!=""): ?>
                        <tr>
                            <td scope="row" data-label="">Extra 2</td>
                            <td><?php echo e(number_format($i1, 2)); ?> <?php echo e($cur6); ?></td>
                            <td><?php if($i2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $i2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($i4==""): ?><input type="file" class="iorm-control" style="width: 100% !important" name="i4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $i4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 9 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($i3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $i3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <?php endif; ?>

                        <?php if($j1!=""): ?>
                        <tr>
                            <td scope="row" data-label="">Extra 3</td>
                            <td><?php echo e(number_format($j1, 2)); ?> <?php echo e($cur6); ?></td>
                            <td><?php if($j2!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $j2; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                            <td><?php if($j4==""): ?><input type="file" class="jorm-control" style="width: 100% !important" name="j4[]" multiple /><?php else: ?> <a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $j4; ?>" target="_" style="color:#1da2a4">Voir</a> | <a href="<?php echo e(route('deleteProof', [ 'inv'=> 10 ])); ?>" style="color:#1da2a4"><?php echo e(__('invoices.a10')); ?></a>  <?php endif; ?></td>
                            <td><?php if($j3!=""): ?><a href="<?php echo e($urlWebSite); ?>/media/invoice/<?php echo $j3; ?>" target="_" style="color:#1da2a4"><?php echo e(__('invoices.a8')); ?> </a> <?php endif; ?></td>
                        </tr>
                        <?php endif; ?>


                    </tbody>
                </table> 
                </div>
                <div class="col-md-12" ><button type="submit" class="btn btn-success"><?php echo e(__('invoices.a9')); ?></button><br><br></div>             

              </div>
            </div>
          </div>
        </div>
      </div>     
    </div>
    </form>
  </div>
</div>


    <!-- Datatable ************************************** -->
    <!-- ************************************************ -->
    <script type="text/javascript" src="<?php echo e(url('datatable/jquery-3.5.1.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('datatable/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('datatable/dataTables.responsive.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('datatable/dataTables.fixedHeader.min.js')); ?>"></script>

    <script type="text/javascript" src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/fixedcolumns/3.2.1/js/dataTables.fixedColumns.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            var table = $('#oneColumnTable').DataTable( {
                scrollY: "800px",
                scrollCollapse: true,
                responsive: false,
                paging: false,
                footer: true,
                scrollX: true,
                order: [[ 0, "desc" ]],
                lengthMenu: [[-1, 20, 30, 50], ["All", 20, 30, 50]],
                fixedColumns:   {
                    leftColumns: 1
                }
            } );
            new $.fn.dataTable.FixedHeader( table );
        } );
    </script>

    <script type="text/javascript">

      $(".sidebar-open-button-mobile").on("click",function(){
        if($(".sidebar").css("display") == "block"){
          $(".sidebar").css("display","none")
        }else{
          $(".sidebar").css("display","block")
        }
      });
    </script>
          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/invoices.blade.php ENDPATH**/ ?>