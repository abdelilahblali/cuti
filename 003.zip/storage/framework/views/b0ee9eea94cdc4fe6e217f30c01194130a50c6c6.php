<?php $__env->startSection('content'); ?>
<div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">SERVICES </h3>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<div class="clv_about_wrapper clv_section" style="padding-top: 0px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 img-about" style="padding-top: 0px">
                <div class="garden_service2_wrapper  meil-service">
                  <div class="container">




                      <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                        <div class="col-md-3"></div>
                        <div class="col-md-6" style=" padding: 0; margin-left: 0px">
                            <ul class="list-group">
                                <li class="list-group-item"><a href="#">Femme de ménage</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('marocaines')); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i> Les marocaines</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('africaines')); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i> Les africaines subsahariennes</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('asiatiques')); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i> Les asiatiques</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('printemps')); ?>"><i class="fa fa-angle-right" aria-hidden="true"></i> Ménage de printemps</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('cuisinieres')); ?>">Cuisinières diplômées et expérimentées</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('nounous')); ?>">Nounous diplômées et/ou expérimentées</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('noubonnes')); ?>">Noubonnes</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('dame')); ?>">Dame de Compagnie</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('chauffeurs')); ?>">Chauffeurs</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('coach')); ?>">Des coachs sportifs et diététiciens</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('aide')); ?>">Aides aux devoirs et remises à niveau</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('jardinier')); ?>">Jardiniers/Paysagiste</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('securite')); ?>">Agent de sécurité</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('Couple')); ?>">Couple de gardiens</a></li>
                                <li class="list-group-item"><a href="<?php echo e(url('majordome')); ?>">Majordome/Gouvernante</a></li>
                            </ul>
                        </div>
                    </div>



                </div>
            </div>
        </div>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/services2.blade.php ENDPATH**/ ?>