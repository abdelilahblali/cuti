<?php $__env->startSection('content'); ?>

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }

  h4 { font-weight: bold; font-size: 13px;  }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3') or Route::is('clientFolder_travaux') ): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">Architecture : Travaux suplémentaires</h4>

<div class="col-md-12">
  <div class="panel panel-default client-content"  style="padding-top: 2px;">
    <h4>Add new document</h4>
    <form method="POST" action="<?php echo e(route('clientFolder_design_AddPdf',[ 'ref' => $ref ] )); ?>" enctype="multipart/form-data" class="form-inline">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
      <div class="form-group" style="width: 100% !important;" >
          <textarea class="form-control" name="dcr" style="width: 100% !important; margin-top: 10px; margin-bottom: 10px" placeholder="Text"></textarea>
      </div>
      <div class="form-group">
          <input type="hidden" name="d" value="5">
          <input type="hidden" name="typ" value="5">
          <input type="file" name="url[]" id="url" class="form-control" multiple  />
      </div>
      <div class="form-group" >
          <button type="submit" class="btn btn-default" style="float: right;"><i class="fa fa-plus" style="padding-right: 10px;"></i>Add</button>
      </div>
    </form>
    <hr>
    <h4>Documents uploaded</h4>
    <?php $__currentLoopData = $pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="" style="margin-top: 10px; padding-left: 0;  padding: 10px; <?php if($i->valid==0): ?> background:#ffdbdb <?php else: ?> background:#afedba <?php endif; ?>" >
      <?php if($i->valid==0): ?>
        <span style="color:red; font-weight: bold;">Document no validated by the client</span>
      <?php else: ?>
        <span style="color:green; font-weight: bold;">Document validated by the client</span>
      <?php endif; ?>
      <p><?php echo e($i->dcr); ?></p>
      <a target="_blank" href="<?php echo e($urlWebSite); ?>/media/d/<?php echo e($i->url); ?>"><button style="font-weight: bold; color: black">View Document</button></a>
      <a href="<?php echo e(route('clientFolder_design_DeletePdf',[ 'ref' => $i->ref ])); ?>" onclick="return confirm('Are you sure you delete this item?'); event.preventDefault(); document.getElementById('clientFolder_design_DeletePdf').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
      <form id="clientFolder_design_DeletePdf" action="<?php echo e(route('clientFolder_design_DeletePdf',[ 'ref' => $i->ref ])); ?>" method="POST">
          <?php echo e(method_field('DELETE')); ?>

          <?php echo csrf_field(); ?>
      </form>  
    </div>
    <hr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientFolder_travaux.blade.php ENDPATH**/ ?>