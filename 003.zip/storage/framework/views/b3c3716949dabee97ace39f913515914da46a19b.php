

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($slides_count!=0): ?>
<section>
    <div class="container">
        <div id="carousel1" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carousel1" data-slide-to="0" class="active"></li>
                <li data-target="#carousel1" data-slide-to="1"></li>
                <li data-target="#carousel1" data-slide-to="2"></li>
            </ol>

            <div class="carousel-inner" role="listbox">
                <?php $i = 0; ?>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i++; ?>
                <div class="item <?php if($i==1): ?> active <?php endif; ?>">
                    <img src="<?php echo e(url('img-slide')); ?>/<?php echo e($sld->img); ?>" width="100%">
                    <div class="carousel-caption">
                        <h3><?php echo e($sld->des); ?></h3>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <a class="left carousel-control" href="#carousel1" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carousel1" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<section style="margin-top: 30px">
    <div class="container">
        <h4 class="my-title">Nouveaux Produits</h4>
        <div class="row" style="margin-top: 30px">
            <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-5 col-md-3">
                <div class="thumbnail">
                    <a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>"><img src="<?php echo e(url('pro')); ?>/<?php echo e($prod->img); ?>" width="100%"></a>
                    <div class="caption">
                        <h3 class="my-product"><?php echo e($prod->des); ?></h3>
                        <p class="my-price" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri1, 2)); ?></p>
                        <p><a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>" class="btn btn-default my-view" role="button" style="background: <?php echo e($u->color2); ?>">Voir le produit</a>
                        <a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>" class="btn btn-primary my-cmd" role="button" style="background: <?php echo e($u->color3); ?>">Commander</a></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.mystore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/mystore.blade.php ENDPATH**/ ?>