

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section>
    <div class="container">
        <h4 class="my-title"><?php echo e($categorie); ?></h4>
        <div class="row" style="margin-top: 30px">
            <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-5 col-md-3">
                <div class="thumbnail">
                    <a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>"><img src="<?php echo e(url('pro')); ?>/<?php echo e($prod->img); ?>" width="100%"></a>
                    <div class="caption">
                        <h3 class="my-product"><?php echo e($prod->des); ?></h3>
                        <p class="my-price" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri1, 2)); ?></p>
                        <p><a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>" class="btn btn-default my-view" role="button" style="background: <?php echo e($u->color2); ?>">Voir le produit</a>
                        <a href="<?php echo e(route('mystoreProduit',[ 'ref' => $prod->ref, 'mystore' => $u->store ])); ?>" class="btn btn-primary my-cmd" role="button" style="background: <?php echo e($u->color3); ?>">Commander</a></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.mystore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/mystoreProCat.blade.php ENDPATH**/ ?>