<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-15" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title>EcomBladi : Gerer votre store facilement</title>
    <link href="<?php echo e(url('imgs/icon.png')); ?>" rel="icon">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/fonts/font-awesome.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <nav class="navbar navbar-default">
          <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>" style="padding-top: 3px"><img src="<?php echo e(url('imgs/logo.svg')); ?>" class="logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <!-- <li><a href="#">Chercher Missions</a></li>
                    <li><a href="#">Nos Tarifs</a></li> -->
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li><a href="">A Propos</a></li>
                    <li><a href="">Contact</a></li>
                    <?php if(auth()->guard()->guest()): ?>
                        <li><a href="" style="padding-top: 8px; padding-bottom: 0;"><button class="btn btn-xs btn-default btn1">Créer votre boutique</button></a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e(route('store')); ?>" style="padding-top: 8px; padding-bottom: 0;"><button class="btn btn-xs btn-default btn1" style="font-weight: bold">Gérer ma boutique <?php echo e(Auth::user()->store); ?></button></a></li>
                    <?php endif; ?>
                    <li><a href="">Guide</a></li>
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="client"><a href="<?php echo e(route('login')); ?>">Espace Client</a></li>
                    <?php else: ?>
                        <li class="client" id="navbarDropdown" class="nav-link dropdown-toggle" ><a href="<?php echo e(route('profil')); ?>"><?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            </div>
        </nav>
    </header>

    <div class="page">
        <section id="hero" class="">  
            <section id="contact" class="padd-section">
              <div class="title-section">
                  <h1></h1>
              </div>
              <div class="container">
                <div class="row justify-content-center">
                  <div class="col-md-3">
                    <ul class="list-group menu-cmd">
                        <li class="list-group-item t1">Mon Compte</li>
                        <li class="list-group-item t2 <?php echo e(Request::is('profil') ? 'btn-active' : ''); ?>"><span class="badge"></span><a href="<?php echo e(route('profil')); ?>"><i class="fa fa-edit"></i> Modifier mes informations</a></li>
                        <li class="list-group-item t2 <?php echo e(Request::is('password') ? 'btn-active' : ''); ?>"><span class="badge"></span><a href="<?php echo e(route('user.password')); ?>"><i class="fa fa-lock"></i> Modifier mon mot de passe</a></li>
                    </ul>

                    <ul class="list-group menu-cmd">
                        <li class="list-group-item t1">Ma Boutique</li>
                        <li class="list-group-item t2 "><span class="badge"></span><a href="<?php echo e(route('store')); ?>"><i class="fa fa-edit"></i> Gérer ma boutique</a></li>
                        <li class="list-group-item t2 "><span class="badge"></span><a href=""><i class="fa fa-eye"></i> Ouvrir ma boutique</a></li>
                    </ul>

                    <ul class="list-group menu-cmd">
                        <li class="list-group-item t1">Options</li>
                        <li class="list-group-item t2 "><span class="badge"></span><a href="<?php echo e(route('logout' )); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-power-off"></i> Déconnection</a></li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>    
                    </ul>

                  </div>
                  <div class="col-md-9">
                      <?php echo $__env->yieldContent('content'); ?>            
                  </div>
                </div>
              </div>
            </section>
        </section>
    </div>

    <footer>
        <div class="container" style="margin-bottom: 30px; border-bottom: 1px solid rgba(0,0,0,0.05); padding-bottom: 20px">
            <center><img src="<?php echo e(url('imgs/logo.svg')); ?>" class="logo"></center>
        </div>
        <div class="container" >
            <div class="col-md-3">
                <div class="title">Menu Spécial</div>
                <ul>
                    <li><a href="#">Accueil</a></li>
                    <li><a href="#">A propos</a></li>
                    <li><a href="#">Guide d'utilisation</a></li>
                    <li><a href="#">Espace Client</a></li>
                    <li><a href="#">Contactez-nous</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <div class="title">Methodes</div>
                <ul>
                    <li><a href="#">Créer un compte</a></li>
                    <li><a href="#">Mot de passe oublié</a></li>
                    <li><a href="#">Gestion du store</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <div class="title">Nous rejoindre</div>
                <ul>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Instagram</a></li>
                    <li><a href="#">Whatsapp</a></li>
                    <li><a href="#">Twitter</a></li>
                    <li><a href="#">Linkedin</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <div class="title">EcomBladi</div>
                <ul>
                    <li><a href="#">+212 662 52 78 95</a></li>
                    <li><a href="#">contact@ecombladi.com</a></li>
                    <li><a href="#">www.ecombladi.com</a></li>
                </ul>
            </div>
        </div>
        <div class="copyright">
            <a href="#">EcomBladi &copy; 2020</a>
        </div>
    </footer>





    <script src="<?php echo e(url('lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('lib/jquery/jquery-migrate.min.js')); ?>"></script>
    <script src="<?php echo e(url('lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(url('lib/superfish/hoverIntent.js')); ?>"></script>
    <script src="<?php echo e(url('lib/superfish/superfish.min.js')); ?>"></script>
    <script src="<?php echo e(url('lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(url('lib/modal-video/js/modal-video.js')); ?>"></script>
    <script src="<?php echo e(url('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(url('lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(url('contactform/contactform.js')); ?>"></script>
    <script src="<?php echo e(url('js/main.js')); ?>"></script>
    <script src="<?php echo e(url('js/datatables.min.js')); ?>"></script>

</body>
</html><?php /**PATH I:\Wamp\www\ecombladi\resources\views/master/client.blade.php ENDPATH**/ ?>