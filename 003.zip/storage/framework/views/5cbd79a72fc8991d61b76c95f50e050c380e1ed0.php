<?php echo e($slot); ?>

<?php /**PATH I:\Wamp\www\ecombladi\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>