

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-paint-brush"></i> Liste des photos du chantier</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <div class="row">
    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-2" style="margin-bottom: 30px">
      <a href="http://localhost/monprojetbali/media/cli/<?php echo e($img->img); ?>" onclick="return hs.expand(this)">
        <img src="http://localhost/monprojetbali/media/cli/<?php echo e($img->img); ?>" style="width: 100%; height: 200px" class="img-thumbnail">
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>   

 <div class="col-md-12">
  <div class="row">
    <?php echo e($photos->links()); ?>

  </div>
</div>  


<script type="text/javascript" src="<?php echo e(url('highslide/highslide-with-gallery.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('highslide/highslide.css')); ?>" />
<script type="text/javascript">



  hs.graphicsDir = 'highslide/graphics/';

  hs.align = 'center';

  hs.transitions = ['expand', 'crossfade'];

  hs.wrapperClassName = 'dark borderless floating-caption';

  hs.fadeInOut = true;

  hs.dimmingOpacity = .75;



  // Add the controlbar

  if (hs.addSlideshow) hs.addSlideshow({

    //slideshowGroup: 'group1',

    interval: 5000,

    repeat: false,

    useControls: true,

    fixedControls: 'fit',

    overlayOptions: {

      opacity: .6,

      position: 'bottom center',

      hideOnMouseOut: true

    }

  });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\monprojetbali\resources\views/photos.blade.php ENDPATH**/ ?>