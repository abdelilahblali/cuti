

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List of steps</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>




<style type="text/css">
.check { color: green; margin-right: 20px;  }
</style>

<div class="col-md-12" style="position: absolute; margin-top: 130px">

  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite" style="width:160% !important;; max-width:200% !important;">
    <thead>
      <tr>
        <td>Sale</td>
        <td>Client</td>

        <td>CONTRAT DE RESERVATION</td>
        <td>CONTRAT DE PARTENARIAT</td>
        <td>5000</td>
        <td>PROCURATION TERRAIN</td>
        <td>LEASE AGREEMENT</td>
        <td>PAIMENT TERRAIN</td>
        <td>NAMA PTPMA</td>
        <td>AKTA</td>
        <td>IMB</td>
        <td>Contrat Construction</td>
        <td>Date C.C.</td>
        <td>Payment 40 %(1)</td>
        <td>Meeting Deco</td>
        <td>Location</td>        
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><span class="bold ref"><a style="color:white" title="Show" href="<?php echo e(route('stepEdit',[ 'ref' => $step->ref ])); ?>"><?php echo e($step->cod); ?></a></span></td>
        <td><span class="bold" style="color:black"><?php echo e($step->civ); ?> <?php echo e($step->nom); ?> <?php echo e($step->pre); ?></span></td>

        <td><span class="bold"><?php echo e($step->contratreservation); ?></span></td>
        <td><span class="bold"><?php echo e($step->contratreservationdate); ?></span></td>
        <td><span class="bold"><?php echo e($step->five); ?></span></td>
        <td><span class="bold"><?php echo e($step->procuation); ?></span></td>
        <td><span class="bold"><?php echo e($step->leaseagreement); ?></span></td>
        <td><span class="bold"><?php echo e($step->terrain); ?></span></td>
        <td><span class="bold"><?php echo e($step->ptpmaname); ?></span></td>
        <td><span class="bold"><?php echo e($step->akta); ?></span></td>
        <td><span class="bold"><?php echo e($step->imbptpma); ?></span></td>
        <td><span class="bold"><?php echo e($step->contratconstruction); ?></span></td>
        <td><span class="bold"><?php echo e($step->contratconstructiondate); ?></span></td>
        <td><span class="bold"><?php echo e($step->four1); ?></span></td>
        <td><span class="bold"><?php echo e($step->meet); ?></span></td>
        <td><span class="bold"><?php echo e($step->landname); ?></span></td>


        <td><span class="bold"><?php echo e($step->par); ?>, <span style="font-size: 9px"><?php echo e($step->fait); ?></span></span></td>
        <td align="right">
          <a title="Show" href="<?php echo e(route('stepEdit',[ 'ref' => $step->ref ])); ?>"><button class="btn btn-xs btn-default"><i class="fa fa-eye a-icon"></i></button></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/step.blade.php ENDPATH**/ ?>