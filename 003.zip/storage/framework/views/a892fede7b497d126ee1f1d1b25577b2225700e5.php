

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cubes"></i> Gestion des produits</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('produitAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> Nouveau Produit</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
    
    <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
      <thead>
        <tr>
          <td width="80"></td>
          <td>Nom du produit</td>
          <td width="100" align="center">Prix ( x1 )</td>
          <td width="100" align="center">Prix ( x2 )</td>
          <td width="100" align="center">Prix ( x3 )</td>
          <td width="100" align="center">Prix ( x4 )</td>
          <td width="100" align="center">Prix ( x5 )</td>
          <td width="120" align="center">Commandes</td>
          <td width="120" align="center">Stock</td>
          <td width="130"></td>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><img src="<?php echo e(url('pro')); ?>/<?php echo e($prod->img); ?>" style="width: 60px"></td>
            <td>
              <?php echo e($prod->produit); ?>

              <br/>
              ID : <b><?php echo e($prod->id); ?></b>
              <br/>
              Catégorie : <b><?php echo e($prod->categorie); ?></b>
            </td>
            <td align="center" style="padding-top: 26px !important;"><span class="bold <?php if($prod->pri1!=0): ?> prix <?php endif; ?> "><?php echo e(number_format($prod->pri1, 2)); ?></span></td>
            <td align="center" style="padding-top: 26px !important;"><span class="bold <?php if($prod->pri2!=0): ?> prix <?php endif; ?>"><?php echo e(number_format($prod->pri2, 2)); ?></span></td>
            <td align="center" style="padding-top: 26px !important;"><span class="bold <?php if($prod->pri3!=0): ?> prix <?php endif; ?>"><?php echo e(number_format($prod->pri3, 2)); ?></span></td>
            <td align="center" style="padding-top: 26px !important;"><span class="bold <?php if($prod->pri4!=0): ?> prix <?php endif; ?>"><?php echo e(number_format($prod->pri4, 2)); ?></span></td>
            <td align="center" style="padding-top: 26px !important;"><span class="bold <?php if($prod->pri5!=0): ?> prix <?php endif; ?>"><?php echo e(number_format($prod->pri5, 2)); ?></span></td>
            <td align="center" style="padding-top: 26px !important;"><span class="ref bold"><?php echo e($prod->qte); ?></span></td>
            <td align="center" style="padding-top: 26px !important;"><span class="ref bold"><?php echo e($prod->qte); ?></span></td>
            <td style="padding-top: 24px !important;padding-right: 10px !important ">
              <a href="<?php echo e(route('produitEdit',[ 'ref' => $prod->ref ])); ?>"><button class="btn btn-xs btn-default"  style="text-align: center; width: 30px !important"><i class="fa fa-edit a-icon"></i></button></a>
              <a href="<?php echo e(route('produitDeleted',[ 'ref' => $prod->ref ])); ?>" onclick="return confirm('Vous-êtes sûr de supprimer ce produit ?'); event.preventDefault(); document.getElementById('prodDelete').submit();"><button class="btn btn-xs btn-danger" style="text-align: center;width: 30px !important"><i class="fa fa-trash a-icon"></i></button></a>
              <a href="<?php echo e(route('produitImages',[ 'ref' => $prod->ref ])); ?>"><button class="btn btn-xs btn-default"  style="text-align: center;width: 30px !important"><i class="fa fa-picture-o a-icon"></i></button></a>
              <form id="prodDelete" action="<?php echo e(route('produitDeleted',[ 'ref' => $prod->ref ])); ?>" method="POST">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo csrf_field(); ?>
              </form>  
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/produit.blade.php ENDPATH**/ ?>