

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section>
<div class="container">
    <h4 class="my-title">Contactez-nous</h4>
    <div class="row" style="margin-top: 30px">
        <div class="col-md-8">
           
            <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title">N'hésitez plus à nous contacter pour n'importe quelle information</h3>
              </div>
              <div class="panel-body">
                <form>
                      <div class="form-group">
                        <label for="nom">Nom</label>
                        <input type="text" class="form-control" name="nom" placeholder="Nom">
                    </div>
                    <div class="form-group">
                        <label for="prenom">Prénom</label>
                        <input type="text" class="form-control" name="prenom" placeholder="Prénom">
                    </div>
                    <div class="form-group">
                        <label for="telephone">Téléphone</label>
                        <input type="text" class="form-control" name="telephone" placeholder="Téléphone">
                    </div>
                    <div class="form-group">
                        <label for="message" >Message</label>
                        <textarea class="form-control" name="message" placeholder="Message" rows="10"></textarea>
                    </div>
                    <button type="submit" class="btn btn-default">Envoyer le message</button>
                </form>
              </div>
            </div>

        </div>
        <div class="col-md-4">
            <div class="panel panel-default">
              <div class="panel-heading">Informations de contact</div>
              <div class="panel-body">
                <h2 style="text-align: center; font-weight: bold"><?php echo e($u->telephone); ?></h2>
              </div>
            </div>
        </div>
    </div>
</div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.mystore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/contact.blade.php ENDPATH**/ ?>