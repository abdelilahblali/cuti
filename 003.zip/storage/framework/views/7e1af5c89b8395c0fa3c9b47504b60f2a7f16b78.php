

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-unlock"></i> Modifier mon mot de passe </li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Erreur')): ?>
  <div class="alert alert-danger">
    <?php echo e(session()->get('Erreur')); ?>

  </div>
  <?php endif; ?>
</div>

<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('passwordEdited')); ?>">
      <?php echo e(csrf_field()); ?>


      <div class="row">
          <div class="col-md-6">
              <h6><label for="pas1" class="control-label form-label label01">Nouveau mot de passe <span class="c3_color">*</span></label></h6>
              <input type="password" name="pas1" id="pas1" class="form-control" required />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="pas2" class="control-label form-label label01">Confirmation <span class="c3_color">*</span></label></h6>
              <input type="password" name="pas2" id="pas2" class="form-control" required />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-6">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Modifier mon mot de passe</button>
        </div>
      </div>
    </form>
  </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\monprojetbali\admin\resources\views/password.blade.php ENDPATH**/ ?>