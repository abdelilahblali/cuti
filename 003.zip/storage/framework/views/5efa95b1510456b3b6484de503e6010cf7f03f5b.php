

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title>Magnitude Construction : Sales management</title>
    <link href="<?php echo e(url('dash/css/root.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('dash/style.css')); ?>">
    <link rel="icon" href="<?php echo e(url('imgs/logo.png')); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('chosen/chosen.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/fonts/font-awesome.min.css')); ?>">
</head>

<body>

    <div id="top" class="clearfix">
        <div class="applogo" style="width: 650px !important; padding-top: 9px, color:white; font-size: 20px; padding-top: 15px">
            SALES <span style="font-weight: bold">MANAGEMENT</span>
        </div>
        <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-bars"></i></a>
        <div class="col-md-2">
        </div>
        <ul class="top-right" style="background-color: #0AA2A5; padding:10px 8px">
            <li class=" link">
                <a href="#" style="padding-top: 2px; padding-right: 20px; padding-left: 20px">Welcome <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></a>
            </li>
        </ul>
    </div>


    
    <div class="sidebar clearfix">
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Menu</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li><a href="<?php echo e(route('ventes')); ?>" <?php if(Route::is('ventes') or Route::is('venteEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-diamond"></i></span><span class="panel_menu">Sales</span></a></li>
          <!-- <li><a href="<?php echo e(route('infos')); ?>"  <?php if(Route::is('infos') or Route::is('infosEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-info"></i></span><span class="panel_menu">Infos</span></a></li> -->
          <li><a href="<?php echo e(route('land')); ?>"   <?php if(Route::is('land') or Route::is('landEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-map-marker"></i></span><span class="panel_menu">Land</span></a></li>
          <li><a href="<?php echo e(route('suivis')); ?>" <?php if(Route::is('suivis') or Route::is('suivisEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-calendar"></i></span><span class="panel_menu">Suivi Contrat</span></a></li>
          <li><a href="<?php echo e(route('ptpma')); ?>"  <?php if(Route::is('ptpma') or Route::is('ptpmaEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-file-o"></i></span><span class="panel_menu">PT PMA</span></a></li>
          <li><a href="<?php echo e(route('bank')); ?>"   <?php if(Route::is('bank') or Route::is('bankEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-bank"></i></span><span class="panel_menu">Bank</span></a></li>
          <li><a href="<?php echo e(route('architecture')); ?>" <?php if(Route::is('architecture') or Route::is('architectureEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-print"></i></span><span class="panel_menu">Architecture</span></a></li>
          <li><a href="<?php echo e(route('herlinda')); ?>"     <?php if(Route::is('herlinda') or Route::is('herlindaEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-user"></i></span><span class="panel_menu">Construction</span></a></li>
          <li><a href="<?php echo e(route('payment')); ?>"      <?php if(Route::is('payment') or Route::is('paymentEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-credit-card"></i></span><span class="panel_menu">Payment</span></a></li>
          <li><a href="<?php echo e(route('progress')); ?>"     <?php if(Route::is('progress') or Route::is('progressEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-spinner"></i></span><span class="panel_menu">Worksite Progress</span></a></li>
          <li><a href="<?php echo e(route('taxe')); ?>"         <?php if(Route::is('taxe') or Route::is('taxeEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-legal"></i></span><span class="panel_menu">Taxe</span></a></li>
          <li><a href="<?php echo e(route('building')); ?>"     <?php if(Route::is('building') or Route::is('buildingEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-building-o"></i></span><span class="panel_menu">Detail Building</span></a></li>
          <li><a href="<?php echo e(route('marketing')); ?>"    <?php if(Route::is('marketing') or Route::is('marketingEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-bell"></i></span><span class="panel_menu">Marketing</span></a></li>
          <li><a href="<?php echo e(route('step')); ?>"         <?php if(Route::is('step') or Route::is('stepEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-sitemap"></i></span><span class="panel_menu">Project steps</span></a></li>
          <li><a href="<?php echo e(route('banjar')); ?>"       <?php if(Route::is('banjar') or Route::is('banjarEdit')): ?> style="background-color: rgba(0, 0, 0, 0.1);" <?php endif; ?> ><span class="icon color5"><i class="fa fa-money"></i></span><span class="panel_menu">Payment Banjar</span></a></li>
          


          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-clock-o"></i></span><span class="panel_menu">S.C. Construction</span></a></li> -->
          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-th-large"></i></span><span class="panel_menu">Equipements Ex.</span></a></li> -->
          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-plus"></i></span><span class="panel_menu">Tampons</span></a></li> -->
          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-magnet"></i></span><span class="panel_menu">Variable</span></a></li> -->
        </ul>
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Bases</li>
        </ul>
        <ul class="sidebar-panel nav">
          <?php if( Auth::user()->typ=='ADMIN' ): ?>
          <li><a href="<?php echo e(route('client')); ?>"><span class="icon color5"><i class="fa fa-lock"></i></span><span class="panel_menu">Users</span></a></li>
          <?php endif; ?>
          <li><a href="<?php echo e(route('subkon')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span><span class="panel_menu">Subkon</span></a></li>
          <li><a href="<?php echo e(route('notary')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span><span class="panel_menu">Notary</span></a></li>
          <li><a href="<?php echo e(route('landname')); ?>"><span class="icon color5"><i class="fa fa-map-marker"></i></span><span class="panel_menu">Lands Name</span></a></li>
          <li><a href="<?php echo e(route('notifications')); ?>"><span class="icon color5"><i class="fa fa-bell"></i></span><span class="panel_menu">Notifications</span></a></li>
        </ul>
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Account</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('password')); ?>"><span class="icon color5"><i class="fa fa-unlock"></i></span>
            <span class="panel_menu">Password</span></a>
          </li>
        </ul>
        <ul class="sidebar-panel nav" style="position: fixed; bottom: 0; background-color: red; width: 195px; margin-left: 0; padding-left: 20px">
          <li>
            <a href="<?php echo e(route('logout' )); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span class="icon color5"><i class="fa fa-power-off" style="color: white"></i></span>
            <span class="panel_menu" style="color: white">Sign Out</span></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>   
          </li>
        </ul>
    </div>
    



    <div class="content">
        <?php echo $__env->yieldContent('content'); ?> 
    </div>

     <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button> 


    <script src="<?php echo e(url('dash/js/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('dash/js/datatables/datatables.min.js')); ?>"></script>
    <script> $(document).ready(function() { $('#tab').DataTable( { "order": [[ 1, "asc" ]] } ); } ); </script>
    
    <script src="http://ajax.googleapis.com/ajax/libs/mootools/1.3/mootools-yui-compressed.js"></script>
    <script src="<?php echo e(url('chosen/mootools-more-1.4.0.1.js')); ?>"></script>
    <script src="<?php echo e(url('chosen/chosen.js')); ?>"></script>
    <script src="<?php echo e(url('chosen/Locale.en-US.Chosen.js')); ?>"></script>
    <script> $$(".chzn-select").chosen(); $$(".chzn-select-deselect").chosen({allow_single_deselect:true}); </script>

    <script type="text/javascript">
    var inputs, index;
    inputs = document.getElementsByTagName('input');
    for (index = 0; index < inputs.length; ++index) {
        // deal with inputs[index] element.
    }
    </script>


    <script type="text/javascript">
    document.querySelectorAll('input[type="text"]').forEach(e => {
      e.addEventListener('focusout', setInputBackground)
    });
    document.querySelectorAll('input[type="date"]').forEach(e => {
      e.addEventListener('focusout', setInputBackground)
    });

    document.querySelectorAll('select').forEach(e => {
      e.addEventListener('focusout', setInputBackground)
    });

    function setInputBackground() {
      this.style.backgroundColor = !!this.value ? "#e0ffef" : "#ffe8e5";
    }

    var inputs, index;
    inputs = document.getElementsByTagName('input');
    for (index = 0; index < inputs.length; ++index) {
      // deal with inputs[index] element.
      inputs[index].style.backgroundColor = !!inputs[index].value ? "#e0ffef" : "#ffe8e5";
    }

    var inputs2, index2;
    inputs2 = document.getElementsByTagName('select');
    for (index2 = 0; index2 < inputs2.length; ++index2) {
      inputs2[index2].style.backgroundColor = !!inputs2[index2].value ? "#e0ffef" : "#ffe8e5";
    }
    </script>




    <script type="text/javascript">
      //Get the button:
      mybutton = document.getElementById("myBtn");
      // When the user scrolls down 20px from the top of the document, show the button
      window.onscroll = function() {scrollFunction()};
      function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          mybutton.style.display = "block";
        } else {
          mybutton.style.display = "none";
        }
      }
      // When the user clicks on the button, scroll to the top of the document
      function topFunction() {
        document.body.scrollTop = 0; // For Safari
        document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
      } 
    </script>

</body>

    

</html><?php /**PATH C:\wamp64\www\mag.sales\resources\views/master/admin.blade.php ENDPATH**/ ?>