

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-file"></i> Gestion des landings pages</li>
      </ol>
     <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('landing')); ?>" class="btn-right "><i class="fa fa-list"></i> Liste des landings</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-6">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Danger')): ?>
  <div class="alert alert-danger">
      <?php echo e(session()->get('Danger')); ?>

  </div>
  <?php endif; ?>


  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('landingAdded')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        	<div class="col-md-12">
            	<h6><label for="pro" class="control-label form-label label01">Produit <span class="c3_color">*</span></label></h6>
              <select name="pro" class="form-control" placeholder="Nom du produit">
                <option>Selectionner un produit</option>
                <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($prod->ref); ?>"><?php echo e($prod->produit); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        	</div>
          <div class="col-md-12">
              <h6><label for="des" class="control-label form-label label01">Désignation <span class="c3_color">*</span></label></h6>
              <input type="text" name="des" id="des" class="form-control" placeholder="Nom de la page (Que les chiffres et les lettres)">
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-check" style="padding-right: 10px"></i>Ajouter la page </button>
        </div>
      </div>
    </form>
  </div>
</div>


<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js'></script><script  src="./script.js"></script>

<script type="text/javascript">

    $('#des').keypress(function (e) {
       var regex = new RegExp("^[a-zA-Z0-9]+$");
       var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
       if (regex.test(str)) {
           return true;
       }
       e.preventDefault();
       return false;
});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/landingAdd.blade.php ENDPATH**/ ?>