<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Factures</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 5px">Architecture</h4>

<div class="row" style="padding: 13px">
  <div class="col-md-3">
    <a href="<?php echo e(route('clientFolder_design0',[ 'ref' => $ref ])); ?>"><button class=" btn-block" style="color:gray">Design 0</button></a>
  </div>

  <div class="col-md-3">
    <a href="<?php echo e(route('clientFolder_design1',[ 'ref' => $ref ])); ?>"><button class=" btn-block" style="color:gray">Design 1</button></a>
  </div>

  <div class="col-md-3">
    <a href="<?php echo e(route('clientFolder_design2',[ 'ref' => $ref ])); ?>"><button class=" btn-block" style="color:gray">Design 2</button></a>
  </div>

  <div class="col-md-3">
    <a href="<?php echo e(route('clientFolder_design3',[ 'ref' => $ref ])); ?>"><button class=" btn-block" style="color:gray">Design 3</button></a>
  </div>
</div>


<div class="row" style="padding: 13px">
  <div class="col-md-3">
    <a href="<?php echo e(route('clientFolder_plan',[ 'ref' => $ref ])); ?>"><button class=" btn-block" style="color:gray">Plan</button></a>
  </div>

  <div class="col-md-3">
    <a href="<?php echo e(route('clientFolder_interior',[ 'ref' => $ref ])); ?>"><button class=" btn-block" style="color:gray">Interior Design</button></a>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/clientFolder_architecture.blade.php ENDPATH**/ ?>