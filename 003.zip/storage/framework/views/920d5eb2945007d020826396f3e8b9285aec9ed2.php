<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <a href="<?php echo e(route('clientAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> New customer </a>
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>

  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td>Code</td>
        <td>Full name</td>
        <td>Email</td>
        <td>Login</td>
        <td>Notification</td>
        <td>Sent</td>
        <td>Doc</td>
        <td align="center">Options</td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr onclick="window.location='<?php echo e(route('clientFolder',[ 'ref' => $cli->ref ])); ?>';">
        <td><span class="bold ref" style="color:black"><?php echo e($cli->code); ?></span></td>
        <td><span class="bold" style="color:black"><?php echo e($cli->civ); ?> <?php echo e($cli->nom); ?> <?php echo e($cli->pre); ?></span></td>
        <td><span class="bold"><?php echo e($cli->mail); ?></span></td>
        <td><span class="tel"><?php echo e($cli->username); ?></span></td>
        <td>
            <?php if($cli->sent==0): ?>
            <a title="Send notification to customer" href="<?php echo e(route('clientNotification',[ 'mail' => $cli->mail ])); ?>" onclick="return confirm('Are you sure you send a notification to the customer??');"><button class="btn btn-xs btn-default"><i class="fa fa-send a-icon"></i>Send</button></a>
            <?php else: ?>
            <a title="Send notification to customer" href="<?php echo e(route('clientNotification',[ 'mail' => $cli->mail ])); ?>" onclick="return confirm('Are you sure you send a notification to the customer??');"><button class="btn btn-xs btn-success"><i class="fa fa-send a-icon"></i>Send</button></a>
            <?php endif; ?>
        </td>
        <td><span style="font-size:10px"><?php echo e($cli->sent_dat); ?></span>
        </td>
        <td align="center">
            <?php if($cli->doc==0): ?>
            <a title="Authorize this client to view the documents" href="<?php echo e(route('docView',[ 'mail' => $cli->mail, 'vf' => 1 ])); ?>" onclick="return confirm('Vous-êtes sûr d autoriser ce client à consulter les documents ?');"><i class="fa fa-times a-icon" style='color:red'></i></a>
            <?php else: ?>
            <a title="Do not allow this client to view documents" href="<?php echo e(route('docView',[ 'mail' => $cli->mail, 'vf' => 0 ])); ?>" onclick="return confirm('Vous-êtes sûr de ne pas autoriser ce client à consulter les documents ?');"><i class="fa fa-check a-icon" style='color:green'></i></a>
            <?php endif; ?>
        </td>
        <td align="center">
          <a title="View" href="<?php echo e(route('clientFolder',[ 'ref' => $cli->ref ])); ?>"><i class="fa fa-folder a-icon"></i></a>
          <a title="Documents management" href="<?php echo e(route('clientDocs',[ 'ref' => $cli->ref ])); ?>"><i class="fa fa-file-o a-icon"></i></a>
          <a title="Pictures management" href="<?php echo e(route('clientPhotos',[ 'ref' => $cli->ref ])); ?>"><i class="fa fa-picture-o a-icon"></i></a>
          <a title="Edit customer" href="<?php echo e(route('clientEdit',[ 'ref' => $cli->ref ])); ?>"><i class="fa fa-edit a-icon"></i></a>
          <a title="Delete customer" href="<?php echo e(route('clientDelete',[ 'ref' => $cli->ref ])); ?>" onclick="return confirm('Are you sure you want to delete this client?'); event.preventDefault(); document.getElementById('clientDelete').submit();"><i class="fa fa-trash a-icon"></i></a>
          <form id="clientDelete" action="<?php echo e(route('clientDelete',[ 'ref' => $cli->ref ])); ?>" method="POST">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
          </form>  
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.min.js')); ?>"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "asc" ]] } ); } ); </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/client.blade.php ENDPATH**/ ?>