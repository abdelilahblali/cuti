<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">PARCE QU’À PLUSIEURS, ON EST MEILLEUR </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">UN RÉSEAU SOLIDE DEPUIS PLUS DE 12ANS </h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Pour nous permettre d’accomplir notre mission et offrir nos services de façon optimale en recrutement du personnel de maison, <b><span style="color:#EC008C; padding-left: 5px; font-weight: bold">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> peut compter sur la collaboration de plusieurs partenaires solides : des organisations privées ou publiques, qui partagent nos valeurs et qui souhaitent appuyer notre mission.
                            <br/>
                            <b><span style="color:#EC008C; font-weight: bold">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> a tissé des liens solides depuis sa création avec de nombreuses associations de défense des droits de la femme, des enfants ou bien des consulats qui nous permettent de connaitre d’avantage et de s’assurer de la fiabilité du personnel étranger que nous nous engageons.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-4" style=" padding: 0; margin-left: 0px">
                            <img src="<?php echo e(url('imgs/partenaires/1.jpg')); ?>" style="width: 250px">
                            </div>
                           <div class="col-md-4" style=" padding: 0; margin-left: 0px">
                            <center><img src="<?php echo e(url('imgs/partenaires/2.jpg')); ?>" style="width: 250px"></center>
                            </div>
                            <div class="col-md-4" style=" padding: 0; margin-left: 0px">
                            <img src="<?php echo e(url('imgs/partenaires/3.jpg')); ?>" style="width: 250px; float: right;">
                            </div>
                          </div>

                          

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/partenaires.blade.php ENDPATH**/ ?>