<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <title>MAGNITUDE CONSTRUCTION</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <meta property="og:locale" content="fr_FR" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="" />
  <meta property="og:url" content="https://keenthemes.com/products/ceres-html-pro" />
  <meta property="og:site_name" content="" />
  <link rel="canonical" href="" />
  <link rel="shortcut icon" href="<?php echo e(url('imgs/logo.png')); ?>" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
  <link href="<?php echo e(url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(url('theme/assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(url('theme/assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src= '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5FS8GGP');</script>

  <link href="<?php echo e(url('signatureAssets/css/bootstrap.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(url('signatureAssets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(url('signatureAssets/css/bootstrap-select.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(url('signatureAssets/css/app_style.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  #signArea{ width:304px; margin: 15px auto; }
  .sign-container { width: 90%; margin: auto; }
  .sign-preview { width: 150px; height: 50px; margin: 10px 5px; }
  .center-text { text-align: center; }
  </style>

  <style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
  </style>
</head>
<body id="kt_body" style=" background-image: url('<?php echo e(url('theme/assets/media/patterns/header-bg-dark.png')); ?>')" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled">
     
<div class="d-flex flex-column flex-root">
  <div class="page d-flex flex-row flex-column-fluid">
    <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
      
      <div class="container" style="padding: 30px;">
          <center><img alt="Logo" src="<?php echo e(url('imgs/logo_noel.png')); ?>" style="width:260px;" /></center>
      </div>

      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($i->sign1==''): ?>
        <div id="">
          <div class="content flex-row-fluid" id="kt_content">
              <div class="card card-page">
                <div class="card-body" style="padding: 0px 38px 30px 33px">
                  <div class="col-md-8 col-md-offset-2">
                  <div class="card card-xxl-stretch">
                    <p style="padding: 20px 50px  10px 50px ; text-align: center; ">
                      <br><br>
                      <strong>
                      Hello <b><?php echo e($i->civ); ?> <?php echo e($i->nom); ?> <?php echo e($i->pre); ?></b>
                      </strong>
                      <br><br>
                      Sur cette base, veuillez trouver en pièce jointe le détail de nos relevés bancaire ou figure vos versements. 
                      <br><br>
                      Afin de régulariser cette situation, 2 options s’offrent à vous : 
                      <br>
                      - Le paiement de la somme manquante sur notre compte bancaire,
                      <br>
                      - ou le prélèvement sur vos revenus locatif de votre villa. 
                      <br><br>
                      S’il y a prélèvement sur le compte bancaire de votre société celui- ci sera opéré par votre entreprise de gestion, 
                      <br><br>
                      Ci-dessous notre procuration pour le prélèvement sur votre compte bancaire de société ;
                      <br><br>
                      Je soussignée Marie Royère agissant en qualité de directeur de l’entreprise PT Magnitude Construction, donne à l’entreprise Bali Super host Management procuration pour retirer en son nom les fonds manquants comme subventionné et figurant sur la facture jointe. L’entreprise Bali super host se verra ainsi seul mandataire pour retirer et manager le compte bancaire de votre société. Magnitude se retire définitivement du projet et se rapprochera automatiquement de votre entreprise de management. 
                      <br>
                      Veuillez svp nous donner votre décisions et accords, 
                      <br>
                      Vous trouverez un formulaire à remplir afin de confirmer ces informations, 
                      <br>
                      Veuillez trouver le détail sur la facture que nous avons joint à ce courriel.
                      <br>
                      S'il vous plaît laissez-moi savoir si vous avez des questions, 
                      <br>
                      Vous adressant nos sincères salutations, 
                      <br><br>
                    </p>

                    <div class="col-md-8 col-md-offset-2" style="padding: 30px 10px">
                      <form method="POST" action="<?php echo e(route('signatureSaved',[ 'ref' => $i->ref ])); ?>" enctype="multipart/form-data" style="background: transparent !important;">
                        <?php echo e(csrf_field()); ?>


                          <h3>Facture #1 <a href="https://sales.magnitudeconstruction.com/public/media/signature/<?php echo e($i->inv1); ?>" target="_blank" style="font-size: 12px; color:#0AA2A5; font-weight: bold; float: right;"><i class="fa fa-arrow-right"></i> Cliquer ici pour consulter la facture</a></h3>
                          <div class="col-md-12" style="padding: 30px 55px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 30px;">
                            <div class="mb-5">
                              <label for="sign1" class=" form-label">Souhaitez-vous êtres prélever sur vos revenus locatifs ? </label>
                              <select  class="form-control" name="sign1" value="" required>
                                <option></option>
                                <option value="YES">OUI</option>
                                <option value="NO">NON</option>
                              </select>
                            </div>
                            <div class="mb-5">
                              <label for="confirm1" class=" form-label">Confirmez-vous cette facture</label>
                              <select  class="form-control" name="confirm1" value="" required>
                                <option></option>
                                <option value="YES">OUI</option>
                                <option value="NO">NON</option>
                              </select>
                            </div>
                          </div>

                          <h3>Facture #2 <a href="https://sales.magnitudeconstruction.com/public/media/signature/<?php echo e($i->inv2); ?>" target="_blank" style="font-size: 12px;color:#0AA2A5; font-weight: bold; float: right;"><i class="fa fa-arrow-right"></i> Cliquer ici pour consulter la facture</a></h3>
                          <div class="col-md-12" style="padding: 30px 55px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 20px;">
                            <div class="mb-5">
                              <label for="sign2" class=" form-label">Accepter</label>
                              <select  class="form-control" name="sign2" value="" required>
                                <option></option>
                                <option value="YES">OUI</option>
                                <option value="NO">NON</option>
                              </select>
                            </div>
                            <div class="mb-5">
                              <label for="confirm2" class=" form-label">Confirmez-vous cette facture</label>
                              <select  class="form-control" name="confirm2" value="" required>
                                <option></option>
                                <option value="YES">OUI</option>
                                <option value="NO">NON</option>
                              </select>
                            </div>
                          </div>

                          <h3>Signature numérique</h3>
                          <div class="col-md-12" style="padding: 30px 0px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 20px;">
                            <div class="mb-5">
                              <div id="signArea" >
                                <p style="text-align: center;">Je soussigné  autorise Magnitude a prélevé le montant demandée via l’entreprise Bali super Host sur le compte de société. </p>
                                <div class="sig sigWrapper" style="height:auto;">
                                  <div class="typed"></div>
                                  <canvas class="sign-pad" id="sign-pad" width="300" height="100"></canvas>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="mb-5">
                              <button class="btn btn-success btn-sm" style="margin-top: 10px"  id="btnSaveSign"><i class="fa fa-save"></i>Entegistrer & Envoyer</button>
                          </div>
                        </form>
                    </div>

                  </div>
                  </div>
                </div>
              </div> 
          </div>
        </div>
        <?php else: ?>
        <div id="">
          <div class="content flex-row-fluid" id="kt_content">
              <div class="card card-page">
                <div class="card-body" style="padding: 0px 38px 30px 33px">
                  <div class="col-md-8 col-md-offset-2">
                  <div class="card card-xxl-stretch" style="min-height: 800px; border-radius:0; padding:150px 80px">
                    
                    <div class="alert alert-danger" style="font-weight: bold; text-align:center;">Vous avez déja répondre sur notre formulaire, merci</div>

                  </div>
                  </div>
                </div>
              </div> 
          </div>
        </div>

        
        <?php endif; ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>

  <div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
      <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-bold me-1"><?php echo date("Y"); ?> ©</span>
        <a href="https://magnitudeconstruction.com/" target="_blank" class="text-gray-800 text-hover-primary">Magnitude Construction</a>
      </div>
    </div>
  </div>
</div>


<script src="<?php echo e(url('signatureAssets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('signatureAssets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('signatureAssets/js/bootstrap-select.js')); ?>"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link href="<?php echo e(url('signatureAssets/css/jquery.signaturepad.css')); ?>" rel="stylesheet">
<script src="<?php echo e(url('signatureAssets/js/numeric-1.2.6.min.js')); ?>"></script> 
<script src="<?php echo e(url('signatureAssets/js/bezier.js')); ?>"></script>
<script src="<?php echo e(url('signatureAssets/js/jquery.signaturepad.js')); ?>"></script> 
<script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>
<script src="<?php echo e(url('signatureAssets/js/json2.min.js')); ?>"></script>
<script>
$(document).ready(function(e){
$(document).ready(function() { $('#signArea').signaturePad({drawOnly:true, drawBezierCurves:true, lineTop:90}); });
$("#btnSaveSign").click(function(e){ 
  html2canvas([document.getElementById('sign-pad')], {
    onrendered: function (canvas) {
      var canvas_img_data = canvas.toDataURL('image/png');
      var img_data = canvas_img_data.replace(/^data:image\/(png|jpg);base64,/, "");
      //ajax call to save image inside folder
      $.ajax({
        url: '../../save_signature.php',
        data: { img_data:img_data },
        type: 'post',
        dataType: 'json',
        success: function (response) {
           // window.location.reload(); 
           alert('ok');
        }
      });
    }
  });
});
});
</script>

</body> 
</html>

<?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/signature.blade.php ENDPATH**/ ?>