

<?php $__env->startSection('content'); ?>



    <div class="clv_gallery_wrapper clv_section" style="background-image: url('<?php echo e(url('imgs/bg1.jpg')); ?>') !important; background-attachment: fixed;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading white_heading">
                            <h3>Notre Galerie</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline2.png')); ?>" alt="image" /></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="gallery_slider">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="gallery_slide">
                                            <div class="gallery_grid">

                                                <?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="gallery_grid_item" style="padding: 10px">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('gal')); ?>/<?php echo e($img->img); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="<?php echo e(url('gal')); ?>/<?php echo e($img->img); ?>" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/twobcom/glurivd.com/om/resources/views/gallery.blade.php ENDPATH**/ ?>