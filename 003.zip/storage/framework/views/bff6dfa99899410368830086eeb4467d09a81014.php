<?php $__env->startSection('content'); ?>

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Factures</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">Architecture : Design 1</h4>

<div class="col-md-12">
  <div class="panel panel-default client-content">
  <h5><i class="fa fa-plus"></i> New Photos</h5>
    <form method="POST" action="<?php echo e(route('clientFolder_design_AddImg',[ 'ref' => $ref ] )); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
      <div class="row">
          <div class="col-md-12" style="padding-top: 20px">
              <input type="hidden" name="d" value="1">
              <input type="file" name="url[]" id="url" class="form-control" multiple  />
          </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-12">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
  <div class="panel panel-default client-content" style="overflow: hidden;">
    <div class="col-md-7">
      <div class="row">
        <img src="<?php echo e($urlWebSite); ?>/media/d/<?php echo e($img->url); ?>" width="600px" id="pointer_div<?php echo e($img->ref); ?>" onclick="clickcoord<?php echo e($img->ref); ?>(event)">
        
        <br>
        <a href="<?php echo e(route('cliEntfolder_design_Delete',[ 'ref' => $img->ref ])); ?>" onclick="return confirm('Are you sure you delete this item?'); event.preventDefault(); document.getElementById('cliEntfolder_design_Delete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
        <form id="cliEntfolder_design_Delete" action="<?php echo e(route('cliEntfolder_design_Delete',[ 'ref' => $img->ref ])); ?>" method="POST">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
        </form>  

        <?php $__currentLoopData = $cmt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($c->img==$img->ref): ?>
        <div id="tagged<?php echo e($img->ref); ?>" title="<?php echo e($c->cmt); ?>" class="tag tag<?php echo e($img->ref); ?>" style="left: <?php echo e(($c->x)-13); ?>px; top: <?php echo e(($c->y)-13); ?>px; visibility: visible; background: red">
          <a href="#"><span id="span-id<?php echo e($img->ref); ?>"></span></a>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </div> 
    </div>

    <div class="col-md-5">
      <table class="table">
        <?php $__currentLoopData = $cmt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($c->img==$img->ref): ?>
          <tr style="background: rgba(0,0,0,0.05)">
            <td style="font-weight: bold;"><?php echo e($c->cmt); ?></td>
          </tr>
          <tr>
            <td>
              <table class="table">
                <?php $__currentLoopData = $answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($a->cmt==$c->ref): ?>
                  <tr>
                    <td><?php echo e($a->msg); ?></td>
                    <td>
                      <a href="<?php echo e(route('answerDelete',[ 'answer' => $a->ref ])); ?>" onclick="return confirm('Are you sure you delete this answer?'); event.preventDefault(); document.getElementById('answerDelete').submit();"><i class="fa fa-trash a-icon" style="color: red"></i></a>
                      <form id="answerDelete" action="<?php echo e(route('answerDelete',[ 'answer' => $a->ref ])); ?>" method="POST">
                          <?php echo e(method_field('DELETE')); ?>

                          <?php echo csrf_field(); ?>
                      </form>  
                    </td>
                  </tr>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              </table>
            </td>
          </tr>
          <tr>
            <td>
              <form method="POST" action="<?php echo e(route('answerAdd')); ?>" class="inline" name="form<?php echo e($c->ref); ?>">
                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="cmt" value="<?php echo e($c->ref); ?>">

                <div class="row">
                    <div class="col-md-11">
                        <input type="text" name="msg" class="form-control" placeholder="votre réponse" />
                    </div>
                  <div class="col-md-1">
                    <button type="submit" class="btn btn-s"><i class="fa fa-plus" style="padding-right: 10px"></i></button>
                  </div>
                </div>
              </form>
            </td>
          </tr>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </table>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/clientFolder_design1.blade.php ENDPATH**/ ?>