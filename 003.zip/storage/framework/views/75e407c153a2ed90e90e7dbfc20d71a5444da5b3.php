<?php use \App\Http\Controllers\Admin; ?>


<?php $__env->startSection('content'); ?>


<link rel="stylesheet" type="text/css" href="<?php echo e(url('datatable/responsive.dataTables.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(url('datatable/jquery.dataTables.min.css')); ?>">

<style type="text/css">
  .span_Manager { background:#0AA2A5; color:white; font-weight:bold; padding:5px 8px; border-radius:5px }
  .span_User { background:#0b54a3; color:white; font-weight:bold; padding:5px 8px; border-radius:5px }
  .modal-backdrop { width:100% !important; height:100% !important  }
</style>


<div class="col-lg-12 grid-margin stretch-card">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Accounts</h4>
      <div class="table-responsive">
        <table id="table1" class="table display nowrap" style="width: 100%;">
          <thead>
            <tr>
              <th></th>
              <th>Name</th>
              <th>Code</th>
              <th>Email</th>
              <th>Type</th>
              <th>Manager</th>
              <th>Department</th>
              <th>Position</th>
              <th>Phone</th>
              <th>Created</th>
              <th>Contratcs</th>
              <th>Status</th>
              <th>Options</th>
            </tr>
          </thead>
          <tbody>
          	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <?php if($item->img!=''): ?>
                <img class="img-xs rounded-circle" src="<?php echo e(url('media/profil/')); ?>/<?php echo e($item->img); ?>" >
                <?php else: ?>
                <img class="img-xs rounded-circle" src="<?php echo e(url('imgs/no-profil_magnitude.jpg')); ?>">
                <?php endif; ?>
              </td>
              <td class="bold">
                <a style="text-decoration:none !important; color:black" href="<?php echo e(route('users_update',[ 'ref' => $item->ref ])); ?>" ><span class="bold ref"><?php echo e($item->nom); ?> <?php echo e($item->pre); ?></span></a>
              </td>
              <td class="bold"><?php echo e($item->code); ?></td>
              <td><?php echo e($item->username); ?></td>

              <td>
                <a id="type_<?php echo e($item->ref); ?>" data-toggle="modal" data-target="#modal_select" onClick="getData( '<?php echo e($item->ref); ?>', 'type', '<?php echo e($item->type); ?>' );">
                  <?php if($item->category=='Manager'): ?>
                  <span class="span_<?php echo e($item->category); ?>"><?php echo e($item->category); ?></span>
                  <?php else: ?>
                  <span class="span_User">Staff</span>
                  <?php endif; ?>
                </a>
              </td>

              <td class="bold"><span><?php echo e(Admin::usersGetManager($item->ref)); ?></span></td>

              <td class="bold"><?php echo e(Admin::usersGetDepartment($item->department)); ?></td>
              <td class="bold"><?php echo e(Admin::usersGetPosition($item->position)); ?></td>
              <td><?php echo e($item->phone); ?></td>
              <td><?php echo date('m/d/Y H:i:s', strtotime($item->fait)); ?></td>

              <td>
                <?php $count = Admin::usersContracts_count($item->ref); ?>
                <?php if($count==0): ?> <i class="mdi mdi-close red bold"></i> <?php else: ?> <i class="mdi mdi-check green bold"></i> <?php endif; ?> 
                <a title="Contracts Management" href="<?php echo e(route('usersContracts',[ 'cli' => $item->ref ])); ?>" ><i class=" mdi mdi-shape-square-plus" style="margin-left: 10px;"></i></a>
              </td>

              <td>
              	<?php if($item->act==0): ?><label class="badge badge-warning">Pending</label><?php endif; ?>
              	<?php if($item->act==1): ?><label class="badge badge-success">Enabled</label><?php endif; ?>
              	<?php if($item->act==-1): ?><label class="badge badge-danger">Disabled</label><?php endif; ?>
              </td>
              <td>
                <?php if($item->act==-1 or $item->act==0): ?>
              	<a title="Enabled" href="<?php echo e(route('usersEditAct',[ 'ref' => $item->ref, 'act' => '1' ])); ?>" ><button class="btn btn-xs btn-success" type="button" onclick="return confirm('Are you sure to enable this item ?');">Enabled</button></a>
              	<?php endif; ?>
                <?php if($item->act==1): ?>
                <a title="Disabled" href="<?php echo e(route('usersEditAct',[ 'ref' => $item->ref, 'act' => '-1' ])); ?>" ><button class="btn btn-xs btn-danger" type="button" onclick="return confirm('Are you sure to disable this item ?');">Disabled</button></a>
                <?php endif; ?>

                

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script type="text/javascript">
  function getData(ref, item, value)
  {
      document.getElementById("ref").value = ref;
      document.getElementById("item").value = item;
      document.getElementById("value").value = value;
  }
</script>

<!-- Select -->
<script type='text/javascript'>
$(document).ready(function(){
  $('#save_select').click(function(){ 
      var ref = $("#ref").val(); 
        var item = $("#item").val(); 
        var value = $("#value").val(); 
     $.ajax({
        url: '../updateTypeUser/'+ref+'/'+item+'/'+value,
        type: 'get',
        dataType: 'json',
        success: function(response){ }
    });
    document.getElementById(item+"_"+ref).innerHTML = value;
    $('#modal_select').hide();
  });
});
</script>
<!-- <div class="modal fade" id="modal_select" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Type Update</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="ref" id="ref" class="form-control" value="" >
        <input type="hidden" name="item" id="item" class="form-control" value="" >
        <br>
        <select name="type" class="form-control" >
          <option value="Manager">Manager</option>
          <option value="">Staff</option>
        </select>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="save_select" data-dismiss="modal">Save</button>
      </div>
    </div>
  </div>
</div>
 -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/cuti.magnitudeconstruction.com/resources/views/users.blade.php ENDPATH**/ ?>