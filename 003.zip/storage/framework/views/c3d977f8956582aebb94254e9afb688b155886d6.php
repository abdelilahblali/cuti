<?php $__env->startSection('content'); ?>

        
  

    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/menage.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">FEMME DE MÉNAGE CLASSIQUE ET POLYVALENTES </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="margin: 0; padding: 0">
      <div class="container" style="position: relative;">
        <div class="col-md-12" >
          <div class="container" style="position: relative; z-index: 10 !important">
            <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success consultation" style="border:0; font-weight: bold; padding: 10px 25px; position: absolute; right: 0; border-radius: 0 0 5px 5px; color:white"><span style="color: white !important">Consultation Gratuite</span></button></a>
          </div>
        </div>
      </div>
    </div>



    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">LES DADAs EXISTENT TOUJOURS CHEZ   <span style="color:#EC008C; padding-left: 5px">BAYTI</span><span style="color:#00AEEF ">HELP</span></h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> est une <b>agence de recrutement et de placement d’employés de maison</b> qui propose <b>des femmes de ménage classiques ou polyvalentes, logées ou non logées, à temps plein ou à temps partiel.</b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">Une consultation </span><span style="color:#00AEEF ">gratuite</span></b> d'évaluation de vos besoins est organisée <b>selon votre calendrier sans quitter votre sofa</b> avant la mise en place de notre prestation de service à domicile.
                            <br/><br/>
                            Êtes-vous nostalgiques des temps de <b>LA DADA</b> de votre enfance ?
                            <br/><br/>
                            Nous recrutons pour vous <b>l’employée classique, des DADAs</b> qui nous font revivre le bon vieux temps et <b>uniquement les meilleures candidatures du personnel de maison qualifié bilingue ou trilingue.</b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span> propose aussi des hommes de ménage discrets et professionnels.</b>
                            <br/><br/>
                            Que vous <b>VIVIEZ</b> au <b><span style="color: #EF3937">M</span><span style="color: #EF3937">A</span><span style="color:#00B04F">R</span><span style="color: #70AD45">O</span><span style="color: #70AD45">C</span></b>, que vous soyez <b>EXPATRIÉ</b> ou tout simplement en <b>VACANCES</b>, <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> agence d’employés de maison, vous trouve <b>le collaborateur</b> adéquat à <b>vos besoins.</b>
                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/menage1.jpg')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT</span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <b>Nos femmes / Hommes de ménage peuvent vous aider au :</b>
                            <br/><br/>
                            <ul  style="">
                              <li >Rangement global de l'habitation</li>
                              <li >Entretien des sols, des parquets et meubles</li>
                              <li >Nettoyage des vitres et baies vitrées</li>
                              <li >Entretien des matériaux de valeur (marbre, argenterie, laiton, moquette délicate...)</li>
                              <li >Nettoyage courant des sanitaires et des salles de bains</li>
                              <li >Nettoyage et rangement de la vaisselle et ustensiles de cuisine, placards, réfrigérateur, fours...</li>
                              <li >Utilisation des lave-linge et lave-vaisselle</li>
                              <li >Nettoyage à la main des vêtements sur-mesure</li>
                              <li >Repassage et rangement du linge de maison</li>
                              <li >Rangement et organisation de votre garde-robe</li>
                              <li >Cuisine familiale</li>
                              <li >Course alimentaire et autres</li>
                              <li >Gestion des stocks alimentaire et produits</li>
                              <li >Entretien et gestion des fleurs</li>
                              <li >Nettoyage argenterie, laiton et cuivre</li>
                              <li >S’occuper de votre animal de compagnie</li>
                            </ul>
                            </div>
                          </div>

                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE FEMME DE MÉNAGE CLASSIQUE ET POLYVALENTE</button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/marocaines.blade.php ENDPATH**/ ?>