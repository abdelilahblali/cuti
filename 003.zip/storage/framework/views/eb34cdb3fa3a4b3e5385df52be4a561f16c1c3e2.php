<!DOCTYPE html>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta http-equiv="content-type" content="text/html; charset=iso-8859-15" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title> <?php echo e($u->store); ?> : Boutique en ligne crée par EcomBladi.com</title>
    <link href="<?php echo e(url('imgs/icon.png')); ?>" rel="icon">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/fonts/font-awesome.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <?php echo $u->head; ?>


    <?php if( Route::is('mystoreCmdAdded')): ?>  
    <?php echo $u->foot; ?>

    <?php endif; ?>

</head>
<body>
    <section>
    <div class="container">
        <?php if( $u->cover=='' or $u->cover=='0' ): ?>
            <div class="panel panel-default client-content" style="height: 250px; position: relative; border-radius: 0;  background: rgba(0,0,0,0.1);">
        <?php else: ?>
            <div class="panel panel-default client-content" style="height: 250px; position: relative; border-radius: 0; background-size: cover; background-image:url('<?php echo e(url('img-cover')); ?>/<?php echo e($u->cover); ?>')">
        <?php endif; ?>
        <?php if( $u->logo=='' or $u->logo=='0' ): ?>
            <div class="profil-logo" style="position: absolute; width: 140px; height: 140px; border-radius: 15px; background:rgba(0,0,0,0.2); top: 30px; left: 30px;"></div>
        <?php else: ?>
            <a href="<?php echo e(route('mystore',[ 'mystore' => $u->store ])); ?>"><div class="profil-logo" style="position: absolute; top: 30px; left: 30px; width: 140px; height: 140px; border-radius: 15px; background-size: contain;  background-image:url('<?php echo e(url('img-logo')); ?>/<?php echo e($u->logo); ?>')"></div></a>
        <?php endif; ?>
        <div class="store-title">
            <a href="<?php echo e(route('mystore',[ 'mystore' => $u->store ])); ?>"><?php echo e($u->store); ?></a>
        </div>
        <div class="store-menu">
            <div class="my-menu">
                <header>
                    <nav class="navbar navbar-default">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                            <div class="my-logo" style="border-bottom-color: <?php echo e($u->color1); ?>"><a class="navbar-brand " href="<?php echo e(route('mystore',[ 'mystore' => $u->store ])); ?>" ><?php echo e($u->store); ?></a></div>
                        </div>
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li><a href="<?php echo e(route('mystore',[ 'mystore' => $u->store ])); ?>">Accueil</a></li>
                                <li><a href="<?php echo e(route('mystoreAbout',[ 'mystore' => $u->store ])); ?>">A Propos</a></li>
                                <li><a href="<?php echo e(route('contact',[ 'mystore' => $u->store ])); ?>">Contact</a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right cats">
                                <li><a href="<?php echo e(route('mystoreAllPro',[ 'mystore' => $u->store ])); ?>">Produits</a></li>
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('mystoreProCat',[ 'ref' => $cat->ref, 'mystore' => $u->store ])); ?>"><?php echo e($cat->des); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </nav>
                </header>
            </div>
        </div>
    </div>
</section>

    <?php echo $__env->yieldContent('content'); ?>  


    <section class="my-footer">
        <div class="container">
            <footer style="min-height: 200px; margin-top: 20px; text-align: center;">
                <img src="<?php echo e(url('img-logo')); ?>/<?php echo e($u->logo); ?>" width="100px">
                <br/>
                <br/>
                <a href="<?php echo e(route('mystore',[ 'mystore' => $u->store ])); ?>">Accueil</a> | 
                <a href="<?php echo e(route('mystoreAbout',[ 'mystore' => $u->store ])); ?>">A propos</a> | 
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('mystoreProCat',[ 'ref' => $cat->ref, 'mystore' => $u->store ])); ?>"><?php echo e($cat->des); ?></a> | 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="">Contact</a>
            </footer>
        </div>
    </section>

    <section>
        <div class="container">
            <div style="min-height: 50px; margin-top: 30px; text-align: center;">
                <a href="<?php echo e(route('contact',[ 'mystore' => $u->store ])); ?>" style="color:black">&copy; 2020 Boutique créer par EcomBladi</a>
            </div>
        </div>
    </section>
      

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script type="text/javascript">
    $('.carousel').carousel({
  interval: 2000
})
</script>

</body>
</html>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/master/mystore.blade.php ENDPATH**/ ?>