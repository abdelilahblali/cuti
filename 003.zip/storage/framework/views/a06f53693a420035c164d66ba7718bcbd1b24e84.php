

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>La carte des éleveurs</h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                   
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="about_content" style="text-align: center;">
                            <div class="about_heading">
                        <img src="<?php echo e(url('imgs/map.png')); ?>" alt="image" width="100%" />
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/card.blade.php ENDPATH**/ ?>