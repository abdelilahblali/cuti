<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>

<style type="text/css">
  #oneColumnTable .fa { color:#0D3A5D ; }
</style>


<div class="col-md-12">
  <table id="oneColumnTable" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Name</td>
        <td>Start</td>
        <td>End</td>
        <td>Rainy days</td>
        <td>Ceremony days</td>
        <td>Public Holidays</td>
        <td>Total</td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><span class="bold ref"><?php echo e($t['code']); ?></span></td>
        <td><span class="bold" style="color:black"><?php echo e($t['nom']); ?></span></td>
        <td><span class="bold black"><?php echo e($t['de']); ?></span></td>
        <td><span class="bold black"><?php echo e($t['a']); ?></span></td>
        <td><span class="bold non"><?php echo e($t['rai']); ?></span></td>
        <td><span class="bold non"><?php echo e($t['cer']); ?></span></td>
        <td><span class="bold non"><?php echo e($t['hol']); ?></span></td>
        <td><span class="bold oui"><?php echo e($t['rai']+$t['cer']+$t['hol']); ?></span></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.min.js')); ?>"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/holidays_total.blade.php ENDPATH**/ ?>