

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-print"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('architecture')); ?>" class="btn-right "><i class="fa fa-list"></i> List of architectures </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $architecture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('architectureEdited',[ 'ref' => $item->ref ])); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="landname" class="control-label form-label label01">Land Name  </label></h6>
              <input type="text" name="landname" id="landname" class="form-control" disabled style="font-weight: bold" value="<?php echo e($item->landname); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="villaname" class="control-label form-label label01">Villa Name </label></h6>
              <input type="text" name="villaname" id="villaname" class="form-control" disabled style="font-weight: bold" value="<?php echo e($item->villaname); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="template" class="control-label form-label label01">Template  </label></h6>
              <input type="text" name="template" id="template" class="form-control" disabled style="font-weight: bold" value="<?php echo e($item->template); ?>"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="d0" class="control-label form-label label01">Design 0  </label></h6>
              <input type="date" name="d0" id="d0" class="form-control" value="<?php echo e($item->d0); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="d1" class="control-label form-label label01">Design 1  </label></h6>
              <input type="date" name="d1" id="d1" class="form-control" value="<?php echo e($item->d1); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="d2" class="control-label form-label label01">Design 2 </label></h6>
              <input type="date" name="d2" id="d2" class="form-control" value="<?php echo e($item->d2); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="d3" class="control-label form-label label01">Design 3 </label></h6>
              <input type="date" name="d3" id="d3" class="form-control" value="<?php echo e($item->d3); ?>" />
          </div>      
          <div class="col-md-4">
              <h6><label for="valide" class="control-label form-label label01">Valide  </label></h6>
              <input type="date" name="valide" id="valide" class="form-control" value="<?php echo e($item->valide); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="landscape" class="control-label form-label label01">Landscape  </label></h6>
              <input type="date" name="landscape" id="landscape" class="form-control" value="<?php echo e($item->landscape); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="c1" class="control-label form-label label01">C1  </label></h6>
              <input type="date" name="c1" id="c1" class="form-control" value="<?php echo e($item->c1); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="c2" class="control-label form-label label01">C2 </label></h6>
              <input type="date" name="c2" id="c2" class="form-control" value="<?php echo e($item->c2); ?>" />
          </div>

          <div class="col-md-3">
              <h6><label for="imb" class="control-label form-label label01">IMB </label></h6>
              <input type="date" name="imb" id="imb" class="form-control" value="<?php echo e($item->imbdate); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="meet" class="control-label form-label label01">Meeting Deco </label></h6>
              <input type="text" name="meet" id="meet" class="form-control" value="<?php echo e($item->meet); ?>" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/architectureEdit.blade.php ENDPATH**/ ?>