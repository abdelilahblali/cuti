

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Show</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('step')); ?>" class="btn-right "><i class="fa fa-list"></i> List of steps </a>
          </div>
      </div>
  </div>
</div>

<?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="contratreservation" class="control-label form-label label01">Contrat Reservation  </label></h6>
              <input type="text" name="contratreservation" id="contratreservation" class="form-control"  style="font-weight: bold" value="<?php echo e($step->contratreservation); ?>"  />
          </div>
          <div class="col-md-3">
              <h6><label for="contratreservationdate" class="control-label form-label label01">Date Contrat Reservation  </label></h6>
              <input type="text" name="contratreservationdate" id="contratreservationdate" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->contratreservationdate); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="five" class="control-label form-label label01">Payment 5000€ </label></h6>
              <input type="text" name="five" id="five" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->five); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="procuation" class="control-label form-label label01">Procuation   </label></h6>
              <input type="text" name="procuation" id="procuation" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->procuation); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="leaseagreement" class="control-label form-label label01">Lease Agreement  </label></h6>
              <input type="text" name="leaseagreement" id="leaseagreement" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->leaseagreement); ?>" />
          </div>
          <div class="col-md-6">
              <h6><label for="terrain" class="control-label form-label label01">Payment Terrain  </label></h6>
              <input type="text" name="terrain" id="terrain" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->terrain); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="ptpmaname" class="control-label form-label label01">Name PTPMA</label></h6>
              <input type="text" name="ptpmaname" id="ptpmaname" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->ptpmaname); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="akta" class="control-label form-label label01">AKTA  </label></h6>
              <input type="text" name="akta" id="akta" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->akta); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="imbptpma" class="control-label form-label label01">IMB  </label></h6>
              <input type="text" name="imbptpma" id="imbptpma" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->imbptpma); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="design" class="control-label form-label label01">Design  </label></h6>
              <input type="text" name="design" id="design" class="form-control"  style="font-weight: bold"  value="" />
          </div>
          <div class="col-md-4">
              <h6><label for="contratconstruction" class="control-label form-label label01">Contrat Construction  </label></h6>
              <input type="text" name="contratconstruction" id="contratconstruction" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->contratconstruction); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="contratconstructiondate" class="control-label form-label label01">Date Contrat Construction  </label></h6>
              <input type="text" name="contratconstructiondate" id="contratconstructiondate" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->contratconstructiondate); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="four1" class="control-label form-label label01">Payment 40% (1)  </label></h6>
              <input type="text" name="four1" id="four1" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->four1); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="facebook" class="control-label form-label label01">Building Progress  </label></h6>
              <input type="text" name="facebook" id="facebook" class="form-control"  style="font-weight: bold"  value="" />
          </div>
          <div class="col-md-3">
              <h6><label for="meet" class="control-label form-label label01">Meeting Deco  </label></h6>
              <input type="text" name="meet" id="meet" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->meet); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="landname" class="control-label form-label label01">Location  </label></h6>
              <input type="text" name="landname" id="landname" class="form-control"  style="font-weight: bold"  value="<?php echo e($step->landname); ?>" />
          </div>
      </div>


    </div>
  </div>


</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/stepEdit.blade.php ENDPATH**/ ?>