

<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/bg.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-4">
              <div class="breadcrumb_inner">
                <h3>FEMME DE MÉNAGE</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

        <div class="container">
            <div class="row">
                <div class="col-md-8 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2>LES MAROCAINES</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;">
                            <h2>FEMME DE MÉNAGE CLASSIQUE ET POLYVALENTE</h2>
                            <p style="color: black">
                                BAYTI HELP est une agence de recrutement et de placement
                                d’employés de maison qui propose des femmes de ménage
                                classiques ou polyvalentes, logées ou non logées, à temps plein ou
                                à temps partiel.
                                <br/>
                                Nos recruteurs vérifient les dossiers des employés de maison (casier
                                judiciaire, carte d’identité, adresse postale, historique professionnel,
                                vérification des références...)et vous offreun suivi disponible jusqu’à
                                chez vous après embauche de votre employé.
                                <br/><br/>
                                Le personnel de maison que nous embauchons pour
                                votre compte sont des collaborateurs très expérimentés et de
                                confiance. Notre sélection est rigoureuse et pointue depuis
                                plus de 12 ans.
                                <br/><br/>
                                Une consultation gratuite d&#39;évaluation de vos besoins est
                                organisée selon votre calendrier sans quitter votre sofa avant la
                                mise en place de notre prestation de service à domicile.
                                Êtes-vous nostalgiques des temps de LA DADA de votre enfance ?
                                Nous recrutons pour vous l’employée classique, des DADAsqui nous font
                                revivre le bon vieux temps et uniquement les meilleures candidaturesdu
                                personnel de maison qualifiébilingue ou trilingue.
                                BAYTI HELP propose aussi des hommes de ménage discrets et
                                professionnels.
                                <br/><br/>
                                Que vous viviez au MAROC, que vous soyez EXPATRIÉ ou tout
                                simplement en VACCANCES, BAYTI HELP agence d’employés de
                                maison, vous trouve le collaborateur adéquat à vos besoins.
                            </p>

                            <h5>Nos femmes / Hommesde ménage peuvent vous aider au :</h5>
                            <ul style="margin-top: 20px; margin-bottom: 30px">
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Rangement global de l&#39;habitation</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Entretien des sols, des parquets et meubles</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Nettoyage des vitres et baies vitrées</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Entretien des matériaux de valeur (marbre, argenterie, laiton, moquette délicate...)</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Nettoyage courant des sanitaires et des salles de bains</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Nettoyage et rangement de la vaisselle et ustensiles de cuisine, placards, réfrigérateur, fours...</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Utilisation des lave-linge et lave-vaisselle</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Nettoyage à la main des vêtements sur-mesure</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Repassage et rangement du linge de maison</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Rangement et organisation de votre garde-robe</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Cuisine familiale</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Course alimentaire et autres</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Gestion des stocks alimentaire et produits</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Entretien et gestion des fleurs</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> Nettoyage argenterie, laiton et cuivre</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i> S’occuper de votre animal de compagnie</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>

            <div class="col-md-4" style="margin-top: 260px">
                <img src="<?php echo e(url('imgs/i/i01.jpg')); ?>" width="100%">
                <br/><br/><br/>
                <img src="<?php echo e(url('imgs/i/i02.jpg')); ?>" width="100%">
            </div>
        </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px; background: rgba(0,0,0,0.05) ">
        <div class="container">
            <div class="row">
                <div class="col-md-4" style="margin-top: 200px">
                    <img src="<?php echo e(url('imgs/i/i03.jpg')); ?>" width="100%">
                </div>
                <div class="col-md-8 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2>LES AFRICAINES SUBSAHARIENNES</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;">
                            <h2>DES SUBSAHARIENNES ADAPTÉES AU QUOTIDIEN MAROCAIN</h2>
                            <p style="color: black">
                                BAYTI HELP est une agence de recrutement et de placement
                                d’employés de maison qui propose des femmes de ménage, des
                                agents de propreté et d’hygiène, des Noubonnes, des aide-
                                ménagères, des domestiques, des gouvernantes, des majordomeset
                                des gens de maison Sénégalaises, Ivoiriennes, Camerounaises,
                                Maliennes, Gambiennes... expérimentées, qualifiés pour le bien-être et le
                                confort de nos clients. 
                                <br/><br/>
                                Notre personnel de maison subsaharien est formé selon les exigences
                                du ménage marocain traditionnel; elles sont capables d’effectuer un
                                grand ménage ainsi quediverses tâches peuvent leurs être attribuées
                                comme le repassage, le nettoyage des vitres, la couture, la lessive, la
                                préparation des repas…<br/>
                                Nos femmes de ménage subsahariennes sont francophones,
                                anglophones ou arabophones.
                                Elles sont polyvalentesetportent un grand intérêt à la discrétion et à la
                                ponctualité.<br/>
                                BAYTI HELP propose aussi des hommes de ménage discrets et
                                professionnels.
                                <br/><br/>
                                Vous préférez une nouvelle arrivante? Ou une expérimentée ?
                                BAYTI HELP met à votre disposition sa banque de personnel de
                                maison  enrichie et entretenue depuis plus de 12ans.
                                Les employés de maison subsahariens de BAYTI HELP sont enregistrés
                                dans leurs consulats respectifs pour la sécurité de nos clients.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>

            
        </div>
    </div>
</div>


<div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-8 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2>LES ASIATIQUES</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;">
                            <h2>PHILIPPINS ET INDONÉSIENNESEFFICACES ET DISCRÈTES</h2>
                            <p style="color: black">
                                BAYTI HELP agence pionnière du recrutement et placement
                                d'employés de maison qualifiés et expérimentés, recrute pour vous
                                le meilleur personnel de maisonIndonésien et Philippins.
                                Nous disposons d’une large sélection de profils
                                asiatiquescomme«Homemade» ou « Nanny » indonésiennes ou des
                                philippins.
                                <br/><br/>
                                Des Helpers rigoureusement sélectionnées, bénéficiant d’une bonne
                                maitrise de la langue anglaise, elles sontanglophones et trilingues.
                                Un personnel de maisondiscret et minutieux dans son travail.
                                <br/>
                                BAYTI HELPa mis en place un processus de recrutement minutieux et
                                rigoureuxafin de trier pour vous, en collaboration avec ses partenaires, des
                                philippinos, des indonésiennes et du personnel de maison asiatique sous
                                contrat à durée déterminée, indéterminée et contrat saisonnier.
                                <br/>
                                Notre expertise acquise après plus de 12 années de pratique sur le
                                marché marocain et international nous a permis de développer des
                                partenariats solides avec des agences locales et à l’international
                                pour trier et faire parvenir des employés de maison asiatiques; des
                                indonésiennes et des philippins.
                            </p>

                            <h5>Nos femmes / Hommes de ménage peuvent vous aider au :</h5>
                            <ul style="margin-top: 20px; margin-bottom: 30px">
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i>Adapter le profil adéquat à votre requête en fonction de vos exigences.</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i>Vous proposez des références contrôlables.</li>
                                <li><i class="fa fa-angle-double-right" style="color: #00AEEF"></i>Vous fournir des garanties administratives certifiées.</li>
                            </ul>
                            <br/>
                            <p style="color: black">
                                BAYTI HELP reste à l&#39;écoute de ses clients et assure le suivi de l’agent placé
                                avec une garantie de remplacement illimitée en cas de non satisfaction.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>

            <div class="col-md-4" style="margin-top: 260px">
                <img src="<?php echo e(url('imgs/i/i04.jpg')); ?>" width="100%">
            </div>
        </div>
    </div>
</div>


    <div class="clv_about_wrapper clv_section" style="padding-top: 0px; background: rgba(0,0,0,0.05) ">
        <div class="container">
            <div class="row">
                <div class="col-md-4" style="margin-top: 270px">
                    <img src="<?php echo e(url('imgs/i/i05.jpg')); ?>" width="100%">
                </div>
                <div class="col-md-8 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2>Ménage de printemps</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;">
                            <h2>GRAND MÉNAGE À LA CARTE</h2>
                            <p style="color: black">
                                Votre maison ou appartement a besoin d’être nettoyé de fond en comble?
                                BAYTI HELP vous propose un service de GRAND NETTOYAGE A LA CARTESUR
                                MESUREselon vos besoins, pour faire le ménage à fond de votre intérieur. Laver vos vitres, vos
                                murs, faire briller vos sols ou encore nettoyer vos meubles.
                                <br/><br/>
                                BAYTI HELP vous propose des prestations pour un ménage complet à la carte, dispensées par
                                une employée de maison spécialement formée pour réaliser un nettoyage approfondi de votre
                                maison ou appartement.
                                <br/><br/>
                                Avec votre conseillère BAYTI HELP,vous convenez d’un véritable programme de votre choix.
                                Lessivage des murs, nettoyage et rangement des placards, dépoussiérage des tapis et rideaux,
                                nettoyage des vitres, quels que soient vos besoins, les femmes de ménage BAYTI HELP sauront
                                répondre efficacement à votre demande.
                                <br/><br/>
                                BAYTI HELP vous fait bénéficier d’une recommandation des anciens employeurs, des
                                références contrôlées et un suivi disponible jusqu’à chez vous après embauche de votre
                                employé.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>

            
        </div>
    </div>
</div>


    <div class="container" style="margin-bottom: 50px; margin-top: 50px">
        <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%"><i class="fa fa-send" style="padding-right: 20px"></i> Réserver votre femme de ménage expérimentée</button></a>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/menage.blade.php ENDPATH**/ ?>