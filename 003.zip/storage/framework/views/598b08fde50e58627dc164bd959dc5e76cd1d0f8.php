

<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/bg2.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-4">
              <div class="breadcrumb_inner">
                <h3>CUISINIÈRE</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

        <div class="container">
            <div class="row">
                <div class="col-md-8 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2>CUISINIÈRES DIPLÔMÉES ET EXPÉRIMENTÉES</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;">
                            <p style="color: black">
                                Vous recherchez un chef à domicile? Un(e) cuisinier(e) ? Nos helpers sont à
                                votre disposition pour vous proposer des collaborateurs dotés d’une cuisine
                                raffinée et de qualité. 
                                <br/><br/>
                                ​En fonction de vos souhaits, nous sélectionnons des cuisinier(e)s spécialisés
                                en cuisine Française, Italienne, Russe, Japonaise, Chinoise, etc.… ou
                                tout simplement une cuisine traditionnelle familiale.
                                Nos cuisinier(e)s respectent vos goûts et vos restrictions alimentaires. Vous
                                êtes à la diète?
                                <br/><br/>
                                Sans problème, prévenez votre chef à domicile, il élaborera votre menu de la
                                semaine en prenant en considération vos demandes mais aussi en mettant en
                                place les menus de votre famille.
                                BAYTIHELP vous offre des cuisinier(e)s à domicile, talentueux(e)s et
                                expérimenté(e)s.
                                <br/><br/>
                                Des personnes qualifiées pour vous préparer des repas variés d&#39;une cuisine
                                traditionnelle ou internationale.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>

            <div class="col-md-4" style="margin-top: 200px">
                <img src="<?php echo e(url('imgs/i/c01.jpg')); ?>" width="100%">
            </div>
        </div>
    </div>

    

    <div class="container" style="margin-bottom: 50px; margin-top: 50px">
        <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%"><i class="fa fa-send" style="padding-right: 20px"></i> Réserver votre cuisinière expérimentée</button></a>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/cuisine.blade.php ENDPATH**/ ?>