<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>

<style type="text/css">
  #oneColumnTable .fa { color:#0D3A5D ; }
</style>


<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>


  

  <table id="oneColumnTable" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Full name</td>
        <td>Email</td>
        <td>Login</td>
        <td align="center">Conversation</td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $msg_non_lu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($m['cli']==$cli->ref && $m['nb']!=0): ?>
      <tr>
        <td><a href="<?php echo e(route('clientChat',[ 'ref' => $cli->ref ])); ?>"><span class="bold ref" style="color:black"><?php echo e($cli->code); ?></span></a></td>
        <td><span class="bold" style="color:black"><?php echo e($cli->civ); ?> <?php echo e($cli->nom); ?> <?php echo e($cli->pre); ?></span></td>
        <td><span class="bold"><?php echo e($cli->mail); ?></span></td>
        <td><span class="tel"><?php echo e($cli->username); ?></span></td>
        
        <td align="center">
          <a title="Chat" href="<?php echo e(route('clientChat',[ 'ref' => $cli->ref ])); ?>" style="margin-right: 4px;"><i class="fa fa-envelope a-icon" style="color: red;"></i></a>
          
        </td>
      </tr>
      <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<script type="text/javascript" src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.min.js')); ?>"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/clientMsgNoLu.blade.php ENDPATH**/ ?>