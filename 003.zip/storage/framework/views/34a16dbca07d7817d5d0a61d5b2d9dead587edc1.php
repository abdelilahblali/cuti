<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-paint-brush"></i> Updating photos for the customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('clientPhotosAdd',[ 'ref' => $ref ])); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-12">
          <h6><label for="images" class="control-label form-label label01">Choose one or more images <span class="c3_color">*</span></label></h6>
          <input type="file" class="form-control" name="images[]" multiple />
          <!-- <input name="pic[]" id="pic" type="file" class="form-control" multiple/> -->
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-upload" style="padding-right: 10px"></i>Add</button>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="col-md-12">
  <div class="row">
    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-2" style="margin-bottom: 30px">
      <img src="<?php echo e(url('media/cli')); ?>/<?php echo e($img->img); ?>" style="width: 100%; height: 200px" class="img-thumbnail">
      <a href="<?php echo e(route('clientPhotosDelete',[ 'ref' => $img->ref  ])); ?>" onclick="return confirm('Are you sure you delete this photo?'); event.preventDefault(); document.getElementById('clientPhotosDelete').submit();"><i class="fa fa-times" style="color:red; position: absolute; right: 20px; top: 3px;"></i></a>
      <form id="clientPhotosDelete" action="<?php echo e(route('clientPhotosDelete',[ 'ref' => $img->ref  ])); ?>" method="POST">
        <?php echo e(method_field('DELETE')); ?>

        <?php echo csrf_field(); ?>
      </form>  
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>   

<div class="col-md-12">
  <div class="row">
    <?php echo e($photos->links()); ?>

  </div>
</div>  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/clientPhotos.blade.php ENDPATH**/ ?>