

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-spinner"></i> New Worksite Progress</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('progress')); ?>" class="btn-right "><i class="fa fa-list"></i> List of Worksites Progress </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('progressAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="landname" class="control-label form-label label01">LandName  </label></h6>
              <input type="text" name="landname" id="landname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="dp" class="control-label form-label label01">DP Client </label></h6>
              <input type="text" name="dp" id="dp" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="costomer" class="control-label form-label label01">Name Costomer  </label></h6>
              <input type="text" name="costomer" id="costomer" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="respcomm" class="control-label form-label label01">Responsable Commercial  </label></h6>
              <select name="respcomm" id="respcomm" class="form-control">
                <option>Paul </option>
                <option>Thibaud</option>
                <option>Magali</option>
                <option>Nicolas</option>
                <option>Yann</option>
                <option>Marie</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="respwork" class="control-label form-label label01">Responsable WorkSite  </label></h6>
              <select name="respwork" id="respwork" class="form-control">
                <option>Eloy</option>
                <option>Yannick </option>
                <option>Tom</option>
                <option>Edy</option>
               <option> Vivi</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="namesubkon" class="control-label form-label label01">Name Subkon  </label></h6>
              <select name="namesubkon" id="namesubkon" class="form-control">
                <option></option>
                <option>En cours</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="dpsubkon" class="control-label form-label label01">DP Subkon </label></h6>
              <input type="date" name="dpsubkon" id="dpsubkon" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="remarque" class="control-label form-label label01">Remarque  </label></h6>
              <input type="text" name="remarque" id="remarque" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-2">
              <h6><label for="dp11" class="control-label form-label label01">DP 1.1  </label></h6>
              <label class="switch" for="dp11" >
                <input type="checkbox"  name="dp11" id="dp11">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp21" class="control-label form-label label01">DP 1.2 </label></h6>
              <label class="switch" for="dp21" >
                <input type="checkbox"  name="dp21" id="dp21">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp31" class="control-label form-label label01">DP 2.1 </label></h6>
              <label class="switch" for="dp31" >
                <input type="checkbox"  name="dp31" id="dp31">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp32" class="control-label form-label label01">DP 3.1 </label></h6>
              <label class="switch" for="dp32" >
                <input type="checkbox"  name="dp32" id="dp32">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="final" class="control-label form-label label01">DP 3.2  </label></h6>
              <label class="switch" for="final" >
                <input type="checkbox"  name="final" id="final">
                <span class="slider round"></span>
              </label>
          </div>
        </div>

        <div class="row">
          <div class="col-md-2">
              <h6><label for="dp4" class="control-label form-label label01">DP 4  </label></h6>
              <label class="switch" for="dp4" >
                <input type="checkbox"  name="dp4" id="dp4">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp45" class="control-label form-label label01">DP 4.5 </label></h6>
              <label class="switch" for="dp45" >
                <input type="checkbox"  name="dp45" id="dp45">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp5" class="control-label form-label label01">DP 5 </label></h6>
              <label class="switch" for="dp5" >
                <input type="checkbox"  name="dp5" id="dp5">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp51" class="control-label form-label label01">DP 5.1 </label></h6>
              <label class="switch" for="dp51" >
                <input type="checkbox"  name="dp51" id="dp51">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="dp6" class="control-label form-label label01">DP 6  </label></h6>
              <label class="switch" for="dp6" >
                <input type="checkbox"  name="dp6" id="dp6">
                <span class="slider round"></span>
              </label>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12">
              <h6><label for="dateend" class="control-label form-label label01">Date End  </label></h6>
              <input type="date" name="dateend" id="dateend" class="form-control" />
          </div>
        </div>

        <div class="row">
          <div class="col-md-4">
              <h6><label for="cuisine" class="control-label form-label label01">Cuisine </label></h6>
              <label class="switch" for="cuisine" >
                <input type="checkbox"  name="cuisine" id="cuisine">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-4">
              <h6><label for="mat" class="control-label form-label label01">Furniture </label></h6>
              <label class="switch" for="mat" >
                <input type="checkbox"  name="mat" id="mat">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-4">
              <h6><label for="fur" class="control-label form-label label01">Meeting deco  </label></h6>
              <label class="switch" for="fur" >
                <input type="checkbox"  name="fur" id="fur">
                <span class="slider round"></span>
              </label>
          </div>
        </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add Worksite Progress</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#landname").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'suiviGetLand/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#landname").val(response['data'][0].landname); 
       }
    });
  });

});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/progressAdd.blade.php ENDPATH**/ ?>