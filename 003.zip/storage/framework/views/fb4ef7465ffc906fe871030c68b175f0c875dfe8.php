

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-money"></i> New payement banjar</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('banjar')); ?>" class="btn-right "><i class="fa fa-list"></i> List of payements banjar </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('banjarAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="villaname" class="control-label form-label label01">Villa name  </label></h6>
              <input type="text" name="villaname" id="villaname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-6">
              <h6><label for="villaddress" class="control-label form-label label01">Villa Address  </label></h6>
              <input type="text" name="villaddress" id="villaddress" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="amountbanjar" class="control-label form-label label01">Amount Banjar  </label></h6>
              <input type="text" name="amountbanjar" id="amountbanjar" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="datepaiement" class="control-label form-label label01">Date Payment  </label></h6>
              <input type="date" name="datepaiement" id="datepaiement" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="amountsubak" class="control-label form-label label01">Amount Subak  </label></h6>
              <input type="text" name="amountsubak" id="amountsubak" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="datesubak" class="control-label form-label label01">Date Subak</label></h6>
              <input type="date" name="datesubak" id="datesubak" class="form-control" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add Payement Banjar</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#villaname").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'landGetInfo/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#villaname").val(response['data'][0].villaname); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#villaddress").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'suiviGetLand/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#villaddress").val(response['data'][0].addressvilla); 
       }
    });
  });

});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/banjarAdd.blade.php ENDPATH**/ ?>