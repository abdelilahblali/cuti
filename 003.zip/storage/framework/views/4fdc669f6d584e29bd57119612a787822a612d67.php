<?php use \Statickidz\GoogleTranslate; ?>
<html>
<head>
	<title>Magnitude</title>
</head>

<body style='font-family: arial '>
	<table style='border:1px solid #e2e2e2; padding: 10px; border-radius: 6px'>
		<tr >
			<td>
				<table width='' >
					<tr >
						<td><img src='https://villa.magnitudeconstruction.com/imgs/logo.png' width='200px'></td>
					</tr>
				</table>
				<table bgcolor='#0AA2A5' style='margin-top: 15px; padding: 6px'  width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td style='font-weight: bold; color: white; text-align: center;'>New signature</td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px '  bgcolor='#e2e2e2' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;'>
							          	<br/>
							          	<strong>Client Code : <?php echo e($codeClient); ?></strong>
							          	<br/><a href="https://sales.magnitudeconstruction.com/signatureEdit/<?php echo e($v1); ?>">click here to go to the page</a>
							          	<br/><br/>
							          	<br/>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px' bgcolor='black' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;text-algin:center;'>
										<a href='https://www.magnitudeconstruction.com' target="_" style='text-decoration: none; font-weight: bold; color: white '>www.magnitudeconstruction.com</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='margin-top: 20px '>
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td width='40%' style='padding: 0px ; font-weight: normal'>
										<span style='text-decoration: none; font-weight: normal; color: gray '>Magnitude &copy;</span>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
<?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/mail/notifSignature.blade.php ENDPATH**/ ?>