<?php $__env->startSection('content'); ?>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Architecture</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>

    <?php if(session()->has('no')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('no')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
 
<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">



    <div class="card card-page">
      <div class="card-body">
        <div class="card card-xxl-stretch">
          <div class="row">
            <a href="<?php echo e(url('design')); ?>" class="btn btn-secondary">Design</a>
          </div>
          <div class="row" style="margin-top: 10px">
            <a href="<?php echo e(url('plan')); ?>" class="btn btn-secondary">Plan</a>
          </div>
          <div class="row" style="margin-top: 10px">
            <a href="<?php echo e(url('interior')); ?>" class="btn btn-secondary">Interior Design</a>
          </div>
        </div>
      </div>
    </div>



  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/architecture.blade.php ENDPATH**/ ?>