

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Liste des commandes <span class="bold etat<?php echo e($etat); ?>"><?php echo e($etats[$etat]); ?></span></li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <table data-page-length='40' id="tab" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td width="100">Date</td>
        <td>Client</td>
        <td width="150">Téléphone</td>
        <td width="150">Ville</td>
        <td>Produit</td>
        <td width="60">Qte</td>
        <td width="80">Prix</td>
        <td align="center" width="100">Etat</td>
        <td align="center"></td>
      </tr>
    </thead>
      <tbody>
          <?php $__currentLoopData = $cmds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr >
            <td><a style="color:black" href="#"><span class=""><?php echo e($cmd->dat); ?></span></a></td>
            <td><a style="color:black" href="#"><span class="bold"><?php echo e($cmd->nom); ?></span></a></td>
            <td><a style="color:black" href="#"><span class="bold tel"><?php echo e(Str::limit($cmd->tel, 7, '###')); ?> </span></a></td>
            <td><a style="color:black" href="#"><span class="bold"><?php echo e($cmd->vil); ?></span></a></td>
            <td><a style="color:black" href="#"><span class="bold"><?php echo e($cmd->pro); ?></span></a></td>
            <td><a style="color:black" href="#"><span class="bold"><?php echo e($cmd->qte); ?></span></a></td>
            <td><a style="color:black" href="#"><span class="bold prix"><?php echo e(number_format($cmd->pri, 2)); ?></span></a></td>
            <td align="center"><a style="color:black" href="#"><span class="bold etat<?php echo e($cmd->etat); ?>"><?php echo e($etats[$cmd->etat]); ?></span></a></td>
            <td align="center">
              <a href="<?php echo e(route('cmdShow', ['ref' => $cmd->ref ] )); ?>"><button type="button" class="btn btn-rounded btn-default btn-icon btn02" data-toggle="tooltip" data-placement="bottom"><i class="fa fa-info"></i></button></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/cmds.blade.php ENDPATH**/ ?>