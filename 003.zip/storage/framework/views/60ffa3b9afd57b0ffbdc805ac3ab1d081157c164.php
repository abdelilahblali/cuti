<?php $__env->startSection('content'); ?>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5"><?php echo e(__('plan.a1')); ?></h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('yes')); ?>

      </div>
    </div>
    <?php endif; ?>

    <?php if(session()->has('no')): ?>
    <div class="col-md-12">
      <div class="alert alert-success">
        <?php echo e(session()->get('no')); ?>

      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
 
<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body">
        <div class="card card-xxl-stretch" style="margin-top: 0 !important">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('plan.a2')); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('plan.a3')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                <!-- Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. -->
              </p>
            </div>
          </div>

          <?php $__currentLoopData = $reservation2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('plan.a4')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="card-body" <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> style="background-color: rgba(255,0,0,0.1)" <?php elseif($i->valid==1): ?> style="background-color: rgba(0,255,0,0.1)" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <h3>
              <span <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e(__('plan.a5')); ?> </span>
              <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a6')); ?></span></span>
              <?php elseif($i->valid==1): ?>
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a7')); ?></span></span>
              <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
            <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="row" <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required  />
                      <input type="hidden" name="type" value="reservation">
                      <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px"><i class="fa fa-eye" style="padding-right: 10px"></i><?php echo e(__('plan.a7')); ?></button></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-success" <?php $__currentLoopData = $reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><i class="fa fa-upload" style="padding-right: 10px"></i><?php echo e(__('plan.a8')); ?></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #2 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('plan.a9')); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('plan.a10')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                <!-- Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. -->
              </p>
            </div>
          </div>

          <?php $__currentLoopData = $construction2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('plan.a11')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="card-body" <?php $__currentLoopData = $construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> style="background-color: rgba(255,0,0,0.1)" <?php elseif($i->valid==1): ?> style="background-color: rgba(0,255,0,0.1)" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <h3>
              <span <?php $__currentLoopData = $construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>> <?php echo e(__('plan.a12')); ?></span>
              <?php $__currentLoopData = $construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a6')); ?></span></span>
              <?php elseif($i->valid==1): ?>
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a7')); ?></span></span>
              <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
            <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="row" <?php $__currentLoopData = $construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required  />
                      <input type="hidden" name="type" value="construction">
                      <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <?php $__currentLoopData = $construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px"><i class="fa fa-eye" style="padding-right: 10px"></i><?php echo e(__('plan.a7')); ?></button></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-success" <?php $__currentLoopData = $construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><i class="fa fa-upload" style="padding-right: 10px"></i><?php echo e(__('plan.a8')); ?></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #3 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark"><?php echo e(__('plan.a13')); ?></span>
              <span class="text-muted mt-1 fw-bold fs-7"><?php echo e(__('plan.a10')); ?></span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                <!-- Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. -->
              </p>
            </div>
          </div>

          <?php $__currentLoopData = $terrain2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i><?php echo e(__('plan.a14')); ?></button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="card-body" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> style="background-color: rgba(255,0,0,0.1)" <?php elseif($i->valid==1): ?> style="background-color: rgba(0,255,0,0.1)" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <h3>
              <span <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e(__('plan.a15')); ?> </span>
              <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a6')); ?></span></span>
              <?php elseif($i->valid==1): ?>
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a7')); ?></span></span>
              <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
            <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="row" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required  />
                      <input type="hidden" name="type" value="terrain">
                      <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px"><i class="fa fa-eye" style="padding-right: 10px"></i><?php echo e(__('plan.a7')); ?></button></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-success" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><i class="fa fa-upload" style="padding-right: 10px"></i><?php echo e(__('plan.a8')); ?></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #3 ################## -->
<!-- <div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body" style="padding-top: 0px">
        <div class="card card-xxl-stretch">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark">Plan Contrat</span>
              <span class="text-muted mt-1 fw-bold fs-7">Télécharger & importer</span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
              </p>
            </div>
          </div>

          <?php $__currentLoopData = $terrain2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i>Download your terrain contrat</button></a>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="card-body" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> style="background-color: rgba(255,0,0,0.1)" <?php elseif($i->valid==1): ?> style="background-color: rgba(0,255,0,0.1)" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <h3>
              <span <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>Upload your Plan Contrat </span>
              <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==0): ?> 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a6')); ?></span></span>
              <?php elseif($i->valid==1): ?>
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2"><?php echo e(__('plan.a7')); ?></span></span>
              <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>
            <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="row" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required  />
                      <input type="hidden" name="type" value="terrain">
                      <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px"><i class="fa fa-eye" style="padding-right: 10px"></i><?php echo e(__('plan.a7')); ?></button></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <button type="submit" class="btn btn-success" <?php $__currentLoopData = $terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($i->valid==1): ?> style="display:none;"  <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><i class="fa fa-upload" style="padding-right: 10px"></i>Importer</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div> -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/plan.blade.php ENDPATH**/ ?>