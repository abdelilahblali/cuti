

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Pourquoi l’œuf</h3>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <style type="text/css">.fa-angle-right { color:#FEC007; padding-right: 8px  }</style>
        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 60px">
                            <img src="<?php echo e(url('imgs2/i05.jpg')); ?>" alt="image" width="90%" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Economique</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Chaque marocain consomme 180 œufs annuellement, non seulement parce qu’il s’agit d’un aliment facile à préparer, riche en vitamines et en protéines, mais également pace qu’il est très économique à la portée de tout le monde.
                            <br/><br/>
                            Cette source de minéraux et d’oméga 3 est le meilleur ami des sportifs, un œuf contient environ 7 grammes de protéine et ne coute pas cher. 
                            <br/><br/>
                            Deux œufs par jour est l’équivalent de 100 grammes de viande ou de poisson et contiennent tous les acides aminés essentiels pour un menu parfait et économique pour les sportifs qui n’ont pas tous les moyens pour varier leurs plats avec les autres aliments protéinés.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section" style="background: rgba(0,0,0,0.1)">
            <div class="container">
                <div class="row">                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Rapide à préparer</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Considéré comme l’aliment le plus basique et universel de toutes les cuisines de monde, l’œuf peut être préparé rapidement et facilement pour un copieux petit déjeuner ou un délicieux déjeuner ou dîner.
                            <br/><br/>
                            Il ne faut pas être un bon cuisinier pour manger un plat à base d’œuf, tout le monde, mêmes les enfants peuvent préparer une omelette en deux minutes pour un coupe-faim ou pour un plat à la dernière minute. 
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 40px">
                            <img src="<?php echo e(url('imgs2/i09.jpg')); ?>" alt="image" width="90%" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row"> 
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 100px">
                            <img src="<?php echo e(url('imgs2/oeuf5.jpg')); ?>" alt="image" width="90%" />
                        </div>
                    </div>                   
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Riche en protéines</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Une très bonne source de protéine, de minéraux et de vitamines tels que la vitamine A, D et E ainsi que les vitamines B (B2, B5, B9 ou folates, B12), l’œuf est un aliment complet avec une très haute qualité nutritionnelle convenable aux petits et aux grands.
                            <br/><br/>
                            Les protéines dites complètes qui composent l’œuf contiennent les neufs acides aminés essentiels pour l’organisme humain : La lysine qui joue un rôle très important dans le renforcement musculaire, la thréonine indispensable pour la santé de la peau et des dents, la valine pour l’acuité mentale, la coordination musculaire et le calme émotionnel, l’isoleucine qui améliore l’immunité, la leucine qui régularise la glycémie et participe à la croissance des muscles et des os, la phénylalanine aide le corps à utiliser les autres acides aminés, le tryptophane qui améliore la croissance des nourrissons et l’histidine qui participe à la croissance des cellules sanguines et la réparation des tissus.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/about4.blade.php ENDPATH**/ ?>