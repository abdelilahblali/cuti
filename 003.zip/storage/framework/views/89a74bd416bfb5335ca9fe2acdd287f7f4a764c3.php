<?php $__env->startSection('content'); ?>

<?php if(session()->has('yes')): ?> <div class="col-md-12"><div class="alert alert-success"><?php echo e(session()->get('yes')); ?></div></div> <?php endif; ?>
<?php if(session()->has('no')): ?> <div class="col-md-12"><div class="alert alert-danger"><?php echo e(session()->get('no')); ?></div></div> <?php endif; ?>

<div class="col-lg-12 grid-margin stretch-card">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Leaves</h4>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>From</th>
              <th>To</th>
              <th>Half Day</th>
              <th>Raison</th>
              <th>Status</th>
              <th>Options</th>
            </tr>
          </thead>
          <tbody>
          	<?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="bold"><?php echo date('m/d/Y', strtotime($item->from_date)); ?> <?php if($item->from_time!=''): ?> <?php echo e($item->from_time); ?> <?php endif; ?></td>
              <td class="bold"><?php echo date('m/d/Y', strtotime($item->to_date)); ?> <?php if($item->to_time!=''): ?> <?php echo e($item->to_time); ?> <?php endif; ?></td>
              <td><span><?php echo e($item->halfday); ?></span></td>
              <td><?php echo e($item->raison); ?></td>
              <td>
              	<?php if($item->act==0): ?><label class="badge badge-warning">Pending</label><?php endif; ?>
              	<?php if($item->act==1): ?><label class="badge badge-success">Accepted</label><?php endif; ?>
              	<?php if($item->act==-1): ?><label class="badge badge-danger">Refused</label><?php endif; ?>
              </td>
              <td>
                <a title="View" href="<?php echo e(route('leave_edit',[ 'ref' => $item->ref ])); ?>" ><button class="btn btn-sm btn-success" type="button">View</button></a>
              	<?php if($item->act==0): ?>
                <a title="Update" href="<?php echo e(route('leave_edit',[ 'ref' => $item->ref ])); ?>" ><button class="btn btn-sm btn-success" type="button">Update</button></a>
              	<a title="Delete" href="<?php echo e(route('leave_deleted',[ 'ref' => $item->ref ])); ?>" ><button class="btn btn-sm btn-danger" type="button" onclick="return confirm('Are you sure to delete this item ?');">Delete</button></a>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php if(count($leaves)==0): ?>
        <center><div class="badge badge-danger" style="margin-top: 100px; margin-bottom: 100px;">No items on this list</div></center>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /homepages/43/d729370671/htdocs/cuti.magnitudeconstruction.com/resources/views/leaves.blade.php ENDPATH**/ ?>