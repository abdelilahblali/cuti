<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(public_path('bootstrap/css/bootstrap/bootstrap.css')); ?>">
	<style type="text/css">
		html {  font-family: helvetica; font-size: 12px;  }
    .mb-5 { border:0.5px solid #e0e0e0; padding: 6px; }
    h3 { background: black; color: white; padding: 6px; }
	</style>
</head>
<body>


<div class="col-md-12">
  <div class="panel panel-default client-content">
      <div class="">
        <div class="card-body">
          <div class="card card-xxl-stretch">

              <div class="imgShow"></div>

              <img src="https://villa.magnitudeconstruction.com/imgs/logo.png" style="width:200px; margin-bottom: 30px;">


              <h1 style="font-size: 16px; border: 1px solid #0aa2a5; color:#0aa2a5; background:#c4f1f2; padding: 10px;">
                Nom : <?php echo $v76.' '.$v77; ?>
                <br>
                Email : <?php echo $v78; ?>
              </h1>


              <h1 style="font-size: 16px; border-bottom: 1px solid #b5b5b5; ">SÉLECTION DES FINITIONS ET ÉQUIPEMENTS</h1>

              <h2 style="font-size: 14px;">FINITIONS ET ÉQUIPEMENTS EXTÉRIEURS DE VOTRE VILLA</h2>
              

              <div class="mb-5">
                <label for="v1" class=" form-label">Souhaitez-vous ajouter un portail coulissant sur la rue ?</label>
                <br><strong style="background:#c4f1f2 "><?php echo $v1; ?></strong><br>
              </div>

              <div class="mb-5">
                <label for="v2" class=" form-label">Souhaitez-vous ajouter un espace de bagagerie à l'entrée de la villa ? </label>
                <br><strong style="background:#c4f1f2 "><?php echo $v2; ?></strong><br>
              </div>

              <h3>P05 -  Porte d'entrée</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v3" class=" form-label">Souhaitez-vous une porte d'entrée telle que proposée (page 6) ?</label>
                   <br><strong style="background:#c4f1f2 "><?php echo $v3; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <label for="v4" class=" form-label">Souhaitez vous une porte en bois travaillée / gravée (page 5) ? </label>
                <br><strong style="background:#c4f1f2 "><?php echo $v4; ?></strong><br>
              </div>

              <h3>P07 -  Sols extérieurs :</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                <label for="v5" class=" form-label">Quelle finition souhaitez-vous pour les sols extérieurs de votre villa ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v5; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v6" class=" form-label">Souhaitez vous un autre type de revêtement avec un coût supplémentaire ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v6; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v79" class=" form-label">Quelle finition souhaitez vous pour les plateformes bois ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v79; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v7; ?></strong><br>
              </div>

              <h3>P10 -  Toitures </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v8" class=" form-label">Quel type de couverture de toiture souhaitez vous retenir ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v8; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v9" class=" form-label">Souhaitez vous un autre type de couverture avec un coût supplémentaire ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v9; ?></strong><br>
                </div>
              </div>

              <h3>P11 - Façades et baies coulissantes</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v10" class=" form-label">Quelle touche de parement décoratif souhaitez-vous appliquer sur vos façades ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v10; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v11" class=" form-label">Quel type d’huisserie de fenêtre (fixe et coulissante) souhaitez vous pour votre villa ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v11; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="v12" class=" form-label">Souhaitez-vous intégrer un autre type d’ouverture des baies vitrées ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v12; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v13; ?></strong><br>
              </div>

              <h3>P13 - Jardin </h3>


              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="v15" class=" form-label">La réalisation proposée des jardins correspond-elle à vos attentes ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v15; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v16; ?></strong><br>
              </div>


              <h3>P14 - Statues</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="v18" class=" form-label">Quelle statue souhaitez vous intégrer dans votre villa ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v18; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="v19" class=" form-label">Souhaitez-vous choisir un autre type de statue ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v19; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v20; ?></strong><br>
              </div>

              <h3>P15 - Salon extérieur </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="v21" class=" form-label">Quelle typologie de salon extérieur voulez-vous pour votre villa ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v21; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="v22" class=" form-label">Souhaitez-vous choisir d'autres options hors standard? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v22; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v23; ?></strong><br>
              </div>

              <h3>P18 - Gardes-corps </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v24" class=" form-label">Si nécessaire, quelle structure de garde-corps souhaitez vous retenir  ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v24; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="v25" class=" form-label">Dans le cas d’un garde-corps, souhaitez-vous une main-courante ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v5; ?></strong><br>
                </div>
              </div>

              <h3>P20 - Espace de baignade </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous modifier les surfaces et profondeurs proposées ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v26; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous, avec un coût supplémentaire, ajouter à cet espace de baignade :</label>
                  <br><strong style="background:#c4f1f2 ">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($o->case=='v27'): ?>
                      <?php echo e($o->val); ?> - 
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </strong><br>
                </div>
              </div>

              <h2>FINITIONS ET ÉQUIPEMENTS INTÉRIEURS DE VOTRE VILLA </h2>

              <h3>P24 - Les sols</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Quel type de sol souhaitez vous revêtir l'intérieur de votre villa ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v28; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Souhaitez-vous un autre type de revêtement avec un coût supplémentaire ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v29; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v30; ?></strong><br>
              </div>

              <h3>P26 - Les murs</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Souhaitez-vous ajouter un autre revêtement mural que la peinture pour vos intérieurs ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v31; ?></strong><br>
                </div>
              </div>

              <h3>P27 - Les portes </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Souhaitez-vous conserver le type de porte sur charnières standard ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v32; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Dans le cas cas contraire vous pouvez choisir d’autres designs de porte avec supplément :</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v33; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v34; ?></strong><br>
              </div>

              <h3>P29 - Les plafonds </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Souhaitez vous conserver le modèle standard de plafond blanc ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v35; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Dans le cas cas contraire, d’autres plafonds sont disponibles avec supplément :</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v36; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v37; ?></strong><br>
              </div>

              <h3>P30 - L’espace de vie  </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">La conception de l'espace de vie correspond-elle à vos attentes ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v38; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v39; ?></strong><br>
              </div>

              <h3>P32 - La cuisine</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Quel type d’agencement de cuisine préférez-vous ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v40; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Quelle finition choisissez-vous pour votre agencement de cuisine ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v41; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Concernant le plan de travail et les crédences, que préférez-vous ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v42; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous conserver les dimensions du modèle standard de cuisine ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v43; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v44; ?></strong><br>
              </div>

              <h3>P34 - Les chambres </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous conserver la composition des chambres selon nos standards ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v45; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v46; ?></strong><br>
              </div>

              <h3>P36 - La salle de bain : </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous conserver le plan de toilette standard en agencement bois ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v47; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Dans le cas contraire, avec un coût additionnel, quel plan vasque préférez- vous ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v48; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Dans notre sélection de lavabos, lequel correspond à vos attentes?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v49; ?></strong><br>
                </div>
              </div> 

               <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Concernant la finition murale, il est prévu un mélange de peinture et de carrelage, mais avec un surcoût seriez vous intéressé par des touches de finitions différentes ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v50; ?></strong><br>
                </div>
              </div>  

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous ajouter des douches extérieures dans des jardins privatifs ? ( 407€/unité / 459$/unité) </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v63; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v64; ?></strong><br>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous ajouter des baignoires intérieures ou extérieures ? (813€/unité / 919$/unité)</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v65; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v66; ?></strong><br>
              </div>

              <h2>LISTE DES ADDITIONNELS APPLICABLES</h2>

              <h3>P42 - Salle de massage :</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous une salle de massage sur mesure au sein de votre villa ? (à partir de 9000€ / 10 170$)</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v51; ?></strong><br>
                </div>
              </div>

              <h3>P43 - Salle de sports</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous une salle de sport sur mesure au sein de votre villa ? (à partir de 9000€ / 10 170$)</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v52; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Si oui, quels sont les 3 éléments que vous souhaitez pour l’équiper ? </label>
                  <br><strong style="background:#c4f1f2 ">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($o->case=='v53'): ?>
                      <?php echo e($o->val); ?> - 
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous réaliser un ou des terrains de sport ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v54; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v55; ?></strong><br>
              </div>

              <h3>P45 - Yoga shala </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous une structure pour espace yoga au sein de votre villa ? (à partir de 2000€)</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v56; ?></strong><br>
                </div>
              </div>

              <h3>P46 - Pergola  </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous ajouter une pergola au sein de votre villa ? (à partir de 2500€ / 2825$)</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v57; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Concernant la réalisation de pergola, quelle structure préférez-vous ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v58; ?></strong><br>
                </div>
              </div> 

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Pour l'ombrage, quel matériau est votre favori ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v59; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" >
                  <label for="" class=" form-label">Souhaitez-vous une protection contre la pluie ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v60; ?></strong><br>
                </div>
              </div>  

              <h3>P48 - Gazebo : </h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous ajouter un gazebo sur mesure au sein de votre jardin ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v61; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v62; ?></strong><br>
              </div>

              

              <h3>P49 - Éléments décoratifs</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous décorer votre villa de murs végétaux ?</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v68; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous décorer votre villa de bassin d’agrément ? image 80 (244€ / 276$) ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v69; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous décorer votre villa d’une fontaine ? (prix calculé sur mesure) ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v70; ?></strong><br>
                </div>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous ajouter à votre villa un temple à offrandes ? (276€/unité / 312$/unité) ? </label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v71; ?></strong><br>
                </div>
              </div>

              <h3>P50 - Jacuzzi</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Souhaitez-vous ajouter un jacuzzi dans un espace privé ou public de la villa ? (à partir de 10000€ / 11301$)</label>
                  <br><strong style="background:#c4f1f2 "><?php echo $v67; ?></strong><br>
                </div>
              </div>


              <h3>Additionnel divers</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class=" form-label">Aimeriez-vous ajouter des éléments de détentes photogéniques ? (prix calculé sur mesure) ?</label>
                  <br><strong style="background:#c4f1f2 ">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($o->case=='v72'): ?>
                      <?php echo e($o->val); ?> - 
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v73; ?></strong><br>
              </div>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <label for="" class="form-label">Aimeriez-vous ajouter des équipements à votre villa ?</label>
                  <br><strong style="background:#c4f1f2 ">
                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($o->case=='v74'): ?>
                      <?php echo e($o->val); ?> - 
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </strong><br>
                </div>
              </div>

              <div class="mb-5">
                  <br><strong style="background:#c4f1f2 "><?php echo $v75; ?></strong><br>
              </div>


          </div>
        </div>
      </div>
  </div>
</div>

</body>
</html><?php /**PATH /homepages/43/d729370671/htdocs/monprojetbali/resources/views/catalogFormPrint.blade.php ENDPATH**/ ?>