<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">PLAN</h4>

<!-- Contrat 1 -->
<div class="col-md-4">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Reservation</h4>
    <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-12">
          <h6><label for="url" class="control-label form-label label01">Upload Reservation Contrat <span class="c3_color">*</span></label></h6>
          <input type="file" class="form-control" name="url[]" multiple />
          <input type="hidden" name="type" value="reservation2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $plan_reservation2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="http://localhost/monProjetBali/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>View your file uploaded</button></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>


    <?php $__currentLoopData = $plan_reservation1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <div class="row" style="margin-top: 20px">
      <div class="col-md-8">
        <a href="http://localhost/monProjetBali/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-block btn-default btn-block" style="background-color: gray">Contrat uploaded</button></a>
      </div>
      <div class="col-md-4">
        <?php if($i->valid==0): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'plan' ])); ?>" ><button type="button" class="btn btn-block btn-danger" title="click to validate">No Valide</button></a>
        <?php elseif($i->valid==1): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'plan' ])); ?>" ><button type="button" class="btn btn-block btn-success" title="click to cancel validation">Valide</button></a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>

<!-- Contrat 2 -->
<div class="col-md-4">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Construction</h4>
    <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-12">
          <h6><label for="url" class="control-label form-label label01">Upload Construction Contrat <span class="c3_color">*</span></label></h6>
          <input type="file" class="form-control" name="url[]" multiple />
          <input type="hidden" name="type" value="construction2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $plan_construction2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="http://localhost/monProjetBali/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>View your file uploaded</button></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>


    <?php $__currentLoopData = $plan_construction1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <div class="row" style="margin-top: 20px">
      <div class="col-md-8">
        <a href="http://localhost/monProjetBali/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-block btn-default btn-block" style="background-color: gray">Contrat uploaded</button></a>
      </div>
      <div class="col-md-4">
        <?php if($i->valid==0): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'plan' ])); ?>" ><button type="button" class="btn btn-block btn-danger" title="click to validate">No Valide</button></a>
        <?php elseif($i->valid==1): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'plan' ])); ?>" ><button type="button" class="btn btn-block btn-success" title="click to cancel validation">Valide</button></a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>

<!-- Contrat 3 -->
<div class="col-md-4">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
    <h4>Land</h4>
    <form method="POST" action="<?php echo e(route('planAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-12">
          <h6><label for="url" class="control-label form-label label01">Upload Plan Contrat <span class="c3_color">*</span></label></h6>
          <input type="file" class="form-control" name="url[]" multiple />
          <input type="hidden" name="type" value="terrain2">
          <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <?php $__currentLoopData = $plan_terrain2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
          <a href="http://localhost/monProjetBali/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-success btn-block" style="margin-right: 10px; background-color: gray"><i class="fa fa-eye" style="padding-right: 10px"></i>View your file uploaded</button></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <button type="submit" class="btn btn-default btn-block">Upload</button>
        </div>
      </div>
    </form>


    <?php $__currentLoopData = $plan_terrain1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr>
    <div class="row" style="margin-top: 20px">
      <div class="col-md-8">
        <a href="http://localhost/monProjetBali/media/cli/<?php echo e($i->url); ?>" target="_blank"><button type="button" class="btn btn-block btn-default btn-block" style="background-color: gray">Contrat uploaded</button></a>
      </div>
      <div class="col-md-4">
        <?php if($i->valid==0): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'plan' ])); ?>" ><button type="button" class="btn btn-block btn-danger" title="click to validate">No Valide</button></a>
        <?php elseif($i->valid==1): ?>
        <a href="<?php echo e(route('clientFolderValidate',[ 'ref' => $ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'plan' ])); ?>" ><button type="button" class="btn btn-block btn-success" title="click to cancel validation">Valide</button></a>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/clientFolder_plan.blade.php ENDPATH**/ ?>