

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-bank"></i> New bank</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('bank')); ?>" class="btn-right "><i class="fa fa-list"></i> List of banks </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('bankAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="ptpmaname" class="control-label form-label label01">PTPMA NAME  </label></h6>
              <input type="text" name="ptpmaname" id="ptpmaname" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="bankname" class="control-label form-label label01">Bank Name  </label></h6>
              <input type="text" name="bankname" id="bankname" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="banknumber" class="control-label form-label label01">Bank Number  </label></h6>
              <input type="text" name="banknumber" id="banknumber" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="bank" class="control-label form-label label01">Bank  </label></h6>
              <input type="text" name="bank" id="bank" class="form-control" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add Bank</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#ptpmaname").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'bankgetptpma/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#ptpmaname").val(response['data'][0].ptpmaname); 
       }
    });
  });

});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/bankAdd.blade.php ENDPATH**/ ?>