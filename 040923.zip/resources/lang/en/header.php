<?php
 
// lang/en/messages.php
 
return [
    'a1' => 'Home',
    'a2' => 'Administration',
    'a3' => 'PTPMA',
    'a4' => 'Land',
    'a5' => 'Architecture',
    'a6' => 'Construction',
    'a7' => 'Invoices',
    'a8' => 'History',
    'a9' => 'Pictures',
    'a10' => 'Documents',
    'a11' => 'Contact us',
    'a12' => 'Notifications',
    'a13' => 'Mark all as read',
    'a14' => 'Request an appointment',
    'a15' => 'Close',
    'a16' => 'Confirm',
    'a17' => 'Need help ?',
    'a18' => 'Please fill in the name of your villa and the name of PTPMA,',
     'a19' => 'click here',
];