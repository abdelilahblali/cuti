

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-plus"></i> Nouveau document</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('docAdded')); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>


      <div class="row">
          <div class="col-md-6">
              <h6><label for="des" class="control-label form-label label01">Désignation <span class="c3_color">*</span></label></h6>
              <input type="text" name="des" id="des" class="form-control" required />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="images" class="control-label form-label label01">Document <span class="c3_color">*</span></label></h6>
              <input type="file" name="images[]" id="images" class="form-control" required />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-6">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Ajouter le document</button>
        </div>
      </div>
    </form>
  </div>
</div>

<div id="uploadimageModal" class="modal" role="dialog">
  <div class="modal-dialog" style="width: 100% !important">
    <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Recadrer la photo</h4>
          </div>
          <div class="modal-body">
            <div class="row">
            <div class="col-md-12 text-center col-md-offset-2">
              <div id="image_demo" style="width:350px; margin-top:30px"></div>
            </div>
        </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-success crop_image">Enregistrer</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          </div>
      </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/docAdd.blade.php ENDPATH**/ ?>