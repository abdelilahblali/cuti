

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Nutrition</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>Nutrition</li>
                </ul>
            </div>
        </div>

        <style type="text/css">.fa-angle-right { color:#FEC007; padding-right: 8px  }</style>
        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Biologie autour de l’œuf</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> L’œuf dont le poids moyen est de 60 g est composé de 30% de jaune d’œuf, 60% du banc, et les 10% qui restent constituent son coquille.
                            <br/><br/>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> Le jaune comporte environ 50 % d’eau et le blanc est constitue très majoritairement d’eau (90% environ), mais aussi de glycoprotéines (ovalbumine essentiellement), de sucres (glucose) et de sels minéraux.
                            <br/><br/>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> Les lipides y sont uniquement à l’état de traces, de même que les vitamines.
                            <br/><br/>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> La coquille contient 99% de matière sèche dont 95% de sels minéraux et 4% de protéines. 
                            <br/><br/>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> Pour un œuf type 60 g Jaune, 1/3 = 18 g de vitellus, . H2O Protéines 30, lipides 70 Blanc, 2/3 = 36 g d’albumen, 9/10 H2O Composition moyenne du jaune (% Mat. Sèche) 
                            <br/><br/>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> Protéines: 30% du jaune (les 2/3 sous forme de lipoprotéines) 
                            <br/><br/>
                            <i class="fa fa-angle-right;" style="color:#FEC007"></i> Lipides: 69% du jaune Triglycérides : 46% Phopholipides : 20% (lécithine, cephaline) Stérols: 3% Minéraux (surtout du phosphore et du fer), vitamines (surtout A, D, E, certaines B, mais aussi K, PP), pigments (carotènes et xanthophylles): 1%f
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 40px">
                            <img src="<?php echo e(url('imgs2/assiete.jpg')); ?>" alt="image" width="90%" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

         <div class="clv_about_wrapper clv_section" style="padding-top: 0">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 0px">
                            <img src="<?php echo e(url('imgs/schema.png')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="about_content" style="padding-top: 0">
                            <div class="about_heading">
                                <h2>Composents de <span>l’œuf</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Les œufs sont collectés au moins deux fois par jour soit manuellement ou automatiquement sur de s convoyeur s pour réduire au maximum les risques de contamination.
                            <br/>
                            Les œufs cassés ou fêlés sont écartés et les autres sont triés selon leur poids en quatre catégories :
                            <br/>
                            Petit calibre (< 50 g). Moyen calibre (50 à 58 g). Gros calibre (58 à 68 g). Extra gros (> 68 g).
                            <br/>
                            Ils sont ensuite placés dans des plateaux alvéolés en cartons ou en plastiques de 6, 9, 12, 16, 24 ou 30 unités.
                            <br/>
                            Le s œufs sont stockés et entreposés dans des locaux propres en dehors des bâtiments d’élevage et à l’abri de toute source de chaleur pour conserver leur fraîcheur et leur qualité en attendant l’expédition aux points de vente.
                            <br/>
                            Plusieurs facteurs influencent le poids de l’œuf, le plus important étant l’âge de la pondeuse. Plus celle-ci est âgée, plus les œufs sont gros.
                            <br/>
                            Les œufs à doubles jaunes sont liés à des accident s de ponte qui interviennent généralement au début du cycle de production.
                            <br/>
                            Ces œufs ne sont nullement recherchés par les éleveurs car ils causent des dommages importants aux poules pondeuses.</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>


  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/about3.blade.php ENDPATH**/ ?>