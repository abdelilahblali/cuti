

<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/bg3.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-4">
              <div class="breadcrumb_inner">
                <h3>BABY SITTER</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

        <div class="container">
            <div class="row">
                <div class="col-md-8 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2>NOUNOUS DIPLÔMÉES ET/OU EXPÉRIMENTÉES</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;">
                            <p style="color: black">
                                Vous avez besoin d’un service de garde d’enfant à temps complet ou à temps partiel?
                                <br/><br/>
                                Vous avez repris votre activité professionnelle ou vous êtes en télétravail?<br/>
                                Vous êtes à la recherche d’une nourrice compétente pour garder votre enfant ?<br/>
                                Ne laissez pas vos enfants à des personnes sans garanties.
                                <br/><br/>
                                BAYTIHELP
                                vous propose un service de garde d’enfant à domicile à temps complet ou

                                partiel, assuré par des nounous spécialistes de l’enfance. Une garde complète
                                et active.<br/>
                                La préoccupation principale des nourrices BAYTIHELP est la sécurité et le
                                bien-être des enfants. Elles participent activement au développement et à l’éveil
                                de votre enfant tout en respectant vos exigences. Les nannys BAYTIHELP,
                                sont de vraies spécialistes au service des petits et des tout petits : biberon,
                                toilette, changes, préparation du dîner, jeux, lecture d’histoires ou même sorties
                                au parc.<br/>
                                Nous avons également des Baby Sitters spécialisées dans la petite enfance
                                mais aussi des éducateurs (trices) spécialisés pour les enfants ayant un
                                handicap.<br/><br/>
                                Avec BAYTI HELP junior, vos enfants sont entre de bonnes mains.
                                Notre prestation vous garantit la sécurité et la garde de vos enfants dans des
                                conditions optimales.
                            </p>
                        </div>
                    </div>
                </div>
                
            </div>

            <div class="col-md-4" style="margin-top: 200px">
                <img src="<?php echo e(url('imgs/i/d01.jpg')); ?>" width="100%">
            </div>
        </div>
    </div>

    

    <div class="container" style="margin-bottom: 50px; margin-top: 50px">
        <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%"><i class="fa fa-send" style="padding-right: 20px"></i> Réserver votre cuisinière expérimentée</button></a>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/sitter.blade.php ENDPATH**/ ?>