

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-credit-card"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('payment')); ?>" class="btn-right "><i class="fa fa-list"></i> List of payments </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('paymentEdited',[ 'ref' => $item->ref ])); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>
      
      <div class="row">
          <div class="col-md-2">
              <h6><label for="five" class="control-label form-label label01">5000€  </label></h6>
              <label class="switch" for="five" >
                <input type="checkbox"  name="five" id="five" <?php if($item->five=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-2">
              <h6><label for="terrain" class="control-label form-label label01">Terrain </label></h6>
              <label class="switch" for="terrain" >
                <input type="checkbox"  name="terrain" id="terrain" <?php if($item->terrain=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-3">
              <h6><label for="four1" class="control-label form-label label01">40% (1) </label></h6>
              <input type="date" name="four1" id="four1" class="form-control"  value="<?php echo e($item->four1); ?>" />
          </div>
          <div class="col-md-2">
              <h6><label for="four2" class="control-label form-label label01">40% (2) </label></h6>
              <label class="switch" for="four2" >
                <input type="checkbox"  name="four2" id="four2" <?php if($item->four2=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>

          <div class="col-md-2">
              <h6><label for="final" class="control-label form-label label01">Final Payment  </label></h6>
              <label class="switch" for="final" >
                <input type="checkbox"  name="final" id="final" <?php if($item->final=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>

        </div>

        <div class="row">

          <div class="col-md-6">
              <h6><label for="dpsoo" class="control-label form-label label01">Dp SOO LIVING </label></h6>
              <input type="date" name="dpsoo" id="dpsoo" class="form-control"  value="<?php echo e($item->dpsoo); ?>"/>
          </div>
          <div class="col-md-6">
              <h6><label for="dpnau" class="control-label form-label label01">Dp nautylus</label></h6>
              <input type="date" name="dpnau" id="dpnau" class="form-control" value="<?php echo e($item->dpnau); ?>" />
          </div>
      </div>


    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/paymentEdit.blade.php ENDPATH**/ ?>