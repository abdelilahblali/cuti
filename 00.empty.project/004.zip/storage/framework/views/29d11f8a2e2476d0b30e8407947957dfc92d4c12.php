<?php $__env->startSection('content'); ?>

        
        <!-- slide -->
        <div class="clv_rev_slider">

            <div id="rev_slider_149_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="snowaddon1" data-source="gallery" style="background-color:#2d3032;padding:0px;">

            <!-- START REVOLUTION SLIDER 5.4.1 fullscreen mode -->

                <div id="rev_slider_149_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">

                    <ul>    <!-- SLIDE  -->

                        <li data-index="rs-407" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="2000"  data-thumb="<?php echo e(url('imgs/sld/sld1.jpg')); ?>"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1000" data-fsslotamount="7" data-saveperformance="off"  data-title="One" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                            <!-- MAIN IMAGE -->

                            <img src="<?php echo e(url('imgs/sld/sld1.jpg')); ?>"  alt="image"  data-bgposition="center center" data-kenburns="on" data-duration="2000" data-ease="Linear.easeNone" data-scalestart="130" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="6" class="rev-slidebg" data-no-retina style="background-color: rgba(0,0,0,0.8)" >

                            <!-- LAYERS -->

                            <div id="rrzm_407" class="rev_row_zone rev_row_zone_middle" style="z-index: 6;">



                            <!-- LAYER NR. 1 -->

                            <div class="tp-caption  " 

                                 id="slide-407-layer-14" 

                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 

                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                            data-width="none"

                                data-height="none"

                                data-whitespace="nowrap"

                     

                                data-type="row" 

                                data-columnbreak="2" 

                                data-basealign="slide" 

                                data-responsive_offset="on" 

                                data-responsive="off"

                                data-frames='[{"delay":10,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'

                                data-margintop="[0,0,0,0]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['inherit','inherit','inherit','inherit']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[100,50,50,50]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[100,50,50,50]"



                                style="z-index: 6; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255, 255, 255, 1.00);">

                            <!-- LAYER NR. 2 -->

                            <div class="tp-caption  " 

                                 id="slide-407-layer-15" 

                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 

                                 data-y="['top','top','top','top']" data-voffset="['100','100','100','100']" 

                                            data-width="none"

                                data-height="none"

                                data-whitespace="nowrap"

                     

                                data-type="column" 

                                data-responsive_offset="on" 

                                data-responsive="off"

                                data-frames='[{"delay":"+0","speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'

                                data-columnwidth="100%"

                                data-margintop="[0,0,0,0]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['left','left','left','left']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"



                                style="z-index: 7; width: 100%;">

                            <!-- LAYER NR. 3 -->

                           

                            <!-- LAYER NR. 4 -->

                            <div class="tp-caption   tp-resizeme" 

                                 id="slide-407-layer-2" 

                                 data-x="['left','left','left','left']" data-hoffset="['0','50','0','0']" 

                                 data-y="['top','top','top','top']" data-voffset="['0','430','460','290']" 

                                            data-fontsize="['82','82','40','40']"

                                data-lineheight="['82','82','50','30']"

                                data-width="['none','100%','100%','100%']"

                                data-height="none"

                                data-whitespace="normal"

                     

                                data-type="text" 

                                data-basealign="slide" 

                                data-responsive_offset="on" 



                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'

                                data-margintop="[0,0,0,0]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['inherit','inherit','center','center']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"



                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 82px; font-weight: 700; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;color: #fec007;">L'œuf Marocain</div>

                                <!-- LAYER NR. 5 -->

                            <div class="tp-caption   tp-resizeme" 

                                 id="slide-407-layer-3" 

                                 data-x="['left','left','left','left']" data-hoffset="['100','50','0','0']" 

                                 data-y="['top','top','top','top']" data-voffset="['0','430','460','290']" 

                                            data-fontsize="['82','82','40','40']"

                                data-lineheight="['82','82','50','30']"

                                data-width="['none','100%','100%','100%']"

                                data-height="none"

                                data-whitespace="normal"

                     

                                data-type="text" 

                                data-basealign="slide" 

                                data-responsive_offset="on" 



                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'

                                data-margintop="[8,8,8,8]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['inherit','inherit','center','center']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 81px; font-weight: 300; color: rgba(255, 255, 255, 1); display: block;font-family:'Changa', sans-serif; ">et sa richesse</div>

                                

                                

                                <a href="javascript:;" target="_blank" class="tp-caption rev-btn clv_btn" 

                                 id="slide-407-layer-4" 

                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                                 data-y="['bottom','bottom','top','top']" data-voffset="['30','30','30','30']" 

                                            data-width="170px"

                                data-height="none"

                                data-whitespace="nowrap"

                     

                                data-type="button" 

                                data-actions=''

                                data-basealign="slide" 

                                data-responsive_offset="off" 

                                data-responsive="off"

                                data-startslide="0" 

                                data-endslide="2" 

                                data-frames='[{"delay":1600,"speed":1000,"frame":"0","from":"y:20px;sX:1.5;sY:1.5;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"opacity:0;fb:10px;","ease":"Power4.easeOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);"}]'

                                data-textAlign="['center','center','center','center']"

                                data-margintop="[18,18,0,0]"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[35,35,35,35]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[35,35,35,35]"



                                style="z-index: 8; white-space: nowrap; font-size: 16px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:'Source Sans Pro', sans-serif;border-radius:30px 30px 30px 30px;display:inline-block;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none;">A Propos</a>

                                

                                    </div>

                                </div>

                            </div>



                            <!-- LAYER NR. 6 -->

                            <div class="tp-caption tp-shape tp-shapewrapper " 

                                 id="slide-407-layer-16" 

                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                            data-width="full"

                                data-height="full"

                                data-whitespace="normal"

                     

                                data-type="shape" 

                                data-basealign="slide" 

                                data-responsive_offset="off"    

                                data-responsive="off"

                                data-frames='[{"delay":10,"speed":2000,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'

                                data-textAlign="['inherit','inherit','inherit','inherit']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"



                                style="z-index: 5;background-color:rgba(37, 37, 37, 0.7);"> </div>

                        </li>

                        <!-- SLIDE  -->

                        <li data-index="rs-408" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="2000"  data-thumb="<?php echo e(url('imgs/sld/sld2.jpg')); ?>"  data-rotate="0"  data-saveperformance="off"  data-title="Two" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                            <!-- MAIN IMAGE -->

                            <img src="<?php echo e(url('imgs/sld/sld2.jpg')); ?>"  alt="image"  data-bgposition="center center" data-kenburns="on" data-duration="20000" data-ease="Linear.easeNone" data-scalestart="130" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="6" class="rev-slidebg" data-no-retina style="background-color: rgba(0,0,0,0.8)" >

                            <!-- LAYERS -->

                            <div id="rrzm_408" class="rev_row_zone rev_row_zone_middle" style="z-index: 6;">



                            <!-- LAYER NR. 1 -->

                            <div class="tp-caption  " 

                                 id="slide-408-layer-14" 

                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 

                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                    data-width="none"

                                    data-height="none"

                                    data-whitespace="nowrap"

                     

                                data-type="row" 

                                data-columnbreak="2" 

                                data-basealign="slide" 

                                data-responsive_offset="on" 

                                data-responsive="off"

                                data-frames='[{"delay":10,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'

                                data-margintop="[0,0,0,0]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['inherit','inherit','inherit','inherit']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[100,50,50,50]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[100,50,50,50]"



                                style="z-index: 6; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255, 255, 255, 1.00);">

                            <!-- LAYER NR. 2 -->

                            <div class="tp-caption  " 

                                 id="slide-408-layer-15" 

                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 

                                 data-y="['top','top','top','top']" data-voffset="['100','100','100','100']" 

                                 data-width="none"

                                data-height="none"

                                data-whitespace="nowrap"

            

                                data-type="column" 

                                data-responsive_offset="on" 

                                data-responsive="off"

                                data-frames='[{"delay":"+0","speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'

                                data-columnwidth="100%"

                                data-margintop="[0,0,0,0]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['left','left','left','left']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"



                                style="z-index: 7; width: 100%;">

                            <!-- LAYER NR. 3 -->

                        

                            <!-- LAYER NR. 4 -->

                            <div class="tp-caption   tp-resizeme" 

                                 id="slide-408-layer-2" 

                                 data-x="['left','left','left','left']" data-hoffset="['0','50','0','0']" 

                                 data-y="['top','top','top','top']" data-voffset="['0','430','460','290']" 

                                            data-fontsize="['82','82','40','40']"

                                data-lineheight="['82','82','50','30']"

                                data-width="['none','100%','100%','100%']"

                                data-height="none"

                                data-whitespace="normal"

                     

                                data-type="text" 

                                data-basealign="slide" 

                                data-responsive_offset="on" 



                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'

                                data-margintop="[0,0,0,0]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['inherit','inherit','center','center']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"



                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 82px; font-weight: 700; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;">L’œuf est l’ami </div>

                                <!-- LAYER NR. 5 -->

                            <div class="tp-caption   tp-resizeme" 

                                 id="slide-408-layer-3" 

                                 data-x="['left','left','left','left']" data-hoffset="['100','50','0','0']" 

                                 data-y="['top','top','top','top']" data-voffset="['0','430','60','90']" 

                                            data-fontsize="['82','82','40','40']"

                                data-lineheight="['82','82','50','30']"

                                data-width="['none','100%','100%','100%']"

                                data-height="none"

                                data-whitespace="normal"

                     

                                data-type="text" 

                                data-basealign="slide" 

                                data-responsive_offset="on" 



                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'

                                data-margintop="[8,8,8,8]"

                                data-marginright="[0,0,0,0]"

                                data-marginbottom="[0,0,0,0]"

                                data-marginleft="[0,0,0,0]"

                                data-textAlign="['inherit','inherit','center','center']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"



                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 81px; font-weight: 300; color: rgba(255, 255, 255, 1); display: block;color: #fec007;font-family:'Source Sans Pro', sans-serif;">des sportifs</div>

                                

                                

                                <a href="javascript:;" target="_blank" class="tp-caption rev-btn clv_btn" 

                                 id="slide-408-layer-4" 

                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                                 data-y="['bottom','bottom','top','top']" data-voffset="['30','30','30','30']" 

                                            data-width="170px"

                                data-height="none"

                                data-whitespace="nowrap"

                     

                                data-type="button" 

                                data-actions=''

                                data-basealign="slide" 

                                data-responsive_offset="off" 

                                data-responsive="off"

                                data-startslide="0" 

                                data-endslide="2" 

                                data-frames='[{"delay":1600,"speed":1000,"frame":"0","from":"y:20px;sX:1.5;sY:1.5;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"opacity:0;fb:10px;","ease":"Power4.easeOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);"}]'

                                data-textAlign="['center','center','center','center']"

                                data-margintop="[18,18,0,0]"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[35,35,35,35]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[35,35,35,35]"



                                style="z-index: 8; white-space: nowrap; font-size: 16px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:'Source Sans Pro', sans-serif;border-radius:30px 30px 30px 30px;display:inline-block;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none;">A Propos</a>

                                

                                    </div>

                                </div>

                            </div>



                            <!-- LAYER NR. 6 -->

                            <div class="tp-caption tp-shape tp-shapewrapper " 

                                 id="slide-408-layer-16" 

                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                            data-width="full"

                                data-height="full"

                                data-whitespace="normal"

                     

                                data-type="shape" 

                                data-basealign="slide" 

                                data-responsive_offset="off" 

                                data-responsive="off"

                                data-frames='[{"delay":10,"speed":2000,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'

                                data-textAlign="['inherit','inherit','inherit','inherit']"

                                data-paddingtop="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 5;background-color:rgba(37, 37, 37, 0.7);"> </div>

                        </li>

                    </ul>

                </div>

            </div>

            <div class="scroll_down">

                <span></span>

                <p></p>

            </div>

        </div>


        <!-- 6 Milliards -->
        <div class="about_farm_wrapper clv_section" >
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2 style="font-size: 35px; text-align: justify;">Plus de <span>6 Milliards d’œufs produits</span> par les éleveurs marocains de poules poideuses en 2019. </h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                La production d’œufs au Maroc est une activité en pleine expansion, le développement de ce secteur a commencé en 1981 quand de nombreuses entreprises marocaines spécialisées dans le domaine de poulet en chair ont décidé de se développer en se lançant dans le secteur de l’œuf.
                                </p>
                            </div>
                            <div class="about_img_details" style="background:#FEC007; margin-top: 30px; padding: 20px 25px; width: 100%">
                                <h3 style="color:white; font-weight: bold; font-size: 23px; text-align: center;">En 2019, 6.6 milliards d’unités ont été produites</h3>
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                 pour couvrir les besoins du peuple Marocain en ce produit essentiel dans la vie quotidienne et aussi l’exporter dans certains pays Africains.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 col-md-offset-1">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs/map.png')); ?>" alt="image" style="margin-top: 35px" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ANPO -->
        <div class="about_farm_wrapper clv_section" style="background: rgba(0,0,0,0.1)" >
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-md-offset-4">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs2/anpo.png')); ?>" alt="image" style="margin-top: 35px; width: 80%" />
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2 style="font-size: 35px; text-align: justify;padding-top: 10px">100% d’élevages pondeuses agrées par <span>l’ONSSA</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                L’association nationale des producteurs d’œufs (ANPO) a été agréée à 100% sur le plan sanitaire par l’ONSSA (l’Office  National de Sécurité Sanitaire des produits Alimentaires) conformément aux dispositions de ses textes législatifs et réglementaires.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orphelinats -->
        <div class="about_farm_wrapper clv_section">
            <div class="container">
                <div class="row">                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2 style="font-size: 35px; text-align: justify;padding-top: 0px">Plus de <span>150 000 œufs distribués</span> aux orphelinats et internats d’élèves en 2020</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                L’ANPO soutient les orphelinats pour aider les enfants en situation difficile, en 2020, l’association a distribué environ 150 000 œufs en faveur des orphelinats et des internats d’élèves pour répondre à leurs besoins en alimentation notamment durant cette période difficile du COVID 19.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs2/child.jpg')); ?>" alt="image" style="margin-top: 20px; width: 100%" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Couverture -->
        <div class="about_farm_wrapper clv_section" style="background: #FEC007; padding-top: 12px; padding-bottom: 66px;" >
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs2/i06.jpg')); ?>" alt="image" style="margin-top: 60px; width: 100%" />
                        </div>
                    </div>
                    <div class="col-md-7 col-md-offset-2">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2 style="font-size: 35px; text-align: justify;padding-top: 40px;">Couverture de <span>100% des besoins des marocains</span> en œuf de qualité </h2>
                                <hr style="color:white"> 
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                L’ANPO se place en premier rang de la production d’œufs au Maroc, grâce au savoir-faire et aux investissements de l’association, cette dernière a pu couvrir les besoins des marocains en œuf de qualité par la filière de production nationale.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 150 000 offres d’emploi -->
        <div class="about_farm_wrapper clv_section">
            <div class="container">
                <div class="row">                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2 style="font-size: 35px; text-align: justify;padding-top: 0px">Le secteur avicole crée <span>150 000 offres d’emploi directes</span> et 450 000 offres indirectes</h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                Avec un taux d'accroissement moyen durant les quatre dernières décennies d'environ 6% des productions de viandes de volailles et 6,2% des productions d'œufs de consommation, le secteur avicole constitue l'une des activités agricoles les plus dynamiques au Maroc.
                                <br/>
                                Ce secteur en plein essor permet de créer 150 000 offres d’emploi directes et 450 000 offres indirectes.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs2/offre.jpg')); ?>" alt="image" style="margin-top: 50px; width: 100%" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-11">
                        <div class="about_img_details" style="background:#FEC007; margin-top: 30px; padding: 20px 25px; width: 100%">
                            <h3 style="color:white; font-weight: bold; font-size: 23px; text-align: center;">6,2 % est le taux de croissance annuel moyen du secteur avicole deptuis quatre décennies.</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Couverture -->
        <div class="about_farm_wrapper clv_section" style="padding-top: 12px; padding-bottom: 66px;" >

            <div class="container">
                <div class="row">
                    <div class="col-md-11">
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs2/i06.jpg')); ?>" alt="image" style="margin-top: 80px; width: 100%" />
                        </div>
                    </div>
                    <div class="col-md-7 col-md-offset-2">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2 style="font-size: 35px; text-align: justify;padding-top: 40px">La filière avicole forme <span>1/3 des protéines</span> d’origine animale dans la ration alimentaire moyenne de la consommation marocaine</h2>
                                <hr style="color:white"> 
                            </div>
                            <div class="para_content" style="margin-top: 30px; text-align: justify;">
                                <p>
                                Durant les dernières années, le secteur avicole marocain a connu un grand essor, grâce à ses coûts moins chers par rapport aux autres denrées animales, La filière avicole forme 1/3 des protéines d’origine animale dans la ration alimentaire moyenne de la consommation marocaine.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- chiffres -->
        <div class="clv_counter_wrapper clv_section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading white_heading">
                            <h3>L'œuf Marocain</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline2.png')); ?>" alt="image" /></div>
                        </div>

                    </div>
                </div>
                <div class="counter_section">
                    <div class="row">
                        <div class="col-lg-3 col-md-3">
                            <div class="counter_block">
                                <div class="counter_img">
                                    <span class="red_bg"><img src="<?php echo e(url('assets/images/counter_customer.png')); ?>" alt="image" class="img-fluid" /></span>
                                </div>
                                <div class="counter_text">
                                    <h4><span class="count_no" data-to="18" data-speed="3000">18</span><span>+</span></h4>
                                    <h5>Centres de conditionnement d'œuf</h5>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3">

                            <div class="counter_block">

                                <div class="counter_img">

                                    <span class="yellow_bg"><img src="<?php echo e(url('assets/images/counter_project.png')); ?>" alt="image" class="img-fluid" /></span>

                                </div>

                                <div class="counter_text">

                                    <h4><span class="count_no" data-to="252" data-speed="3000">252</span><span>+</span></h4>

                                    <h5>Fermes agrées par élevage de pondeuse</h5>

                                </div>

                            </div>

                        </div>

                        <div class="col-lg-3 col-md-3">

                            <div class="counter_block">

                                <div class="counter_img">

                                    <span class="orange_bg"><img src="<?php echo e(url('assets/images/counter_branch.png')); ?>" alt="image" class="img-fluid" /></span>

                                </div>

                                <div class="counter_text">

                                    <h4><span class="count_no" data-to="3" data-speed="3000">3</span><span>+</span></h4>

                                    <h5>Unités de transformation d'œuf</h5>

                                </div>

                            </div>

                        </div>

                        <div class="col-lg-3 col-md-3">

                            <div class="counter_block">

                                <div class="counter_img">

                                    <span class="blue_bg"><img src="<?php echo e(url('assets/images/counter_winner.png')); ?>" alt="image" class="img-fluid" /></span>

                                </div>

                                <div class="counter_text">

                                    <h4><span class="count_no" data-to="195" data-speed="3000">195</span><span>+</span></h4>

                                    <h5>195 œufs consomés par habitant par an en 2019</h5>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/home.blade.php ENDPATH**/ ?>