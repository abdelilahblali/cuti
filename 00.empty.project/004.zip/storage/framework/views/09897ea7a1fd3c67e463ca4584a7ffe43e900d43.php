

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-legal"></i> New taxe</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('taxe')); ?>" class="btn-right "><i class="fa fa-list"></i> List of taxes </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('taxeAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="villaname" class="control-label form-label label01">Villa Name  </label></h6>
              <input type="text" name="villaname" id="villaname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="datestart" class="control-label form-label label01">Date Start  </label></h6>
              <input type="text" name="datestart" id="datestart" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="dateend" class="control-label form-label label01">Date End </label></h6>
              <input type="text" name="dateend" id="dateend" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="ptpmaname" class="control-label form-label label01">PTPMA Name  </label></h6>
              <input type="text" name="ptpmaname" id="ptpmaname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="dateptpma" class="control-label form-label label01">Date PTPMA  </label></h6>
              <input type="text" name="dateptpma" id="dateptpma" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="npwp" class="control-label form-label label01">UPWP</label></h6>
              <input type="text" name="npwp" id="npwp" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="bankname" class="control-label form-label label01">Bank Name  </label></h6>
              <input type="text" name="bankname" id="bankname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="banknumber" class="control-label form-label label01">Bank Number  </label></h6>
              <input type="text" name="banknumber" id="banknumber" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="bank" class="control-label form-label label01">bank</label></h6>
              <input type="text" name="bank" id="bank" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="notaryname" class="control-label form-label label01">Notary Name  </label></h6>
              <input type="text" name="notaryname" id="notaryname" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="leaseagreement" class="control-label form-label label01">Lease argeement Name</label></h6>
              <input type="text" name="leaseagreement" id="leaseagreement" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="consultat" class="control-label form-label label01">Consultat </label></h6>
              <input type="text" name="consultat" id="consultat" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="physical" class="control-label form-label label01">Phisical Card  </label></h6>
              <label class="switch" for="physical" >
                <input type="checkbox"  name="physical" id="physical">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-3">
              <h6><label for="agreementptpma" class="control-label form-label label01">Agreement PTPMA </label></h6>
              <label class="switch" for="agreementptpma" >
                <input type="checkbox"  name="agreementptpma" id="agreementptpma">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-3">
              <h6><label for="efin" class="control-label form-label label01">Enfin  </label></h6>
              <label class="switch" for="efin" >
                <input type="checkbox"  name="efin" id="efin">
                <span class="slider round"></span>
              </label>
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add Taxe</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#villaname").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'landGetInfo/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#villaname").val(response['data'][0].villaname); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#dateend").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'taxeGetProgress/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#dateend").val(response['data'][0].dateend); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#ptpmaname").val(""); 
    $("#dateptpma").val(""); 
    $("#npwp").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'taxeGetPtpma/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#ptpmaname").val(response['data'][0].ptpmaname);
        $("#dateptpma").val(response['data'][0].dateptpma); 
        $("#npwp").val(response['data'][0].npwp); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#bankname").val(""); 
    $("#banknumber").val(""); 
    $("#bank").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'taxeGetBank/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#bankname").val(response['data'][0].bankname);
        $("#banknumber").val(response['data'][0].banknumber); 
        $("#bank").val(response['data'][0].bank); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#notaryname").val(""); 
    $("#leaseagreement").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'suiviGetLand/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#notaryname").val(response['data'][0].notaryname);
        $("#leaseagreement").val(response['data'][0].leaseagreement); 
       }
    });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/taxeAdd.blade.php ENDPATH**/ ?>