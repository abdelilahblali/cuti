<?php $__env->startSection('content'); ?>

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Factures</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">Architecture : Design 0</h4>
<div class="col-md-12">
  <div class="panel panel-default client-content">
  <h5><i class="fa fa-youtube"></i> Video URL</h5>
    <form method="POST" action="<?php echo e(route('clientFolder_design0_addVideo',[ 'cli' => $ref ] )); ?>" enctype="multipart/form-data">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="cli" value="<?php echo e($ref); ?>">
      <div class="row" style="margin-top: 20px">
        <div class="col-md-12">
          <input type="text" name="url" class="form-control" value="<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($it->url); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-12">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Form ################## -->
<div class="col-md-12">
  <div class="panel panel-default client-content">
      <div class="">
        <div class="card-body">
          <div class="card card-xxl-stretch">
            <form method="POST" action="<?php echo e(route('form_added')); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


              <div class="imgShow"></div>

              <h1>SÉLECTION DES FINITIONS ET ÉQUIPEMENTS</h1>

              <h2>FINITIONS ET ÉQUIPEMENTS EXTÉRIEURS DE VOTRE VILLA</h2>
              

              <div class="mb-5">
                <label for="v1" class=" form-label">Souhaitez-vous ajouter un portail coulissant sur la rue ?</label>
                <select class="form-control" aria-label="Select example" name="v1">
                  <option><?php echo e($v1); ?></option>
                  <option>Oui (prix supplémentaire calculé sur mesure)</option>
                  <option>Non</option>
                </select>
              </div>

              <div class="mb-5">
                <label for="v2" class=" form-label">Souhaitez-vous ajouter un espace de bagagerie à l'entrée de la villa ? </label>
                <select class="form-control" aria-label="Select example" name="v2">
                  <option><?php echo e($v2); ?></option>
                  <option>Oui (prix supplémentaire calculé sur mesure)</option>
                  <option>Non</option>
                </select>
              </div>

              <h3>P05 -  Porte d'entrée</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="
                <table>
                  <tr>
                    <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                  </tr>
                  <tr>
                    <td>Porte simple 1.0m sur charnières ou pivot</td>
                    <td>Porte double 1.4m sur charnières</td>
                    <td>Porte simple 1.4m sur charnières ou pivot</td>
                    <td>Porte double carrée (prix supplémentaire calculé sur mesure)</td>
                  </tr>
                </table>
                " data-trigger="hover" data-placement="auto top">
                  <label for="v3" class=" form-label">Souhaitez-vous une porte d'entrée telle que proposée (page 6) ?</label>
                   <select class="form-control"  id="select1"  name="v3">
                      <option><?php echo e($v3); ?></option>
                      <option>Porte simple 1.0m sur charnières ou pivot</option>
                      <option>Porte double 1.4m sur charnières</option>
                      <option>Porte simple 1.4m sur charnières ou pivot</option>
                      <option>Porte double carrée (prix supplémentaire calculé sur mesure)</option>
                   </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v4" class=" form-label">Souhaitez vous une porte en bois travaillée / gravée (page 5) ? </label>
                <select class="form-control" aria-label="Select example" name="v4">
                  <option><?php echo e($v4); ?></option>
                  <option>Oui (à partir de 650€ / 735$)</option>
                  <option>Non</option>
                </select>
              </div>

              <h3>P07 -  Sols extérieurs :</h3>

              <div class="mb-5">
                <label for="v5" class=" form-label">Quelle finition souhaitez-vous pour les sols extérieurs de votre villa ? </label>
                <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Pierre naturelle Palimanan</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v5">
                    <option><?php echo e($v5); ?></option>
                    <option>Pierre naturelle Palimanan</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v6" class=" form-label">Souhaitez vous un autre type de revêtement avec un coût supplémentaire ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Bois Ulin à raison de 4m² (78€/m² / 88$/m²)</td>
                      <td>Béton bouchardé (41€/m² / 46$/m²)</td>
                      <td>Opus grande taille (24€/m² / 27$/m²)</td>
                      <td>Opus petite taille (31€/m² / 34$/m²)</td>
                      <td>Béton désactivé (41€/m² / 46$/m²)</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v6">
                    <option><?php echo e($v6); ?></option>
                    <option>Bois Ulin à raison de 4m² (78€/m² / 88$/m²)</option>
                    <option>Béton bouchardé (41€/m² / 46$/m²)</option>
                    <option>Opus grande taille (24€/m² / 27$/m²)</option>
                    <option>Opus petite taille (31€/m² / 34$/m²)</option>
                    <option>Béton désactivé (41€/m² / 46$/m²)</option>
                    <option>Finition hors catalogue</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v7" placeholder="Autres" value="<?php echo e($v7); ?>">
              </div>

              <h3>P10 -  Toitures </h3>

              <div class="mb-5">
                <label for="v8" class=" form-label">Quel type de couverture de toiture souhaitez vous retenir ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Tuiles de terre cuite finition naturelle ou peinture</td>
                      <td>Bardeau d’asphalte </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v8">
                    <option><?php echo e($v8); ?></option>
                    <option>Tuiles de terre cuite finition naturelle ou peinture </option>
                    <option>Bardeau d’asphalte </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v9" class=" form-label">Souhaitez vous un autre type de revêtement avec un coût supplémentaire ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Toiture plate en béton avec finition galet ou gazon synthétique (29€/m² / 33$/m²) </td>
                      <td>Sirap / tuiles en bois de fer (50€/m² / 56$/m²) </td>
                      <td>Alang-alang / chaume de Bali (39€/m² / 44$/m²) </td>
                      <td>Décoration sculptée (uniquement sur couverture en tuile </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v9">
                    <option><?php echo e($v9); ?></option>
                    <option>Toiture plate en béton avec finition galet ou gazon synthétique (29€/m² / 33$/m²) </option>
                    <option>Sirap / tuiles en bois de fer (50€/m² / 56$/m²) </option>
                    <option>Alang-alang / chaume de Bali (39€/m² / 44$/m²) </option>
                    <option>Décoration sculptée (uniquement sur couverture en tuile </option>
                  </select>
                </div>
              </div>

              <h3>P11 - Façades et baies coulissantes</h3>

              <div class="mb-5">
                <label for="v10" class=" form-label">Quelle touche de parement décoratif souhaitez-vous appliquer sur vos façades ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Pierre Palimanan (beige) </td>
                      <td>Pierre Kerobokan </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v10">
                    <option><?php echo e($v10); ?></option>
                    <option>Décoration bois</option>
                    <option>Pierre Palimanan (beige) </option>
                    <option>Pierre Batu Candi (noire) </option>
                    <option>Pierre Limestone </option>
                    <option>Pierre Kerobokan </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v11" class=" form-label">Quel type d’huisserie de fenêtre (fixe et coulissante) souhaitez vous pour votre villa ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Aluminium noir </td>
                      <td>Aluminium blanc </td>
                      <td>Pierre Kerobokan </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v11">
                    <option><?php echo e($v11); ?></option>
                    <option>Aluminium noir </option>
                    <option>Aluminium blanc </option>
                    <option>Bois (106€/m² / 120$/m²) </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v12" class=" form-label">Souhaitez-vous intégrer un autre type d’ouverture des baies vitrées ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v12">
                    <option><?php echo e($v12); ?></option>
                    <option>Oui (prix supplémentaire calculé sur mesure)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v13" placeholder="Autres" value="<?php echo e($v13); ?>">
              </div>

              <h3>P12 - Jardin </h3>

              <div class="mb-5">
                <label for="v14" class=" form-label">Quelle couleur de finition souhaitez-vous pour votre mur d’enceinte ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v14">
                    <option><?php echo e($v14); ?></option>
                    <option>Crépis gris </option>
                    <option>Crépis beige</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v15" class=" form-label">La réalisation proposée des jardins correspond-elle à vos attentes ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v15">
                    <option><?php echo e($v15); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v16" placeholder="Autres" value="<?php echo e($v16); ?>">
              </div>

              <div class="mb-5">
                <label for="v17" class=" form-label">Si besoin est, quel type de brise-vue souhaiteriez-vous retenir?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v17">
                    <option><?php echo e($v17); ?></option>
                    <option>Palissade en bois sur structure métallique noire  </option>
                    <option>Canisse de bambou  </option>
                    <option>Câbles tendu avec végétation grimpante </option>
                  </select>
                </div>
              </div>

              <h3>P13 - Statues</h3>

              <div class="mb-5">
                <label for="v18" class=" form-label">Quelle statue souhaitez vous intégrer dans votre villa </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v18">
                    <option><?php echo e($v18); ?></option>
                    <option>Tête de bouddha</option>
                    <option>Bouddha couché</option>
                    <option>Bouddha méditant</option>
                    <option>Bouddha debout</option>
                    <option>Tête de Dewi Sri</option>
                    <option>Dewi Sri debout</option>
                    <option>Ganesh</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v19" class=" form-label">Souhaitez-vous choisir un autre type de statue ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v19">
                    <option><?php echo e($v19); ?></option>
                    <option>Oui (prix supplémentaire calculé sur mesure)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v20" placeholder="Autres" value="<?php echo e($v20); ?>">
              </div>

              <h3>P14 - Salon extérieur </h3>

              <div class="mb-5">
                <label for="v21" class=" form-label">Quelle typologie de salon extérieur voulez-vous pour votre villa ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v21">
                    <option><?php echo e($v21); ?></option>
                    <option>Sunken avec coussin</option>
                    <option>Plateforme pierre avec mobilier </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v22" class=" form-label">Souhaitez-vous choisir d'autres options hors standard? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v22">
                    <option><?php echo e($v22); ?></option>
                    <option>Oui (prix supplémentaire calculé sur mesure)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v23" placeholder="Autres" value="<?php echo e($v23); ?>">
              </div>

              <h3>P16 - Gardes-corps </h3>

              <div class="mb-5">
                <label for="v24" class=" form-label">Si nécessaire, quelle structure de garde-corps souhaitez vous retenir  ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Acier </td>
                      <td>Acier + bois </td>
                      <td>Acier + cordage </td>
                      <td>Acier + verre - image 27 (104€/m² / 118$/m²)</td>
                      <td>Acier + cable tendu (57€/m² / 65$/m²)</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v24">
                    <option><?php echo e($v24); ?></option>
                    <option>Acier </option>
                    <option>Acier + bois </option>
                    <option>Acier + cordage  </option>
                    <option>Acier + verre - image 27 (104€/m² / 118$/m²)</option>
                    <option>Acier + cable tendu (57€/m² / 65$/m²)</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v25" class=" form-label">Dans le cas d’un garde-corps, souhaitez-vous une main-courante </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Acier </td>
                      <td>Bois </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v25">
                    <option><?php echo e($v25); ?></option>
                    <option>Acier </option>
                    <option>Bois </option>
                    <option>Sans main-courante</option>
                  </select>
                </div>
              </div>

              <h3>P19 - Espace de baignade </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous modifier les surfaces et profondeurs proposées </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v26">
                    <option><?php echo e($v26); ?></option>
                    <option>Oui (à partir de 301€/m² / 340$/m²)</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous, avec un coût supplémentaire, ajouter à cet espace de baignade :</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v27">
                    <option><?php echo e($v27); ?></option>
                    <option>Une vitre plexiglass (2 438€ / 2755$)- </option>
                    <option>Une douche </option>
                    <option>Une banquette relaxante intégrée à la piscine (sans bulles) (à partir de 4063€ / 4591$)</option>
                  </select>
                </div>
              </div>

              <h2>FINITIONS ET ÉQUIPEMENTS INTÉRIEURS DE VOTRE VILLA </h2>

              <h3>P21 -  Les sols</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Quel type de sol souhaitez vous revêtir l'intérieur de votre villa </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/b.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Carrelage Cemento (lisse) 60cmx60cm gris </td>
                      <td>Carrelage Infinity (effet pierre) 60cmx60cm gris  </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v28">
                    <option><?php echo e($v28); ?></option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm gris</option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm gris foncé </option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm noir </option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm crème </option>
                    <option>Carrelage Infinity (effet pierre) 60cmx60cm gris</option>
                    <option>Carrelage Infinity (effet pierre) 60cmx60cm blanc </option>
                    <option>Carrelage Infinity (effet pierre) 60cmx60cm crème </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous un autre type de revêtement avec un coût supplémentaire</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Revêtement en béton bouchardé (41€/m² / 46$/m²) </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v29">
                    <option><?php echo e($v29); ?></option>
                    <option>Carrelage Cemento gris (lisse) 100cmx100cm </option>
                    <option>Carrelage Infinity (effet pierre) 60cmx120cm</option>
                    <option>Revêtement en béton bouchardé (41€/m² / 46$/m²) </option>
                    <option>Parquet -(78€/m² / 88$/m²) </option>
                    <option>Autre </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v30" placeholder="Autres" value="<?php echo e($v30); ?>">
              </div>

              <h3>P22 - Les murs</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter un autre revêtement mural pour vos intérieurs </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Pierre Palimanan</td>
                      <td>Pierre Palimanan</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v31">
                    <option><?php echo e($v31); ?></option>
                    <option>Pierre Palimanan</option>
                    <option>Pierre Kerobokan (35€/m² / 40$/m</option>
                    <option>Lambris de bois (à partir de 82€/m² / 92$/m²)</option>
                    <option>Autre </option>
                  </select>
                </div>
              </div>

              <h3>P22 - Les murs</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous conserver le modèle de porte standard ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Porte de 0.8x2.30m en contre-plaqué au dessin géométrique</td>
                      <td>Non</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v32">
                    <option><?php echo e($v32); ?></option>
                    <option>Porte de 0.8x2.30m en contre-plaqué au dessin géométrique</option>
                    <option>Non </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Dans le cas cas contraire vous pouvez choisir d’autres designs de porte avec supplément</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Panneau de bois sculpté (569€/unité / 643$/unité) </td>
                      <td>Porte coulissante (650€/unité / 735$/unité) </td>
                      <td>Double porte (732€/unité / 827$/unité)- </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v33">
                    <option><?php echo e($v33); ?></option>
                    <option>Panneau de bois sculpté (569€/unité / 643$/unité)  </option>
                    <option>Porte coulissante (650€/unité / 735$/unité)  </option>
                    <option>Double porte (732€/unité / 827$/unité)-  </option>
                    <option>Autre </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v34" placeholder="Autres" value="<?php echo e($v34); ?>">
              </div>

              <h3>P25 - Les plafonds </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez vous conserver le modèle standard de plafond</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Plafond de 3m20 dans le séjour et de 2m80 dans les chambres </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v35">
                    <option><?php echo e($v35); ?></option>
                    <option>Plafond de 3m20 dans le séjour et de 2m80 dans les chambres   </option>
                    <option>Non </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Dans le cas cas contraire, d’autres plafonds sont disponibles avec supplément </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Plafond plat en lambris bois (36€/m² / 41$/m²) </td>
                      <td>Plafond plat avec structure bois apparente sur lambris bois (45€/m² /  59$/m²)- </td>
                      <td>Charpente bois apparente sur lambris bois (57€/m² / 65$/m </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v36">
                    <option><?php echo e($v36); ?></option>
                    <option>Plafond plat en lambris bois (36€/m² / 41$/m²) </option>
                    <option>Plafond plat avec structure bois apparente sur lambris bois (45€/m² /  59$/m²)- </option>
                    <option>Charpente bois apparente sur lambris bois (57€/m² / 65$/m </option>
                    <option>Autres </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v37" placeholder="Autres" value="<?php echo e($v37); ?>">
              </div>

              <h3>P26 - L'espace de vie  </h3>

              <div class="mb-5">
                <label for="" class=" form-label">La conception de l'espace de vie correspond-elle à vos attentes</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v38">
                    <option><?php echo e($v38); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v39" placeholder="Autres" value="<?php echo e($v39); ?>">
              </div>

              <h3>P28 - La cuisine</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Quel type d’agencement de cuisine préférez-vous ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v40">
                    <option><?php echo e($v40); ?></option>
                    <option>Agencement fermé (tout en placard) </option>
                    <option>Agencement semi fermé (placard + étagères avec fond en bois) </option>
                    <option>Agencement semi ouvert (placard + étagères sans fond avec mur apparent) </option>
                    <option>Agencement ouvert (tout en étagère sans fond avec mur apparent) </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Quelle finition choisissez-vous pour votre agencement de cuisine ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v41">
                    <option><?php echo e($v41); ?></option>
                    <option>Teck clair  </option>
                    <option>Teck foncé  </option>
                    <option>Teck teinté couleur au choix (prix supplémentaire calculé sur mesure)</option>
                    <option>Teck laqué couleur au choix (prix supplémentaire calculé sur mesure)</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Concernant le plan de travail et les crédences, que préférez-vous ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v42">
                    <option><?php echo e($v42); ?></option>
                    <option>Marbre noir</option>
                    <option>Marbre blanc</option>
                    <option>Granit noir</option>
                    <option>Composite blanc</option>
                    <option>Céramique (prix supplémentaire calculé sur mesure)</option>
                    <option>Terrazzo couleur au choix (prix supplémentaire calculé sur mesure)</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous conserver les dimensions du modèle standard de cuisine ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v43">
                    <option><?php echo e($v43); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v44" placeholder="Autres" value="<?php echo e($v44); ?>">
              </div>

              <h3>P29 - Les chambres </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous conserver la composition des chambres selon nos standards?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v45">
                    <option><?php echo e($v45); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v46" placeholder="Autres" value="<?php echo e($v46); ?>">
              </div>

              <h3>P31 - Les salles de bains : </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous conserver le plan de toilette standard en agencement bois ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v47">
                    <option><?php echo e($v47); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Dans le cas contraire, avec un coût additionnel, quel plan vasque préférez- vous ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v48">
                    <option><?php echo e($v48); ?></option>
                    <option>Agencement maçonné avec plateau en marbre (prix supplémentaire calculé sur mesure)  </option>
                    <option>Agencement maçonné avec revêtement en terrazzo (488€/unité / 551$/unité)  </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Dans notre sélection de lavabos, lequel correspond à vos attentes?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Céramique rectangulaire  </td>
                      <td>Céramique circulaire </td>
                      <td>Terrazzo rectangulaire </td>
                      <td>Pierre de rivière (grise)  </td>
                      <td>Pierre Onix (beige)  </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v49">
                    <option><?php echo e($v49); ?></option>
                    <option>Céramique rectangulaire  </option>
                    <option>Céramique circulaire </option>
                    <option>Terrazzo rectangulaire </option>
                    <option>Pierre de rivière (grise)  </option>
                    <option>Pierre Onix (beige)  </option>
                  </select>
                </div>
              </div> 

               <div class="mb-5">
                <label for="" class=" form-label">Concernant la finition murale, il est prévu un mélange de peinture et de carrelage, mais avec un surcoût seriez vous intéressé par des touches de finitions différentes (à partir de 41€/m² / 46$/m²) ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Terrazzo (tous coloris) </td>
                      <td>Marbre</td>
                      <td>Limestone  </td>
                      <td>Susun Siri (petite pierre taillée horizontale) </td>
                      <td>Pierre taillée Palimanan</td>
                      <td>Pierre taillée Batu Candi</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v50">
                    <option><?php echo e($v50); ?></option>
                    <option>Terrazzo (tous coloris) </option>
                    <option>Marbre</option>
                    <option>Limestone  </option>
                    <option>Susun Siri (petite pierre taillée horizontale) </option>
                    <option>Pierre taillée Palimanan</option>
                    <option>Pierre taillée Batu Candi</option>
                  </select>
                </div>
              </div>  

              <h2>LISTE DES ADDITIONNELS APPLICABLES</h2>

              <h3>P36 - Salle de massage :</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une salle de massage sur mesure au sein de votre villa (à partir de 9000€ / 10 170$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v51">
                    <option><?php echo e($v51); ?></option>
                    <option>Deux tables de massage </option>
                    <option>Deux tables de massage et un lavabo </option>
                    <option>Deux tables de massage, un lavabo et une douche </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>P37 - Salle de sports</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une salle de sport sur mesure au sein de votre villa (à partir de 9000€ / 10 170$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v52">
                    <option><?php echo e($v52); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Si oui, quels sont les 3 éléments que vous souhaitez pour l’équiper </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v53">
                    <option><?php echo e($v53); ?></option>
                    <option>A Vélo </option>
                    <option>B Vélo elliptique</option>
                    <option>C Tapis de course</option>
                    <option>D Machine de musculation</option>
                    <option>E Banc de musculation</option>
                    <option>F Ballon de gym</option>
                    <option> G Demi ballon de gym</option>
                    <option>H Poids fitness</option>
                    <option>I Step de fitness</option>
                    <option>J Tapis de gym</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous réaliser un ou des terrains de sport? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v54">
                    <option><?php echo e($v54); ?></option>
                    <option>Oui  </option>
                    <option>Non</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v55" placeholder="Autres" value="<?php echo e($v55); ?>">
              </div>

              <h3>P39 - Yoga shala</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une structure pour espace yoga au sein de votre villa (à partir de 2000€)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v56">
                    <option></option>
                    <option>Toiture avec plafond en lambris  </option>
                    <option>Toiture avec charpente bois apparente</option>
                    <option>Structure en bambou</option>
                    <option>Non</option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>P40 - Pergola </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter une pergola au sein de votre villa (à partir de 1000€ / 1130$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v57">
                    <option><?php echo e($v57); ?></option>
                    <option>Oui</option>
                    <option>Non</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Concernant la réalisation de pergola, quelle structure préférez-vous ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Bois </td>
                      <td>Acier </td>
                      <td>Béton   </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v58">
                    <option><?php echo e($v58); ?></option>
                    <option>Bois  </option>
                    <option>Acier </option>
                    <option>Béton   </option>
                  </select>
                </div>
              </div> 

              <div class="mb-5">
                <label for="" class=" form-label">Pour l'ombrage, quel matériau est votre favori ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Bois manufacturé  </td>
                      <td>Bois flotté  </td>
                      <td>Métal</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v59">
                    <option><?php echo e($v59); ?></option>
                    <option>Bois manufacturé   </option>
                    <option>Bois flotté</option>
                    <option>Métal</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous une protection contre la pluie ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                      <td><img class='imgShow' src='<?php echo e(url('select/a.jpg')); ?>'></td>
                    </tr>
                    <tr>
                      <td>Sans protection </td>
                      <td>Verre </td>
                      <td>Polycarbonate fumé</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v60">
                    <option><?php echo e($v60); ?></option>
                    <option>Sans protection</option>
                    <option>Verre </option>
                    <option>Polycarbonate fumé</option>
                  </select>
                </div>
              </div>  

              <h3>P42 - Gazebo : </h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter un gazebo sur mesure au sein de votre jardin (à partir de 700€ / 791$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v61">
                    <option><?php echo e($v61); ?></option>
                    <option>Oui </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v62" placeholder="Autres" value="<?php echo e($v62); ?>">
              </div>

              <h3>P43 - Point d’eau</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter des douches extérieures dans des jardins privatifs ( 407€/unité / 459$/unité)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v63">
                    <option><?php echo e($v63); ?></option>
                    <option>Oui, au nombre de  </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v64" placeholder="Autres" value="<?php echo e($v64); ?>">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter des baignoires intérieures ou extérieures (813€/unité / 919$/uité)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v65">
                    <option><?php echo e($v65); ?></option>
                    <option>Baignoire en faïence -page 53 au nombre de </option>
                    <option>Baignoire en terrazzo , au nombre de </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v66" placeholder="Autres" value="<?php echo e($v66); ?>">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter un jacuzzi dans un espace privé ou public de la villa ? (à partir de 8125€ / 9182$)</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v67">
                    <option><?php echo e($v67); ?></option>
                    <option>Jacuzzi manufacturé 2 places </option>
                    <option>Jacuzzi manufacturé 4 places  </option>
                    <option>Jacuzzi manufacturé 6 places </option>
                    <option>Jacuzzi construit taille au choix </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>P44 - Éléments décoratifs</h3>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous décorer votre villa de murs végétaux (160€/m² / 181$/m²) ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v68">
                    <option><?php echo e($v68); ?></option>
                    <option>Intérieur </option>
                    <option>Extérieur  </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous décorer votre villa de bassin d’agrément (244€ / 276$)(image 59) ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v69">
                    <option><?php echo e($v69); ?></option>
                    <option>Oui  </option>
                    <option>Non </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous décorer votre villa d’une fontaine ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v70">
                    <option><?php echo e($v70); ?></option>
                    <option>Mur d’eau - image 59 (122€ / 138$)  </option>
                    <option>Sculpture (prix supplémentaire calculé sur mesure </option>
                    <option>Non</option>
                    </option>
                  </select>
                  </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Souhaitez-vous ajouter à votre villa un temple à offrandes (276€/unité / 312$/unité) ? </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v71">
                    <option><?php echo e($v71); ?></option>
                    <option>Non</option>
                    <option>Non</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">Aimeriez-vous ajouter des éléments de détentes photogéniques ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v72">
                    <option><?php echo e($v72); ?></option>
                    <option>Hamac</option>
                    <option>Filet hamac sur structure construite</option>
                    <option>Balançoire</option>
                    <option>Structure Coeur </option>
                    <option>Structure Nid</option>
                    <option>Autre</option>
                    <option>Non</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v73" placeholder="Autres" value="<?php echo e($v73); ?>">
              </div>

              <div class="mb-5">
                <label for="" class="form-label">Aimeriez-vous ajouter des équipements à votre villa ?</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control" aria-label="Select example" name="v74">
                    <option><?php echo e($v74); ?></option>
                    <option>Écran TV 55” dans le séjour</option> 
                    <option>Écran TV 43” dans les chambres (au lieu de 33”)</option> 
                    <option>Vidéo projecteur</option> 
                    <option>Ecran motorisé pour projection</option> 
                    <option>Enceinte Sonos bluetooth au nombre de </option> 
                    <option>Ampli pour système son</option> 
                    <option>Enceinte connectée pour ampli au nombre de</option> 
                    <option>Machine-à-laver</option> 
                    <option>Machine-à-laver / sécher</option> 
                    <option>Lave-vaisselle</option> 
                    <option>Lumière RVB dans la piscine</option> 
                    <option>Autre </option> 
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v75" placeholder="Autres" value="<?php echo e($v75); ?>">
              </div>

              <div class="mb-5">
                  <button class="btn btn-success" style="margin-top: 10px"><i class="fa fa-save"></i> Save</button>
              </div>

            </form>
          </div>
        </div>
      </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/clientFolder_design0.blade.php ENDPATH**/ ?>