

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-diamond"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('ventes')); ?>" class="btn-right "><i class="fa fa-list"></i> List of sales </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<form method="POST" action="<?php echo e(route('venteEdited',[ 'ref' => $vente->ref ])); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-2">
              <h6><label for="cod" class="control-label form-label label01">Code <span class="c3_color">*</span></label></h6>
              <input type="text" name="cod" id="cod" class="form-control" required value="<?php echo e($vente->cod); ?>" />
          </div>
          <div class="col-md-2">
              <h6><label for="civ" class="control-label form-label label01">Civility <span class="c3_color">*</span></label></h6>
              <select name="civ" id="civ" class="form-control">
                <option value="<?php echo e($vente->civ); ?>"><?php echo e($vente->civ); ?></option>
                <option value="M.">M.</option>
                <option value="Mme">Mme</option>
              </select>
          </div>
          <div class="col-md-4">
              <h6><label for="nom" class="control-label form-label label01">Last Name <span class="c3_color">*</span></label></h6>
              <input type="text" name="nom" id="nom" class="form-control" required value="<?php echo e($vente->nom); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="pre" class="control-label form-label label01">First Name <span class="c3_color">*</span></label></h6>
              <input type="text" name="pre" id="pre" class="form-control" required value="<?php echo e($vente->pre); ?>"/>
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="tel" class="control-label form-label label01">Phone <span class="c3_color">*</span></label></h6>
              <input type="text" name="tel" id="tel" class="form-control" required value="<?php echo e($vente->tel); ?>"/>
          </div>
          <div class="col-md-4">
              <h6><label for="mail" class="control-label form-label label01">Email <span class="c3_color">*</span></label></h6>
              <input type="email" name="mail" id="mail" class="form-control" required value="<?php echo e($vente->mail); ?>"/>
          </div>
          <div class="col-md-4">
              <h6><label for="passeport" class="control-label form-label label01">Passport | <a href="http://localhost/mag.sales/media/cli/<?php echo e($vente->passeport); ?>" target="_">Voir le passeport existant</a></label></h6>
              <input type="file" name="images[]" id="passeport" class="form-control"  />
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Sale informations</h4>

      <div class="row">
        <div class="col-md-3">
              <h6><label for="seller" class="control-label form-label label01">Seller  </label></h6>
              <input type="text" name="seller" id="seller" class="form-control" value="<?php echo e($vente->seller); ?>"  />
          </div>
          <div class="col-md-2">
              <h6><label for="ares" class="control-label form-label label01">Number of Ares sold  </label></h6>
              <input type="text" name="ares" id="ares" class="form-control" value="<?php echo e($vente->ares); ?>" />
          </div>
          <div class="col-md-2">
              <h6><label for="lease" class="control-label form-label label01">Lease duration   </label></h6>
              <select name="lease" id="lease" class="form-control">
                <option><?php echo e($vente->lease); ?></option>
                <option>20</option>
                <option>25</option>
                <option>30</option>
                <option>20 + 30 ans renouvellable 
                <option>25 + 25 ans renouvellable
                <option>30 + 20 ans renouvelable
                <option>Autres durée -> a rempli</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="position" class="control-label form-label label01">Position of the field   </label></h6>
              <select name="position" id="position" class="form-control chzn-select">
                <option><?php echo e($vente->position); ?></option>
                <option>Terrain pas encore choisi</option>
                <option>Gentong Jungle</option>
                <option>Canggu</option>
                <option>Petulu</option>
                <option>Gentong Jungle</option>
                <option>Sala Ricefield</option>
                <option>Singakerta River II</option>
                <option>Pas encore</option>
                <option>Tatiapi Pura; Between El Zhar and Chavatte</option>
                <option>Gentong Jungle (entre wotschke et haathio)</option>
                <option>Tatiapi Sawah</option>
                <option>Marvelous Mas (5 ares au sud)</option>
                <option>Marvelous Mas les 7 ares au Nord</option>
                <option>Pas encore</option>
                <option>Singakerta River II</option>
                <option>Singakerta River I</option>
                <option>Marvelous Mas</option>
              </select>
          </div>
          <div class="col-md-2">
              <h6><label for="chambre" class="control-label form-label label01">Villa no. Of bedroom  </label></h6>
              <select name="chambre" id="chambre" class="form-control" >
                <option><?php echo e($vente->chambre); ?></option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>
                <option>7</option>
                <option>8</option>
                <option>9</option>
              <select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="basee" class="control-label form-label label01">Sale of the villa based on </label></h6>
              <select name="basee" id="basee" class="form-control">
                <option ><?php echo e($vente->basee); ?></option>
                <option >Template</option>
                <option >Hors template avec inspiration</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="template" class="control-label form-label label01">Template   </label></h6>
              <select name="template" id="template" class="form-control chzn-select">
                <option value="<?php echo e($vente->template); ?>"><?php echo e($vente->template); ?></option>
                <option>Andong</option>
                <option>Passion</option>
                <option>Cheng</option>
                <option>Alma</option>
                <option>Jump</option>
                <option>Dona neto</option>
                <option>Gabrielle</option>
                <option>Yuka</option>
                <option>Jacuzzi</option>
                <option>Oasis</option>
                <option>Paradise</option>
                <option>Joy</option>
                <option>Destiny</option>
                <option>Dream</option>
                <option>Eden</option>
                <option>Emotion</option>
                <option>Fire</option>
                <option>Joy</option>
                <option>Passion</option>
                <option>Spirit</option>
                <option>Victory</option>
                <option>Zen</option>
                <option>Zest</option>
                <option>Bouddha</option>
                <option>Cantik</option>
                <option>Frangipani </option>
                <option>Green </option>
                <option>Kodok</option>
                <option>Lotus</option>
                <option>Orchid</option>
                <option>Paradise</option>
                <option>Sawah</option>
              </select>
          </div>
          <div class="col-md-6">
              <h6><label for="inspiration" class="control-label form-label label01">Inspiration existing villa or others?   </label></h6>
              <input type="text" name="inspiration" id="inspiration" class="form-control" value="<?php echo e($vente->inspiration); ?>"  />
          </div>
    </div>
    <div class="row">
          <div class="col-md-1">
              <h6><label for="extra" class="control-label form-label label01">Extra  </label></h6>
              <label class="switch" for="extra" >
                <input type="checkbox"  name="extra" id="extra" <?php if($vente->extra=='on'): ?> checked  <?php endif; ?>>
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-4">
              <h6><label for="extras" class="control-label form-label label01">Liste des extras vendus.  </label></h6>
              <input type="text" name="extras" id="extras" class="form-control"  value="<?php echo e($vente->extras); ?>"/>
          </div>
     
          <div class="col-md-5">
              <h6><label for="prix" class="control-label form-label label01">Selling price   <span class="c3_color">*</span></label></h6>
              <input type="number" name="prix" id="prix" class="form-control" required  value="<?php echo e($vente->prix); ?>"/>              
          </div>

          <div class="col-md-2">
              <h6><label for="unite" class="control-label form-label label01">Unity</label></h6>
              <select name="unite" id="unite" class="form-control">
                <option><?php echo e($vente->unite); ?></option>
                <option value="€">€</option>
                <option value="$">$</option>
              </select>
          </div>

      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save changes</button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/venteEdit.blade.php ENDPATH**/ ?>