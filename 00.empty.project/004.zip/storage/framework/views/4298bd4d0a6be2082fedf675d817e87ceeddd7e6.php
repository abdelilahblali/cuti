

<?php $__env->startSection('content'); ?>



<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
          <li class="titrePage"><i class="fa fa-paint-brush"></i> Mise à jour l'interface de la boutique</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group" aria-label="...">
            <a href="<?php echo e(route('editionLogo')); ?>" class="btn-right ">Changer le logo </a> | 
            <a href="<?php echo e(route('editionCover')); ?>" class="btn-right ">Changer la couverture | </a>
            <a href="<?php echo e(route('editionSlide')); ?>" class="btn-right ">Gérer les slides </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-8">
  <?php if( Auth::user()->cover=='' ): ?>
    <div class="panel panel-default client-content" style="height: 250px;  background: rgba(0,0,0,0.1);">
  <?php else: ?>
    <div class="panel panel-default client-content" style="height: 250px;  background-size: cover; background-image:url('<?php echo e(url('img-cover')); ?>/<?php echo e(Auth::user()->cover); ?>')">
  <?php endif; ?>
  
    <?php if( Auth::user()->logo=='' ): ?>
      <div class="profil-logo" style="width: 140px; height: 140px; margin: 10px; border-radius: 15px; background: #ef4136;"></div>
    <?php else: ?>
      <div class="profil-logo" style="width: 140px; height: 140px; margin: 10px; border-radius: 15px; background-size: contain;  background-image:url('<?php echo e(url('img-logo')); ?>/<?php echo e(Auth::user()->logo); ?>')"></div>
    <?php endif; ?>
  </div>
</div>

<!-- <?php echo e(url('img-logo')); ?>/<?php echo e(Auth::user()->logo); ?> -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/edition.blade.php ENDPATH**/ ?>