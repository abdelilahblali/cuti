

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title>Magnitude Construction : Mon Projet Bali "Administration"</title>
    <link href="<?php echo e(url('dash/css/root.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('dash/style.css')); ?>">
    <link rel="icon" href="<?php echo e(url('imgs/logo.png')); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
</head>

<body>

  

    <div id="top" class="clearfix">

        <div class="applogo" style="width: 650px !important; padding-top: 9px, color:white; font-size: 20px; padding-top: 15px">
            <span style="font-weight: bold">Mon Projet Bali</span> : Gestion des chantiers
        </div>

        <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-bars"></i></a>

        <div class="col-md-2">

        </div>

        <ul class="top-right" style="background-color: #00aeef; padding:10px 8px">
            <li class=" link">
                <a href="#" style="padding-top: 2px; padding-right: 20px; padding-left: 20px">Bienvenue <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></a>
            </li>

        </ul>

    </div>



    <div class="sidebar clearfix">

        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Clients</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('clientAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">Nouveau</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('client')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">Liste</span></a>
          </li>
        </ul>

        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Documents</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('docAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">Nouveau</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('doc')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">Liste</span></a>
          </li>
        </ul>

        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Compte</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('password')); ?>"><span class="icon color5"><i class="fa fa-unlock"></i></span>
            <span class="panel_menu">Mot de passe</span></a>
          </li>
        </ul>

        <ul class="sidebar-panel nav" style="position: fixed; bottom: 0; background-color: red; width: 195px; margin-left: 0; padding-left: 20px">
          <li>
            <a href="<?php echo e(route('logout' )); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span class="icon color5"><i class="fa fa-power-off" style="color: white"></i></span>
            <span class="panel_menu" style="color: white">Déconnexion</span></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>   
          </li>
        </ul>
    </div>



    <div class="content">
        <?php echo $__env->yieldContent('content'); ?> 
    </div>


    <script src="<?php echo e(url('dash/js/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('dash/js/datatables/datatables.min.js')); ?>"></script>
    <script> $(document).ready(function() { $('#tab').DataTable( { "order": [[ 1, "asc" ]] } ); } ); </script>

</body>

    

</html><?php /**PATH I:\Wamp\www\monprojetbali\admin\resources\views/master/admin.blade.php ENDPATH**/ ?>