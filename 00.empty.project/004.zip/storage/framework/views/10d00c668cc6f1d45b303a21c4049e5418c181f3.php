

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Gestion des catégories des produits</li>
      </ol>
     <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('categorie')); ?>" class="btn-right "><i class="fa fa-list"></i> Liste des catégories</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-6">
  <?php if(session()->has('Modification')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Modification')); ?>

  </div>
  <?php endif; ?>

  <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('categorieEdited',[ 'ref' => $cat->ref ])); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        	<div class="col-md-12">
            	<h6><label for="des" class="control-label form-label label01">Désignation <span class="c3_color">*</span></label></h6>
              <input type="text" name="des" class="form-control" placeholder="Désignation du produit" value="<?php echo e($cat->des); ?>">
        	</div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-check" style="padding-right: 10px"></i>Modifier la catégorie </button>
        </div>
      </div>
    </form>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/categorieEdit.blade.php ENDPATH**/ ?>