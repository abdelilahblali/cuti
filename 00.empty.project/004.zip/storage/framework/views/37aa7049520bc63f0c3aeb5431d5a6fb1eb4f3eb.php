<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">Gardez la forme en toutes circonstances   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="margin: 0; padding: 0">
      <div class="container" style="position: relative;">
        <div class="col-md-12" >
          <div class="container" style="position: relative; z-index: 10 !important">
            <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success consultation" style="border:0; font-weight: bold; padding: 10px 25px; position: absolute; right: 0; border-radius: 0 0 5px 5px; color:white"><span style="color: white !important">Consultation Gratuite</span></button></a>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">Faire du sport et avoir la ligne sans se priver <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous assiste.</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> met à votre disposition sa banque de coach performant avec lesquels vous pouvez vous entrainer en salle, au grand air ou à domicile. 
                            <br/><br/>
                            L’entraînement à domicile amène des résultats surprenants. Si vous n’avez pas atteint vos objectifs en salle, vous les atteindrez avec l’aide d’un coach BAYTIHELP. 
                            <br/><br/>
                            Un encadrement professionnel est <b>la clé de votre réussite</b>. Contrairement à ce que vous pouvez croire, il est tout à fait possible d’obtenir un entraînement efficace à la maison (ou n’importe où ailleurs) et ce, en ayant recours à très peu d’équipement et/ou d’espace. Un seul secret : <b>l’encouragement</b>.
                            <br/><br/>
                            Nos coachs disposent <b>d'une expérience estimable sur le terrain</b> ainsi qu'un <b>savoir-faire reconnu</b>. Ils sont recrutés selon leur domaine d'activité et en fonction de leur capacité à vous motiver, à écouter vos besoins mais aussi à transmettre leur savoir.
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> dispose de <b>coach diététiciens expérimentés et reconnus</b> en tant que <b>diététicien sportif</b>. Votre diététicien suivra votre alimentation en parallèle de vos séances sportives afin d’obtenir <b>un résultat optimal et rapide</b>.
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous fait bénéficier d’une recommandation des anciens employeurs, des références contrôlées et un suivi disponible jusqu’à chez vous après embauche de votre employé.
                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/coach1.png')); ?>" style="width: 100% !important"><br/>
                              <img src="<?php echo e(url('imgs/pages/coach2.png')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT</span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>

                          

                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE COACH </button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/coach.blade.php ENDPATH**/ ?>