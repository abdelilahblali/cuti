<?php $__env->startSection('content'); ?>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Todays’ Agenda</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <!-- <a href="#" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">Contact our team</a> -->
      <a href="<?php echo e(url('getPhotosAll')); ?>" class="btn btn-success my-2">View all pictures</a>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body">
        
        <div class="card card-xxl-stretch">
          <div class="card-header">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark">My Calendar</span>
              <span class="text-muted mt-1 fw-bold fs-7">Preview monthly events</span>
            </h3>
            <div class="card-toolbar">
            </div>
          </div>
          <div class="card-body">
            <div id="kt_calendar_widget_1"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/construction.blade.php ENDPATH**/ ?>