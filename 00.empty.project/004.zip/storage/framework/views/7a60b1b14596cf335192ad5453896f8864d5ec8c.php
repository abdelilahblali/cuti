<?php $__env->startSection('content'); ?>

    <div class="">
      <div class=" container covid" id="covid">
        <div class="close"><button style="background: transparent;; border: 0" onclick="clos();"><i class="fa fa-times"></i></button></div>
        BaytiHelp suit avec la plus grande attention l’évolution de la propagation du Coronavirus (COVID-19).
        <br/>
        Notre société a mis en place une cellule de veille et de crise ainsi que de nouveaux modes opératoires pour faire face à cette situation sans précédent.
      </div>
    </div>
      
     <!--Banner Slider-->
    <div class="clv_banner_slider" style="margin-top: 169px;">
        <!-- Swiper -->
        <div class="swiper-container">
            <div class="swiper-wrapper"  >

                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld2/sld1.png')); ?>');">
                        <div class="container" > 
                            <div class="offset-md-1 clv_slide_inner" style="text-align: center;">
                                <img src="<?php echo e(url('imgs/logo/logo.svg')); ?>" width="20%" >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld/sld01.jpg')); ?>');">
                        <div class="container" > 
                            <div class="offset-md-1 clv_slide_inner" style="text-align: center;">
                                <img src="<?php echo e(url('imgs/logo/empty.svg')); ?>" width="20%">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld2/sld3.png')); ?>');">
                        <div class="container" > 
                            <div class="offset-md-1 clv_slide_inner" style="text-align: center;">
                                <img src="<?php echo e(url('imgs/logo/empty.svg')); ?>" width="20%">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-slide" >
                    <div class="clv_slide"  style="background-image: url('<?php echo e(url('imgs/sld2/sld4.png')); ?>');">
                        <div class="container" > 
                            <div class="offset-md-1 clv_slide_inner" style="text-align: center;">
                                <img src="<?php echo e(url('imgs/logo/empty.svg')); ?>" width="20%">
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <span class="slider_arrow banner_left left_arrow">
                <svg 
                 xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink"
                 width="10px" height="20px">
                <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                 d="M0.272,10.703 L8.434,19.703 C8.792,20.095 9.372,20.095 9.731,19.703 C10.089,19.308 10.089,18.668 9.731,18.274 L2.217,9.990 L9.730,1.706 C10.089,1.310 10.089,0.672 9.730,0.277 C9.372,-0.118 8.791,-0.118 8.433,0.277 L0.271,9.274 C-0.082,9.666 -0.082,10.315 0.272,10.703 Z"/>
                </svg>
            </span>
            <span class="slider_arrow banner_right right_arrow">
                <svg 
                 xmlns="http://www.w3.org/2000/svg"
                 xmlns:xlink="http://www.w3.org/1999/xlink"
                 width="10px" height="20px">
                <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                 d="M9.728,10.703 L1.566,19.703 C1.208,20.095 0.627,20.095 0.268,19.703 C-0.090,19.308 -0.090,18.668 0.268,18.274 L7.783,9.990 L0.269,1.706 C-0.089,1.310 -0.089,0.672 0.269,0.277 C0.627,-0.118 1.209,-0.118 1.567,0.277 L9.729,9.274 C10.081,9.666 10.081,10.315 9.728,10.703 Z"/>
                </svg>
            </span>
        </div>
    </div>
   

    <div class="garden_service2_wrapper  meil-service">
      <div class="container">
          <div class="row">
            <div class="col-md-12" style="text-align: center;">
                  <h2>HAUTE QUALITÉ ET MEILLEURS SERVICES DE NETTOYAGE</h2>
                  <h4>D'UNE ENTREPRISE DE NETTOYAGE DE CONFIANCE</h4>
            </div>

            <div class="col-md-6 offset-md-3" style="text-align: center;">
                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; margin: auto;left: 0;right: 0;"></div>
                  <div class="lin-blue" ></div>
            </div>

          </div>
        </div>
      </div>


   <div class="garden_service2_wrapper clv_section">
        <div class="container">

                <div class="row">
                  <div class="col-md-4">

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-rocket " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Plus de 12 ans d’expérience </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-check" style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Vérification des références des anciens employeurs </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-cog " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>SAH : Service après Help </span>
                        </div>
                      </div>


                  </div>
                  <div class="col-md-4">

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-clock-o " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Une entreprise PIONNIÈRE </span>
                          <p>Un réseau riche et fiable étendu sur tout le royaume marocain depuis plus de 12 ans.<br/>Il est bien connu que c’est dans les vieux pots que l’on fait les meilleures confitures.</p>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-tag " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Des garanties administratives certifiées </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-sign-language " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>De solides partenaires </span>
                        </div>
                      </div>
                  </div>
                  <div class="col-md-4">

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-university " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Vérification des antécédents judiciaires </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square1" style="margin: auto;">
                             <i class="fa fa-diamond" style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle1-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>Plus que des employés de maison, une communauté de Helpers </span>
                        </div>
                      </div>

                      <div class="note">
                        <div class="row">
                          <div class="col-md-12" style="margin-top: 20px">
                            <div class="square" style="margin: auto;">
                             <i class="fa fa-lock " style="font-size: 35px; color:white; margin-top: 8px;" aria-hidden="true"></i>
                            </div>
                            <div class="triangle-down" style="margin: auto;"></div>
                           </div>
                        </div>
                        <div class="row">
                          <span>La sécurité de nos Helpers et nos clients est la première priorité de BAYTIHELP </span>
                        </div>
                      </div>

                  </div>
                </div>
           
        </div>
    </div>

    <div class=" clv_section" style="background: #00AEEF">
      <div class="container">
        <div class="counter_section">
          <div class="row">
            <div class="col-md-4">
              <img src="<?php echo e(url('imgs/logo/logo-white.svg')); ?>" style="width: 60%">
            </div>
            <div class="col-md-8 form-home" >
              <form>
                <div class="col-md-12 col-lg-12">
                  <input type="text" name="last_name" class="form-control" placeholder="Nom" style="height: 45px; background: rgba(255,255,255,0.1); color: white" >
                </div>
                <div class="col-md-12 col-lg-12" style="margin-top: 10px">
                  <input type="text" name="last_name" class="form-control" placeholder="Prénom" style="height: 45px; background: rgba(255,255,255,0.1); color: white" >
                </div>
                <div class="col-md-12 col-lg-12" style="margin-top: 10px">
                  <input type="text" name="last_name" class="form-control" placeholder="Téléphone" style="height: 45px; background: rgba(255,255,255,0.1); color: white" >
                </div>
                <div class="col-md-12 col-lg-12" style="margin-top: 10px">
                  <input type="text" name="last_name" class="form-control" placeholder="Email" style="height: 45px; background: rgba(255,255,255,0.1); color: white" >
                </div>
                <div class="col-md-12 col-lg-12" style="margin-top: 10px">
                  <button class="btn btn-success" style="background: #EC008C; float: right; border: 0">Envoyer le message</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="garden_service2_wrapper  meil-service">
        <div class="container">
            <div class="row">
              <div class="col-md-2"></div>
              <div class="col-md-8">

                    <h2 style="text-align: center;">NOS CHIFFRES PARLENT D’EUX-MÊMES</h2>
                    <h4 style="text-align: center;">Notre agence est spécialisée dans le placement du personnel de maison de différentes nationalités au Maroc et à l’Étranger.</h4>
                    <div class="lin-pink"></div>
                    <div class="lin-blue"></div>
                    <p style="color: black;text-align: center; font-size: 17px !important; font-family: 'open sans'">
                      Depuis nos débuts, nous avons priorisé la satisfaction de nos clients, en leur offrant une qualité de travail de premier ordre, d’une grande efficacité et répondant aux standards les plus élevés, le tout combiné à des économies de coûts.
                      <br/><br/>
                      Notre expérience et nos connaissances sont essentielles pour y parvenir, mais le savoir-faire, le travail sans relâche et la fiabilité de nos employés sont encore plus importants. Nous investissons donc dans la formation de notre main-d’œuvre et à sa motivation. Nous en tirons profit tout autant que nos précieux employés et clients.
                    </p>

                    <center><a href="<?php echo e(url('pourquoi')); ?>"><button class="btn btn-success" style="background: #ec008c; border:0; padding: 10px 40px">Lire Plus</button></a></center>
              </div>
            </div>
        </div>
    </div>
    <!--Service 2-->
     
    <div class="garden_service2_wrapper back-img">
            
        <div class="row">

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/01.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/09.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/03.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/04.jpg')); ?>" width="100%">
          </div>

        </div>

        <div class="row">

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/05.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/06.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/07.jpg')); ?>" width="100%">
          </div>

          <div class="col-md-3" >
            <img src="<?php echo e(url('imgs/glr/08.jpg')); ?>" width="100%">
          </div>

        </div>

    </div>
  


    <!-- <div class="dairy_about_wrapper clv_section" style="">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-8 col-md-8">
            <div class="clv_heading">
              <h3 style="color: black">Téléchargez l'application mobile</h3>
                <div class="row justify-content-center" style="padding: 50px 0">
                    <div class="col-lg-6 col-md-6">
                        <div class="text-center">
                            <div class="separ_blue"></div>
                            <div class="separ_pink"></div>
                        </div>
                    </div>
                </div>
              
            </div>
          </div>
        </div>
        <div class="dairy_about_inner">
          <div class="row">
            <div class="col-md-8">
              <div class="about_img">
                <img src="<?php echo e(url('imgs/phone.png')); ?>" alt="image" width="100%" />
              </div>
            </div>
            <div class="col-md-4">
              <div class="about_content" style="margin-top: 100px">
                <div class="about_heading">
                  <h2>A propos</h2>
                  <hr/>
                </div>
                <p>Réservez et gérez les rendez-vous, envoyez un message à votre femme de méange, affichez les profils et les notes des professionnels, voyez l'emplacement en temps réel de votre femme de ménage et bien plus encore.</p>
                
                <a target="_blank" href="https://play.google.com/store/apps/details?id=com.agency.app_2bcom"><img src="<?php echo e(url('imgs/store.png')); ?>" width="60%"></a>
                
              </div>
            </div>
          </div>
        </div>
      </div>
     </div> -->

      <!--Blog-->
   
    <!--Shop-->
    <!-- <div class="garden_shop_wrapper srvc-details">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-6">
                    <div class="text-center">
                        <h3>BLOG BaytiHelp</h3>
                        <h4>NOUS SOMMES À JOUR</h4>
                        <div class="separ_blue"></div>
                        <div class="separ_pink"></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="garden_shop_slider ">
                        <div class="swiper-container ">
                            <div class="swiper-wrapper ">
                             
                                <?php $__currentLoopData = $acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="garden_shop_slide">
                                        <div class="item_image">
                                            <a href="<?php echo e(route('actshow',[ 'ref' => $act->ref ])); ?>"><img src="<?php echo e(url('actualites')); ?>/<?php echo e($act->img); ?>" alt="image" class="img-fluid" /></a>
                                        </div>
                                        <div class="item_details">
                                            <div class="item_name">
                                                <h5><?php echo e($act->des); ?></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
     






<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/home.blade.php ENDPATH**/ ?>