

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cubes"></i> Gestion des actualités</li>
      </ol>
     <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('actualite')); ?>" class="btn-right "><i class="fa fa-list"></i> Liste des actualités</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Danger')): ?>
  <div class="alert alert-danger">
      <?php echo e(session()->get('Danger')); ?>

  </div>
  <?php endif; ?>


  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('actualiteAdded')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="des" class="control-label form-label label01">Titre de l'actualité <span class="c3_color">*</span></label></h6>
              <input type="text" name="des" class="form-control" placeholder="Titre de l'actualité">
          </div>
      </div>


      <div class="row">
          <div class="col-md-12">
              <h6><label for="img" class="control-label form-label label01">Image <span class="c3_color">*</span></label></h6>
              <input type="file" name="upload_image" id="upload_image" class="form-control" />
              <br />
              <div id="uploaded_image"></div>
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="dcr" class="control-label form-label label01">Description <span class="c3_color">*</span></label></h6>
              <textarea name="dcr" class="form-control" placeholder="Description" rows="15" id="dcr"></textarea>
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-check" style="padding-right: 10px"></i>Ajouter l'actualité </button>
        </div>
      </div>
    </form>
  </div>
</div>


<div id="uploadimageModal" class="modal" role="dialog">
  <div class="modal-dialog" style="width: 946px !important;">
    <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Recadrer la photo</h4>
          </div>
          <div class="modal-body">
            <div class="row">
            <div class="col-md-8 text-center col-md-offset-2">
              <div id="image_demo" style="width:400px; margin-top:30px"></div>
            </div>
        </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-success crop_image">Enregistrer</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          </div>
      </div>
    </div>
</div>

<script>  
$(document).ready(function(){

  $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:500,
      height:300,
      type:'square' //circle
    },
    boundary:{
      width:600,
      height:400
    }
  });

  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });

  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"<?php echo e(url('uploadimg1/upload.php')); ?>",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
        }
      });
    })
  });

});  
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\oeuf\resources\views/actualiteAdd.blade.php ENDPATH**/ ?>