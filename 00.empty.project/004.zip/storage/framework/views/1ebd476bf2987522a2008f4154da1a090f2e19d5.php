

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Qui sommes-nous ?</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>Qui sommes-nous ?</li>
                </ul>
            </div>
        </div>

        <!--About Section-->
        <style type="text/css">.fa-angle-right { color:#FEC007; padding-right: 8px  }</style>
        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img">
                            <img src="<?php echo e(url('pages/about2.jpg')); ?>" alt="image" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Présentation  <span>ANPO</span></h2>
                                <h6>Association professionnelle au service<br/>des éleveurs de poules pondeuses au Maroc</h6>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>Membre actif de la FISA<br/>
                            Membre de la CGEM<br/>
                            Date de création : 1995</p>
                            <p>
                                <b>Président : M.Abdelltif ZAIME</b><br/>
                                <ul>
                                    <li><i class="fa fa-angle-right"></i>Défendre les intérêts de la filière.</li>
                                    <li><i class="fa fa-angle-right"></i>Représenter la filière dans les situations locales, régionales, nationales et internationales.</li>
                                    <li><i class="fa fa-angle-right"></i>Améliorer les conditions techniques et sanitaires de production.</li>
                                    <li><i class="fa fa-angle-right"></i>Contribuer à l’organisation de la production et la commercialisation d’œufs.</li>
                                    <li><i class="fa fa-angle-right"></i>Promouvoir la consommation d’œufs.</li>
                                </ul>
                            </p>
                            <br/>
                            <b>Organiser et participer aux rencontres nationales et internationales traitant des thèmes en relation avec le secteur avicole.</b>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="clv_team_wrapper clv_section" style="background: url('pages/team.jpg'); background-size: cover; background-attachment: fixed;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading">
                            <h3>Conseil d’Administration</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline3.png')); ?>" alt="image" /></div>
                            <p>Un Conseil d’Administration composé de 15 membres élus<br/>par l’Assemblée Générale Ordinaire</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="team_section">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Farid IBNKHAYAT ZOUGARI</h3>
                                                <p>Président d’honneur</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">zougari@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Abdelltif ZAIME</h3>
                                                <p>Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">zaime@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Rachid BENNIS</h3>
                                                <p>1er Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">bennis@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Hassan ERREIMI</h3>
                                                <p>2ème Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">erreimi@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row" style="margin-top: 30px">

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Mohammed HAJJI</h3>
                                                <p>3ème Vice Président </p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">hajji@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Mohammed IBNKHAYAT</h3>
                                                <p>4ème Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">ibnikhayat@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Adil SENHADJI</h3>
                                                <p>5ème Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">senhadji@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Mehdi SLAOUI</h3>
                                                <p>6ème Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">slaoui@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row" style="margin-top: 30px">

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Mohamed ERREIMI</h3>
                                                <p>Secrétaire Général</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">erreimi@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Bouchta BOUSSOUF</h3>
                                                <p>Trésorier</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">boussouf@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Houcein DABRAHIM</h3>
                                                <p>Trésorier Adjoint</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">dabrahim@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/twobcom/glurivd.com/om/resources/views/about.blade.php ENDPATH**/ ?>