

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>De la poule à l’assiette</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>De la poule à l’assiette</li>
                </ul>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: -40px">
                            <img src="<?php echo e(url('pages/oeuf.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Production d’œufs <span>au Maroc</span></h2>
                                <h6>Le Maroc compte environ 500 fermes de production d’œufs</h6>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                               Le Maroc compte environ 500 fermes de production d’œufs de consommation regroupant près de 1 4 mi l l ions de poules pondeuses et produisant environ 2,5 milliards d’œufs par an.
                               <br/><br/>
                               Malgré la progression significative de la consommation moyenne d’œufs par habitant et par an durant la dernière décennie, celle-ci demeure relativement faible au Maroc à 110 œufs contre plus de 250 œufs dans les pays développés.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section" style="padding-top: -100px !important; background: rgba(0,0,0,0.04)" >
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Élevages de  <span>reproducteurs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            La filière de production des œuf s de consommation commence par l’élevage des reproducteurs qui sont les parents de nos poules pondeuses. Ces reproducteurs sont sélectionnés par des firmes internationales en fonction de critères techniques de viabilité, de production d’œufs et d’efficience alimentaire (quantité d’aliment nécessaire pour produire un œuf).
                            <br/><br/>
                            L’élevage des reproducteurs de type ponte dure environ 18 mois (72 semaines).
                            <br/><br/>
                            L’objectif est la production d’œufs fécondés appelés’ ‘œuf s à couver’ ‘. Ces œufs sont ensuite transférés au couvoir.
                            </p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 10px">
                            <img src="<?php echo e(url('pages/oeuf1.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 20px">
                            <img src="<?php echo e(url('pages/panier.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Au niveau des   <span>couvoirs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Les couvoirs sont des établissements dont l’activité consiste en l’incubation des œufs à couver pour produire des poussins. Ces couvoirs sont équipés en matériel incubateurs, éclosoirs,… permettant de créer un environnement et une ambiance favorables pour le développement embryonnaire dans les œufs.
                            <br/><br/>
                            Ces matériels reproduisent ainsi les conditions naturel les de couvaison des œufs par les volailles.
                            <br/><br/>
                            L’éclosion des œufs se produit au bout de 21jours. Le jour même de l’éclosion, les poussins sont triés, mis dans des boîtes à poussins avant d ’être transférés aux élevages des poules pondeuses.
                            </p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section" style="padding-top: -100px !important; background: rgba(0,0,0,0.04)" >
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Au niveau   <span>des élevages</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p style="text-align: justify; padding-right: 30px">
                            Avant l’arrivée des poussins à la ferme, celle-ci subit des opérations de dératisation et de désinsectisation car les poussins d’un jour sont très vulnérables aux agents pathogènes (bactéries, virus,…).
                            <br/><br/>
                            Les poulaillers et le matériel d’élevage sont nettoyés, lavés et désinfectés et une période de vide sanitaire d’au moins 3 s e m a i n e s est observée pour interrompre le cycle de développement des agent spathogènes. L’objectif est de réduire au maximum la pression microbienne dans la ferme. 
                            </p>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Alimentation   <span>des poules</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p style="text-align: justify;">
                            L’aliment destiné aux poules pondeuses est composé de matières premières et sous produits naturels énergétiques (maïs, orge, son de blé,…) et protéiques ( tourteaux de soja et de tournesol, farine de poissons,…) ainsi que de compléments d’acides aminés essentiels, minéraux et vitamines.
                            <br/><br/>
                            Tous ces ingrédients sont broyés et mélangés dans des proportions équilibrées pour satisfaire les besoins d’entretien et de production des poules aux différentes phases d’élevage et de production.
                            <br/><br/>
                            Le calcium et le phosphore sont particulièrement importants dans la formation de la coquille des œufs et conditionnent sa qualité et sa solidité.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">

                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 130px">
                            <img src="<?php echo e(url('imgs/schema.png')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>classement des    <span>oeufs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Les œufs sont collectés au moins deux fois par jour soit manuellement ou automatiquement sur de s convoyeur s pour réduire au maximum les risques de contamination.
                            <br/>
                            Les œufs cassés ou fêlés sont écartés et les autres sont triés selon leur poids en quatre catégories :
                            <br/>
                            Petit calibre (< 50 g). Moyen calibre (50 à 58 g). Gros calibre (58 à 68 g). Extra gros (> 68 g).
                            <br/>
                            Ils sont ensuite placés dans des plateaux alvéolés en cartons ou en plastiques de 6, 9, 12, 16, 24 ou 30 unités.
                            <br/>
                            Le s œufs sont stockés et entreposés dans des locaux propres en dehors des bâtiments d’élevage et à l’abri de toute source de chaleur pour conserver leur fraîcheur et leur qualité en attendant l’expédition aux points de vente.
                            <br/>
                            Plusieurs facteurs influencent le poids de l’œuf, le plus important étant l’âge de la pondeuse. Plus celle-ci est âgée, plus les œufs sont gros.
                            <br/>
                            Les œufs à doubles jaunes sont liés à des accident s de ponte qui interviennent généralement au début du cycle de production.
                            <br/>
                            Ces œufs ne sont nullement recherchés par les éleveurs car ils causent des dommages importants aux poules pondeuses.</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\oeuf\resources\views/about1.blade.php ENDPATH**/ ?>