<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">Pourquoi s’imposer de choisir alors qu’on peut avoir les Deux ?   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">La polyvalence avec des garanties administratives chez  <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b></h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">
                            Vous avez besoin <b>d’une personne polyvalente</b> ? vous avez un <b>ménage quotidien</b> à effectuer mais aussi <b>votre enfant à faire garder</b>?
                            <br/><br/>
                            Besoin d’un <b> service de ménage et de garde d’enfant</b> à court ou long terme ??    
                            <br/><br/>  
                            Où Envie de profiter tout simplement de <b>votre temps libre</b>?
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> met à votre disposition du <b>personnel qualifié, expérimenté et ceci depuis plus de 12ans.</b>
                            <br/><br/>
                            Nos <b>Noubonnes</b> sont dotée d’une expérience minimum de 5 ans, nous avons également des <b>collaborateurs diplômé(e)s de la petite enfance.</b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> vous fait bénéficier <b>d’une recommandation des anciens employeurs</b>, des <b>références contrôlées</b> et <b> un suivi</b> disponible jusqu’à chez vous après embauche de votre employé. 
                            <br/><br/>
                            Notre équipe d’Helpers sont minutieux et organisés dans leur fonction afin de vous assurer un travail qui vous apaise et vous offre une <b>sécurité amplifiée</b>.
                            <br/><br/>
                            <b><span style="color:#EC008C;">Ne réfléchissez plus</span>, <span style="color:#00AEEF ">appelez nous…</span></b>
                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/noubonnes.png')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT</span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>

                         

                          

                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE NOUBONNE EXPÉRIMENTÉE</button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/noubonnes.blade.php ENDPATH**/ ?>