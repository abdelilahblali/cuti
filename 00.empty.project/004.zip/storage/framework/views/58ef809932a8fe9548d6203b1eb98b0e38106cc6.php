<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <title>BAYTI HELP : Femmes de ménage et cuisinières à Casablanca et au Maroc  </title>

        <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"  />

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="width=device-width, initial-scale=1.0" name="viewport">

        <meta name="description" content="">

        <meta name="keywords" content="">

        <meta name="author" content="kamleshyadav">

        <meta name="MobileOptimized" content="320">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
        <link  rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"  />
        <link rel="stylesheet" href="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link  rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"  />

        <!--Start Style -->

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/swiper.min.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/magnific-popup.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/layers.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/navigation.css')); ?>">
        

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/settings.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/range.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/nice-select.css')); ?>" >

        <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/style.css')); ?>">

        <link rel="shortcut icon" type="image/png" href="<?php echo e(url('assets/images/icon.svg')); ?>">

        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">

        <link rel="stylesheet" type="text/sass" href="<?php echo e(url('assets/css/shar.sass')); ?>">
    </head>

    
    <body>
   
<div class="sreach-nav-top" id="barrsaerch">
     <div class="center-div" style="">
      <i class="fa fa-times" onclick="barserch();" style="cursor: pointer;"></i>
        <div class="col-md-8 offset-md-2">
          <div class="row">
            <input type="text" class="form-control" placeholder="RECHERCHE" >
            <button class="btn btn-searsh-nav" style=""><i class="fa fa-search searsh" aria-hidden="true"></i> </button>
          </div>
        </div>
     </div>
    
    </div>
<div class="clv_main_wrapper index_v4">
    <div class="header3_wrapper">
        <div class="clv_header3" >
            <div class="row nave-top  d-none d-xl-block "  >
              <div class="container" >
                <div class="row ">
                    <div class="col-md-4 top-adrs" >
                     <h5>8 RUE D'ARMÉNIE, RÉSIDENCE ANAS - 2 MARS -CASABLANCA</h5>   
                    </div>

                    <div class="col-md-4 icon-top" >
                        <a href="https://www.facebook.com/Bayti-Help-officiel-1708473266054530/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                        <a href="https://ma.linkedin.com/pub/bayti-help/60/400/367" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        <a href="" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                    </div>
                    <div class="col-md-4 contact-top" >
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo e(url('assets/images/phone.svg')); ?>" style="width: 20px ;float: left; margin-top: 17px;    margin-left: 8px;" >
                                <a href="tel:+212522863951"><p style="    margin-top: 7px;"> <span style="font-size: 13px; color: #00AEEF; font-weight: bold">+212  5 22 86 39 51 </span></p></a>
                                <a href="tel:+212649757540"><p style=" margin-top: -22px;margin-left: 25px;"><span style="font-size: 13px; color: #00AEEF; font-weight: bold">+212 6 49 75 75 40 </span></p></a>
                            </div>
                            <div class="col-md-6" style="border-left: 2px solid rgba(0,0,0,0.05);padding-right: 0px !important;">
                                <p><i class="fa fa-envelope-o" aria-hidden="true"></i><span style="font-size: 13px">contact@baytihelp.com</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
          <div class=" container" >
              <div class="row">
                  <div class="col-lg-1 col-md-1">
                      <div class="clv_left_header">
                          <div class="clv_logo">
                              <a href="<?php echo e(url('home')); ?>"><img src="<?php echo e(url('imgs/logo/logo.svg')); ?>" alt="Cultivation" width="106px" /></a>
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-11 col-md-11">
                      <div class="clv_right_header">
                          <div class="clv_menu">
                              <div class="clv_menu_nav">
                                  <ul>
                                      <li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
                                      <li>
                                          <a href="javascript:;">Nos prestations</a>
                                          <ul>
                                              <li><a href="#">Ménage</a></li>
                                              <li><a href="#">Cuisiniér</a></li>
                                              <li><a href="#">Baby Sitter</a></li>
                                              <li><a href="#">Chauffeur</a></li>
                                              <li><a href="#">Agent de sécurité</a></li>
                                              <li><a href="#">Formateur</a></li>
                                              <li><a href="#">Coach sportif</a></li>
                                              <li><a href="#">Grand Nettoyage</a></li>
                                              <li><a href="#">Africaines subsahariennes</a></li>
                                              <li><a href="#">Les asiatiques</a></li>
                                          </ul>
                                      </li>
                                      <li><a href="#">Prestations à l'étranger</a></li>
                                      <li><a href="#">Réclamation et suggestion</a></li>
                                      <li><a href="#">Charte</a></li>
                                      <li><a href="#">Partenaires</a></li>
                                      <li><a href="<?php echo e(url('contact')); ?>">Consultation gratuite</a></li>
                                      <li><i class="fa fa-search searsh" aria-hidden="true" onclick="barserch();" style="cursor: pointer;"></i></li>
                                  </ul>
                                  <script type="text/javascript">
                                      document.getElementById('barrsaerch').style.display="none";
                                      var etat="true";
                                      function barserch(){
                                          if ( etat=="true") {
                                            document.getElementById('barrsaerch').style.display="block";
                                            etat='false';
                                          }
                                           else if ( etat=="false") {
                                            document.getElementById('barrsaerch').style.display="none";
                                            etat="true";
                                          }
                                      };
                                  </script>
                              </div>
                              <div class="cart_nav">
                                  <ul>
                                      <li class="menu_toggle">
                                          <span>
                                              <?xml version="1.0" encoding="iso-8859-1"?>
                                              <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                   viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve" width="20px" height="20px">
                                              <g>
                                                  <g>
                                                      <path d="M2,13.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,13.5,2,13.5z"/>
                                                      <path d="M2,28.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,28.5,2,28.5z"/>
                                                      <path d="M2,43.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,43.5,2,43.5z"/>
                                                  </g>
                                              </g>
                                              </svg>
                                          </span>
                                      </li>
                                  </ul>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              
          </div>
        </div>
    </div>
       <?php echo $__env->yieldContent('content'); ?>  
    
    <!--Footer-->
    <div class="clv_footer_wrapper  footer-bayti">
        <div class="container">
            <div class=" return-haut text-center">
                <a href="#"><i class="fa fa-chevron-up" aria-hidden="true"></i> 
                <h4 style="font-size: 16px; font-weight:bold">RETOUR EN HAUT</h4></a>
            </div>
            <div class="row">
                    <div class="text-center nav-footer-menu" style="padding-left: 0px; padding-right: 0px">
                        <div class="clv_right_header">
                            <div class="clv_menu">
                                <div class="clv_menu_nav">
                                    <ul>
                                        <li><a href="<?php echo e(url('home')); ?>">Accueil</a></li>
                                        <li>
                                            <a href="javascript:;">Nos prestations</a>
                                            <ul>
                                                <li><a href="#">Ménage</a></li>
                                                <li><a href="#">Cuisiniér</a></li>
                                                <li><a href="#">Baby Sitter</a></li>
                                                <li><a href="#">Chauffeur</a></li>
                                                <li><a href="#">Agent de sécurité</a></li>
                                                <li><a href="#">Formateur</a></li>
                                                <li><a href="#">Coach sportif</a></li>
                                                <li><a href="#">Grand Nettoyage</a></li>
                                                <li><a href="#">Africaines subsahariennes</a></li>
                                                <li><a href="#">Les asiatiques</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="#">Prestations à l'étranger</a></li>
                                        <li><a href="#">Réclamation et suggestion</a></li>
                                        <li><a href="#">Charte</a></li>
                                        <li><a href="#">Partenaires</a></li>
                                        <li><a href="<?php echo e(url('contact')); ?>">Consultation gratuite</a></li>
                                    </ul>
                                </div>
                                <div class="cart_nav">
                                    <ul>
                                        <li class="menu_toggle">
                                            <span>
                                                <?xml version="1.0" encoding="iso-8859-1"?>
                                                <svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                                     viewBox="0 0 53 53" style="enable-background:new 0 0 53 53;" xml:space="preserve" width="20px" height="20px">
                                                <g>
                                                    <g>
                                                        <path d="M2,13.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,13.5,2,13.5z"/>
                                                        <path d="M2,28.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,28.5,2,28.5z"/>
                                                        <path d="M2,43.5h49c1.104,0,2-0.896,2-2s-0.896-2-2-2H2c-1.104,0-2,0.896-2,2S0.896,43.5,2,43.5z"/>
                                                    </g>
                                                </g>
                                                </svg>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <div class="row" style="margin-top: 40px">

                <div class="col-md-4 col-lg-4">
                  <div class="footer_block aprps aprps-footer">
                    <h4>A PROPOS</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <p>est une agence d’employés de maison qui propose des :
                      <br/>.
                      Femmes de ménage ÉTRANGÈRES (indonésiennes, Philippinos, Sénégalaises, Ivoiriennes, Camerounaises, Gambiennes... ) ainsi que des MAROCAINES  - 
                      Cuisinières diplômées et expérimentées - 
                      Nounou diplômées et expérimentées  - 
                      Chauffeurs FEMMES et hommes AVEC ou sans leurs propres véhicules.</p>
                      <a href="" class="btn btn-footer-aprps">Plus de détails </a>
                  </div>
                </div>

                 <div class="col-md-4 col-lg-4 ">
                  <div class="footer_block aprps ">
                    <h4>NOS SERVICES</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <div class="footer-services">
                        <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Ménage</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Cuisinière</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Baby Sitter</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Chauffeur</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Agent de sécurité</h6>
                      </div>
                      <div class="row ">
                        <img src="<?php echo e(url('assets/img/tach.svg')); ?>">
                        <h6>Formateur</h6>
                      </div>
                      </div>
                  </div>
                </div>

                 <div class="col-md-4 col-lg-4">

                  <div class="footer_block aprps footer-cntct">
                    <h4>Contactez-nous</h4>
                     <div class="separ_blue"></div>
                      <div class="separ_pink"></div>
                      <h6>Adresse</h6>
                      <p>8 RUE D’ARMÉNIE, RÉSIDENCE ANAS - 2 MARS  - CASABLANCA</p>
                      <h6>Téléphone</h6>
                      <p>+212 5 22 86 39 51 | +212 6 49 75 75 40</p>
                      <h6>Email</h6>
                      <p>contact@baytihelp.com</p>
                  </div>

                </div>

            </div>
            </div>
        </div>
    </div>

    <div class="clv_copyright_wrapper">
      <div class="container">
        <p> &copy;  <a href="javascript:;">2BCOM .</a> 2020</p>
      </div>
    </div>
    
    <a href="tel:+212 5 22 86 39 51">
      <div class="telephone animate__animated animate__jello animate__bounce animate__infinite">
        <i class="fa fa-phone"></i>
      </div>
    </a>

    <div style=" position: fixed;bottom: 10px; right: 30px;z-index: 100">
      
      <div class="chat" style="" id="chat">
        <div class="info-chat">

            <div class="col-md-10 " >

                <div class="row">

                  <img src="<?php echo e(url('imgs/logo/logo.svg')); ?>" width="18%">
                  <h1 > TCHAT BAYTI</h1>

                </div>

                <div class="row">

                  <p >Pour toute question, échangez directement avec notre équipe de concierges.</p>

                </div>

            </div>

        </div>

        <div class="dsecu" >
        

          <div class="col-md-12" style="" >

            <div class="message1"  >IBOURK Redouane</div>
            <div class="msg2" >message <span style="">11:00</span></div>
         
          </div>
            <div class="col-md-12" style="" >

            <div class="message1"  >IBOURK Redouane</div>
            <div class="msg2" >message <span style="">11:00</span></div>
         
          </div>
             
          
        </div>

         <div class="row">
              <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Tapez votre message ">
              <button class="btn btn-chat">ENVOYER</button>
         </div>

       </div>

        <div class="row info_chat_text" style=""> 

            <div class="col-md-8">
                  <h6>Pour toute question, échangez directement avec notre équipe de concierges.</h6>
            </div> 

        </div>

      <div class="closeed"  id="closed" onclick="chatt();">
        <img src="<?php echo e(url('imgs/logo/logo-white.svg')); ?>" id="imglogo">
        <i class="fa fa-times "  id="iconclose" style="cursor: pointer;"></i>
      </div>


      <script type="text/javascript">
        var cosed =document.getElementById('closed');
        var imglogo =document.getElementById('imglogo');
        var iconclose =document.getElementById('iconclose');
        var chat  =document.getElementById('chat');

        chat.style.display='none';
        iconclose.style.display='none';

        var eta='true';

       function  chatt(){

         if (eta=='true') {

          imglogo.style.display='block';
          iconclose.style.display='none';
          chat.style.display='none';

          eta='false';

        }
        else if (eta=='false') {
          imglogo.style.display='none';
          iconclose.style.display='block';
          chat.style.display='block';
          eta='true';

        }
       }

      </script>

    </div>

    
  

    <div class="" style="position: fixed; background-color: black;right: 0; top:50%;z-index: 1000">
      <input type="checkbox" id="click">
      <label for="click" class="share-btn">
        <span class="fa fa-share-alt"></span>
        <a href="#"><span class="fa fa-whatsapp"></span></a>
        <a href="#"><span class="fa fa-instagram"></span></a>
        <a href="#"><span class="fa fa-facebook"></span></a>
        <a href="#"><span class="fa fa-linkedin"></span></a>
      </label>
    </div>
    </div>


   

</div>


       


    <script src="<?php echo e(url('assets/js/jquery.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/swiper.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/magnific-popup.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.themepunch.tools.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.themepunch.revolution.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.appear.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/jquery.countTo.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/isotope.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/nice-select.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/range.js')); ?>"></script>



    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    

    <script src="<?php echo e(url('assets/js/revolution.extension.actions.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.kenburn.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.layeranimation.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.migration.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.parallax.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.slideanims.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/revolution.extension.video.min.js')); ?>"></script>

    <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>

    </body>





</html>

<?php /**PATH C:\wamp64\www\baytihelp\resources\views/master/page.blade.php ENDPATH**/ ?>