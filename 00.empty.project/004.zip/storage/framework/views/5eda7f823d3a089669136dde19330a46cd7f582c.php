

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Biologie autour de l’oeuf</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>Biologie autour de l’oeuf</li>
                </ul>
            </div>
        </div>

        <style type="text/css">.fa-angle-right { color:#FEC007; padding-right: 8px  }</style>
        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: 140px">
                            <img src="<?php echo e(url('imgs/eggs.jpg')); ?>" alt="image" width="90%" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Biologie autour de   <span>l’oeuf</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            <b>Composition de l’œuf</b>
                            <ul>
                            <li><i class="fa fa-angle-right"></i> Poids moyen de 60 g</li>
                            <li><i class="fa fa-angle-right"></i> Le jaune constitue environ 30% du poids de l’œuf,</li>
                            <li><i class="fa fa-angle-right"></i> Le blanc 60% et la coquille 10%.</li>
                            <li><i class="fa fa-angle-right"></i> Le jaune se compose d’environ 50 % d’eau</li>
                            <li><i class="fa fa-angle-right"></i> Le blanc est constitue très majoritairement d’eau (90% environ ), mais aussi de glycoprotéines(ovalbumine essentiellement), de sucres (glucose) et de sels minéraux. Les lipides y sont uniquement a l ’état de traces, de même que les vitamines.</li>
                            <li><i class="fa fa-angle-right"></i> La coquille contient 99% de matière sèche dont 95% de sels minéraux et 4% de protéines.</li>
                            <li><i class="fa fa-angle-right"></i> Pour un oeuf type 60 g Jaune, 1/3 = 18 g de vitellus, . H2O</li>
                            <li><i class="fa fa-angle-right"></i> Protéines 30, lipides 70</li>
                            <li><i class="fa fa-angle-right"></i> Blanc, 2/3 = 36 g d’albumen, 9/10 H2O</li>
                            <li><i class="fa fa-angle-right"></i> Composition moyenne du jaune (% Mat. Sèche)</li>
                            <li><i class="fa fa-angle-right"></i> Proteines: 30% du jaune (les 2/3 sous forme de lipoproteines)</li>
                            <li><i class="fa fa-angle-right"></i> Lipides: 69% du jaune</li>
                            <li><i class="fa fa-angle-right"></i> Triglycerides : 46%</li>
                            <li><i class="fa fa-angle-right"></i> Phopholipides : 20% (lecithine, cephaline)</li>
                            <li><i class="fa fa-angle-right"></i> Sterols: 3%</li>
                            <li><i class="fa fa-angle-right"></i> Mineraux (surtout du phosphore et du fer), vitamines (surtout A, D, E, certaines B, mais aussi K, PP), pigments (carotenes et xanthophylles): 1%f</li>
                            </ul>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/twobcom/glurivd.com/om/resources/views/about3.blade.php ENDPATH**/ ?>