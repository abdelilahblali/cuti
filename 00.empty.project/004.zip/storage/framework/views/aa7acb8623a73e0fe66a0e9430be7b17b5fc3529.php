<?php $__env->startSection('content'); ?>





    <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('imgs/sld/sld03.jpg')); ?>');margin-top: 169px;">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-md-4">

                    <div class="breadcrumb_inner">

                        <h3>Consultation gratuite</h3>

                    </div>

                </div>

            </div>

        </div>

        <div class="breadcrumb_block">

            <ul>

                <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>

                <li>Consultation gratuite</li>

            </ul>

        </div>

    </div>

    <!--Contact Block-->

    <div class="contact_blocks_wrapper clv_section">

        <div class="container">

            <div class="row">

                <div class="col-lg-4 col-md-4">

                    <div class="contact_block">

                        <span></span>

                        <div class="contact_icon"><img src="<?php echo e(url('assets/images/contact_icon1.png')); ?>" alt="image" /></div>

                        <h4>Appelez-nous</h4>

                        <p>( +212 ) 5 22 86 39 51</p>

                        <p>( +212 ) 6 49 75 75 40</p>

                    </div>

                </div>

                <div class="col-lg-4 col-md-4">

                    <div class="contact_block">

                        <span></span>

                        <div class="contact_icon"><img src="<?php echo e(url('assets/images/contact_icon2.png')); ?>" alt="image" /></div>

                        <h4>email</h4>

                        <p>contact@baytihelp.com</p>

                    </div>

                </div>

                <div class="col-lg-4 col-md-4">

                    <div class="contact_block">

                        <span></span>

                        <div class="contact_icon"><img src="<?php echo e(url('assets/images/contact_icon3.png')); ?>" alt="image" /></div>

                        <h4>Adresse</h4>

                        <p>8 RUE D'ARMÉNIE, RÉSIDENCE ANAS - 2 MARS </p>

                        <p>-CASABLANCA, Maroc</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!--Contact Form-->

    <div class="contact_form_wrapper clv_section">

        <div class="container">

            <div class="row">

                <div class="col-lg-8 col-md-8">

                    <div class="contact_form_section">

                        <div class="row">

                            <div class="col-md-12 col-lg-12">

                                <h3>Contactez-nous</h3>

                            </div>

                            <form method="POST" action="<?php echo e(route('consuladd')); ?>">
                                <?php echo e(csrf_field()); ?>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="first_name" class="form_field require" placeholder="Prénom" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="last_name" class="form_field require" placeholder="Nom" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="email" class="form_field require" placeholder="Email" data-valid="email" data-error="Email should be valid." >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="tel" class="form_field require" placeholder="Téléphone" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="adr" class="form_field require" placeholder="Quartier / zone géographique / ville" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <select name="bayti" class="form_field require" >
                                        <option>A</option>
                                        <option>B</option>
                                        <option>C</option>
                                    </select>

                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">

                                    <textarea placeholder="Message" name="message" class="form_field require" ></textarea>

                                    <div class="response"></div>

                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">

                                    <button type="submit" class="clv_btn submitForm" data-type="contact">Envoyer le message</button>

                                </div>

                            </div>

                            </form>

                        </div>

                    </div>

                </div>

                <div class="col-lg-4 col-md-4">

                    <div class="working_time_section">

                        <div class="timetable_block">

                            <h5>Horaires d'ouverture</h5>

                            <ul>

                                <li>

                                    <p>Lundi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Mardi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Mercredi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>jeudi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Vendredi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Samedi</p>

                                    <p>9:00 - 13:00 </p>

                                </li>

                                <li>

                                    <p>Dimanche</p>

                                    <p>Fermé</p>

                                </li>

                            </ul>

                        </div>

                        <div class="tollfree_block">

                            <h5 style="color: #032C58 !important;">Contactez-nous </h5>

                            <h3 style="color: #032C58 !important;">( +212 ) 5 22 86 39 51</h3>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div> 







<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\baytihelp\resources\views/contact.blade.php ENDPATH**/ ?>