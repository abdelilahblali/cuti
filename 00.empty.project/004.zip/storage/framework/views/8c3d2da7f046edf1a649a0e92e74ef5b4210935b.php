

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-paint-brush"></i> Liste des documents</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <div class="row">
    <?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3" style="margin-bottom: 30px">
      <a href="http://localhost/monprojetbali/media/doc/<?php echo e($doc->doc); ?>" target="_blank" >
        <img src="<?php echo e(url('imgs/pdf.png')); ?>" style="width: 100%;" class="img-thumbnail">
        <br/>
        <h6 style="background: rgba(0,0,0,0.1) ; border-radius: 6px; width: 100%; padding: 5px 20px; text-align: center;"><?php echo e($doc->des); ?></h6>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>    


<script type="text/javascript" src="<?php echo e(url('highslide/highslide-with-gallery.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('highslide/highslide.css')); ?>" />
<script type="text/javascript">



  hs.graphicsDir = 'highslide/graphics/';

  hs.align = 'center';

  hs.transitions = ['expand', 'crossfade'];

  hs.wrapperClassName = 'dark borderless floating-caption';

  hs.fadeInOut = true;

  hs.dimmingOpacity = .75;



  // Add the controlbar

  if (hs.addSlideshow) hs.addSlideshow({

    //slideshowGroup: 'group1',

    interval: 5000,

    repeat: false,

    useControls: true,

    fixedControls: 'fit',

    overlayOptions: {

      opacity: .6,

      position: 'bottom center',

      hideOnMouseOut: true

    }

  });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\monprojetbali\client\resources\views/docs.blade.php ENDPATH**/ ?>