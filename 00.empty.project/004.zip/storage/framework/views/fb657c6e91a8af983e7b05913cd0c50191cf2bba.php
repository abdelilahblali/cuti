<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="garden_service2_wrapper  meil-service" style="margin-bottom: 50px; margin-top: 150px">
    <div class="container">
        <div class="row">

          <div class="col-md-8">

            <div class="col-md-12">
                  <h2><?php echo e($act->des); ?></h2>
                  <div class="lin-pink"></div>
                  <div class="lin-blue"></div>
            </div>

            <div class="col-md-12" style="margin-top: 20px">
              <img src="<?php echo e(url('actualites')); ?>/<?php echo e($act->img); ?>" style="width: 100% !important" />
            </div>

            <div class="col-md-12" style="margin-top: 0px">
              <?php echo $act->dcr; ?>

            </div>

          </div>

          <div class="col-md-4">
            <div class="col-md-12">
              <h2>Autres Actualités</h2>
              <div class="lin-pink"></div>
              <div class="lin-blue"></div>
            </div>
            <br/>
            <?php $__currentLoopData = $allacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12" style="margin-bottom: 30px">
              <a href="<?php echo e(route('actshow',[ 'ref' => $act->ref ])); ?>"><img src="<?php echo e(url('actualites')); ?>/<?php echo e($act->img); ?>" style="width: 100% !important" /></a>
              <span style="position: absolute; font-weight: bold; color:black; text-align: center; bottom: 0"><?php echo e($act->des); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>


        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/actshow.blade.php ENDPATH**/ ?>