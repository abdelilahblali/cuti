<?php $__env->startSection('content'); ?>

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Architecture / Design / D3 </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   <?php if(session()->has('yes')): ?>
   <div class="col-md-12">
    <div class="alert alert-success">
      <?php echo e(session()->get('yes')); ?>

    </div>
  </div>
  <?php endif; ?>

  <?php if(session()->has('no')): ?>
  <div class="col-md-12">
    <div class="alert alert-success">
      <?php echo e(session()->get('no')); ?>

    </div>
  </div>
  <?php endif; ?>
</div>
</div>

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">

      <div class="col-xxl-7">  
        <div class="card card-page">
          <div class="card-body">
            <div class="card card-xxl-stretch">
              <form name="pointform<?php echo e($img->ref); ?>" method="POST" action="<?php echo e(route('designAddCmt')); ?>">
                <?php echo e(csrf_field()); ?>

                <div style="position: relative;">
                  <div id="tagged<?php echo e($img->ref); ?>" class="tag">
                    <span id="span-id<?php echo e($img->ref); ?>">0</span>
                  </div>
                  <img src="http://localhost/monProjetBali/media/d/<?php echo e($img->url); ?>" width="600px" id="pointer_div<?php echo e($img->ref); ?>" onclick="clickcoord<?php echo e($img->ref); ?>(event)">
                  <div class="col-md-12">
                    <div id="cloth<?php echo e($img->ref); ?>" style="visibility:hidden;">
                      <hr>
                      <textarea rows="2" placeholder="Add your comment here" id="cmt" name="cmt" class="form-control" style="width: 600px !important;"></textarea>
                      <input type="hidden" id="x" name="x"/>
                      <input type="hidden" id="y" name="y"/>
                      <input type="hidden" id="img" name="img" value="<?php echo e($img->ref); ?>" />
                      <button class="btn btn-success" style="margin-top: 10px"><i class="fa fa-plus"></i> Add</button>
                    </div>
                  </div>
                </div>
                <div></div>
              </form>

              <?php $__currentLoopData = $cmt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($c->img==$img->ref): ?>
              <div id="tagged<?php echo e($img->ref); ?>" title="<?php echo e($c->cmt); ?>" class="tag tag<?php echo e($img->ref); ?>" style="left: <?php echo e(($c->x)-13); ?>px; top: <?php echo e(($c->y)-13); ?>px; visibility: visible; background: red">
                <a href="#"><span id="span-id<?php echo e($img->ref); ?>"></span></a>
              </div>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

            </div>
          </div>
        </div>
      </div>

      <div class="col-xxl-5">  
        <div class="card card-page">
          <div class="card-body">
            <div class="card card-xxl-stretch">
              
              <div class="bg-body" >
                <div class="card shadow-none rounded-0">
                  <div class="card-header" id="kt_activities_header">
                    <h3 class="card-title fw-bolder text-dark">Comments</h3>
                  </div>

                  <div class="card-body position-relative" id="kt_activities_body">
                    <div id="kt_activities_scroll" class="position-relative scroll-y me-n5 pe-5" data-kt-scroll="true" data-kt-scroll-height="auto" data-kt-scroll-wrappers="#kt_activities_body" data-kt-scroll-dependencies="#kt_activities_header, #kt_activities_footer" data-kt-scroll-offset="5px" >
                      <div class="timeline">

                        <?php $__currentLoopData = $cmt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($c->img==$img->ref): ?>
                        <div class="timeline-item">
                          <div class="timeline-line w-40px"></div>
                          <div class="timeline-icon symbol symbol-circle symbol-40px me-4">
                            <div class="symbol-label bg-light">
                              <span class="svg-icon svg-icon-2 svg-icon-gray-500" onclick="document.getElementById('tagged89200352161221125035').style.background='green'; ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                  <path opacity="0.3" d="M2 4V16C2 16.6 2.4 17 3 17H13L16.6 20.6C17.1 21.1 18 20.8 18 20V17H21C21.6 17 22 16.6 22 16V4C22 3.4 21.6 3 21 3H3C2.4 3 2 3.4 2 4Z" fill="black" />
                                  <path d="M18 9H6C5.4 9 5 8.6 5 8C5 7.4 5.4 7 6 7H18C18.6 7 19 7.4 19 8C19 8.6 18.6 9 18 9ZM16 12C16 11.4 15.6 11 15 11H6C5.4 11 5 11.4 5 12C5 12.6 5.4 13 6 13H15C15.6 13 16 12.6 16 12Z" fill="black" />
                                </svg>
                              </span>
                            </div>
                          </div>
                          <div class="timeline-content mb-10 mt-n1">
                            <div class="pe-3 mb-5">
                              <div class="fs-5 fw-bold mb-2" style="text-align: justify;"><?php echo e($c->cmt); ?></div>
                              <div class="d-flex align-items-center mt-1 fs-6">
                                <div class="text-muted me-2 fs-7">
                                    <?php echo e($c->fait); ?>

                                    <a style="margin-left: 20px" title="Delete comment" href="<?php echo e(url('designDeleteCmt', [ 'cmt'=> $c->ref ])); ?>" onclick="return confirm('Are you sure you want to delete this comment?'); event.preventDefault(); document.getElementById('designDeleteCmt').submit();"><i style="color:red" class="fa fa-times a-icon"></i></a>
                                    <form id="designDeleteCmt" action="<?php echo e(url('designDeleteCmt', [ 'cmt'=> $c->ref ])); ?>" method="POST">
                                      <?php echo e(method_field('DELETE')); ?>

                                      <?php echo csrf_field(); ?>
                                    </form>  
                                </div>
                                <div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Nina Nilson">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script type="text/javascript">
        function clickcoord<?php echo e($img->ref); ?>(event){
          var i = parseInt(document.getElementById("span-id<?php echo e($img->ref); ?>").innerHTML);

          var image = document.getElementById("pointer_div<?php echo e($img->ref); ?>");
          var tag = document.getElementById("tagged<?php echo e($img->ref); ?>");
          var clothes = document.getElementById("cloth<?php echo e($img->ref); ?>");

          var pos_x = event.offsetX?(event.offsetX):event.pageX-image.offsetLeft;
          var pos_y = event.offsetY?(event.offsetY):event.pageY-image.offsetTop;

          tag.style.left = (pos_x-13).toString() + 'px';
          tag.style.top = (pos_y-13).toString() + 'px';
          tag.style.visibility = "visible";

          clothes.style.visibility = "visible";

          document.getElementById("span-id<?php echo e($img->ref); ?>").innerHTML = "";

          document.pointform<?php echo e($img->ref); ?>.x.value = pos_x;
          document.pointform<?php echo e($img->ref); ?>.y.value = pos_y;

        }
      </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      

      <?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/design3.blade.php ENDPATH**/ ?>