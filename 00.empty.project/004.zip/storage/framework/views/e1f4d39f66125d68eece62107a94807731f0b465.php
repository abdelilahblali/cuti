

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-bank"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('bank')); ?>" class="btn-right "><i class="fa fa-list"></i> List of banks </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('bankEdited',[ 'ref' => $item->ref ])); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="ptpmaname" class="control-label form-label label01">PTPMA NAME  </label></h6>
              <input type="text" name="ptpmaname" id="ptpmaname" class="form-control" disabled style="font-weight: bold" value="<?php echo e($item->ptpmaname); ?>"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="bankname" class="control-label form-label label01">Bank Name  </label></h6>
              <input type="text" name="bankname" id="bankname" class="form-control" value="<?php echo e($item->bankname); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="banknumber" class="control-label form-label label01">Bank Number  </label></h6>
              <input type="text" name="banknumber" id="banknumber" class="form-control" value="<?php echo e($item->banknumber); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="bank" class="control-label form-label label01">Bank  </label></h6>
              <input type="text" name="bank" id="bank" class="form-control" value="<?php echo e($item->bank); ?>" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/bankEdit.blade.php ENDPATH**/ ?>