<!DOCTYPE html>
<html>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <title><?php echo e($landing); ?></title>
    <title><?php echo e($u->head); ?></title>
    <link href="<?php echo e(url('imgs/icon.png')); ?>" rel="icon">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('style.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/fonts/font-awesome.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section>
        <div class="container">

            <?php if($item->typ=='title'): ?>
            <div class="row" style="margin-top: 30px">
                <div class="col-md-12">
                    <?php echo $item->txt; ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if($item->typ=='text'): ?>
            <div class="row" style="margin-top: 30px">
                <div class="col-md-12">
                    <?php echo $item->txt; ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if($item->typ=='image'): ?>
            <div class="row" style="margin-top: 30px">
                <div class="col-md-4 col-md-offset-4">
                    <center><img src="<?php echo e($item->txt); ?>" style="width: 100%"></center>
                </div>
            </div>
            <?php endif; ?>

            <?php if($item->typ=='video'): ?>
            <div class="row" style="margin-top: 30px">
                <div class="col-md-12">
                    <iframe width="100%" height="315" src="https://www.youtube.com/embed/<?php echo e($item->txt); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            <?php endif; ?>

            <?php if($item->typ=='form'): ?>
            <div class="row" style="margin-top: 30px">
                <div class="col-md-12">
                <h6 style="font-family: 'Changa'; font-weight: bold; font-size: 26px; margin-top: 30px; color: black; margin-bottom: 30px; text-align: center; ">للطلب المرجو ملئ الإستمارة التالية</h6>

                <form method="POST" class="form1 mystore-form" action="<?php echo e(route('mystoreCmdAddLP',[ 'mystore' => $u->store, 'landing' => $landing ])); ?>">
                <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="proref" value="<?php echo e($proref); ?>">
                    <input type="hidden" name="pro" value="<?php echo e($pro); ?>">

                    <input type="hidden" name="ref" value="43350933">
                    <div class="form-group">
                        <input type="text" class="form-control" name="nom" placeholder="Nom : الاسم الكامل">
                    </div>
                    <div class="form-group">
                        <input data-inputmask="'mask': '9999999999'" type="text" class="form-control" name="tel" placeholder="Téléphone : رقم الهاتف">
                    </div>
                    <div class="form-group">
                        <select class="form-control" name="vil">
                            <option>Ville : المدينة</option>
                            <option>Agadir</option>
                            <option>Aguelmouss</option>
                            <option>Ahfir</option>
                            <option>ain aouda</option>
                            <option>Ain Attig</option>
                            <option>Ait meloul</option>
                            <option>Al Hoceima</option>
                            <option>Anza</option>
                            <option>Aourir</option>
                            <option>Arfoud</option>
                            <option>Assilah</option>
                            <option>Azemmour</option>
                            <option>Azilal</option>
                            <option>Azrou</option>
                            <option>Azrou agadir</option>
                            <option>Ben Ahmed</option>
                            <option>Ben guerir</option>
                            <option>Benguerir base militaire</option>
                            <option>Beni Mellal</option>
                            <option>Benslimane</option>
                            <option>Berkane</option>
                            <option>Berrchid</option>
                            <option>Biougra</option>
                            <option>Boufakrane</option>
                            <option>Boujad</option>
                            <option>Boujdour</option>
                            <option>Boumalne Dadès</option>
                            <option>Bouskoura</option>
                            <option>Bouznika</option>
                            <option>Casablanca</option>
                            <option>Chefchaouen</option>
                            <option>Dakhla</option>
                            <option>Dar bouaza</option>
                            <option>Demnate</option>
                            <option>Deroua oulad ziane</option>
                            <option>El Attaouia</option>
                            <option>El Gara</option>
                            <option>El Hajeb</option>
                            <option>El jadida</option>
                            <option>El kelaa des sraghna</option>
                            <option>Errachidia</option>
                            <option>Errahma</option>
                            <option>Essaouira</option>
                            <option>Essmara</option>
                            <option>Fes</option>
                            <option>Fnideq</option>
                            <option>Fquih ben salah</option>
                            <option>Guelmim</option>
                            <option>Guercif</option>
                            <option>Had Soualem</option>
                            <option>ifran</option>
                            <option>Inzegane</option>
                            <option>Jamaat shaim</option>
                            <option>Kasba tadla</option>
                            <option>Kasbat lmzar</option>
                            <option>Kelaat M'Gouna</option>
                            <option>Kenitra</option>
                            <option>Khemis des zemamra</option>
                            <option>Khemisset</option>
                            <option>khenifra</option>
                            <option>Khouribga</option>
                            <option>Ksar El Kebir</option>
                            <option>Laayayda</option>
                            <option>Laayoune</option>
                            <option>Larache</option>
                            <option>M diq</option>
                            <option>Marrakech</option>
                            <option>Martil</option>
                            <option>Mediouna</option>
                            <option>Meknes</option>
                            <option>Merzouga</option>
                            <option>Midelt</option>
                            <option>Mohammedia</option>
                            <option>Moulay Abellah Amghar</option>
                            <option>Mrirt</option>
                            <option>Nador</option>
                            <option>Nouaceur</option>
                            <option>Ouarzazat</option>
                            <option>ouazzane</option>
                            <option>Oued zem</option>
                            <option>Oujda</option>
                            <option>Oulad teima</option>
                            <option>Oulad Yaich</option>
                            <option>Quliaa</option>
                            <option>Rabat</option>
                            <option>Rissani</option>
                            <option>safi</option>
                            <option>Saidia</option>
                            <option>Sale</option>
                            <option>Sale el jadida</option>
                            <option>Sebt el guerdane</option>
                            <option>Sebt Ouled Nemma</option>
                            <option>Sefrou</option>
                            <option>Settat</option>
                            <option>Sidi bennour</option>
                            <option>Sidi Bibi</option>
                            <option>Sidi Bouknadel</option>
                            <option>Sidi bouzid</option>
                            <option>Sidi Hajjaj</option>
                            <option>Sidi Ifni</option>
                            <option>Sidi kacem</option>
                            <option>Sidi sliman</option>
                            <option>Skhirat</option>
                            <option>Sidi Yahya du Rharb</option>
                            <option>Skhirat</option>
                            <option>Souk el arbaa du gharb</option>
                            <option>Taddart</option>
                            <option>Tagadirt</option>
                            <option>Tamait Izder</option>
                            <option>Tamansourt</option>
                            <option>Tamelelt</option>
                            <option>Tamesna</option>
                            <option>Tamraght</option>
                            <option>Tan Tan</option>
                            <option>Tanant</option>
                            <option>Tanger</option>
                            <option>Taounate</option>
                            <option>Taourirt</option>
                            <option>Tar</option>
                            <option>Tarfaaya</option>
                            <option>Taroudannt</option>
                            <option>Taza</option>
                            <option>Temara</option>
                            <option>Tetouan</option>
                            <option>Tiflet</option>
                            <option>Tinghir</option>
                            <option>Tit mellil</option>
                            <option>Tiznit</option>
                            <option>Youssoufia</option>
                            <option>Zagora</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="adr" placeholder="Adresse : العنوان">
                    </div>
                    <div class="form-group">
                        <select class="form-control" name="qte">
                            <option value="1">1</option>
                            <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->pri2!=0): ?><option value="2">2</option><?php endif; ?>
                            <?php if($p->pri3!=0): ?><option value="3">3</option><?php endif; ?>
                            <?php if($p->pri4!=0): ?><option value="4">4</option><?php endif; ?>
                            <?php if($p->pri5!=0): ?><option value="5">5</option><?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-block btn-success mystore-commander" style="background: <?php echo e($u->color3); ?>; border-color: <?php echo e($u->color3); ?>">اطلب الآن و التوصيل بالمجـــان</button>
                </form>
                </div>
            </div>
            <?php endif; ?>


            <?php if($item->typ=='prix'): ?>
                <h6 style="font-family: 'Changa'; font-weight: bold; font-size: 30px; color: black; margin-bottom: 30px; margin-top: 30px; text-align: center; ">الأثمنة </h6>
              <div class="panel panel-default">
                <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table width="100%" class="table table-striped">
                  <tr>
                    <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">1 Pack</h4></td>
                    <td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri1, 2)); ?> MAD</h4></td>
                    <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; ">باقة واحدة</h4></td>
                  </tr>
                  <?php if($prod->pri2!=0): ?>
                  <tr>
                    <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">2 Packs</h4></td>
                    <td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri2, 2)); ?> MAD</h4></td>
                    <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">باقتين</h4></td>
                  </tr>
                  <?php endif; ?>
                  <?php if($prod->pri3!=0): ?>
                  <tr>
                    <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">3 Packs</h4></td>
                    <td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri3, 2)); ?> MAD</h4></td>
                    <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">ثلاث باقات</h4></td>
                  </tr>
                  <?php endif; ?>
                  <?php if($prod->pri4!=0): ?>
                  <tr>
                    <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">4 Packs</h4></td>
                    <td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri4, 2)); ?> MAD</h4></td>
                    <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">أربع باقات</h4></td>
                  </tr>
                  <?php endif; ?>
                  <?php if($prod->pri5!=0): ?>
                  <tr>
                    <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">5 Packs</h4></td>
                    <td align="center"><h4 class="myresto-h4" style="color: <?php echo e($u->color4); ?>"><?php echo e(number_format($prod->pri5, 2)); ?> MAD</h4></td>
                    <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">خمس باقات</h4></td>
                  </tr>
                  <?php endif; ?>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

        </div>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <div class="row" style="min-height: 100px">
            <div class="col-md-12" style="text-align: center; margin-top: 50px">
                <a href="" target="_blank" style="font-size: 16px; font-family:'Changa'; font-weight: bold; color: black; text-decoration: none; ">سياسة المتجر</a>
            </div>
        </div>


    </div>
</body>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html>

<?php /**PATH I:\Wamp\www\ecombladi\resources\views/mystoreLanding.blade.php ENDPATH**/ ?>