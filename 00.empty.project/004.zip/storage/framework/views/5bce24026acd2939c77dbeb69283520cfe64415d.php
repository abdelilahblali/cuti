<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">ICI ON PREND SOIN DE NOS EMPLOYÉS POUR QU’ILS PRENNENT SOIN DE NOS CLIENTS </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">Voici ce qui fait la force de la communauté  <span style="color:#EC008C; padding-left: 5px">BAYTI</span><span style="color:#00AEEF ">HELP</span></h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nous sommes avant tout une société humaine, passionnée par le sens du service et la qualité de prestation sur mesure.
                            <br/>
                            Pour y parvenir, <b><span style="color:#EC008C; padding-left: 5px; font-weight: bold">Bayti</span><span style="color:#00AEEF ">Help</span></b> s’est entourée d’une équipe de <b><span style="color:#EC008C; padding-left: 5px">Hel</span><span style="color:#00AEEF ">pers</span></b> professionnels dévouée aux mêmes valeurs. 
                            <br/>
                            Nous avons trié pour vous une <b>Team</b> de <b><span style="color:#EC008C; padding-left: 5px">Hel</span><span style="color:#00AEEF ">pers</span></b> reconnue par <b>sa grande rigueur, sa pro activité, et son respect de nos standards élevés</b> lui permettant de dépasser les exigences du marché.
                            <br/>
                            Grâce à notre équipe <b>UNIQUE</b> nous pouvons offrir un <b>service de premier</b> niveau, mais également <b>d’importantes économies</b> à nos clients, ce qui nous permet d’être <b>des plus compétitifs</b>.
                            <br/><br/>
                            <b>La satisfaction</b> de nos clients est au cœur des principales priorités de notre équipe.
                            <br/>
                            Nos clients font <b>confiance</b> aux <b><span style="color:#EC008C; padding-left: 5px">Hel</span><span style="color:#00AEEF ">pers</span></b> de <b><span style="color:#EC008C; padding-left: 5px">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> puisqu’ils leur ont maintes fois prouvé qu’ils savaient répondre à leurs demandes avec les <b>solutions les plus efficaces et efficientes</b>.
                            <br/>
                            <b>La force</b> de nos <b><span style="color:#EC008C; padding-left: 5px">Hel</span><span style="color:#00AEEF ">pers</span></b> est de comprendre la réalité et la complexité du travail à domicile, tant du point de vue du client que de celui <b>des employés de maison</b>.
                            </div>
                          </div>

                          

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/equipe.blade.php ENDPATH**/ ?>