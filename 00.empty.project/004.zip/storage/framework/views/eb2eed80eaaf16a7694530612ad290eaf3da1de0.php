<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row justify-content-center page">
        <div class="col-md-12" style="border:1px solid rgba(0,0,0,0.1); padding: 30px; border-radius: 10px; margin-top: 40px">
            <div class="card">
                <div class="card-header" style="font-weight: bold; font-size: 16px">Vérifier votre adresse email</div>

                <div class="card-body" style="margin-top: 30px">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            Avant de continuer, veuillez vérifier votre e-mail pour un lien de vérification. Si vous n'avez pas reçu l'e-mail,
                        </div>
                    <?php endif; ?>

                    Avant de continuer, veuillez vérifier votre e-mail pour un lien de vérification.
                    <br/><br/>
                    
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-default" style="background:#EF4136; color:white; ">Si vous n'avez pas reçu l'e-mail cliquez ici pour en demander un autre</button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/auth/verify.blade.php ENDPATH**/ ?>