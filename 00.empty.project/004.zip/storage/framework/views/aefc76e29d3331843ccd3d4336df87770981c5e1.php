

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-file"></i> Gestion des landings</li>
      </ol>
     <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('landing')); ?>" class="btn-right "><i class="fa fa-list"></i> Liste des landings</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Danger')): ?>
  <div class="alert alert-danger">
      <?php echo e(session()->get('Danger')); ?>

  </div>
  <?php endif; ?>

</div>

<div class="col-md-12">
  <?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="panel panel-default client-content" style="padding:7px 10px 10px 20px"> 
      <div class="row">
        <div class="col-md-5">
            <h6><label for="dat" class="control-label form-label label01">Nom de la page : <span class="cmd-show"><?php echo e($land->landing); ?></span></label></h6>
        </div>
        <div class="col-md-5">
            <h6><label for="pro" class="control-label form-label label01">Produit : <span class="cmd-show"><?php echo e($land->produit); ?></span></label></h6>
        </div>
        <div class="col-md-2" style="padding-top: 10px">
           <a title="Aperçu" target="_blank" href="<?php echo e(route('mystoreLanding',[ 'mystore' => 'ecombladi', 'landing' => $land->landing ])); ?>"><button class="btn btn-xs btn-default" style="float: right; margin-right: 12px">Aperçu la page</button></a>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="col-md-3">
  <div class="panel panel-header client-content" style="padding:17px 30px 20px"> 
    <div class="row" style="margin-bottom: 10px">
      <div class="col-md-12">
        <a href="<?php echo e(route('landingItemAddTitle', ['ref' => $ref])); ?>" ><button class="btn btn-block btn-option" style="text-align: center;">Ajouter un titre <i class="fa fa-plus" style="float: right; padding-top: 3px"></i></button></a>
        <form id="addtitle" action="<?php echo e(route('landingItemAddTitle', ['ref' => $ref])); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

        </form>  
      </div>
    </div>
    <div class="row" style="margin-bottom: 10px">
      <div class="col-md-12">
        <a href="<?php echo e(route('landingItemAddImage', ['ref' => $ref])); ?>" ><button class="btn btn-block btn-option" style="text-align: center;">Ajouter une image <i class="fa fa-plus" style="float: right; padding-top: 3px"></i></button></a>
        <form id="addtitle" action="<?php echo e(route('landingItemAddImage', ['ref' => $ref])); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

        </form>  
      </div>
    </div>
    <div class="row" style="margin-bottom: 10px">
      <div class="col-md-12">
        <a href="<?php echo e(route('landingItemAddVideo', ['ref' => $ref])); ?>" ><button class="btn btn-block btn-option" style="text-align: center;">Ajouter une vidéo <i class="fa fa-plus" style="float: right; padding-top: 3px"></i></button></a>
        <form id="addtitle" action="<?php echo e(route('landingItemAddVideo', ['ref' => $ref])); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

        </form>  
      </div>
    </div>
    <div class="row" style="margin-bottom: 10px">
      <div class="col-md-12">
        <a href="<?php echo e(route('landingItemAddText', ['ref' => $ref])); ?>" ><button class="btn btn-block btn-option" style="text-align: center;">Ajouter un text <i class="fa fa-plus" style="float: right; padding-top: 3px"></i></button></a>
        <form id="addtitle" action="<?php echo e(route('landingItemAddText', ['ref' => $ref])); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

        </form>  
      </div>
    </div>
    <div class="row" style="margin-bottom: 10px">
      <div class="col-md-12">
        <a href="<?php echo e(route('landingItemAddPrix', ['ref' => $ref])); ?>" ><button class="btn btn-block btn-option" style="text-align: center;">Ajouter les prix <i class="fa fa-plus" style="float: right; padding-top: 3px"></i></button></a>
        <form id="addPrix" action="<?php echo e(route('landingItemAddPrix', ['ref' => $ref])); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

        </form>  
      </div>
    </div>
    <div class="row" style="margin-bottom: 10px">
      <div class="col-md-12">
        <a href="<?php echo e(route('landingItemAddForm', ['ref' => $ref])); ?>" ><button class="btn btn-block btn-option" style="text-align: center;">Ajouter le formulaire <i class="fa fa-plus" style="float: right; padding-top: 3px"></i></button></a>
        <form id="addtitle" action="<?php echo e(route('landingItemAddForm', ['ref' => $ref])); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

        </form>  
      </div>
    </div>
  </div>
</div>

<div class="col-md-9">
<?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('landingEdited',[ 'ref' => $land->ref ])); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e(csrf_field()); ?>

  <div class="panel panel-default">
    <div class="panel-heading">
      <h3 class="panel-title" style="background: rgba(0,0,0,0.1)">Squellete de la page</h3>
    </div>
    <div class="panel-body" style="min-height: 700px">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($item->typ=='title'): ?>
      <div class="panel panel-default">
      <a href="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" title="Supprimer cette section" onclick="return confirm('Vous-êtes sûr de supprimer cette section ?'); event.preventDefault(); document.getElementById('deleteTitle').submit();"><i class="fa fa-trash icon-landing" style="color:red; font-size: 15px; float: right;top: 5px"></i></a>
      <!-- <form id="deleteTitle" action="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" method="POST"> <?php echo e(method_field('DELETE')); ?> <?php echo csrf_field(); ?> </form>   -->
      <h6>
        <a href="<?php echo e(route('landingItemUp',[ 'ref' => $item->ref ])); ?>" title="En haut"><i class="fa fa-chevron-up icon-landing" style="color:green; font-size: 15px; top: 5px"></i></a>
        <a href="<?php echo e(route('landingItemDown',[ 'ref' => $item->ref ])); ?>" title="En bas"><i class="fa fa-chevron-down icon-landing" style="color:red; font-size: 15px; top: 5px"></i></a>
        <label for="title-<?php echo e($item->ref); ?>" class="control-label form-label label01"><?php echo e($types[$item->typ]); ?> </label>
      </h6>
      <textarea name="<?php echo e($item->ref); ?>" class="form-control" id="title-<?php echo e($item->ref); ?>" style="height: 50px !important"><?php echo e($item->txt); ?></textarea>
      </div>
      <?php endif; ?>

      <?php if($item->typ=='image'): ?>
      <div class="panel panel-default">
      <a href="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" title="Supprimer cette section" onclick="return confirm('Vous-êtes sûr de supprimer cette section ?'); event.preventDefault(); document.getElementById('deleteTitle').submit();"><i class="fa fa-trash icon-landing" style="color:red; font-size: 15px; float: right;top: 5px"></i></a>
      <!-- <form id="deleteTitle" action="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" method="POST"> <?php echo e(method_field('DELETE')); ?> <?php echo csrf_field(); ?> </form>   -->
      <h6>
        <a href="<?php echo e(route('landingItemUp',[ 'ref' => $item->ref ])); ?>" title="En haut"><i class="fa fa-chevron-up icon-landing" style="color:green; font-size: 15px; top: 5px"></i></a>
        <a href="<?php echo e(route('landingItemDown',[ 'ref' => $item->ref ])); ?>" title="En bas"><i class="fa fa-chevron-down icon-landing" style="color:red; font-size: 15px; top: 5px"></i></a>
        <label for="image-<?php echo e($item->ref); ?>" class="control-label form-label label01"><?php echo e($types[$item->typ]); ?> </label></h6>
        <input type="text" name="<?php echo e($item->ref); ?>" class="form-control" id="image-<?php echo e($item->ref); ?>" value="<?php echo e($item->txt); ?>">
      </div>
      <?php endif; ?>

      <?php if($item->typ=='video'): ?>
      <div class="panel panel-default">
      <a href="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" title="Supprimer cette section" onclick="return confirm('Vous-êtes sûr de supprimer cette section ?'); event.preventDefault(); document.getElementById('deleteTitle').submit();"><i class="fa fa-trash icon-landing" style="color:red; font-size: 15px; float: right;top: 5px"></i></a>
      <!-- <form id="deleteTitle" action="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" method="POST"> <?php echo e(method_field('DELETE')); ?> <?php echo csrf_field(); ?> </form>   -->
      <h6>
        <a href="<?php echo e(route('landingItemUp',[ 'ref' => $item->ref ])); ?>" title="En haut"><i class="fa fa-chevron-up icon-landing" style="color:green; font-size: 15px; top: 5px"></i></a>
        <a href="<?php echo e(route('landingItemDown',[ 'ref' => $item->ref ])); ?>" title="En bas"><i class="fa fa-chevron-down icon-landing" style="color:red; font-size: 15px; top: 5px"></i></a>
        <label for="video-<?php echo e($item->ref); ?>" class="control-label form-label label01"><?php echo e($types[$item->typ]); ?> </label></h6>
        <input type="text" name="<?php echo e($item->ref); ?>" class="form-control" id="video-<?php echo e($item->ref); ?>" value="<?php echo e($item->txt); ?>">
      </div>
      <?php endif; ?>

      <?php if($item->typ=='text'): ?>
      <div class="panel panel-default">
      <a href="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" title="Supprimer cette section" onclick="return confirm('Vous-êtes sûr de supprimer cette section ?'); event.preventDefault(); document.getElementById('deleteTitle').submit();"><i class="fa fa-trash icon-landing" style="color:red; font-size: 15px; float: right;top: 5px"></i></a>
      <!-- <form id="deleteTitle" action="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" method="POST"> <?php echo e(method_field('DELETE')); ?> <?php echo csrf_field(); ?> </form>   -->
      <h6>
        <a href="<?php echo e(route('landingItemUp',[ 'ref' => $item->ref ])); ?>" title="En haut"><i class="fa fa-chevron-up icon-landing" style="color:green; font-size: 15px; top: 5px"></i></a>
        <a href="<?php echo e(route('landingItemDown',[ 'ref' => $item->ref ])); ?>" title="En bas"><i class="fa fa-chevron-down icon-landing" style="color:red; font-size: 15px; top: 5px"></i></a>
        <label for="text-<?php echo e($item->ref); ?>" class="control-label form-label label01"><?php echo e($types[$item->typ]); ?> </label></h6>
        <textarea name="<?php echo e($item->ref); ?>" class="form-control" id="text-<?php echo e($item->ref); ?>"><?php echo e($item->txt); ?></textarea>
      </div>
      <?php endif; ?>

      <?php if($item->typ=='form'): ?>
      <div class="panel panel-default">
      <a href="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" title="Supprimer cette section" onclick="return confirm('Vous-êtes sûr de supprimer cette section ?'); event.preventDefault(); document.getElementById('deleteTitle').submit();"><i class="fa fa-trash icon-landing" style="color:red; font-size: 15px; float: right;top: 5px"></i></a>
      <!-- <form id="deleteTitle" action="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" method="POST"> <?php echo e(method_field('DELETE')); ?> <?php echo csrf_field(); ?> </form>   -->
      <h6>
        <a href="<?php echo e(route('landingItemUp',[ 'ref' => $item->ref ])); ?>" title="En haut"><i class="fa fa-chevron-up icon-landing" style="color:green; font-size: 15px; top: 5px"></i></a>
        <a href="<?php echo e(route('landingItemDown',[ 'ref' => $item->ref ])); ?>" title="En bas"><i class="fa fa-chevron-down icon-landing" style="color:red; font-size: 15px; top: 5px"></i></a>
        <label for="<?php echo e($item->ref); ?>" class="control-label form-label label01"><?php echo e($types[$item->typ]); ?> </label></h6>
        <img src="<?php echo e(url('imgs/form.jpg')); ?>">
      </div>
      <?php endif; ?>

      <?php if($item->typ=='prix'): ?>
      <div class="panel panel-default">
      <a href="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" title="Supprimer cette section" onclick="return confirm('Vous-êtes sûr de supprimer cette section ?'); event.preventDefault(); document.getElementById('deleteTitle').submit();"><i class="fa fa-trash icon-landing" style="color:red; font-size: 15px; float: right;top: 5px"></i></a>
      <!-- <form id="deleteTitle" action="<?php echo e(route('landingItemDeleted',[ 'ref' => $item->ref ])); ?>" method="POST"> <?php echo e(method_field('DELETE')); ?> <?php echo csrf_field(); ?> </form>   -->
      <h6>
        <a href="<?php echo e(route('landingItemUp',[ 'ref' => $item->ref ])); ?>" title="En haut"><i class="fa fa-chevron-up icon-landing" style="color:green; font-size: 15px; top: 5px"></i></a>
        <a href="<?php echo e(route('landingItemDown',[ 'ref' => $item->ref ])); ?>" title="En bas"><i class="fa fa-chevron-down icon-landing" style="color:red; font-size: 15px; top: 5px"></i></a>
        <label for="<?php echo e($item->ref); ?>" class="control-label form-label label01"><?php echo e($types[$item->typ]); ?> </label></h6>
        
        <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table width="100%" class="table table-striped">
          <tr>
            <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">1 Pack</h4></td>
            <td align="center"><h4 class="myresto-h4" style="color: <?php echo e(Auth::user()->color4); ?>"><?php echo e(number_format($prod->pri1, 2)); ?> MAD</h4></td>
            <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; ">باقة واحدة</h4></td>
          </tr>
          <?php if($prod->pri2!=0): ?>
          <tr>
            <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">2 Packs</h4></td>
            <td align="center"><h4 class="myresto-h4" style="color: <?php echo e(Auth::user()->color4); ?>"><?php echo e(number_format($prod->pri2, 2)); ?> MAD</h4></td>
            <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">باقتين</h4></td>
          </tr>
          <?php endif; ?>
          <?php if($prod->pri3!=0): ?>
          <tr>
            <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">3 Packs</h4></td>
            <td align="center"><h4 class="myresto-h4" style="color: <?php echo e(Auth::user()->color4); ?>"><?php echo e(number_format($prod->pri3, 2)); ?> MAD</h4></td>
            <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">ثلاث باقات</h4></td>
          </tr>
          <?php endif; ?>
          <?php if($prod->pri4!=0): ?>
          <tr>
            <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">4 Packs</h4></td>
            <td align="center"><h4 class="myresto-h4" style="color: <?php echo e(Auth::user()->color4); ?>"><?php echo e(number_format($prod->pri4, 2)); ?> MAD</h4></td>
            <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">أربع باقات</h4></td>
          </tr>
          <?php endif; ?>
          <?php if($prod->pri5!=0): ?>
          <tr>
            <td width="33.33%"><h4 class="myresto-h4"><span style="color:gray;">5 Packs</h4></td>
            <td align="center"><h4 class="myresto-h4" style="color: <?php echo e(Auth::user()->color4); ?>"><?php echo e(number_format($prod->pri5, 2)); ?> MAD</h4></td>
            <td width="33.33%" align="right"><h4 class="myresto-h4"><span style="color:gray; text-align: right; ">خمس باقات</h4></td>
          </tr>
          <?php endif; ?>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <div class="row" style="margin-top: 12px">
      <div class="col-md-8">
        <?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $land): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Sauvegarder la page</button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>

</form>
</div>


<script src="<?php echo e(url('textarea/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(url('textarea/bootstrap.min.js')); ?>"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="<?php echo e(url('textarea/summernote.min.js')); ?>"></script>


<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($item->typ=='title'): ?>
  <script> $(document).ready(function() { $('#title-<?php echo e($item->ref); ?>').summernote(); }); </script>
  <?php endif; ?>
  <?php if($item->typ=='text'): ?>
  <script> $(document).ready(function() { $('#text-<?php echo e($item->ref); ?>').summernote(); }); </script>
  <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/landingEdit.blade.php ENDPATH**/ ?>