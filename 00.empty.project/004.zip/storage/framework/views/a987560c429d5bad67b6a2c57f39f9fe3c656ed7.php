

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> Liste des clients</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <a href="<?php echo e(route('clientAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> Nouveau client </a>
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>

  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td>Nom & prénom</td>
        <td>Email</td>
        <td width="170">Téléphone</td>
        <td width="200">Identifiant</td>
        <td width="200">Mot de passe</td>
        <td width="160"></td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $clis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><span class="bold" style="color:black"><?php echo e($cli->civ); ?> <?php echo e($cli->nom); ?> <?php echo e($cli->pre); ?></span></td>
        <td><span class="bold"><?php echo e($cli->mail); ?></span></td>
        <td><span class="bold"><?php echo e($cli->tel); ?></span></td>
        <td><span class="tel"><?php echo e($cli->log); ?></span></td>
        <td><span class="tel"><?php echo e($cli->log); ?></span></td>
        <td>
          <a href="<?php echo e(route('clientPhotos',[ 'ref' => $cli->ref ])); ?>"><button class="btn btn-xs btn-default"><i class="fa fa-picture-o a-icon"></i></button></a>
          <a href="<?php echo e(route('clientEdit',[ 'ref' => $cli->ref ])); ?>"><button class="btn btn-xs btn-default"><i class="fa fa-edit a-icon"></i></button></a>
          <a href="<?php echo e(route('clientDelete',[ 'ref' => $cli->ref ])); ?>" onclick="return confirm('Vous-êtes sûr de supprimer ce client ?'); event.preventDefault(); document.getElementById('clientDelete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
          <form id="clientDelete" action="<?php echo e(route('clientDelete',[ 'ref' => $cli->ref ])); ?>" method="POST">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
          </form>  
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\monprojetbali\admin\resources\views/client.blade.php ENDPATH**/ ?>