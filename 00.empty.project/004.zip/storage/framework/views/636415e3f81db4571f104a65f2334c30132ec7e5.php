<?php $__env->startSection('content'); ?>





    <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('imgs/sld/slddd03.jpg')); ?>');margin-top: 169px; background: #00AEEF">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-md-4">

                    <div class="breadcrumb_inner">

                        <h3>Formulaire de contact</h3>

                    </div>

                </div>

            </div>

        </div>


    </div>


    <!--Contact Form-->

    <div class="contact_form_wrapper clv_section">

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                    <div class="contact_form_section">

                        <div class="row">

                            <div class="col-md-12 col-lg-12">

                                <h3></h3>

                            </div>

                            <form method="POST" action="">
                                <?php echo e(csrf_field()); ?>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="first_name" class="form_field require" placeholder="Prénom *" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="last_name" class="form_field require" placeholder="Nom *" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="email" class="form_field require" placeholder="Email *" data-valid="email" data-error="Email should be valid." >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="tel" class="form_field require" placeholder="Téléphone *" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="adr" class="form_field require" placeholder="Quartier / zone géographique / ville" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <select name="bayti" class="form_field require" >
                                        <option>Comment avez-vous connu BaytiHelp ? *</option>
                                        <option>Recommandation</option>
                                        <option>Ancien Client</option>
                                        <option>Google ou Moteur de Recherche</option>
                                        <option>Press</option>
                                        <option>TV</option>
                                        <option>Agence Immobilière</option>
                                        <option>Hotel de Luxe - palace</option>
                                        <option>Autres</option>
                                    </select>

                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">

                                    <textarea placeholder="Message" name="message" class="form_field require" ></textarea>

                                    <div class="response"></div>

                                </div>

                            </div>

                            <?php 
                            $a = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,1);
                            $b = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,1);
                            ?>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">
                                    <span style="float: left;"><span style="color:#00AEEF; font-weight: bold; font-size: 20px; padding-right: 15px"><?php echo $a; ?></span> <span style="font-weight: bold; padding-right: 15px">+</span> <span style="color:#EC008C; font-weight: bold; font-size: 20px; padding-right: 15px"><?php echo $b; ?></span> = </span><input type="text" class="form-control" style="width: 60px; float: left; margin-left: 15px" name="">
                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12" style="margin-top: 20px">

                                <div class="form_block">

                                    <button type="submit" class="clv_btn submitForm" data-type="contact" >Envoyer le message</button>

                                </div>

                            </div>

                            </form>

                        </div>

                    </div>

                </div>

                
            </div>

        </div>

    </div> 







<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/contact.blade.php ENDPATH**/ ?>