<?php $__env->startSection('content'); ?>

<style type="text/css">
  .bs-stepper-label { color:rgba(0,0,0,0.2) }
  .bgCyrcle { background:rgba(0,0,0,0.2) !important } 
  .bs-stepper-line { margin-left: 15px !important; flex: 1 0 16px !important }
  .activeClas { font-weight: bold; color :#1da2a4 !important; }
  .activeClasBg { background :#1da2a4 !important; }
  .activeClasAlready { font-weight: bold; color :rgba(0,0,0,0.6) !important; }
  .activeClasAlreadyBg { background :rgba(0,0,0,0.6) !important; }
</style>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>
<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Dashbord</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <a href="#" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">Contact our team</a>
      <a href="#" class="btn btn-success my-2" tooltip="New App" data-bs-toggle="modal" data-bs-target="#kt_modal_create_app">Make an appointment</a>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">
      <div class="col-xxl-7"> 

        <div class="card card-page">
          <div class="card-body">

            <div class="card-header border-0 pt-5 pb-3">
              <h3 class="card-title fw-bolder text-gray-800 fs-2">Step of project</h3>
            </div>
            
            <div class="card card-xxl-stretch">
              <div class="card-header">
                  
                  <?php $steps = array(
                    1 => "Envoi du contrat de reservation",
                    2 => "Envoie de la facture de 5000e",
                    3 => "Validation du paiement de 5000e ",
                    4 => "Envoie des documents PTPTMA",
                    5 => "Envoie des documents bancaires",
                    6 => "Choix du terrain",
                    7 => "Envoie des documents du terrain ",
                    8 => "Remise des documents ptpma",
                    9 => "Envoie de la facture terrain",
                    10 => "Création de la société ",
                    11 => "Réception du paiement terrain ",
                    12 => "Signature du terrain",
                    13 => "D0",
                    14 => "D1",
                    15 => "D2",
                    16 => "D3",
                    17 => "Envoie des Rendering",
                    18 => "Contrat de construction",
                    19 => "Signature des Rendering",
                    20 => "Facture 40(1)",
                    21 => "Envoie des plans",
                    22 => "Réception du paiement ",
                    23 => "Préparation du terrain",
                    24 => "Démarrage des travaux",
                    25 => "Fondation ",
                    26 => "Structure",
                    27 => "Facture du deuxieme accompte",
                    28 => "Mur",
                    29 => "Toiture",
                    30 => "Meeting décoration",
                    31 => "Démarrage des finitions",
                    32 => "Acompte de 15% ",
                    33 => "Ameublement ",
                    34 => "Réception de la villa ",
                    35 => "Paiement du solde final",
                    36 => "Mise en location"
                  ); ?>
                  
                  <div id="stepper4" class="bs-stepper vertical linear">
                    <div class="bs-stepper-header" role="tablist">
                      
                      <?php $i=1; ?>
                      <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="bs-stepper-line"></div>
                      <div class="step">
                          <span class="bs-stepper-circle  <?php if($i==$etape): ?> activeClasBg <?php elseif($i<$etape): ?> activeClasAlreadyBg <?php else: ?> bgCyrcle  <?php endif; ?>" ><?php echo e($i); ?></span><span class="bs-stepper-label <?php if($i==$etape): ?> activeClas <?php elseif($i<$etape): ?> activeClasAlready <?php endif; ?>"><?php echo e($s); ?></span>
                      </div>
                       <?php $i+=1; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                  </div>

              </div>
            </div>
          </div>
        </div>

      </div>

      <div class="col-xxl-5">
          <div class="card card-page">
            <div class="card-body">
              <div class="card-header border-0 pt-5 pb-3">
                <h3 class="card-title fw-bolder text-gray-800 fs-2">Last Added Pictures </h3>
              </div>
              <?php $__currentLoopData = $pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card-header border-0 pt-5 pb-3"  style="margin-bottom: 5px">
                <img src="<?php echo e($urlWebSite); ?>/media/cli/<?php echo e($img->img); ?>" width="100%">
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
       </div> 

    </div>
  </div>
</div>
          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/dashboard.blade.php ENDPATH**/ ?>