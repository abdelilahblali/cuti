

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-bell"></i> List of notifications</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <a href="<?php echo e(route('notificationsAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> New notification</a>
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>

  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td>Action</td>
        <td>Title</td>
        <td>Message</td>
        <td width="160"></td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr onclick="window.location='<?php echo e(route('notificationsEdit',[ 'ref' => $item->refNotif ])); ?>';">
        <td><span class="bold"><?php echo e($item->role); ?></span></td>
        <td><span class="bold ref"><?php echo e($item->title); ?></span></td>
        <td><span class="bold"><?php echo e($item->message); ?></span></td>
        <td align="right">
          <a title="Edit" href="<?php echo e(route('notificationsEdit',[ 'ref' => $item->refNotif ])); ?>"><button class="btn btn-xs btn-default"><i class="fa fa-edit a-icon"></i></button></a>
          <a title="Delete" href="<?php echo e(route('notificationsDelete',[ 'ref' => $item->refNotif ])); ?>" onclick="return confirm('Are you sure you want to delete this element?'); event.preventDefault(); document.getElementById('notificationsDelete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
          <form id="notificationsDelete" action="<?php echo e(route('notificationsDelete',[ 'ref' => $item->refNotif ])); ?>" method="POST">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
          </form>  
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mag.sales\resources\views/notifications.blade.php ENDPATH**/ ?>