

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title>Magnitude Construction : Sales management</title>
    <link href="<?php echo e(url('dash/css/root.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('dash/style.css')); ?>">
    <link rel="icon" href="<?php echo e(url('imgs/logo.png')); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('chosen/chosen.css')); ?>" />
</head>

<body>

    <div id="top" class="clearfix">
        <div class="applogo" style="width: 650px !important; padding-top: 9px, color:white; font-size: 20px; padding-top: 15px">
            SALES <span style="font-weight: bold">MANAGEMENT</span>
        </div>
        <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-bars"></i></a>
        <div class="col-md-2">
        </div>
        <ul class="top-right" style="background-color: #00aeef; padding:10px 8px">
            <li class=" link">
                <a href="#" style="padding-top: 2px; padding-right: 20px; padding-left: 20px">Welcome <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></a>
            </li>
        </ul>
    </div>


    <?php if( Auth::user()->type=='admin' ): ?>
    <div class="sidebar clearfix">
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Menu</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li><a href="<?php echo e(route('ventes')); ?>"><span class="icon color5"><i class="fa fa-diamond"></i></span><span class="panel_menu">Sales</span></a></li>
          <li><a href="<?php echo e(route('infos')); ?>"><span class="icon color5"><i class="fa fa-info"></i></span><span class="panel_menu">Infos</span></a></li>
          <li><a href="<?php echo e(route('land')); ?>"><span class="icon color5"><i class="fa fa-map-marker"></i></span><span class="panel_menu">Land</span></a></li>
          <li><a href="<?php echo e(route('suivis')); ?>"><span class="icon color5"><i class="fa fa-calendar"></i></span><span class="panel_menu">Suivi Contrat</span></a></li>
          <li><a href="<?php echo e(route('banjar')); ?>"><span class="icon color5"><i class="fa fa-money"></i></span><span class="panel_menu">Payment Banjar</span></a></li>
          <li><a href="<?php echo e(route('ptpma')); ?>"><span class="icon color5"><i class="fa fa-file-o"></i></span><span class="panel_menu">PT PMA</span></a></li>
          <li><a href="<?php echo e(route('bank')); ?>"><span class="icon color5"><i class="fa fa-bank"></i></span><span class="panel_menu">Bank</span></a></li>
          <li><a href="<?php echo e(route('architecture')); ?>"><span class="icon color5"><i class="fa fa-print"></i></span><span class="panel_menu">Architecture</span></a></li>
          <li><a href="<?php echo e(route('herlinda')); ?>"><span class="icon color5"><i class="fa fa-user"></i></span><span class="panel_menu">Herlinda</span></a></li>
          <li><a href="<?php echo e(route('payment')); ?>"><span class="icon color5"><i class="fa fa-credit-card"></i></span><span class="panel_menu">Payment</span></a></li>
          <li><a href="<?php echo e(route('progress')); ?>"><span class="icon color5"><i class="fa fa-spinner"></i></span><span class="panel_menu">Worksite Progress</span></a></li>
          <li><a href="<?php echo e(route('taxe')); ?>"><span class="icon color5"><i class="fa fa-legal"></i></span><span class="panel_menu">Taxe</span></a></li>
          <li><a href="<?php echo e(route('building')); ?>"><span class="icon color5"><i class="fa fa-building-o"></i></span><span class="panel_menu">Detail Building</span></a></li>
          <li><a href="<?php echo e(route('marketing')); ?>"><span class="icon color5"><i class="fa fa-bell"></i></span><span class="panel_menu">Marketing</span></a></li>
          <li><a href="<?php echo e(route('step')); ?>"><span class="icon color5"><i class="fa fa-sitemap"></i></span><span class="panel_menu">Project steps</span></a></li>
          


          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-clock-o"></i></span><span class="panel_menu">S.C. Construction</span></a></li> -->
          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-th-large"></i></span><span class="panel_menu">Equipements Ex.</span></a></li> -->
          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-plus"></i></span><span class="panel_menu">Tampons</span></a></li> -->
          <!-- <li><a style="color:red" href="#"><span class="icon color5"><i class="fa fa-magnet"></i></span><span class="panel_menu">Variable</span></a></li> -->
        </ul>
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Users</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('clientAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">Add New</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('client')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">List of users</span></a>
          </li>
        </ul>
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Account</li>
        </ul>
        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('password')); ?>"><span class="icon color5"><i class="fa fa-unlock"></i></span>
            <span class="panel_menu">Password</span></a>
          </li>
        </ul>
        <ul class="sidebar-panel nav" style="position: fixed; bottom: 0; background-color: red; width: 195px; margin-left: 0; padding-left: 20px">
          <li>
            <a href="<?php echo e(route('logout' )); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span class="icon color5"><i class="fa fa-power-off" style="color: white"></i></span>
            <span class="panel_menu" style="color: white">Sign Out</span></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>   
          </li>
        </ul>
    </div>
    <?php endif; ?>



    <div class="content">
        <?php echo $__env->yieldContent('content'); ?> 
    </div>


    <script src="<?php echo e(url('dash/js/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(url('dash/js/datatables/datatables.min.js')); ?>"></script>
    <script> $(document).ready(function() { $('#tab').DataTable( { "order": [[ 1, "asc" ]] } ); } ); </script>
    
    <script src="http://ajax.googleapis.com/ajax/libs/mootools/1.3/mootools-yui-compressed.js"></script>
    <script src="<?php echo e(url('chosen/mootools-more-1.4.0.1.js')); ?>"></script>
    <script src="<?php echo e(url('chosen/chosen.js')); ?>"></script>
    <script src="<?php echo e(url('chosen/Locale.en-US.Chosen.js')); ?>"></script>
    <script> $$(".chzn-select").chosen(); $$(".chzn-select-deselect").chosen({allow_single_deselect:true}); </script>

    

</body>

    

</html><?php /**PATH I:\Wamp\www\mag.sales\resources\views/master/admin.blade.php ENDPATH**/ ?>