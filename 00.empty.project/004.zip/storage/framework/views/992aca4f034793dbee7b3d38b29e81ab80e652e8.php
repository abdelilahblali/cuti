<?php $__env->startSection('content'); ?>





    <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('imgs/sld/slddd03.jpg')); ?>');margin-top: 169px; background: #00AEEF">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-md-4">

                    <div class="breadcrumb_inner">

                        <h3>Contact</h3>

                    </div>

                </div>

            </div>

        </div>


    </div>


    <div class="contact_blocks_wrapper clv_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="contact_block">
                        <span></span>
                        <div class="contact_icon"><i class="fa fa-phone" style="color:#EC008C; font-size: 50px"></i></div>
                        <h4>Appelez-Nous</h4>
                        <p>+212 5 22 86 39 51</p>
                        <p>+212 6 49 75 75 40</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="contact_block">
                        <span></span>
                        <div class="contact_icon"><i class="fa fa-envelope" style="color:#EC008C; font-size: 50px"></i></div>
                        <h4>Email</h4>
                        <p>contact@baytihelp.com</p>
                        <p>client@baytihelp.com</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="contact_block">
                        <span></span>
                        <div class="contact_icon"><i class="fa fa-envelope" style="color:#EC008C; font-size: 50px"></i></div>
                        <h4>Adresse</h4>
                        <p>8 rue d'arménie, rés. anas - 2 mars Casablanca, Maroc</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class=" ">
        <div class="container">
            <div class="row">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3324.327558829437!2d-7.616373184425912!3d33.57084355039127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xda7d2a8d939218d%3A0x2f96a6447c7daea!2sBAYTI%20HELP%20femme%20de%20m%C3%A9nage%20nounou%20cuisini%C3%A8re%20%2C%20marocaine%20africaine%20philippine%20au%20Maroc%20et%20Alg%C3%A9rie!5e0!3m2!1sfr!2sma!4v1609419824656!5m2!1sfr!2sma" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
        </div>
    </div>

    <div class="contact_form_wrapper clv_section">

        <div class="container">

            <div class="row">

                <div class="col-md-12">

                    <div class="contact_form_section">

                        <div class="row">

                            <div class="col-md-12 col-lg-12">

                                <h3></h3>

                            </div>

                            <form method="POST" action="">
                                <?php echo e(csrf_field()); ?>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="first_name" class="form_field require" placeholder="Prénom *" required >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="last_name" class="form_field require" placeholder="Nom *" required >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="email" class="form_field require" placeholder="Email *" required data-valid="email" data-error="Email should be valid." >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="tel" class="form_field require" placeholder="Téléphone *" required >

                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">

                                    <textarea placeholder="Message *" name="message" class="form_field require" ></textarea>

                                    <div class="response"></div>

                                </div>

                            </div>

                            <?php 
                            $a = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,1);
                            $b = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,1);
                            ?>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">
                                    <span style="float: left;"><span style="color:#00AEEF; font-weight: bold; font-size: 20px; padding-right: 15px"><?php echo $a; ?></span> <span style="font-weight: bold; padding-right: 15px">+</span> <span style="color:#EC008C; font-weight: bold; font-size: 20px; padding-right: 15px"><?php echo $b; ?></span> = </span><input type="text" class="form-control" style="width: 60px; float: left; margin-left: 15px" name="">
                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12" style="margin-top: 20px">

                                <div class="form_block">

                                    <button type="submit" class="clv_btn submitForm" data-type="contact" >Envoyer le message</button>

                                </div>

                            </div>

                            </form>

                        </div>

                    </div>

                </div>

                
            </div>

        </div>

    </div> 







<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/contacts.blade.php ENDPATH**/ ?>