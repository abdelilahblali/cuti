

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cubes"></i> Gestion des actualités</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('actualiteAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> Nouvelle actualité </a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
    
    <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
      <thead>
        <tr>
          <td width="150"></td>
          <td>Titre</td>
          <td width="130"></td>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><img src="<?php echo e(url('actualites')); ?>/<?php echo e($act->img); ?>" style="width: 60px"></td>
            <td>
              <?php echo e($act->des); ?>

              <br/>
            </td>
            <td style="padding-top: 8px !important;padding-right: 10px !important ">
              <a href="<?php echo e(route('actualiteEdit',[ 'ref' => $act->ref ])); ?>"><button class="btn btn-xs btn-default"  style="text-align: center; width: 30px !important"><i class="fa fa-edit a-icon"></i></button></a>
              <a href="<?php echo e(route('actualiteDeleted',[ 'ref' => $act->ref ])); ?>" onclick="return confirm('Vous-êtes sûr de supprimer cet actualité ?'); event.preventDefault(); document.getElementById('actualiteDelete').submit();"><button class="btn btn-xs btn-danger" style="text-align: center;width: 30px !important"><i class="fa fa-trash a-icon"></i></button></a>
              <form id="actualiteDelete" action="<?php echo e(route('actualiteDeleted',[ 'ref' => $act->ref ])); ?>" method="POST">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo csrf_field(); ?>
              </form>  
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/actualite.blade.php ENDPATH**/ ?>