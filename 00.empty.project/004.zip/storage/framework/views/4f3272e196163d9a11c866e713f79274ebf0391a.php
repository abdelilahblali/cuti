

<?php $__env->startSection('content'); ?>
<div class="panel panel-default client-content" style="padding:25px 30px">

	<?php if(session()->has('Modification')): ?>
	<div class="alert alert-success">
	    <?php echo e(session()->get('Modification')); ?>

	</div>
	<?php endif; ?>

  <form method="POST"  action="<?php echo e(route('user.edit')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="row">
      	<div class="col-md-12">
          	<h6><label for="nom" class="control-label form-label label01">Nom  <span class="c3_color">*</span></label></h6>
          	<input type="text" name="nom" class="form-control" placeholder="Nom" required value="<?php echo e(Auth::user()->nom); ?>">
      	</div>
    </div>
    <div class="row">
      	<div class="col-md-12">
          	<h6><label for="prenom" class="control-label form-label label01">Prénom  <span class="c3_color">*</span></label></h6>
          	<input type="text" name="prenom" class="form-control" placeholder="Prénom" required value="<?php echo e(Auth::user()->prenom); ?>">
      	</div>
    </div>
    <div class="row">
      	<div class="col-md-12">
          	<h6><label for="telephone" class="control-label form-label label01">Téléphone  <span class="c3_color">*</span></label></h6>
          	<input type="text" name="telephone" class="form-control" placeholder="Téléphone" required value="<?php echo e(Auth::user()->telephone); ?>">
      	</div>
    </div>
    <div class="row">
      	<div class="col-md-12">
          	<h6><label for="ville" class="control-label form-label label01">Ville  </label></h6>
          	<input type="text" name="ville" class="form-control" placeholder="Ville" value="<?php echo e(Auth::user()->ville); ?>">
      	</div>
    </div>
    <div class="row" style="margin-top: 20px">
      <div class="col-md-8">
        <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Sauvegarder</button>
      </div>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/profil.blade.php ENDPATH**/ ?>