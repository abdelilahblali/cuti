<?php $__env->startSection('content'); ?>

<style type="text/css">
  .bs-stepper-label { color:rgba(0,0,0,0.2) }
  .bgCyrcle { background:rgba(0,0,0,0.2) !important } 
  .bs-stepper-line { margin-left: 15px !important; flex: 1 0 16px !important }
  .activeClas { font-weight: bold; color :#1da2a4 !important; }
  .activeClasBg { background :#1da2a4 !important; }
  .activeClasAlready { font-weight: bold; color :rgba(0,0,0,0.6) !important; }
  .activeClasAlreadyBg { background :rgba(0,0,0,0.6) !important; }
</style>

<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js"></script>
<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Invoices</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <a href="#" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">Contact our team</a>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <form method="POST" action="<?php echo e(route('clientFolder_factures_updated_byClient',[ 'cli' => Auth::user()->ref ])); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    <input type="hidden" name="cli" value="<?php echo e(Auth::user()->ref); ?>">

    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">
      <div class="col-xxl-12"> 

        <div class="card card-page">
          <div class="card-body">

            <div class="card-header border-0 pt-5 pb-3">
              <h3 class="card-title fw-bolder text-gray-800 fs-2">Summary of your invoices</h3>
            </div>
            
            <div class="card card-xxl-stretch">
              <div class="card-header">
                
                  <table class="table table-rounded table-striped border gy-7 gs-7">
                    <thead>
                      <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
                          <th></th>
                          <th>Amount</th>
                          <th>Invoice</th>
                          <th>Document proof</th>
                          <th>Paided Invoice</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Payment</td>
                            <td><?php echo e(number_format($a1, 2)); ?></td>
                            <td><?php if($a2!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $a2; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                            <td><?php if($a4==""): ?><input type="file" class="form-control" style="width: 350px !important" name="a4[]" multiple /><?php else: ?> <a href="http://localhost/monProjetBali/media/invoice/<?php echo $a4; ?>" target="_" style="color:#1da2a4">View </a>  <?php endif; ?></td>
                            <td><?php if($a3!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $a3; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>Land</td>
                            <td><?php echo e(number_format($b1, 2)); ?></td>
                            <td><?php if($b2!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $b2; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                            <td><?php if($b4==""): ?><input type="file" class="form-control" style="width: 350px !important" name="b4[]" multiple /><?php else: ?> <a href="http://localhost/monProjetBali/media/invoice/<?php echo $b4; ?>" target="_" style="color:#1da2a4">View </a>  <?php endif; ?></td>
                            <td><?php if($b3!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $b3; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>40% (1)</td>
                            <td><?php echo e(number_format($c1, 2)); ?></td>
                            <td><?php if($c2!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $c2; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                            <td><?php if($c4==""): ?><input type="file" class="form-control" style="width: 350px !important" name="c4[]" multiple /><?php else: ?> <a href="http://localhost/monProjetBali/media/invoice/<?php echo $c4; ?>" target="_" style="color:#1da2a4">View </a>  <?php endif; ?></td>
                            <td><?php if($c3!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $c3; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>40% (2)</td>
                            <td><?php echo e(number_format($d1, 2)); ?></td>
                            <td><?php if($d2!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $d2; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                            <td><?php if($d4==""): ?><input type="file" class="form-control" style="width: 350px !important" name="a4[]" multiple /><?php else: ?> <a href="http://localhost/monProjetBali/media/invoice/<?php echo $d4; ?>" target="_" style="color:#1da2a4">View </a>  <?php endif; ?></td>
                            <td><?php if($d3!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $d3; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>15</td>
                            <td><?php echo e(number_format($e1, 2)); ?></td>
                            <td><?php if($e2!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $e2; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                            <td><?php if($e4==""): ?><input type="file" class="form-control" style="width: 350px !important" name="a4[]" multiple /><?php else: ?> <a href="http://localhost/monProjetBali/media/invoice/<?php echo $e4; ?>" target="_" style="color:#1da2a4">View </a>  <?php endif; ?></td>
                            <td><?php if($e3!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $e3; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td><?php echo e(number_format($f1, 2)); ?></td>
                            <td><?php if($f2!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $f3; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                            <td><?php if($f4==""): ?><input type="file" class="form-control" style="width: 350px !important" name="a4[]" multiple /><?php else: ?> <a href="http://localhost/monProjetBali/media/invoice/<?php echo $f4; ?>" target="_" style="color:#1da2a4">View </a>  <?php endif; ?></td>
                            <td><?php if($f3!=""): ?><a href="http://localhost/monProjetBali/media/invoice/<?php echo $f2; ?>" target="_" style="color:#1da2a4">View </a> <?php endif; ?></td>
                        </tr>
                    </tbody>

                </table> 

                <div class="col-md-12" ><button type="submit" class="btn btn-success">Save</button><br><br></div>             

              </div>
            </div>
          </div>
        </div>
      </div>     
    </div>
    </form>
  </div>
</div>
          
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/invoices.blade.php ENDPATH**/ ?>