

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-user"></i> New construction</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('suivis')); ?>" class="btn-right "><i class="fa fa-list"></i> List of constructions </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('herlindaAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="d0" class="control-label form-label label01">Design 0  </label></h6>
              <input type="text" name="d0" id="d0" class="form-control" disabled style="font-weight: bold"/>
          </div>
          <div class="col-md-4">
              <h6><label for="d1" class="control-label form-label label01">Design 1  </label></h6>
              <input type="date" name="d1" id="d1" class="form-control" disabled style="font-weight: bold"/>
          </div>
          <div class="col-md-4">
              <h6><label for="d2" class="control-label form-label label01">Design 2 </label></h6>
              <input type="date" name="d2" id="d2" class="form-control" disabled style="font-weight: bold"/>
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="d3" class="control-label form-label label01">Design 3 </label></h6>
              <input type="date" name="d3" id="d3" class="form-control" disabled style="font-weight: bold"/>
          </div>      
          <div class="col-md-4">
              <h6><label for="valide" class="control-label form-label label01">Valide  </label></h6>
              <input type="date" name="valide" id="valide" class="form-control" disabled style="font-weight: bold"/>
          </div>
          <div class="col-md-4">
              <h6><label for="landscape" class="control-label form-label label01">Landscape  </label></h6>
              <input type="date" name="landscape" id="landscape" class="form-control" disabled style="font-weight: bold"/>
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="c1" class="control-label form-label label01">C1  </label></h6>
              <input type="date" name="c1" id="c1" class="form-control" disabled style="font-weight: bold"/>
          </div>
          <div class="col-md-4">
              <h6><label for="c2" class="control-label form-label label01">C2 </label></h6>
              <input type="date" name="c2" id="c2" class="form-control" disabled style="font-weight: bold"/>
          </div>

          <div class="col-md-4">
              <h6><label for="imb" class="control-label form-label label01">IMB </label></h6>
              <input type="date" name="imb" id="imb" class="form-control" disabled style="font-weight: bold" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="dateaccept" class="control-label form-label label01">Date Accept Drawing  </label></h6>
              <input type="date" name="dateaccept" id="dateaccept" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="pricestudy" class="control-label form-label label01">Price Study  </label></h6>
              <label class="switch" for="pricestudy" >
                <input type="checkbox"  name="pricestudy" id="pricestudy">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-3">
              <h6><label for="clarif" class="control-label form-label label01">Clarif </label></h6>
              <label class="switch" for="clarif" >
                <input type="checkbox"  name="clarif" id="clarif">
                <span class="slider round"></span>
              </label>
          </div>
          <div class="col-md-3">
              <h6><label for="deal" class="control-label form-label label01">Deal </label></h6>
              <label class="switch" for="deal" >
                <input type="checkbox"  name="deal" id="deal">
                <span class="slider round"></span>
              </label>
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="dp" class="control-label form-label label01">DP  </label></h6>
              <input type="text" name="dp" id="dp" class="form-control" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add Construction</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#d0").val(""); 
    $("#d1").val(""); 
    $("#d2").val(""); 
    $("#d3").val(""); 
    $("#valide").val(""); 
    $("#landscape").val(""); 
    $("#c1").val(""); 
    $("#c2").val(""); 
    $("#mep").val(""); 
    $("#imb").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'herlindaGetArchi/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#d0").val(response['data'][0].d0); 
        $("#d1").val(response['data'][0].d1); 
        $("#d2").val(response['data'][0].d2); 
        $("#d3").val(response['data'][0].d3); 
        $("#valide").val(response['data'][0].valide); 
        $("#landscape").val(response['data'][0].landscape); 
        $("#c1").val(response['data'][0].c1); 
        $("#c2").val(response['data'][0].c2); 
        $("#mep").val(response['data'][0].mep); 
        $("#imb").val(response['data'][0].imb); 
       }
    });
  });

});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/herlindaAdd.blade.php ENDPATH**/ ?>