<?php $__env->startSection('content'); ?>





    <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-md-4">

                    <div class="breadcrumb_inner">

                        <h3>Contactez-nous</h3>

                    </div>

                </div>

            </div>

        </div>

        <div class="breadcrumb_block">

            <ul>

                <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>

                <li>Contactez-nous</li>

            </ul>

        </div>

    </div>

    <!--Contact Block-->

    <div class="contact_blocks_wrapper clv_section">

        <div class="container">

            <div class="row">

                <div class="col-lg-4 col-md-4">

                    <div class="contact_block">

                        <span></span>

                        <div class="contact_icon"><img src="<?php echo e(url('assets/images/contact_icon1.png')); ?>" alt="image" /></div>

                        <h4>Appelez-nous</h4>

                        <p>( +212 ) 537 12 34 56</p>

                        <p>( +212 ) 537 12 34 56</p>

                    </div>

                </div>

                <div class="col-lg-4 col-md-4">

                    <div class="contact_block">

                        <span></span>

                        <div class="contact_icon"><img src="<?php echo e(url('assets/images/contact_icon2.png')); ?>" alt="image" /></div>

                        <h4>email</h4>

                        <p>contact@œufmarocain.com</p>

                        <p>client@œufmarocain.com</p>

                    </div>

                </div>

                <div class="col-lg-4 col-md-4">

                    <div class="contact_block">

                        <span></span>

                        <div class="contact_icon"><img src="<?php echo e(url('assets/images/contact_icon3.png')); ?>" alt="image" /></div>

                        <h4>Adresse</h4>

                        <p>8654 Bellevue Drive</p>

                        <p>Casablanca, Maroc</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!--Contact Form-->

    <div class="contact_form_wrapper clv_section">

        <div class="container">

            <div class="row">

                <div class="col-lg-8 col-md-8">

                    <div class="contact_form_section">

                        <div class="row">

                            <div class="col-md-12 col-lg-12">

                                <h3>Contactez-nous</h3>

                            </div>

                            <form>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="first_name" class="form_field require" placeholder="Prénom" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="last_name" class="form_field require" placeholder="Nom" >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="email" class="form_field require" placeholder="Email" data-valid="email" data-error="Email should be valid." >

                                </div>

                            </div>

                            <div class="col-md-6 col-lg-6">

                                <div class="form_block">

                                    <input type="text" name="subject" class="form_field require" placeholder="Sujet" >

                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">

                                    <textarea placeholder="Message" name="message" class="form_field require" ></textarea>

                                    <div class="response"></div>

                                </div>

                            </div>

                            <div class="col-md-12 col-lg-12">

                                <div class="form_block">

                                    <button type="button" class="clv_btn submitForm" data-type="contact">Envoyer le message</button>

                                </div>

                            </div>

                            </form>

                        </div>

                    </div>

                </div>

                <div class="col-lg-4 col-md-4">

                    <div class="working_time_section">

                        <div class="timetable_block">

                            <h5>Horaires d'ouverture</h5>

                            <ul>

                                <li>

                                    <p>Lundi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Mardi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Mercredi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>jeudi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Vendredi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Samedi</p>

                                    <p>9:00 - 18:00 </p>

                                </li>

                                <li>

                                    <p>Dimanche</p>

                                    <p>Fermé</p>

                                </li>

                            </ul>

                        </div>

                        <div class="tollfree_block">

                            <h5>Contactez-nous </h5>

                            <h3>( +212 ) 537 12 34 56</h3>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div> 







<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/contact.blade.php ENDPATH**/ ?>