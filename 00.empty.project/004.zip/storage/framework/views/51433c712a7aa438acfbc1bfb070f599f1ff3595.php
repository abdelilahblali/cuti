

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Le Marché</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>Le Marché</li>
                </ul>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img" style="margin-top: -40px">
                            <img src="<?php echo e(url('pages/oeuf.jpg')); ?>" alt="image" width="100%" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>Le  <span>Marché</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <p>
                            Dés leur arrivée aux points de vente, les œufs doivent être entreposés à l’abris de toute source de chaleur à une température maximale de 15 °C ou encore mieux dans des vitrines réfrigérées à une température de 4 à 5 °C.
                            <br/><br/>
                            Les œufs peuvent être conservés dans ces conditions pendant 1 moi s s a n s détérioration de leur qualité.
                            <br/><br/>
                            I l faut toujours vérifier la date limite de consommation -DLC- qui figure sur l’étiquette apposée sur l’emballage des œufs.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\oeuf\resources\views/about2.blade.php ENDPATH**/ ?>