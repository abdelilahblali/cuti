

<?php $__env->startSection('content'); ?>
        <!--Breadcrumb-->
        <div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-4">
                        <div class="breadcrumb_inner">
                            <h3>Tout savoir sur l'œuf</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcrumb_block">
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
                    <li>Tout savoir sur l'œuf</li>
                </ul>
            </div>
        </div>

        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="about_content">
                            <div class="about_heading" style="text-align: center;">
                                <h2>Tout savoir sur <span>l'œuf</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                                <h4 style="margin-top: 15px">Les différents types de logement pour les poules pondeuses : </h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('imgs2/cage1.jpg')); ?>" alt="image" width="100%" />
                    </div>
                    <div class="col-md-7">
                       <div class="about_content" style="padding-top: 0 !important; margin-top: 0">
                            <h6 style="font-weight: bold;"><i class="fa fa-angle-right" style="color:#FEC007"></i> Les cages conventionnelles ou « en batteries » :  </h6>
                            <br/>
                            <p>
                            Permettent de regrouper 5 à 6 poules par cage de 500 cm². Les cages sont organisées en rangées superposées les unes sur les autres.
                            <br/><br/>
                            <span style="color:gray; font-style: italic; padding: 10px;   ">Avantage : Risque de maladies et de parasitisme réduit.</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top: 20px">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('imgs2/cage2.jpg')); ?>" alt="image" width="100%" />
                    </div>
                    <div class="col-md-7">
                        <div class="about_content" style="padding-top: 0 !important; margin-top: 0">
                            <h6 style="font-weight: bold;"><i class="fa fa-angle-right" style="color:#FEC007"></i> Les cages aménagées ou « enrichies   </h6>
                            <br/>
                            <p>
                            Ce sont des cages qui disposent de différents équipements mis à la disposition des poules dont un perchoir, un nid, une aire de grattage et de picotage et un dispositif de raccourcissement des griffes.
                            <br/><br/>
                            <span style="color:gray; font-style: italic; padding: 10px;    ">Avantage : encourager le comportement nature des poules.</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top: 20px">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('imgs2/cage3.jpg')); ?>" alt="image" width="100%" />
                    </div>
                    <div class="col-md-7">
                        <div class="about_content" style="padding-top: 0 !important; margin-top: 0">
                            <h6 style="font-weight: bold;"><i class="fa fa-angle-right" style="color:#FEC007"></i> Volière de ponte  </h6>
                            <br/>
                            <p>
                            Avec ce type de logement, les poules disposent d’un volume d’espace réparti sur plusieurs niveaux sous forme de plateformes avec une litière qui peut être disposée sur le plancher.
                            <br/><br/>
                            <span style="color:gray; font-style: italic; padding: 10px;  ">Avantage : permet d’assurer aux poules un environnement plus sain vu la faible contenance en matière de poussière.</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin-top: 20px">
                    <div class="col-md-5">
                        <img src="<?php echo e(url('imgs2/cage4.jpg')); ?>" alt="image" width="100%" />
                    </div>
                    <div class="col-md-7">
                        <div class="about_content" style="padding-top: 0 !important; margin-top: 0">
                            <h6 style="font-weight: bold;"><i class="fa fa-angle-right" style="color:#FEC007"></i>Système plein air   </h6>
                            <br/>
                            <p>
                            Ce type de logement est composé de deux types d’habitats : le poulailler et le parcours extérieur. Les conditions du poulailler sont similaires à celles de la volière, quant à l’espace extérieur, il doit être accessible aux poules pendant toute la journée, et doit être en grande partie recouvert de végétation.
                            <br/><br/>
                            <span style="color:gray; font-style: italic; padding: 10px;   ">Avantage : les poules peuvent profiter de la lumière naturelle et de l’air frais au cours de la journée.</span>
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>

  
        <div class="clv_about_wrapper clv_section" style="padding-top: 0">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="about_content">
                            <div class="about_heading" style="text-align: center;">
                                <h2>Catégories <span>d’œufs</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                                <h4 style="margin-top: 15px">Les différents types de logement pour les poules pondeuses : </h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="about_content" style="padding-top: 0">
                            <div class="about_heading" style="text-align: center;">
                                <ul style="text-align: left;">
                                    <li style="padding-bottom: 20px; text-align: justify;"><i class="fa fa-angle-right;" style="color:#FEC007"></i> <span style="font-weight: bold">Œufs réguliers :</span><br/>Les poules sont élevées dans des cages conventionnelles ou aménagées, et sont nourries de grains, protéines, vitamines et minéraux<li>
                                    <li style="padding-bottom: 20px; text-align: justify;"><i class="fa fa-angle-right" style="color:#FEC007"></i> <span style="font-weight: bold">Œufs biologiques :</span><br/> Les poules sont élevées suivant un système de plein air et nourries de grains, vitamines, minéraux et certifiés biologiques.<li>
                                    <li style="padding-bottom: 20px; text-align: justify;"><i class="fa fa-angle-right" style="color:#FEC007"></i> <span style="font-weight: bold">Œufs Oméga3 :</span><br/> Les poules sont élevées dans des cages conventionnelles, aménagées ou dans des systèmes d’élevage en liberté et sont nourries avec une alimentation riche en Oméga 3.<li> 
                                    <li style="padding-bottom: 10px; text-align: justify;"><i class="fa fa-angle-right" style="color:#FEC007"></i> <span style="font-weight: bold">Œufs de jeunes pondeuses :</span><br/> Les poules sont élevées dans tous types d’habitats et sont en début de cycle de ponte.<li>
                                </ul>
                                <br/>
                                <p style="font-weight: bold; text-align: left;">La couleur d’œuf, elle, dépend de la couleur de la poule pondeuse. Si cette dernière est brune l’œuf est brun et si elle est de couleur blanche l’œuf est blanc aussi.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img src="<?php echo e(url('imgs2/i01.jpg')); ?>" width="100%">
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\om\resources\views/about2.blade.php ENDPATH**/ ?>