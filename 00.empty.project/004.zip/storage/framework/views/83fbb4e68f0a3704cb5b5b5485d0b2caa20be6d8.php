<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">ASTUCES MÉNAGE</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>6 astuces de nettoyage géniales qui rendront votre ménage plus efficace</h2>
                            <br/>
                            Faire le ménage, ça reste une tâche qui ne fait pas plaisir à grand monde. Mais si on vous donne quelques solutions et astuces de ménage et de nettoyage qui promettent de simplifier GRANDEMENT votre liste de corvées? C'est déjà plus tentant, n'est-ce pas?
                            Voici 6 solutions de nettoyage/ménage qui révolutionneront votre quotidien!
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>1.  Nettoyer les éponges dans le four à micro-ondes</h2>
                            <br/>
                            Les éponges de cuisine deviennent rapidement crasseuses. Pour éviter d’en acheter tout le temps et pour prolonger leur durée de vie, il suffit de les mouiller, puis de les faire chauffer au four à micro-ondes pendant 2 minutes. Attention : il faut ensuite attendre un peu avant de les sortir. Bam! 99 % des germes auront disparus. À répéter quelques fois par semaine.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>2.  La brosse à dents pour nettoyer partout, partout</h2>
                            <br/>
                            Si vous accumulez les brosses à dents offertes par le dentiste, c’est le temps d’en utiliser une pour votre ménage! Celles-ci sont parfaites pour nettoyer les petites surfaces difficiles à atteindre, comme entre les tuiles, le clavier d’ordi, sur le bord du drain dans l'évier, autour de la robinetterie, près des poignées, sur les moulures des portes d’armoires, etc.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>3.  Décrasser la vitre du four</h2>
                            <br/>
                            Avec le temps, surtout si votre gazinière n’est pas neuve, l’espace entre les deux vitres peut s’encrasser, ce qui empêche de bien voir ce qui est en train de cuire, et c’est bien dommage 😊. Voici ce qu’il faut faire pour nettoyer cette surface facilement :
                            <br/><br/>
                            Enlever complètement le tiroir du four.
                            <br/><br/>
                            Regarder en dessous de la porte du four; il y aura des trous. C’est par là qu’il faut passer.
                            <br/><br/>
                            Prendre un support en broche pour les vêtements et l’ouvrir pour en faire un long crochet (on peut le couper avec des pinces en métal).
                            <br/><br/>
                            Attacher avec un élastique sur le bout du crochet une lingette nettoyante pour les vitres, ou encore un papier essuie-tout vaporisé avec du produit nettoyant.
                            <br/><br/>
                            Introduire le crochet par un des trous et frotter partout où c'est possible. Voilà!
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>4.  Enlever les poils d’animaux sur le tapis</h2>
                            <br/>
                            Votre chat ou votre chien perd TROP ses poils et ça se retrouve partout sur le tapis? Il n’y a qu’à prendre une raclette à vitre, et le passer sur le tapis pour enlever complètement et facilement les poils! Ce truc fonctionne aussi sur les divans et autres meubles rembourrés.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>5.  Décrasser la pomme de douche</h2>
                            <br/>
                            La pomme de douche de votre appart fonctionne super mal? C’est probablement le temps de la nettoyer. Il faut simplement remplir un sac en plastique étanche (style Ziploc) de vinaigre et l’installer autour de la pomme de douche, en l’attachant avec un élastique en caoutchouc. On laisse agir jusqu’au lendemain, puis on enlève délicatement le sac. Magic!
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>6.  Nettoyer les ronds de poêle sans effort</h2>
                            <br/>
                            Si on cuisine moindrement, on sait que les ronds de poêle deviennent pleins de graisse et de particules de nourriture hyper rapidement... Eww! Et sérieusement, personne n’a envie de les frotter à l’infini. La solution reprend un peu le même principe que celui pour la pomme de douche : il faut les faire tremper toute une nuit dans un grand sac de plastique étanche avec un peu d’ammoniaque dedans. L’ammoniaque se vend partout.
                            <br/><br/>
                            Dans ce cas-ci, pas besoin de remplir le sac parce que ce sont les vapeurs qui vont déloger la graisse et nettoyer les ronds, et non le liquide lui-même. Attention de bien sceller les sacs (ça sent fort!) et de déposer les sacs sur des plaques, si jamais il y avait une fuite. Après, on jette l’ammoniaque, on sort les ronds, on les rince sous l’eau puis on les essuie.
                            <br/><br/>
                            Propres-propres-propres! Ne pas oublier qu’il ne faut JAMAIS mélanger de l’ammoniaque avec de l’eau de Javel.
                            </div>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/blog1.blade.php ENDPATH**/ ?>