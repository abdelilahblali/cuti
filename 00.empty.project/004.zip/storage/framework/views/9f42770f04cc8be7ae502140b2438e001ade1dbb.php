

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cubes"></i> Gestion des consultations</li>
      </ol>
    
  </div>
</div>



<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
    
    <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
      <thead>
        <tr>
          <td width="150">Nom & Prénom</td>
          <td>Téléphone</td>
          <td>Email</td>
          <td>Bayti</td>
          <td width="130px"></td>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $acts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($act->nom); ?> <?php echo e($act->pren); ?></td>
            <td><?php echo e($act->tel); ?></td>
            <td><?php echo e($act->mail); ?></td>
            <td><?php echo e($act->bayti); ?></td>
            <td>

              <a href="<?php echo e(route('consuledit',[ 'ref' => $act->id ])); ?>"><button class="btn btn-xs btn-default"  style="text-align: center; width: 30px !important"><i class="fa fa-edit a-icon"></i></button></a>
              <a href="<?php echo e(route('consuldelet',[ 'ref' => $act->id ])); ?>" onclick="return confirm('Vous-êtes sûr de supprimer cette vidéo ?'); event.preventDefault(); document.getElementById('videoDelete').submit();"><button class="btn btn-xs btn-danger" style="text-align: center;width: 30px !important"><i class="fa fa-trash a-icon"></i></button></a>
              <form id="videoDelete" action="<?php echo e(route('consuldelet',[ 'ref' => $act->id ])); ?>" method="POST">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo csrf_field(); ?>
              </form>  
              
            </td>
          </tr> 
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/consultation.blade.php ENDPATH**/ ?>