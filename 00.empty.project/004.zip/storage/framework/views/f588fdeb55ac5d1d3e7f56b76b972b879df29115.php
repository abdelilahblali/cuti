

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-upload"></i> Import</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<form method="POST" action="<?php echo e(route('imported')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>



  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>File</h4>

      <div class="row">
          <div class="col-md-12">
              <input type="file" name="file" id="file" class="form-control" required style="font-weight: bold"  />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-upload" style="padding-right: 10px"></i>Import</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\mag.sales\resources\views/import.blade.php ENDPATH**/ ?>