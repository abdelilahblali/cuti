

<?php $__env->startSection('content'); ?>


<?php $__currentLoopData = $lands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-map-marker"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('land')); ?>" class="btn-right "><i class="fa fa-list"></i> List of lands </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<form method="POST" action="<?php echo e(route('landEdited',[ 'ref' => $item->ref ])); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations of land</h4>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="landcode" class="control-label form-label label01">Land code  </label></h6>
              <input type="text" name="landcode" id="landcode" class="form-control" value="<?php echo e($item->landcode); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="landname" class="control-label form-label label01">Land name  </label></h6>
              <input type="text" name="landname" id="landname" class="form-control" value="<?php echo e($item->landname); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="numberarea" class="control-label form-label label01">Number of are  </label></h6>
              <input type="text" name="numberarea" id="numberarea" class="form-control" value="<?php echo e($item->numberarea); ?>"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="leaseagreement" class="control-label form-label label01">Lease Agreement  </label></h6>
              <input type="text" name="leaseagreement" id="leaseagreement" class="form-control" value="<?php echo e($item->leaseagreement); ?>"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="datesigned" class="control-label form-label label01">Date Signed  </label></h6>
              <input type="date" name="datesigned" id="datesigned" class="form-control" value="<?php echo e($item->datesigned); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="notaryname" class="control-label form-label label01">Notary Name  </label></h6>
              <input type="text" name="notaryname" id="notaryname" class="form-control" value="<?php echo e($item->notaryname); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="procuation" class="control-label form-label label01">Procuation  </label></h6>
              <input type="text" name="procuation" id="procuation" class="form-control" value="<?php echo e($item->procuation); ?>"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="villaname" class="control-label form-label label01">Villa Name  </label></h6>
              <input type="text" name="villaname" id="villaname" class="form-control" disabled style="font-weight: bold"  value="<?php echo e($item->villaname); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="addressvilla" class="control-label form-label label01">Address Villa  </label></h6>
              <input type="text" name="addressvilla" id="addressvilla" class="form-control"  value="<?php echo e($item->addressvilla); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="coordinatevilla" class="control-label form-label label01">Coordinate Villa  </label></h6>
              <input type="text" name="coordinatevilla" id="coordinatevilla" class="form-control"  value="<?php echo e($item->coordinatevilla); ?>" />
          </div>
          <div class="col-md-3">
              <h6><label for="coordinateland" class="control-label form-label label01">Coordinate Land  </label></h6>
              <input type="text" name="coordinateland" id="coordinateland" class="form-control"  value="<?php echo e($item->coordinateland); ?>" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save</button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/landEdit.blade.php ENDPATH**/ ?>