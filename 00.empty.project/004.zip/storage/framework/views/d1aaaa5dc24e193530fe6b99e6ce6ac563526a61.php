

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section>
<div class="container">
    <h4 class="my-title">A propos de nous</h4>
    <div class="row" style="margin-top: 30px">
        <div class="col-md-12">
           
            <div class="panel panel-default">
              <div class="panel-body">
                <?php echo $u->apropos; ?>

              </div>
            </div>

        </div>
    </div>
</div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.mystore', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/mystoreAbout.blade.php ENDPATH**/ ?>