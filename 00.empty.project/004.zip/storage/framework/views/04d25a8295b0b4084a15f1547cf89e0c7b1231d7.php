<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black"><?php echo e($client); ?></span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs <?php if(Route::is('clientFolder')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder',[ 'ref' => $ref ])); ?>">Administration</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_ptpma')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_ptpma',[ 'ref' => $ref ])); ?>">PTPMA</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_land')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_land',[ 'ref' => $ref ])); ?>">Land</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_architecture',[ 'ref' => $ref ])); ?>">Architecture</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_construction')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_construction',[ 'ref' => $ref ])); ?>">Construction</a></button>
        <button class="btn btn-xs <?php if(Route::is('clientFolder_factures')): ?> active <?php endif; ?>"><a href="<?php echo e(route('clientFolder_factures',[ 'ref' => $ref ])); ?>">Factures</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 15px">Invoice</h4>

<form method="POST" action="<?php echo e(route('clientFolder_factures_updated',[ 'cli' => $ref ])); ?>" enctype="multipart/form-data" class="inline">
<?php echo e(csrf_field()); ?>


<input type="hidden" name="cli" value="<?php echo e($ref); ?>">

<div class="col-md-2" style="background: rgba(0,0,0,0.05)">Paiement</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-3">
          <h6><label for="a1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="a1" value="<?php echo e($a1); ?>" />
        </div>
        <div class="col-md-3">
          <h6><label for="a2" class="control-label form-label label01">Upload Invoice <?php if($a2!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $a2; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="a2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="a3" class="control-label form-label label01">Upload Invoice #2 <?php if($a3!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $a3; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="a3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="a4" class="control-label form-label label01"><?php if($a4!=""): ?><span>Proof document <br></span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $a4; ?>" target="_">View document</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05)">Land</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-3">
          <h6><label for="b1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="b1" value="<?php echo e($b1); ?>" />
        </div>
        <div class="col-md-3">
          <h6><label for="b2" class="control-label form-label label01">Upload Invoice <?php if($b2!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $b2; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="b2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="b3" class="control-label form-label label01">Upload Invoice #2 <?php if($b3!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $b3; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="b3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="b4" class="control-label form-label label01"><?php if($b4!=""): ?><span>Proof document <br></span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $b4; ?>" target="_">View document</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05)">40% (1)</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-3">
          <h6><label for="c1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="c1"  value="<?php echo e($c1); ?>" />
        </div>
        <div class="col-md-3">
          <h6><label for="f2" class="control-label form-label label01">Upload Invoice <?php if($c2!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $c2; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="c2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="c3" class="control-label form-label label01">Upload Invoice #2 <?php if($c3!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $c3; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="c3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="c4" class="control-label form-label label01"><?php if($c4!=""): ?><span>Proof document <br></span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $c4; ?>" target="_">View document</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05)">40% (2)</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-3">
          <h6><label for="d1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="d1"  value="<?php echo e($d1); ?>" />
        </div>
        <div class="col-md-3">
          <h6><label for="d2" class="control-label form-label label01">Upload Invoice <?php if($d2!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $d2; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="d2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="d3" class="control-label form-label label01">Upload Invoice #2 <?php if($d3!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $d3; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="d3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="d4" class="control-label form-label label01"><?php if($d4!=""): ?><span>Proof document <br></span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $d4; ?>" target="_">View document</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05)">15</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-3">
          <h6><label for="e1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="e1"  value="<?php echo e($e1); ?>" />
        </div>
        <div class="col-md-3">
          <h6><label for="e2" class="control-label form-label label01">Upload Invoice <?php if($e2!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $e2; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="e2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="e3" class="control-label form-label label01">Upload Invoice #2 <?php if($e3!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $e3; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="e3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="e4" class="control-label form-label label01"><?php if($e4!=""): ?><span>Proof document <br></span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $e4; ?>" target="_">View document</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2" style="background: rgba(0,0,0,0.05)">5</div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row">
        <div class="col-md-3">
          <h6><label for="f1" class="control-label form-label label01">Amount </label></h6>
          <input type="text" class="form-control" name="f1"  value="<?php echo e($f1); ?>" />
        </div>
        <div class="col-md-3">
          <h6><label for="f2" class="control-label form-label label01">Upload Invoice <?php if($f2!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $f2; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="f2[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="f3" class="control-label form-label label01">Upload Invoice #2 <?php if($f3!=""): ?><span style="margin:0 10px"> | </span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $f3; ?>" target="_">View document</a> <?php endif; ?></label></h6>
          <input type="file" class="form-control" name="f3[]" multiple />
        </div>
        <div class="col-md-3">
          <h6><label for="f4" class="control-label form-label label01"><?php if($f4!=""): ?><span>Proof document <br></span><a href="http://localhost/monProjetBali/media/invoice/<?php echo $f4; ?>" target="_">View document</a> <?php endif; ?></label></h6>
        </div>
      </div>
  </div>
</div>

<div class="col-md-2"></div>
<div class="col-md-10">
  <div class="panel panel-default client-content" style="padding:0px 30px 20px">
      <div class="row" style="margin-top: 20px">
        <div class="col-md-3">
          <button type="submit" class="btn btn-default btn-block">Save</button>
        </div>
      </div>
  </div>
</div>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\monProjetBali\resources\views/clientFolder_factures.blade.php ENDPATH**/ ?>