
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="" />
    <title>Oeuf Marocoain : Administration</title>
    <link href="<?php echo e(url('dash/css/root.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('dash/style.css')); ?>">
    <link rel="icon" href="<?php echo e(url('imgs/icon.png')); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Changa&amp;display=swap" rel="stylesheet">

    <?php if(\Request::is('actualiteAdd')): ?>  
    <script src="<?php echo e(url('uploadimg1/jquery.min.js')); ?>"></script>  
    <script src="<?php echo e(url('uploadimg1/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('uploadimg1/croppie.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(url('uploadimg1/croppie.css')); ?>" />
    <?php endif; ?>

    <?php if(\Request::is('galerie')): ?>  
    <script src="<?php echo e(url('uploadimg2/jquery.min.js')); ?>"></script>  
    <script src="<?php echo e(url('uploadimg2/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('uploadimg2/croppie.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(url('uploadimg2/croppie.css')); ?>" />
    <?php endif; ?>

    <?php if(\Request::is('videoAdd')): ?>  
    <script src="<?php echo e(url('uploadimg3/jquery.min.js')); ?>"></script>  
    <script src="<?php echo e(url('uploadimg3/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('uploadimg3/croppie.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(url('uploadimg3/croppie.css')); ?>" />
    <?php endif; ?>


    <?php if(\Request::is('actualiteAdd') || \Route::is('actualiteEdit')  || \Route::is('actualiteEdited')  || \Request::is('videoAdd') || \Route::is('videoEdit')  || \Route::is('videoEdited') ): ?>  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/froala_editor.css')); ?>">         
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/froala_style.css')); ?>">          
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/code_view.css')); ?>">     
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/colors.css')); ?>">        
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/emoticons.css')); ?>">     
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/image_manager.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/image.css')); ?>">         
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/line_breaker.css')); ?>">      
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/table.css')); ?>">         
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/char_counter.css')); ?>">  
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/video.css')); ?>">         
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/fullscreen.css')); ?>">            
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/file.css')); ?>">                  
    <link rel="stylesheet" href="<?php echo e(url('editor/editor/css/plugins/quick_insert.css')); ?>">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.css">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/codemirror.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.3.0/mode/xml/xml.min.js"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/froala_editor.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/align.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/char_counter.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/code_beautifier.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/code_view.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/colors.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/draggable.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/emoticons.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/entities.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/file.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/font_size.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/font_family.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/fullscreen.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/image.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/image_manager.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/line_breaker.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/inline_style.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/link.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/lists.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/paragraph_format.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/paragraph_style.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/quick_insert.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/quote.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/table.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/save.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/url.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('editor/editor/js/plugins/video.min.js')); ?>"></script>
    <script>
        $(function(){
          $('#dcr').froalaEditor()
        });
    </script>
    <script type="text/javascript" src="editor/editor/js/languages/fr.js"></script>
    <script>
      $(function() {
        $('div#dcr').froalaEditor({
          language: 'fr'
        })
      });
    </script>
    <script src="<?php echo e(url('uploadimg3/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('uploadimg3/croppie.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(url('uploadimg3/croppie.css')); ?>" />
    <?php endif; ?>



</head>
<body>
  
    <div id="top" class="clearfix">
        <div class="applogo" style="width: 250px !important; padding-top: 9px">
            <a href="<?php echo e(route('admin')); ?>" class="logo"><img src="<?php echo e(url('imgs/logo-white.png')); ?>" class="logo"></a>
        </div>
        <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-bars"></i></a>
        <div class="col-md-5">
            <div class="produits">
                <a href="<?php echo e(route('home')); ?>" class="pro2" target="_blank">Aperçu le site</a>
            </div>
        </div>
        <div class="col-md-2">
        </div>
        <ul class="top-right" style="background-color: #00aeef; padding:10px 8px">
            <li class=" link">
                <a href="#">Bienvenue <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?></a>
            </li>
        </ul>
    </div>

    <div class="sidebar clearfix">

        <!-- ---- -->
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Actualiltés</li>
        </ul>

        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('actualiteAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">Nouvelle</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('actualite')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">Liste</span></a>
          </li>
        </ul>

        <!-- ---- -->
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Galerie</li>
        </ul>

        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('galerie')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">Liste</span></a>
          </li>
        </ul>

        <!-- ---- -->
        <ul class="sidebar-panel nav nav title-nav-ul">
          <li class="title-nav">Vidéos</li>
        </ul>

        <ul class="sidebar-panel nav">
          <li>
            <a href="<?php echo e(route('videoAdd')); ?>"><span class="icon color5"><i class="fa fa-plus"></i></span>
            <span class="panel_menu">Nouvelle</span></a>
          </li>
          <li>
            <a href="<?php echo e(route('video')); ?>"><span class="icon color5"><i class="fa fa-list"></i></span>
            <span class="panel_menu">Liste</span></a>
          </li>
        </ul>

        <ul class="sidebar-panel nav" style="position: fixed; bottom: 0; background-color: red; width: 195px; margin-left: 0; padding-left: 20px">
          <li>
            <a href="<?php echo e(route('logout' )); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span class="icon color5"><i class="fa fa-power-off" style="color: white"></i></span>
            <span class="panel_menu" style="color: white">Déconnexion</span></a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>   
          </li>
        </ul>
    </div>

    <div class="content">
        <?php echo $__env->yieldContent('content'); ?> 
    </div>

    <script src="<?php echo e(url('dash/js/bootstrap/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/jquery.min.js')); ?>" type="text/javascript"></script>
<!--    <script type="text/javascript" src="<?php echo e(url('dash/js/plugins.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/bootstrap-select/bootstrap-select.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/bootstrap-toggle/bootstrap-toggle.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/bootstrap-wysihtml5/wysihtml5-0.3.0.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/bootstrap-wysihtml5/bootstrap-wysihtml5.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/summernote/summernote.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/flot-chart/flot-chart.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/flot-chart/flot-chart-time.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/flot-chart/flot-chart-stack.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/flot-chart/flot-chart-pie.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/flot-chart/flot-chart-plugin.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/chartist/chartist.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/chartist/chartist-plugin.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/easypiechart/easypiechart.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/easypiechart/easypiechart-plugin.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/sparkline/sparkline-plugin.js')); ?>">
    <script src="<?php echo e(url('dash/js/rickshaw/d3.v3.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/rickshaw/rickshaw.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/rickshaw/rickshaw-plugin.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/sweet-alert/sweet-alert.min.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/kode-alert/main.js')); ?>"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script></script> -->
    <script src="<?php echo e(url('dash/js/gmaps/gmaps.js')); ?>"></script>
    <script src="<?php echo e(url('dash/js/gmaps/gmaps-plugin.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('dash/js/date-range-picker/daterangepicker.js')); ?>"></script>


    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> #####################################-->

    <script src="<?php echo e(url('dash/js/datatables/datatables.min.js')); ?>"></script>
    <script> $(document).ready(function() { $('#tab').DataTable( { "order": [[ 1, "asc" ]] } ); } ); </script>

</body>
    
</html><?php /**PATH I:\Wamp\www\oeuf\resources\views/master/admin.blade.php ENDPATH**/ ?>