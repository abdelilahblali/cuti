<?php $__env->startSection('content'); ?>
<div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">SERVICES </h3>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<div class="clv_about_wrapper clv_section" style="padding-top: 0px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 img-about" style="padding-top: 0px">
                <div class="garden_service2_wrapper  meil-service">
                  <div class="container">




                      <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                        <div class="col-md-6" style=" padding: 0; margin-left: 0px">
                            <a href="<?php echo e(url('services2')); ?>"><img src="<?php echo e(url('imgs/services/maroc.png')); ?>" style="width: 95% !important"></a>
                        </div>

                        <div class="col-md-6" style=" padding: 0; margin-left: 0px">
                            <a href="<?php echo e(url('services2')); ?>"><img src="<?php echo e(url('imgs/services/monde.png')); ?>" style="width: 95% !important"></a>
                        </div>
                    </div>



                </div>
            </div>
        </div>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/services.blade.php ENDPATH**/ ?>