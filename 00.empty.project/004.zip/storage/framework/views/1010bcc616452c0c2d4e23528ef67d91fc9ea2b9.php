

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> New step</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('etapes')); ?>" class="btn-right "><i class="fa fa-list"></i> List of steps </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Erreur')): ?>
  <div class="alert alert-danger">
    <?php echo e(session()->get('Erreur')); ?>

  </div>
  <?php endif; ?>
</div>

<form method="POST" action="<?php echo e(route('etapesAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="vente" class="control-label form-label label01">Select a client<span class="c3_color">*</span></label></h6>
              <select name="vente" id="vente" class="form-control chzn-select" >
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vente->ref); ?>"><?php echo e($vente->cod); ?> | <?php echo e($vente->civ); ?> <?php echo e($vente->nom); ?> <?php echo e($vente->pre); ?> | <?php echo e($vente->mail); ?> | <?php echo e($vente->tel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="etape" class="control-label form-label label01">STEP  </label></h6>
              <input type="text" name="etape" id="etape" class="form-control"  />
          </div>
          <div class="col-md-3">
              <h6><label for="res1" class="control-label form-label label01">CONTRAT DE RESERVATION</label></h6>
              <select name="res1" id="res1" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="res2" class="control-label form-label label01">CONTRAT DE RESERVATION "DATE"</label></h6>
              <input type="date" name="res2" id="res2" class="form-control"  />
          </div>
          <div class="col-md-3">
              <h6><label for="part" class="control-label form-label label01">CONTRAT DE PARTENARIAT</label></h6>
              <select name="part" id="part" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="fifty" class="control-label form-label label01">5000 </label></h6>
              <select name="fifty" id="fifty" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="land1" class="control-label form-label label01">LAND : PROCURATION TERRAIN LEGALISÉE </label></h6>
              <select name="land1" id="land1" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="land2" class="control-label form-label label01">LAND : LEASE AGREEMENT</label></h6>
              <select name="land2" id="land2" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="land3" class="control-label form-label label01">LAND : PAIMENT TERRAIN</label></h6>
              <select name="land3" id="land3" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="ptpma1" class="control-label form-label label01">PTPMA : NAMA PTPMA </label></h6>
              <input type="text" name="ptpma1" id="ptpma1" class="form-control old"  />
          </div>
          <div class="col-md-3">
              <h6><label for="ptpma2" class="control-label form-label label01">PTPMA : PROCURATION LEGALISE </label></h6>
              <select name="ptpma2" id="ptpma2" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
                <option value="2">Signe</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="ptpma3" class="control-label form-label label01">AKTA</label></h6>
              <select name="ptpma3" id="ptpma3" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-3">
              <h6><label for="ptpma4" class="control-label form-label label01">IMB </label></h6>
              <select name="ptpma4" id="ptpma4" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="cons1" class="control-label form-label label01">CONTRAT CONSTRUCTION : DESIGN </label></h6>
              <input type="text" name="cons1" id="cons1" class="form-control"  />
          </div>
          <div class="col-md-4">
              <h6><label for="cons2" class="control-label form-label label01">CONTRAT CONSTRUCTION : NUMERO</label></h6>
              <input type="text" name="cons2" id="cons2" class="form-control"  />
          </div>
          <div class="col-md-4">
              <h6><label for="cons3" class="control-label form-label label01">CONTRAT CONSTRUCTION : DATE SIGNE</label></h6>
              <input type="date" name="cons3" id="cons3" class="form-control"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="buil" class="control-label form-label label01">BUILDING </label></h6>
              <input type="text" name="buil" id="buil" class="form-control"  />
          </div>
          <div class="col-md-4">
              <h6><label for="meet" class="control-label form-label label01">MEETING DECO</label></h6>
              <select name="meet" id="meet" class="form-control">
                <option value="0">Non</option>
                <option value="1">Oui</option>
              </select>
          </div>
          <div class="col-md-4">
              <h6><label for="loca" class="control-label form-label label01">LOCATION</label></h6>
              <input type="text" name="loca" id="loca" class="form-control"  />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add </button>
        </div>
      </div>
    
    </div>
  </div>

</form>

 <script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>

<script type='text/javascript'>

    $(document).ready(function(){

      // Department Change
      $('#vente_chzn').click(function(){

        $("#ptpma1").val(""); 

          var ref = $("#vente").val();

         // Empty the dropdown
         $('#client').find('option').not(':first').remove();

         // AJAX request 
         $.ajax({
            url: 'landSelectVente/'+ref,
            type: 'get',
            dataType: 'json',
            success: function(response){

            $("#ptpma1").val(response['data'][0].ref); 

             // var len = 0;
             // if(response['data'] != null){
             //   len = response['data'].length;
             // }

             // if(len > 0){
             //   // Read data and create <option >
             //   for(var i=0; i<len; i++){

             //     var ref = response['data'][i].ref;
             //     var res = response['data'][i].res;

             //     var option = "<option value='"+ref+"'>"+res+"</option>"; 

             //     $("#client").append(option); 
             //   }
             // }

           }
        });
      });

    });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/etapesAdd.blade.php ENDPATH**/ ?>