<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-calendar"></i> New day</li>
      </ol>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>

<div class="col-md-6">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('daysAdd')); ?>">
      <?php echo e(csrf_field()); ?>


      <div class="row">
          <div class="col-md-12">
              <h6><label for="typ" class="control-label form-label label01">Type <span class="c3_color">*</span></label></h6>
              <select name="typ" id="typ" class="form-control" required>
                <option><?php echo e($typ); ?></option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="dat" class="control-label form-label label01">Date <span class="c3_color">*</span></label></h6>
              <input type="date" name="dat" id="dat" class="form-control" required  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="des" class="control-label form-label label01">Designation </label></h6>
              <input type="text" name="des" id="des" class="form-control"  />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
        </div>
      </div>

    </form>
  </div>
</div>

<div class="col-md-6">
  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td>Type</td>
        <td>Date</td>
        <td>Designation</td>
        <td align="center">Options</td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><span class="bold ref"><?php echo e($day->typ); ?></span></td>
        <td><span class="bold"><?php echo e($day->dat); ?></span></td>
        <td><span class="bold"><?php echo e($day->des); ?></span></td>
        
        <td align="center">
          <a title="Delete customer" href="<?php echo e(route('daysDelete',[ 'ref' => $day->ref ])); ?>" onclick="return confirm('Are you sure you want to delete this item?'); event.preventDefault(); document.getElementById('daysDelete').submit();"><i class="fa fa-trash a-icon"></i></a>
          <form id="daysDelete" action="<?php echo e(route('daysDelete',[ 'ref' => $day->ref ])); ?>" method="POST">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
          </form>  
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/jeackel/beta.monprojetbali.com/resources/views/days.blade.php ENDPATH**/ ?>