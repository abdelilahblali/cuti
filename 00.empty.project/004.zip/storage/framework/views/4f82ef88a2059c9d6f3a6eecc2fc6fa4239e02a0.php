

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-bell"></i> Show & Edit</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('marketing')); ?>" class="btn-right "><i class="fa fa-list"></i> List of marketings </a>
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Erreur')): ?>
  <div class="alert alert-danger">
    <?php echo e(session()->get('Erreur')); ?>

  </div>
  <?php endif; ?>
</div>

<?php $__currentLoopData = $marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form method="POST" action="<?php echo e(route('marketingEdited',[ 'ref' => $etape->ref ])); ?>">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="villaname" class="control-label form-label label01">Villa name  </label></h6>
              <input type="text" name="villaname" id="villaname" class="form-control" disabled style="font-weight: bold" value="<?php echo e($etape->villaname); ?>"  />
          </div>
          <div class="col-md-3">
              <h6><label for="landsize" class="control-label form-label label01">Land size  </label></h6>
              <input type="text" name="landsize" id="landsize" class="form-control" disabled style="font-weight: bold" value="<?php echo e($etape->ares); ?>"  />
          </div>
          <div class="col-md-3">
              <h6><label for="buildingsize" class="control-label form-label label01">Building size </label></h6>
              <input type="text" name="buildingsize" id="buildingsize" class="form-control" disabled style="font-weight: bold" value="<?php echo e($etape->buildingm2); ?>"  />
          </div>
          <div class="col-md-3">
              <h6><label for="poolsize" class="control-label form-label label01">Pool Size   </label></h6>
              <input type="text" name="poolsize" id="poolsize" class="form-control" disabled style="font-weight: bold" value=""  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="bankname" class="control-label form-label label01">Bank Name  </label></h6>
              <input type="text" name="bankname" id="bankname" class="form-control" disabled style="font-weight: bold" value="<?php echo e($etape->bankname); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="banknumber" class="control-label form-label label01">Bank Number  </label></h6>
              <input type="text" name="banknumber" id="banknumber" class="form-control" disabled style="font-weight: bold" value="<?php echo e($etape->banknumber); ?>"  />
          </div>
          <div class="col-md-4">
              <h6><label for="bank" class="control-label form-label label01">bank</label></h6>
              <input type="text" name="bank" id="bank" class="form-control" disabled style="font-weight: bold" value="<?php echo e($etape->bank); ?>"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="calendareu" class="control-label form-label label01">Calendar Eu  </label></h6>
              <input type="text" name="calendareu" id="calendareu" class="form-control" value="<?php echo e($etape->calendareu); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="calendar" class="control-label form-label label01">Calendar  </label></h6>
              <input type="text" name="calendar" id="calendar" class="form-control" value="<?php echo e($etape->calendar); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="online" class="control-label form-label label01">Online  </label></h6>
              <input type="text" name="online" id="online" class="form-control" value="<?php echo e($etape->online); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="airbnb" class="control-label form-label label01">Airbnb Link  </label></h6>
              <input type="text" name="airbnb" id="airbnb" class="form-control" value="<?php echo e($etape->airbnb); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="facebook" class="control-label form-label label01">Facebook Link  </label></h6>
              <input type="text" name="facebook" id="facebook" class="form-control" value="<?php echo e($etape->facebook); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="photo" class="control-label form-label label01">Photo Link  </label></h6>
              <input type="text" name="photo" id="photo" class="form-control" value="<?php echo e($etape->photo); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="virtualtour" class="control-label form-label label01">Virtual Tour</label></h6>
              <input type="text" name="virtualtour" id="virtualtour" class="form-control" value="<?php echo e($etape->virtualtour); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="px" class="control-label form-label label01">PX  </label></h6>
              <input type="text" name="px" id="px" class="form-control" value="<?php echo e($etape->px); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="bop" class="control-label form-label label01">BOP Commun  </label></h6>
              <input type="text" name="bop" id="bop" class="form-control" value="<?php echo e($etape->bop); ?>" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="aka" class="control-label form-label label01">AKA Comission</label></h6>
              <input type="text" name="aka" id="aka" class="form-control" value="<?php echo e($etape->aka); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="magnitude" class="control-label form-label label01">Magnitude Web  </label></h6>
              <input type="text" name="magnitude" id="magnitude" class="form-control" value="<?php echo e($etape->magnitude); ?>" />
          </div>
          <div class="col-md-4">
              <h6><label for="where" class="control-label form-label label01">Where  </label></h6>
              <input type="text" name="where" id="where" class="form-control" value="<?php echo e($etape->where); ?>" />
          </div>
      </div>

    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-save" style="padding-right: 10px"></i>Save </button>
        </div>
      </div>
    
    </div>
  </div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/marketingEdit.blade.php ENDPATH**/ ?>