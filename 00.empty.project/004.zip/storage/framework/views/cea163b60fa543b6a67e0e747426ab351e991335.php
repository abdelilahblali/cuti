<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">   </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">ASTUCES SANTÉ</h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div>

                          

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>Pour soulager et guérir le rhume: le gingembre</h2>
                            <br/>
                            Pour vous décongestionner lorsque vous souffrez du rhume, procurez-vous du raifort ou du gingembre frais, râpez la racine et consommez-en une petite quantité. Pour éviter l’embarras gastrique, prenez ces plantes à la fin du repas. Buvez une tasse de tisane de gingembre. Ce rhizome contribue à bloquer la production de substances qui provoquent la congestion des bronches et la gêne respiratoire. Il contient des gingérols, composés antitussifs naturels.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>Pour soulager votre nez bouché: vapeur d’eau</h2>
                            <br/>
                            Faites bouillir de l’eau et versez-la dans un grand bol. Recouvrez votre tête d’une serviette et inhalez la vapeur par le nez pendant cinq à dix minutes. N’approchez pas de trop près votre visage de l’eau, car vous risqueriez de vous brûler la peau ou d’inhaler des vapeurs trop chaudes.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>Lavez-vous souvent les mains pour mieux vous protéger des maladies</h2>
                            <br/>
                            « Pour freiner la propagation de l’infection, le lavage des mains est probablement l’une des mesures de santé publique les plus révolutionnaires, à égalité avec la vaccination », souligne le docteur Plourde. Après tout, il suffit d’entrer en contact avec le virus du rhume ou de la grippe et de toucher ensuite ses yeux, son nez ou sa bouche pour être infecté. Les auteurs d’une revue d’études publiée en 2008 dans le British Medical Journal soulignent que le lavage des mains est beaucoup plus efficace que les antiviraux pour diminuer le risque. Cependant, il est important de bien le faire: lavez-les 20 secondes avec de l’eau chaude et du savon.
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            <h2>Un antibiotique naturel et un fortifiant pour le système immunitaire</h2>
                            <br/>
                            Ce fortifiant renforce le système immunitaire, agi comme antiviral, antibactérien, antifongique et antiparasitaire. Il est d’une aide précieuse pour combattre les infections.
                            <br/><br/>
                            Recette du fortifiant 
                            <br/><br/>
                            Vous devez porter des gants lors de la préparation, en particulier lors de la manipulation des piments forts, car les picotements dans les mains peuvent être difficiles à éliminer. Attention, son odeur est très puissante à cause du raifort frais et il peut stimuler les sinus instantanément.
                            <br/><br/>
                            Ingrédients:
                            <br/><br/>
                            700 ml de vinaigre de cidre (toujours utiliser du bio)<br/>
                            1/4 de tasse d’ail finement haché<br/>
                            1/4 de tasse d’ognon finement haché<br/>
                            2 piments frais, les plus forts que vous pouvez trouver (soyez prudent en les nettoyant, portez des gants)<br/>
                            1/4 de tasse de gingembre râpé<br/>
                            2 cuillères à soupe de raifort râpé<br/>
                            2 cuillères à soupe de curcuma ou deux morceaux de racine de curcuma
                            <br/><br/>
                            Préparation :
                            <br/><br/>
                            Mettez tous les ingrédients dans un bol et mélangez-les, à l’exception du vinaigre.
                            <br/><br/>
                            Transférez le mélange dans un bocal.
                            <br/><br/>
                            Versez du vinaigre de cidre et remplissez-le complètement.
                            <br/><br/>
                            Il est préférable que le bocal contienne 2/3 d’ingrédients secs, et remplir le reste avec du vinaigre.
                            <br/><br/>
                            Fermez bien et remuez.
                            <br/><br/>
                            Conservez le bocal dans un endroit frais et sec pendant 2 semaines. Remuez bien plusieurs fois par jour.
                            <br/><br/>
                            Après 14 jours, passez le mélange dans une passoire ou mieux, ajoutez une gaze pour bien extraire le jus.
                            <br/><br/>
                            Vous pouvez utiliser le reste des ingrédients dans les préparations alimentaires.
                            <br/><br/>
                            Votre fortifiant est prêt à l’emploi. Vous n’avez pas besoin de le garder au réfrigérateur. Il durera longtemps.

                            </div>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/blog2.blade.php ENDPATH**/ ?>