

<?php $__env->startSection('content'); ?>


<!--Breadcrumb-->
<div class="breadcrumb_wrapper" style="background: url('<?php echo e(url('pages/about.jpg')); ?>');">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="breadcrumb_inner">
                    <h3>Actualités</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb_block">
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
            <li>Actualités</li>
        </ul>
    </div>
</div>






<?php $__currentLoopData = $vids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--Blog With Sidebar-->
        <div class="blog_sidebar_wrapper clv_section blog_single_wrapper">
            <div class="container">
                <div class="row">

                    <div class="col-md-1"></div>
                    <div class="col-lg-10 col-md-10">
                        <div class="blog_left_section">
                            <div class="blog_section">
                                <div class="agri_blog_image">
                                    <h3 style="margin-bottom: 20px"><a href=""><?php echo e($vid->des); ?></a></h3>
                                    <img src="<?php echo e(url('actualites')); ?>/<?php echo e($vid->img); ?>" alt="image" class="img-fluid" />
                                </div>
                                <div class="agri_blog_content">
                                    
                                    
                                    <?php echo $vid->dcr; ?>


                                </div>
                                
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/twobcom/glurivd.com/om/resources/views/actualiteshow.blade.php ENDPATH**/ ?>