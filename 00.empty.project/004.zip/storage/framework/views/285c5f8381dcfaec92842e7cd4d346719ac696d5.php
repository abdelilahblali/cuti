

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> Gestion des catégories des produits</li>
      </ol>
     <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('categorie')); ?>" class="btn-right "><i class="fa fa-list"></i> Liste des catégories</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-6">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Danger')): ?>
  <div class="alert alert-danger">
      <?php echo e(session()->get('Danger')); ?>

  </div>
  <?php endif; ?>


  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('categorieAdded')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        	<div class="col-md-12">
            	<h6><label for="des" class="control-label form-label label01">Désignation <span class="c3_color">*</span></label></h6>
              <input type="text" name="des" class="form-control" placeholder="Désignation du produit">
        	</div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-check" style="padding-right: 10px"></i>Ajouter la catégorie </button>
        </div>
      </div>
    </form>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/categorieAdd.blade.php ENDPATH**/ ?>