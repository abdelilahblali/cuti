

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-sitemap"></i> New step</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">            
            <a href="<?php echo e(route('step')); ?>" class="btn-right "><i class="fa fa-list"></i> List of steps </a>
          </div>
      </div>
  </div>
</div>

<form method="POST" action="<?php echo e(route('stepAdded')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Client informations</h4>

      <div class="row">
          <div class="col-md-12">
              <select name="vente" id="vente" class="form-control chzn-select" data-placeholder="Select a client here">
                <option></option>
                <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo $__env->make('master.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
      </div>
    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <h4>Informations</h4>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="contratreservation" class="control-label form-label label01">Contrat Reservation  </label></h6>
              <input type="text" name="contratreservation" id="contratreservation" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-3">
              <h6><label for="contratreservationdate" class="control-label form-label label01">Date Contrat Reservation  </label></h6>
              <input type="text" name="contratreservationdate" id="contratreservationdate" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-3">
              <h6><label for="five" class="control-label form-label label01">Payment 5000€ </label></h6>
              <input type="text" name="five" id="five" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-3">
              <h6><label for="procuation" class="control-label form-label label01">Procuation   </label></h6>
              <input type="text" name="procuation" id="procuation" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="leaseagreement" class="control-label form-label label01">Lease Agreement  </label></h6>
              <input type="text" name="leaseagreement" id="leaseagreement" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-6">
              <h6><label for="terrain" class="control-label form-label label01">Payment Terrain  </label></h6>
              <input type="text" name="terrain" id="terrain" class="form-control" disabled style="font-weight: bold"  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="nameptpma" class="control-label form-label label01">Name PTPMA</label></h6>
              <input type="text" name="nameptpma" id="nameptpma" class="form-control" disabled style="font-weight: bold"  />
          </div>
          <div class="col-md-4">
              <h6><label for="akta" class="control-label form-label label01">AKTA  </label></h6>
              <input type="text" name="akta" id="akta" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="imb" class="control-label form-label label01">IMB  </label></h6>
              <input type="text" name="imb" id="imb" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-4">
              <h6><label for="design" class="control-label form-label label01">Design  </label></h6>
              <input type="text" name="design" id="design" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="contratconstruction" class="control-label form-label label01">Contrat Construction  </label></h6>
              <input type="text" name="contratconstruction" id="contratconstruction" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="contratconstructiondate" class="control-label form-label label01">Date Contrat Construction  </label></h6>
              <input type="text" name="contratconstructiondate" id="contratconstructiondate" class="form-control" />
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
              <h6><label for="four1" class="control-label form-label label01">Payment 40% (1)  </label></h6>
              <input type="text" name="four1" id="four1" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="facebook" class="control-label form-label label01">Building Progress  </label></h6>
              <input type="text" name="facebook" id="facebook" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="photo" class="control-label form-label label01">Meeting Deco  </label></h6>
              <input type="text" name="photo" id="photo" class="form-control" />
          </div>
          <div class="col-md-3">
              <h6><label for="photo" class="control-label form-label label01">Location  </label></h6>
              <input type="text" name="photo" id="photo" class="form-control" />
          </div>
      </div>


    </div>
  </div>

  <div class="col-md-12">
    <div class="panel panel-default client-content" style="padding:7px 30px 20px">

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add step</button>
        </div>
      </div>
    
    </div>
  </div>

</form>


<script type="text/javascript" src="<?php echo e(url('jquery-3.5.1.min.js')); ?>"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#villaname").val(""); 
    $("#landsize").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'landGetInfo/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#villaname").val(response['data'][0].villaname); 
        $("#landsize").val(response['data'][0].ares); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#buildingsize").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'stepGetBuilding/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#buildingsize").val(response['data'][0].buildingm2); 
       }
    });
  });

});
</script>

<script type='text/javascript'>
$(document).ready(function(){
  $('#vente_chzn').click(function(){ 
    $("#bankname").val(""); 
    $("#banknumber").val(""); 
    $("#bank").val(""); 
      var ref = $("#vente").val();
     $.ajax({
        url: 'taxeGetBank/'+ref,
        type: 'get',
        dataType: 'json',
        success: function(response){
        $("#bankname").val(response['data'][0].bankname);
        $("#banknumber").val(response['data'][0].banknumber); 
        $("#bank").val(response['data'][0].bank); 
       }
    });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/stepAdd.blade.php ENDPATH**/ ?>