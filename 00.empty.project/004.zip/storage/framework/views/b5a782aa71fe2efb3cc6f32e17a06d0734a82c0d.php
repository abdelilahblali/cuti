

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-money"></i>List of PTPMA</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <a href="<?php echo e(route('ptpmaAdd')); ?>" class="btn-right "><i class="fa fa-plus"></i> New PTPMA </a>
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  <?php if(session()->has('Validation')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Validation')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Suppression')): ?>
  <div class="alert alert-success">
    <?php echo e(session()->get('Suppression')); ?>

  </div>
  <?php endif; ?>

  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td>Sale</td>
        <td>Client</td>
        <td>Villa Name</td>
        <td>Villa Address</td>

        <td>PTPMA Name</td>
        <td>PTPMA Address</td>
        <td>PTPMA Phone</td>
        <td>PTPMA Mail</td>
        <td>PTPMA Date</td>

        <td>Fait Par / Date</td>
        <td></td>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $ptpma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><span class="bold ref"><?php echo e($item->cod); ?></span></td>
        <td><span class="bold" style="color:black"><?php echo e($item->civ); ?> <?php echo e($item->nom); ?> <?php echo e($item->pre); ?></span></td>
        <td><span class="bold "><?php echo e($item->villaname); ?></span></td>
        <td><span class="bold "><?php echo e($item->addressvilla); ?></span></td>

        <td><span class="bold ref"><?php echo e($item->ptpmaname); ?></span></td>
        <td><span class="bold "><?php echo e($item->ptpmaaddress); ?></span></td>
        <td><span class="bold "><?php echo e($item->ptpmaphone); ?></span></td>
        <td><span class="bold "><?php echo e($item->ptpmamail); ?></span></td>
        <td><span class="bold "><?php echo e($item->dateptpma); ?></span></td>

        <td><span class="bold"><?php echo e($item->par); ?>, <span style="font-size: 9px"><?php echo e($item->fait); ?></span></span></td>
        <td align="right">
          <a title="Show & Edit" href="<?php echo e(route('ptpmaEdit',[ 'ref' => $item->ref ])); ?>"><button class="btn btn-xs btn-default"><i class="fa fa-eye a-icon"></i></button></a>
          <a title="Delete" href="<?php echo e(route('ptpmaDelete',[ 'ref' => $item->ref ])); ?>" onclick="return confirm('Are you sure you want to delete this element ?'); event.preventDefault(); document.getElementById('ptpmaDelete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
          <form id="ptpmaDelete" action="<?php echo e(route('ptpmaDelete',[ 'ref' => $item->ref ])); ?>" method="POST">
            <?php echo e(method_field('DELETE')); ?>

            <?php echo csrf_field(); ?>
          </form>  
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/ptpma.blade.php ENDPATH**/ ?>