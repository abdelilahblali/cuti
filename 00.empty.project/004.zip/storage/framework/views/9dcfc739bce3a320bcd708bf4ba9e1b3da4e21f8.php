<footer>
    <div class="container" style="margin-bottom: 30px; border-bottom: 1px solid rgba(0,0,0,0.05); padding-bottom: 20px">
        <center><img src="<?php echo e(url('imgs/logo.svg')); ?>" class="logo"></center>
    </div>
    <div class="container" >
        <div class="col-md-3">
            <div class="title">Menu Spécial</div>
            <ul>
                <li><a href="#">Accueil</a></li>
                <li><a href="#">A propos</a></li>
                <li><a href="#">Guide d'utilisation</a></li>
                <li><a href="#">Espace Client</a></li>
                <li><a href="#">Contactez-nous</a></li>
            </ul>
        </div>
        <div class="col-md-3">
            <div class="title">Methodes</div>
            <ul>
                <li><a href="#">Créer un compte</a></li>
                <li><a href="#">Mot de passe oublié</a></li>
                <li><a href="#">Gestion du store</a></li>
            </ul>
        </div>
        <div class="col-md-3">
            <div class="title">Nous rejoindre</div>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Instagram</a></li>
                <li><a href="#">Whatsapp</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">Linkedin</a></li>
            </ul>
        </div>
        <div class="col-md-3">
            <div class="title">EcomBladi</div>
            <ul>
                <li><a href="#">+212 662 52 78 95</a></li>
                <li><a href="#">contact@ecombladi.com</a></li>
                <li><a href="#">www.ecombladi.com</a></li>
            </ul>
        </div>
    </div>
    <div class="copyright">
        <a href="#">EcomBladi &copy; 2020</a>
    </div>
</footer><?php /**PATH I:\Wamp\www\ecombladi\resources\views/master/footer.blade.php ENDPATH**/ ?>