<?php $__env->startSection('content'); ?>
    <div class="clv_banner_slider" style="margin-top: 169px;">
    <div class="breadcrumb_wrapper" style="background-image: url('<?php echo e(url('imgs/header-page/page.jpg')); ?>');background-position: center;  ">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <div class="breadcrumb_inner">
                <h3 style="text-shadow: 3px 3px 5px black">La gestion en toute élégance     </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="clv_about_wrapper clv_section" style="padding-top: 0px">
        <div class="container">
            <div class="row">
                <div class="col-md-12 img-about" style="padding-top: 0px">
                    <div class="garden_service2_wrapper  meil-service">
                      <div class="container">
                          <div class="row" style="margin-bottom: 50px">
                            <div class="col-md-12"  style="padding-left: 0; margin-left: 0">
                                  <h2 style="">Confiez la gestion de votre maison et de votre personnel à des Professionnels </h2>
                            </div>
                            <div class="col-md-6">
                                  <div class="lin-pink" style="margin-top: -1px !important; position: absolute; left: 0;right: 0;"></div>
                                  <div class="lin-blue" ></div>
                            </div>
                          </div> 

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-8" style=" padding: 0; margin-left: 0px">                            
                            Nos <b><span style="color:#EC008C;">hel</span><span style="color:#00AEEF ">pers</span></b> s’assurent que <b>les Gouvernantes/Majordomes</b> sélectionnés possèdent <b>toutes les qualités requises pour vous servir.</b> 
                            <br/><br/>
                            Chez <b><span style="color:#EC008C;">BAYTI</span><span style="color:#00AEEF ">HELP</span></b> <b>spécialiste du service à la Personne</b>, nous pensons qu’être <b>gouvernante/majordome</b> nécessite les compétences d'un véritable expert du service.
                            <br/><br/>
                            <b>Les gouvernantes/majordomes sont expérimentés, perfectionnés</b> tout au long de leur parcours pour répondre aux besoins de chaque client.
                            <br/><br/>
                            La gouvernante/Majordome <b>coordonne les activités de tout le personnel dans le respect du cahier des charges et du planning</b> (pour les familles nombreuses) notamment pour l’entretien du logement, du linge, les course, la gestion de vos employés de maison…
                            <br/><br/>
                            La gouvernante/majordome de maison est un personnel hautement qualifié qui offre aux familles un haut niveau de responsabilité et de services à son domicile.
                            <br/><br/>
                            La prestation de votre gestionnaire de domicile comprend: 
                            <br/><br/>
                            <ul>
                              <li>• <b>Gestion</b> du service à table du service du petit déjeuner au dîner</li>
                              <li>• <b>Gestion</b> de l'argenterie et de son entretien. </li>
                              <li>• <b>Entretien et nettoyage</b> de la porcelaine fine et cristal </li>
                              <li>• <b>Gestion</b> de la garde-robe (vêtement, cirage de chaussures, pressing...) </li>
                              <li>• <b>Préparation</b> des bagages lors des voyages </li>
                              <li>• <b>Gestion</b> de vos collections haut de gamme/luxe</li>
                              <li>• <b>S'assurer</b> et de l’inventaire de la bonne tenue des objets de valeur</li>
                              <li>• <b>Gestion</b> des décorations florales</li>
                              <li>• <b>Invitation, organisation</b> des réceptions</li>
                              <li>• <b>Accueil</b> de vos hôtes</li>
                              <li>• <b>Servir</b> des boissons et assurer le service à tout moment</li>
                              <li>• <b>Gestion</b> des appels téléphoniques et correspondances</li>
                              <li>• Responsable de l'ensemble du personnel de maison </li>
                            </ul>

                            </div>
                            <div class="col-md-4">
                              <img src="<?php echo e(url('imgs/pages/maj1.png')); ?>" style="width: 100% !important">
                              <br/>
                              <img src="<?php echo e(url('imgs/pages/maj2.png')); ?>" style="width: 100% !important">
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            C’est <b><span style="color:#EC008C;">TRÉS </span><span style="color:#00AEEF ">SIMPLE </span> :  UNE SEULE ÉTAPE ! </b>
                            <br/><br/>
                            <b><span style="color:#EC008C;">CONTACTEZ-NOUS PAR LE MOYEN QUI VOUS CONVIENT</span></b>
                            <br/>
                            <b>(Téléphone, email, formulaire site web, WhatsApp, Zoom, Skype…)</b>
                            <br/><br/>
                            <b><span style="color:#00AEEF ">ON S’OCCUPE DU RESTE</span></b>
                            </div>
                          </div>

                          <div class="row" style="text-align: justify;  color:black; margin-top: 30px;">
                            <div class="col-md-12" style=" padding: 0; margin-left: 0px">
                            Nos recruteurs :
                            <br/><br/>
                            <ol  style="margin-left: 15px; padding: 0; font-size: 16px">
                              <li style="padding-left: 10px"><b>Vérifient</b> les dossiers des employés de maison <b>(casier judiciaire, carte d’identité, adresse postale, historique professionnel, vérification des références...)</b></li>
                              <li style="padding-left: 10px"><b>Sélectionnent dans notre banque de personnel de maison enrichie et entretenue depuis plus de 12ans le COLLABORATEUR adéquat à vos besoins.</b></li>
                              <li style="padding-left: 10px"><b>Vous contactent</b> pour <b>un rendez-vous selon vos disponibilités</b>  (dans nos bureaux, via WhatsApp, Zoom, Skype…) et vous offre un <b>suivi disponible</b> jusqu’à chez vous après embauche de votre employé.</li>
                            </ol>
                            </div>
                          </div>

                          <div class="row" style="margin-bottom: 50px; margin-top: 50px">
                              <a href="<?php echo e(url('contact')); ?>"><button class="btn btn-success " style="padding: 20px 40px; width: 100%; background: #EC008C; border:0"><i class="fa fa-send" style="padding-right: 20px"></i> RESERVER VOTRE MAJORDOME/GOUVERNANTE </button></a>
                          </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\baytihelp\resources\views/majordome.blade.php ENDPATH**/ ?>