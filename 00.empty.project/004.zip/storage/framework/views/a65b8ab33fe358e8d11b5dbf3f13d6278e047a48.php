

<?php $__env->startSection('content'); ?>

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-user"></i> Add new user</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            
          </div>
      </div>
  </div>
</div>

<div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="<?php echo e(route('clientAdded')); ?>">
      <?php echo e(csrf_field()); ?>


      <div class="row">
          <div class="col-md-2">
              <h6><label for="civ" class="control-label form-label label01">Civility <span class="c3_color">*</span></label></h6>
              <select name="civ" id="civ" class="form-control">
                <option value="M.">M.</option>
                <option value="Mme">Mme</option>
              </select>
          </div>
          <div class="col-md-5">
              <h6><label for="nom" class="control-label form-label label01">Last Name <span class="c3_color">*</span></label></h6>
              <input type="text" name="nom" id="nom" class="form-control" required />
          </div>
          <div class="col-md-5">
              <h6><label for="pre" class="control-label form-label label01">First Name <span class="c3_color">*</span></label></h6>
              <input type="text" name="pre" id="pre" class="form-control" required />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="tel" class="control-label form-label label01">Phone <span class="c3_color">*</span></label></h6>
              <input type="text" name="tel" id="tel" class="form-control" required />
          </div>
          <div class="col-md-6">
              <h6><label for="mail" class="control-label form-label label01">Email <span class="c3_color">*</span></label></h6>
              <input type="email" name="mail" id="mail" class="form-control" required />
          </div>
      </div>

      <div class="row">
          <div class="col-md-6">
              <h6><label for="log" class="control-label form-label label01">Login <span class="c3_color">*</span></label></h6>
              <input type="text" name="log" id="log" class="form-control" required />
          </div>
          <div class="col-md-6">
              <h6><label for="log" class="control-label form-label label01">Password </label></h6>
              <input type="text" name="log" id="log" class="form-control" placeholder="Default Password : 123456" disabled />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add user</button>
        </div>
      </div>
    </form>
  </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\mag.sales\resources\views/clientAdd.blade.php ENDPATH**/ ?>