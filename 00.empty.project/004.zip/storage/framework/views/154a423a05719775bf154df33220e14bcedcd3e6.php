

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cogs"></i> Mise à jour les options de la boutique</li>
      </ol>
      <div class="right">
          <div class="btn-group" role="group">
            <!-- <a href="<?php echo e(route('edition')); ?>" class="btn-right "><i class="fa fa-undo"></i> Retour</a> -->
          </div>
      </div>
  </div>
</div>



<div class="col-md-9">
  <?php if(session()->has('Modification')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('Modification')); ?>

    </div>
    <?php endif; ?>
  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('themeEdited')); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        	<div class="col-md-12">
            	<h6><label for="img" class="control-label form-label label01">Selectionnez un thème <span class="c3_color">*</span></label></h6>
              <select class="form-control" name="theme">
                <option value="1">Thème 1</option>
              </select>
        	</div>
      </div>

      <div class="row" style="margin-top: 10px">
          <div class="col-md-3">
              <h6><label for="color1" class="control-label form-label label01">Couleur Primaire <span class="c3_color">*</span></label></h6>
              <input type="color" name="color1" class="form-control" value="<?php echo e(Auth::user()->color1); ?>" >
          </div>
          <div class="col-md-3">
              <h6><label for="color2" class="control-label form-label label01">Couleur Seondaire <span class="c3_color">*</span></label></h6>
              <input type="color" name="color2" class="form-control" value="<?php echo e(Auth::user()->color2); ?>" >
          </div>
          <div class="col-md-3">
              <h6><label for="color3" class="control-label form-label label01">Couleur Commander <span class="c3_color">*</span></label></h6>
              <input type="color" name="color3" class="form-control" value="<?php echo e(Auth::user()->color3); ?>" >
          </div>
          <div class="col-md-3">
              <h6><label for="color4" class="control-label form-label label01">Couleur Prix <span class="c3_color">*</span></label></h6>
              <input type="color" name="color4" class="form-control" value="<?php echo e(Auth::user()->color4); ?>" >
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-check" style="padding-right: 10px"></i>Changer le thème de la boutique </button>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="col-md-3">
  <img src="<?php echo e(url('theme/theme1.png')); ?>" width="100%">
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/options.blade.php ENDPATH**/ ?>