

<?php $__env->startSection('content'); ?>


<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-cubes"></i> Gestion des des produits</li>
      </ol>
     <div class="right">
          <div class="btn-group" role="group">
            <a href="<?php echo e(route('produit')); ?>" class="btn-right "><i class="fa fa-list"></i> Liste des produits</a>
          </div>
      </div>
  </div>
</div>



<div class="col-md-12">
  <?php if(session()->has('Modification')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('Modification')); ?>

  </div>
  <?php endif; ?>

  <?php if(session()->has('Danger')): ?>
  <div class="alert alert-danger">
      <?php echo e(session()->get('Danger')); ?>

  </div>
  <?php endif; ?>

  <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="panel panel-default client-content" style="padding:7px 30px 20px"> 
    <form method="POST" action="<?php echo e(route('produitEdited',[ 'ref' => $prod->ref ])); ?>">
      <?php echo e(csrf_field()); ?>

      <div class="row">
        	<div class="col-md-4">
            	<h6><label for="cat" class="control-label form-label label01">Catégorie <span class="c3_color">*</span></label></h6>
              <select name="cat" class="form-control" placeholder="Nom du produit">
                <option value="<?php echo e($prod->refcategorie); ?>"><?php echo e($prod->categorie); ?></option>
                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($cat->ref); ?>"><?php echo e($cat->des); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
        	</div>
          <div class="col-md-8">
              <h6><label for="des" class="control-label form-label label01">Désignation <span class="c3_color">*</span></label></h6>
              <input type="text" name="des" class="form-control" placeholder="Nom du produit" value="<?php echo e($prod->produit); ?>">
          </div>
      </div>

      <div class="row">
          <div class="col-md-2">
              <h6><label for="pri1" class="control-label form-label label01">Prix ( x1 ) <span class="c3_color">*</span></label></h6>
              <input type="text" name="pri1" class="form-control" placeholder="Prix : 1 Produit" value="<?php echo e($prod->pri1); ?>">
          </div>
          <div class="col-md-2">
              <h6><label for="pri2" class="control-label form-label label01">Prix ( x2 ) </label></h6>
              <input type="text" name="pri2" class="form-control" placeholder="Prix : 2 Produits" value="<?php echo e($prod->pri2); ?>">
          </div>
          <div class="col-md-2">
              <h6><label for="pri3" class="control-label form-label label01">Prix ( x3 ) </label></h6>
              <input type="text" name="pri3" class="form-control" placeholder="Prix : 3 Produits" value="<?php echo e($prod->pri3); ?>">
          </div>
          <div class="col-md-2">
              <h6><label for="pri4" class="control-label form-label label01">Prix ( x4 ) </label></h6>
              <input type="text" name="pri4" class="form-control" placeholder="Prix : 4 Produits" value="<?php echo e($prod->pri4); ?>">
          </div>
          <div class="col-md-2">
              <h6><label for="pri5" class="control-label form-label label01">Prix ( x5 ) </label></h6>
              <input type="text" name="pri5" class="form-control" placeholder="Prix : 5 Produits" value="<?php echo e($prod->pri5); ?>">
          </div>
      </div>

      <div class="row">
          <div class="col-md-8">
              <h6><label for="img" class="control-label form-label label01">Changer la photo produit </label></h6>
              <input type="file" name="upload_image" id="upload_image" class="form-control" />
          </div>
          <div class="col-md-4">
              <h6><label for="act" class="control-label form-label label01">Afficher dans la boutique </label></h6>
                <label class="switch"><input type="checkbox" name="act" <?php if($prod->act==1): ?> checked <?php endif; ?> ><span class="slider round"></span></label>
          </div>
      </div>

      <div class="row">
          <div class="col-md-3">
            <img src="<?php echo e(url('pro')); ?>/<?php echo e($prod->img); ?>" style="width: 150px">
          </div>
          <div class="col-md-9">
              <div id="uploaded_image"></div>
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="dcr" class="control-label form-label label01">Description <span class="c3_color">*</span></label></h6>
              <textarea name="dcr" class="form-control" placeholder="Description" rows="15" id="dcr"><?php echo e($prod->dcr); ?></textarea>
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-check" style="padding-right: 10px"></i>Modifier le produit </button>
        </div>
      </div>
    </form>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div id="uploadimageModal" class="modal" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Recadrer la photo</h4>
          </div>
          <div class="modal-body">
            <div class="row">
            <div class="col-md-8 text-center col-md-offset-2">
              <div id="image_demo" style="width:350px; margin-top:30px"></div>
            </div>
        </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-success crop_image">Enregistrer</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          </div>
      </div>
    </div>
</div>

<script>  
$(document).ready(function(){

  $image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:300,
      height:300,
      type:'square' //circle
    },
    boundary:{
      width:400,
      height:400
    }
  });

  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });

  $('.crop_image').click(function(event){
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"<?php echo e(url('uploadimg3/upload.php')); ?>",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
        }
      });
    })
  });

});  
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\ecombladi\resources\views/produitEdit.blade.php ENDPATH**/ ?>