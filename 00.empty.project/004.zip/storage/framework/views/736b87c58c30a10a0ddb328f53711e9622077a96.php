

<?php $__env->startSection('content'); ?>
        
        <div class="clv_rev_slider">
            <div id="rev_slider_149_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="snowaddon1" data-source="gallery" style="background-color:#2d3032;padding:0px;">
            <!-- START REVOLUTION SLIDER 5.4.1 fullscreen mode -->
                <div id="rev_slider_149_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
                    <ul>    <!-- SLIDE  -->
                        <li data-index="rs-407" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="2000"  data-thumb="<?php echo e(url('imgs/sld/sld1.jpg')); ?>"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1000" data-fsslotamount="7" data-saveperformance="off"  data-title="One" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                            <!-- MAIN IMAGE -->
                            <img src="<?php echo e(url('imgs/sld/sld1.jpg')); ?>"  alt="image"  data-bgposition="center center" data-kenburns="on" data-duration="2000" data-ease="Linear.easeNone" data-scalestart="130" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="6" class="rev-slidebg" data-no-retina style="background-color: rgba(0,0,0,0.8)" >
                            <!-- LAYERS -->
                            <div id="rrzm_407" class="rev_row_zone rev_row_zone_middle" style="z-index: 6;">

                            <!-- LAYER NR. 1 -->
                            <div class="tp-caption  " 
                                 id="slide-407-layer-14" 
                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 
                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                            data-width="none"
                                data-height="none"
                                data-whitespace="nowrap"
                     
                                data-type="row" 
                                data-columnbreak="2" 
                                data-basealign="slide" 
                                data-responsive_offset="on" 
                                data-responsive="off"
                                data-frames='[{"delay":10,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                data-margintop="[0,0,0,0]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['inherit','inherit','inherit','inherit']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[100,50,50,50]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[100,50,50,50]"

                                style="z-index: 6; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255, 255, 255, 1.00);">
                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption  " 
                                 id="slide-407-layer-15" 
                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 
                                 data-y="['top','top','top','top']" data-voffset="['100','100','100','100']" 
                                            data-width="none"
                                data-height="none"
                                data-whitespace="nowrap"
                     
                                data-type="column" 
                                data-responsive_offset="on" 
                                data-responsive="off"
                                data-frames='[{"delay":"+0","speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                data-columnwidth="100%"
                                data-margintop="[0,0,0,0]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 7; width: 100%;">
                            <!-- LAYER NR. 3 -->
                           
                            <!-- LAYER NR. 4 -->
                            <div class="tp-caption   tp-resizeme" 
                                 id="slide-407-layer-2" 
                                 data-x="['left','left','left','left']" data-hoffset="['0','50','0','0']" 
                                 data-y="['top','top','top','top']" data-voffset="['0','430','460','290']" 
                                            data-fontsize="['82','82','40','40']"
                                data-lineheight="['82','82','50','30']"
                                data-width="['none','100%','100%','100%']"
                                data-height="none"
                                data-whitespace="normal"
                     
                                data-type="text" 
                                data-basealign="slide" 
                                data-responsive_offset="on" 

                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'
                                data-margintop="[0,0,0,0]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['inherit','inherit','center','center']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 82px; font-weight: 700; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;color: #fec007;">Oeuf Marocain</div>
                                <!-- LAYER NR. 5 -->
                            <div class="tp-caption   tp-resizeme" 
                                 id="slide-407-layer-3" 
                                 data-x="['left','left','left','left']" data-hoffset="['100','50','0','0']" 
                                 data-y="['top','top','top','top']" data-voffset="['0','430','460','290']" 
                                            data-fontsize="['82','82','40','40']"
                                data-lineheight="['82','82','50','30']"
                                data-width="['none','100%','100%','100%']"
                                data-height="none"
                                data-whitespace="normal"
                     
                                data-type="text" 
                                data-basealign="slide" 
                                data-responsive_offset="on" 

                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'
                                data-margintop="[8,8,8,8]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['inherit','inherit','center','center']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 81px; font-weight: 300; color: rgba(255, 255, 255, 1); display: block;font-family:'Changa', sans-serif; "> ﺔﻴﺑﺮﻐﻤﻟﺍ ﺔﻀﻴﺒﻟﺍ</div>
                                
                                
                                <a href="javascript:;" target="_blank" class="tp-caption rev-btn clv_btn" 
                                 id="slide-407-layer-4" 
                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                 data-y="['bottom','bottom','top','top']" data-voffset="['30','30','30','30']" 
                                            data-width="170px"
                                data-height="none"
                                data-whitespace="nowrap"
                     
                                data-type="button" 
                                data-actions=''
                                data-basealign="slide" 
                                data-responsive_offset="off" 
                                data-responsive="off"
                                data-startslide="0" 
                                data-endslide="2" 
                                data-frames='[{"delay":1600,"speed":1000,"frame":"0","from":"y:20px;sX:1.5;sY:1.5;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"opacity:0;fb:10px;","ease":"Power4.easeOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);"}]'
                                data-textAlign="['center','center','center','center']"
                                data-margintop="[18,18,0,0]"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[35,35,35,35]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[35,35,35,35]"

                                style="z-index: 8; white-space: nowrap; font-size: 16px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:'Source Sans Pro', sans-serif;border-radius:30px 30px 30px 30px;display:inline-block;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none;">A Propos</a>
                                
                                    </div>
                                </div>
                            </div>

                            <!-- LAYER NR. 6 -->
                            <div class="tp-caption tp-shape tp-shapewrapper " 
                                 id="slide-407-layer-16" 
                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                            data-width="full"
                                data-height="full"
                                data-whitespace="normal"
                     
                                data-type="shape" 
                                data-basealign="slide" 
                                data-responsive_offset="off"    
                                data-responsive="off"
                                data-frames='[{"delay":10,"speed":2000,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                data-textAlign="['inherit','inherit','inherit','inherit']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 5;background-color:rgba(37, 37, 37, 0.7);"> </div>
                        </li>
                        <!-- SLIDE  -->
                        <li data-index="rs-408" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="2000"  data-thumb="<?php echo e(url('imgs/sld/sld2.jpg')); ?>"  data-rotate="0"  data-saveperformance="off"  data-title="Two" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                            <!-- MAIN IMAGE -->
                            <img src="<?php echo e(url('imgs/sld/sld2.jpg')); ?>"  alt="image"  data-bgposition="center center" data-kenburns="on" data-duration="20000" data-ease="Linear.easeNone" data-scalestart="130" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-offsetstart="0 0" data-offsetend="0 0" data-bgparallax="6" class="rev-slidebg" data-no-retina style="background-color: rgba(0,0,0,0.8)" >
                            <!-- LAYERS -->
                            <div id="rrzm_408" class="rev_row_zone rev_row_zone_middle" style="z-index: 6;">

                            <!-- LAYER NR. 1 -->
                            <div class="tp-caption  " 
                                 id="slide-408-layer-14" 
                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 
                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                    data-width="none"
                                    data-height="none"
                                    data-whitespace="nowrap"
                     
                                data-type="row" 
                                data-columnbreak="2" 
                                data-basealign="slide" 
                                data-responsive_offset="on" 
                                data-responsive="off"
                                data-frames='[{"delay":10,"speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                data-margintop="[0,0,0,0]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['inherit','inherit','inherit','inherit']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[100,50,50,50]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[100,50,50,50]"

                                style="z-index: 6; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: rgba(255, 255, 255, 1.00);">
                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption  " 
                                 id="slide-408-layer-15" 
                                 data-x="['left','left','left','left']" data-hoffset="['100','100','100','100']" 
                                 data-y="['top','top','top','top']" data-voffset="['100','100','100','100']" 
                                 data-width="none"
                                data-height="none"
                                data-whitespace="nowrap"
            
                                data-type="column" 
                                data-responsive_offset="on" 
                                data-responsive="off"
                                data-frames='[{"delay":"+0","speed":300,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                data-columnwidth="100%"
                                data-margintop="[0,0,0,0]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['left','left','left','left']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 7; width: 100%;">
                            <!-- LAYER NR. 3 -->
                        
                            <!-- LAYER NR. 4 -->
                            <div class="tp-caption   tp-resizeme" 
                                 id="slide-408-layer-2" 
                                 data-x="['left','left','left','left']" data-hoffset="['0','50','0','0']" 
                                 data-y="['top','top','top','top']" data-voffset="['0','430','460','290']" 
                                            data-fontsize="['82','82','40','40']"
                                data-lineheight="['82','82','50','30']"
                                data-width="['none','100%','100%','100%']"
                                data-height="none"
                                data-whitespace="normal"
                     
                                data-type="text" 
                                data-basealign="slide" 
                                data-responsive_offset="on" 

                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'
                                data-margintop="[0,0,0,0]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['inherit','inherit','center','center']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 82px; font-weight: 700; color: rgba(255, 255, 255, 1); display: block;font-family:'Source Sans Pro', sans-serif;">L’Oeuf &</div>
                                <!-- LAYER NR. 5 -->
                            <div class="tp-caption   tp-resizeme" 
                                 id="slide-408-layer-3" 
                                 data-x="['left','left','left','left']" data-hoffset="['100','50','0','0']" 
                                 data-y="['top','top','top','top']" data-voffset="['0','430','60','90']" 
                                            data-fontsize="['82','82','40','40']"
                                data-lineheight="['82','82','50','30']"
                                data-width="['none','100%','100%','100%']"
                                data-height="none"
                                data-whitespace="normal"
                     
                                data-type="text" 
                                data-basealign="slide" 
                                data-responsive_offset="on" 

                                data-frames='[{"delay":"+290","split":"chars","splitdelay":0.05,"speed":1000,"frame":"0","from":"y:40px;sX:1.5;sY:1.5;opacity:0;fb:20px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"sX:1;sY:1;opacity:0;fb:10px;","ease":"Power4.easeOut"}]'
                                data-margintop="[8,8,8,8]"
                                data-marginright="[0,0,0,0]"
                                data-marginbottom="[0,0,0,0]"
                                data-marginleft="[0,0,0,0]"
                                data-textAlign="['inherit','inherit','center','center']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"

                                style="z-index: 9; white-space: normal; font-size: 82px; line-height: 81px; font-weight: 300; color: rgba(255, 255, 255, 1); display: block;color: #fec007;font-family:'Source Sans Pro', sans-serif;">Votre Santé</div>
                                
                                
                                <a href="javascript:;" target="_blank" class="tp-caption rev-btn clv_btn" 
                                 id="slide-408-layer-4" 
                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                 data-y="['bottom','bottom','top','top']" data-voffset="['30','30','30','30']" 
                                            data-width="170px"
                                data-height="none"
                                data-whitespace="nowrap"
                     
                                data-type="button" 
                                data-actions=''
                                data-basealign="slide" 
                                data-responsive_offset="off" 
                                data-responsive="off"
                                data-startslide="0" 
                                data-endslide="2" 
                                data-frames='[{"delay":1600,"speed":1000,"frame":"0","from":"y:20px;sX:1.5;sY:1.5;opacity:0;fb:10px;","to":"o:1;fb:0;","ease":"Power4.easeOut"},{"delay":"wait","speed":1000,"frame":"999","to":"opacity:0;fb:10px;","ease":"Power4.easeOut"},{"frame":"hover","speed":"0","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;fb:0;","style":"c:rgba(0, 0, 0, 1.00);bg:rgba(255, 255, 255, 1.00);"}]'
                                data-textAlign="['center','center','center','center']"
                                data-margintop="[18,18,0,0]"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[35,35,35,35]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[35,35,35,35]"

                                style="z-index: 8; white-space: nowrap; font-size: 16px; font-weight: 400; color: rgba(255, 255, 255, 1.00);font-family:'Source Sans Pro', sans-serif;border-radius:30px 30px 30px 30px;display:inline-block;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;text-decoration: none;">A Propos</a>
                                
                                    </div>
                                </div>
                            </div>

                            <!-- LAYER NR. 6 -->
                            <div class="tp-caption tp-shape tp-shapewrapper " 
                                 id="slide-408-layer-16" 
                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                 data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                            data-width="full"
                                data-height="full"
                                data-whitespace="normal"
                     
                                data-type="shape" 
                                data-basealign="slide" 
                                data-responsive_offset="off" 
                                data-responsive="off"
                                data-frames='[{"delay":10,"speed":2000,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
                                data-textAlign="['inherit','inherit','inherit','inherit']"
                                data-paddingtop="[0,0,0,0]"
                                data-paddingright="[0,0,0,0]"
                                data-paddingbottom="[0,0,0,0]"
                                data-paddingleft="[0,0,0,0]"
                                style="z-index: 5;background-color:rgba(37, 37, 37, 0.7);"> </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="scroll_down">
                <span></span>
                <p></p>
            </div>
        </div>
      
        <div class="clv_about_wrapper clv_section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_img">
                            <img src="<?php echo e(url('assets/images/oeufs.png')); ?>" alt="image" width="570px" height="510px" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading">
                                <h2>L’Oeuf et votre <span>Santé</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <div class="para_content">
                                 <h6 style="font-weight: 900">Les bienfaits de l'oeuf</h6>
                                <p>Les bienfaits de l’œuf Les œufs sont un des aliments les plus nutritifs créés par Dame Nature. Un gros œuf contient seulement 70 calories et regorge d’éléments nutritifs. Il suffit d’inclure les œufs dans votre régime alimentaire et de laisser les faits parler d’eux-mêmes!    </p>
                               <h6 style="font-weight: 900">Pour les adultes</h6>
                               <p>Le pouvoir des protéines    Puisqu’ils contiennent 6 grammes de protéines de première qualité et 14 éléments nutriments clés, les œufs vous procurent l’énergie dont vous avez besoin. Ils représentent un excellent choix nutritif pour les gens qui mènent une vie active</p>
                            </div>
                            <div class="video_block">
                                <a href="javascript:;" class="clv_btn">Plus de détails</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_counter_wrapper clv_section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading white_heading">
                            <h3>ANPO</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline2.png')); ?>" alt="image" /></div>
                            <p>Association professionnelle au service des éleveurs<br/>de poules pondeuses au Maroc</p>
                        </div>
                    </div>
                </div>
                <div class="counter_section">
                    <div class="row">
                        <div class="col-lg-3 col-md-3">
                            <div class="counter_block">
                                <div class="counter_img">
                                    <span class="red_bg"><img src="<?php echo e(url('assets/images/counter_customer.png')); ?>" alt="image" class="img-fluid" /></span>
                                </div>
                                <div class="counter_text">
                                    <h4><span class="count_no" data-to="926" data-speed="3000">926</span><span>k+</span></h4>
                                    <h5>Clients satisfaits</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <div class="counter_block">
                                <div class="counter_img">
                                    <span class="yellow_bg"><img src="<?php echo e(url('assets/images/counter_project.png')); ?>" alt="image" class="img-fluid" /></span>
                                </div>
                                <div class="counter_text">
                                    <h4><span class="count_no" data-to="700" data-speed="3000">700</span><span>+</span></h4>
                                    <h5>K Oeufs /Jour</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <div class="counter_block">
                                <div class="counter_img">
                                    <span class="orange_bg"><img src="<?php echo e(url('assets/images/counter_branch.png')); ?>" alt="image" class="img-fluid" /></span>
                                </div>
                                <div class="counter_text">
                                    <h4><span class="count_no" data-to="200" data-speed="3000">200</span><span>+</span></h4>
                                    <h5>Succursale Mondiale</h5>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <div class="counter_block">
                                <div class="counter_img">
                                    <span class="blue_bg"><img src="<?php echo e(url('assets/images/counter_winner.png')); ?>" alt="image" class="img-fluid" /></span>
                                </div>
                                <div class="counter_text">
                                    <h4><span class="count_no" data-to="6" data-speed="3000">6</span><span>k+</span></h4>
                                    <h5>Gagnant du prix</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <style type="text/css">.fa-angle-right { color:#FEC007; padding-right: 8px  }</style>
        <div class="about_farm_wrapper clv_section" >
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="about_content">
                            <div class="about_heading"> 
                                <h2>Composition  <span>de l'œuf</span></h2>
                                <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline.png')); ?>" alt="image" /></div>
                            </div>
                            <div class="para_content" style="margin-top: 30px">
                                <ul>
                                    <li><i class="fa fa-angle-right"></i> Poids moyen de 60 g</li>
                                    <li><i class="fa fa-angle-right"></i> Le jaune constitue environ 30% du poids de l’œuf,</li>
                                    <li><i class="fa fa-angle-right"></i> Le blanc 60% et la coquille 10%.</li>
                                    <li><i class="fa fa-angle-right"></i> Le jaune se compose d’environ 50 % d’eau</li>
                                    <li><i class="fa fa-angle-right"></i> Le blanc est constitue très majoritairement d’eau </li>
                                </ul>
                                
                            </div>
                            
                            <div class="about_img_details" style="background:#FEC007; margin-top: 30px; padding: 20px 30px; width: 500px">
                                <h3 style="color:white; font-weight: bold">74% D'EAU</h3>
                                <h3 style="color:white; font-weight: bold">13% DE PROTEINES</h3>
                                <h3 style="color:white; font-weight: bold">11% DE GRAISSES</h3>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about_img">
                            <img src="<?php echo e(url('imgs/schema.png')); ?>" alt="image" style="margin-top: 30px" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_testimonial_wrapper clv_section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading white_heading">
                            <h3>Meilleures recettes oeufs</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline2.png')); ?>" alt="image" /></div>
                            <p>Avec Choumicha</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="testimonial_slider">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="testimonial_slide">
                                            <span class="rounded_quote"><img src="<?php echo e(url('assets/images/quote.png')); ?>" alt="image" /></span>
                                            <span class="bg_quote"><img src="<?php echo e(url('assets/images/bg_quote.png')); ?>" alt="image" /></span>
                                            <div class="client_img">
                                                <img src="<?php echo e(url('assets/images/choumicha.png')); ?>" alt="image" />
                                            </div>
                                            <div class="client_message">
                                                <p style="text-align: justify;">
                                                    deux émissions culinaires sur la chaine télévisée marocaine 2M. La première, s'intitulant Ch'hiwate Choumicha, est une quotidienne diffusée du lundi au vendredi, dans laquelle elle présente des recettes diverses et variées. La seconde, Ch'hiwate Bladi, diffusée tous les samedis à 13 h 15, est présentée sous forme d'un voyage gastronomique à travers les régions marocaines ; à l'aide d'un habitant de la région visitée, elle y fait découvrir les mets et spécialités locales.
                                                </p>
                                                <h3 style="text-align: right; font-size: 14px">Choumicha</h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="clv_shop_wrapper clv_section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading">
                            <h3>Recettes Choumicha</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline3.png')); ?>" alt="image" /></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="shop_slider">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <?php for($i=1; $i<=8; $i++) { ?>
                                    <div class="swiper-slide">
                                        <div class="shop_slide">
                                            <div class="item_image">
                                            <a href=""><img src="<?php echo e(url('videos/imgs/video.jpg')); ?>" width="100%"></a>
                                            </div>
                                            <h5 style="font-size: 18px;">Champignons aux œufs pochés</h5>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    
                                </div>
                            </div>
                            <span class="slider_arrow shop_left left_arrow">
                                <svg 
                                 xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink"
                                 width="10px" height="20px">
                                <path fill-rule="evenodd"  fill="rgb(226, 226, 226)"
                                 d="M0.272,10.703 L8.434,19.703 C8.792,20.095 9.372,20.095 9.731,19.703 C10.089,19.308 10.089,18.668 9.731,18.274 L2.217,9.990 L9.730,1.706 C10.089,1.310 10.089,0.672 9.730,0.277 C9.372,-0.118 8.791,-0.118 8.433,0.277 L0.271,9.274 C-0.082,9.666 -0.082,10.315 0.272,10.703 Z"/>
                                </svg>
                            </span>
                            <span class="slider_arrow shop_right right_arrow">
                                <svg 
                                 xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink"
                                 width="10px" height="20px">
                                <path fill-rule="evenodd"  fill="rgb(226, 226, 226)"
                                 d="M9.728,10.703 L1.566,19.703 C1.208,20.095 0.627,20.095 0.268,19.703 C-0.090,19.308 -0.090,18.668 0.268,18.274 L7.783,9.990 L0.269,1.706 C-0.089,1.310 -0.089,0.672 0.269,0.277 C0.627,-0.118 1.209,-0.118 1.567,0.277 L9.729,9.274 C10.081,9.666 10.081,10.315 9.728,10.703 Z"/>
                                </svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="clv_gallery_wrapper clv_section" style="background-image: url('<?php echo e(url('imgs/bg1.jpg')); ?>') !important; background-attachment: fixed;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading white_heading">
                            <h3>Notre Galerie</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline2.png')); ?>" alt="image" /></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="gallery_slider">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="gallery_slide">
                                            <div class="gallery_grid">
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img10.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img16.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img11.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img12.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img13.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img17.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img14.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="gallery_grid_item">
                                                    <div class="gallery_image">
                                                        <img src="<?php echo e(url('galery/img15.jpg')); ?>" alt="image" />
                                                        <div class="gallery_overlay">   
                                                            <a href="https://via.placeholder.com/550x550" class="view_image"><span><i class="fa fa-search" aria-hidden="true"></i></span></a>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        <div class="clv_team_wrapper clv_section" style="background: white">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6">
                        <div class="clv_heading">
                            <h3>Conseil d’Administration</h3>
                            <div class="clv_underline"><img src="<?php echo e(url('assets/images/underline3.png')); ?>" alt="image" /></div>
                            <p>Un Conseil d’Administration composé de 15 membres élus<br/>par l’Assemblée Générale Ordinaire</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="team_section">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Farid IBNKHAYAT ZOUGARI</h3>
                                                <p>Président d’honneur</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">zougari@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Abdelltif ZAIME</h3>
                                                <p>Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">zaime@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Rachid BENNIS</h3>
                                                <p>1er Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">bennis@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="team_block">
                                        <div class="team_image">
                                            <img src="<?php echo e(url('imgs/profil.jpg')); ?>" alt="image" />
                                            <div class="social_overlay">
                                            </div>
                                        </div>
                                        <div class="team_details">
                                            <div class="team_name">
                                                <h3>M. Hassan ERREIMI</h3>
                                                <p>2ème Vice Président</p>
                                                <span class="divider"></span>
                                                <a href="javascript:;">erreimi@oeufmarocaine.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Wamp\www\oeuf\resources\views/home.blade.php ENDPATH**/ ?>