<?php
 
// lang/fr/messages.php
 
return [
    'a1' => 'Accueil',
    'a2' => 'Administration',
    'a3' => 'PTPMA',
    'a4' => 'Terrain',
    'a5' => 'Architecture',
    'a6' => 'Construction',
    'a7' => 'Factures',
    'a8' => 'Historiques',
    'a9' => 'Photos',
    'a10' => 'Documents',
    'a11' => 'Contactez-nous',
    'a12' => 'Notifications',
    'a13' => 'Tout marquer comme lu',
    'a14' => 'Demander un rendez-vous',
    'a15' => 'Fermer',
    'a16' => 'Confirmer',
    'a17' => 'Besoin d\'aide ?',
    'a18' => 'Veuillez SVP remplir le nom de votre villa et le nom de PTPMA,',
    'a19' => 'cliquez ici',
];