@extends('master.admin')

@section('content')

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-upload"></i> Upload photos for all clients</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  @if(session()->has('yes'))
  <div class="alert alert-success">
    {{ session()->get('yes') }}
  </div>
  @endif

  @if(session()->has('no'))
  <div class="alert alert-success">
    {{ session()->get('no') }}
  </div>
  @endif
</div>

<script type="text/javascript" src="{{ url('jquery-3.5.1.min.js')}}"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#add').click(function(){ 
      $('#add').css('visibility', 'hidden');
      $('#load').css('visibility', 'visible');
  });
});
</script>

<div class="col-md-12">

  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="{{ route('importAllPhotosAdded') }}" enctype="multipart/form-data">
      {{ csrf_field() }}
      <div class="row">
        <div class="col-md-12">
          <h6><label for="images" class="control-label form-label label01">Choose choose the folder that contains all the subfolders <span class="c3_color">*</span></label></h6>
          <input type="file" id="folder" name="images[]" webkitdirectory multiple class="form-control" />
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success" id="add"><i class="fa fa-upload" style="padding-right: 10px"></i>Upload</button>
          <img src="{{ url('imgs/loading.gif') }}" style="width:40px; visibility: hidden;" id="load">
          <ul></ul>
        </div>
      </div>
    </form>
  </div>
</div>

<script type="text/javascript">
document.getElementById("folder").addEventListener("change", function(event) {
var output = document.querySelector("ul");
var files = event.target.files;
  for (var i=0; i<files.length; i++) {
    var item = document.createElement("li");
    item.innerHTML = files[i].webkitRelativePath;
    // output.appendChild(item);
  };
}, false);
</script>

@endsection
