<?php use \Statickidz\GoogleTranslate; ?>
<html>
<head>
	<title>Magnitude</title>
</head>

<?php
	$notif_txt1 = "Nouvelle Notification";
	$notif_txt2 = "Vous pouvez cliquer ici pour consulter votre facture";
	$notif_txt3 = "L'équipe Magnitude";

	// if($langue=='FR') {
	// 	$notif_txt1 = "Nouvelle Notification";
	// 	$notif_txt2 = "Cliquez ici pour consulter";
	// 	$notif_txt3 = "L'équipe Magnitude";
	// } if($langue=='EN') {
	// 	$source = 'fr'; $target = 'en';
	// 	$trans = new GoogleTranslate();
	//	$notif_txt1 = $trans->translate($source, $target, $notif_txt1);
	//	$notif_txt2 = $trans->translate($source, $target, $notif_txt2);
	//	$notif_txt3 = $trans->translate($source, $target, $notif_txt3);
	//	$msg = $trans->translate($source, $target, $msg);
	// }

	if($langue!='FR') {
		$source = 'fr'; $target = $langue;
	   	$trans = new GoogleTranslate();
	   	$notif_txt1 = $trans->translate($source, $target, $notif_txt1);
	   	$notif_txt2 = $trans->translate($source, $target, $notif_txt2);
	   	$notif_txt3 = $trans->translate($source, $target, $notif_txt3);
	   	$msg = $trans->translate($source, $target, $msg);
	}

?>


<body style='font-family: arial '>
	<table style='border:1px solid #e2e2e2; padding: 10px; border-radius: 6px'>
		<tr >
			<td>
				<table width='' >
					<tr >
						<td><img src='https://villa.magnitudeconstruction.com/imgs/logo.png' width='200px'></td>
					</tr>
				</table>
				
				@if($field=='a2')
					@if($langue=='FR')
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>

												Bonjour 
												<br>
												Je me permets de vous rappeler ici les divers règlements dans le processus d’investissement Magnitude :<br>
												•	Dans un premier temps, le règlement des 5000 euros vous permettant d’entamer les démarches de vente et les démarches administratives pour la création de votre société d’investissement (PT PMA). Ce paiement représente la facture numéro 1.<br>
												•	Viendra ensuite le règlement du terrain. Celui-ci intervient une fois toutes les modalités réglées et permet à la fois de bloquer le terrain choisi. C’est donc la facture numéro 2.<br>
												•	Après avoir défini et signé vos plans et designs ainsi que votre contrat de construction, je vous ferai parvenir la facture numéro 3. Celle-ci représente 40% du coût total de la construction.<br>
												•	Puis le paiement des 40% suivants, lors de la pose de la structure de la toiture permettant ainsi de s’attaquer à l’étape des finitions (second-œuvre). Ce paiement intervient généralement 4 à 6 mois après le démarrage de votre chantier et correspond à la facture numéro 4.<br>
												•	Pour anticiper la production et le transit du mobilier, une 5ème facture, d’un montant correspondant à 15 % du coût total de la construction de votre villa vous sera envoyée 1 mois approximativement avant la fin des finitions pour permettre de finaliser les derniers détails de construction et la commande des meubles et équipements de la villa.<br>
												•	La dernière facture : la facture numéro 6 vous sera communiquée après remise des clés de votre villa, que vous effectuerez sur place ou par appel vidéo et représente les 5% du coût de construction.<br>
												<br>
												Vous pourrez toujours revenir vers moi en cours de chantier afin de me demander des dates de paiement approximatives si vous souhaitez pouvoir vous organiser et anticiper vos paiements.
												<br><br>
												Ce mail marque à ce propos le démarrage de votre projet et est donc accompagné de votre facture numéro 1, un acompte de 5000 euros.
												<br><br>
												Vous pouvez nous faire parvenir ce montant par virement international, auquel cas les modalités diffèrent en fonction des banques, je vous invite à vous rapprocher de la vôtre.
												<br><br>
												Dans un second temps, lorsque votre PT PMA et le compte bancaire associés seront ouverts, vous pourrez faire parvenir vos paiement sur celui- ci. Je vous enverrai toutes ces informations en temps voulu.
												<br><br>
												Il est aussi tout à fait possible d’effectuer un virement via Wise (anciennement TransferWise), cette plateforme étant sécurisée et très ergonomique, nous vous recommandons de l’utiliser. Cette plateforme, vous permet de réduire les temps d’attente et les frais bancaires des banques classiques, généralement longs et conséquents. Elle permet aussi de figer le taux de change au moment du transfert.
												<br><br>
												Voici un lien vidéo expliquant son fonctionnement : https://youtu.be/70CimtSGwbo
												<br><br>
												Afin de bien traiter vos opérations bancaires, il est très important de nous faire parvenir vos preuves de paiement. Une capture d’écran de votre application bancaire ou un email de votre banque peuvent suffirent. La preuve d’émission du transfert envoyé par votre banque reste le meilleur support d’information pour nous. En effet, je suis accompagné d’une équipe indonésienne, il devient très difficile pour mon équipe de retrouver des virements si ceux-ci n’ont pas pour objet votre nom et votre motif de paiement. Pour faciliter la lecture de l’opération bancaire, nous envoyer la preuve de transfert est impératif
												<br><br>
												Une fois votre paiement reçu, je vous contacterai par email pour vous faire part de sa bonne réception.
												<br><br>
												Si vous souhaitez payer à plusieurs en divisant la somme entre plusieurs personnes, je n’y vois aucun inconvénient dans la mesure où vous me ferez parvenir toutes les preuves de paiements et m’informerez du nombre de transferts ainsi que de leurs montants.
												<br><br>
												Je reste à votre disposition par mail ou sur WhatsApp pour toute information complémentaire.
												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												En vous souhaitant une excellente journée!<br>
												Bien Cordialement,
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80571
												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@else
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Hello
												<br><br>
												I will be in touch with you during the time of your project regarding its payment and any questions about its financial aspects.
												<br><br>
												But first, let us review the milestones of this project, money-wise. 
												<br><br>
												First, a payment of 5.000 euros enabling us to start the sales process and land research. 
												<br><br>
												This payment is the invoice number 1. 
												<br><br>
												Then comes the payment for the land for which these 5.000 euros are deducted. This one is due once all the modalities have been settled with me and my team and allow us to secure the chosen land and start the administrative procedures for the creation of your investment company (PT PMA). This is therefore invoice number 2. 
												<br><br>
												After having defined and signed your drawings and designs through Séverine our architect as well as your construction contract with me, I will send you the invoice number 3. This represents 40% of the total cost of the construction of your villa. This payment is very important because it defines the date of delivery of the contract in accordance with the agreement established with Magnitude. 
												<br><br>
												Then the payment of the following 40%, corresponding to the completion of the roof and structure of the villa, this making possible to tackle the finishing stage (finishing works). This payment is generally made 4 to 6 months after the start of your worksite, and it is invoice number 4.
												<br><br>
												At the end of the finishing stage, a 5th invoice, for an amount corresponding to 15% of the total cost of the construction of your villa will be sent to you in order to finalize the final construction details and order the furniture and equipment of the villa.
												<br><br>
												The last invoice: invoice number 6 will be communicated to you after handing over the keys to your villa, which you will do on-site or by video call, and represents 5% of the construction cost.
												<br><br>
												As your site contact, I will regularly inform you of the progress of your project and will communicate with you concerning the main stages of it. You will therefore have a better overview of the progress of your villa, linked to the invoices that I will send you. Also remember to follow the progress of your project on the "Mon Projet Bali" platform in your dedicated space.
												<br><br>
												You can always come back to me at any time during the time of your worksite to ask me for approximate payment dates if you want to anticipate them.
												<br><br>
												So, as explained above, this email marks the start of your project in this regard and is therefore accompanied by your invoice number 1, a deposit of 5.000 euros.
												<br><br>
												You can send us this payment through an international transfer for which the terms of payments may differ depending on your bank, and thus I suggest that you ask your banker about your bank specifics terms.
												<br><br>
												Here are the bank details of our company :
												<br><br>
												Name :  PT MAGNITUDE CONSTRUCTION BALI<br>
												Name of bank : PT BANK DANAMON INDONESIA Tbk<br>
												Address : JL. RAYA UBUD - UBUD GIANYAR - BALI INDONESIA <br>
												Account number : 3623730722<br>
												Swift code : BDINIDJA 
												<br><br>
												It is also possible to pay through Wise (previously TransferWise), this secured website is easy to use and allows you to reduce the bank fees and waiting times. In addition, you can freeze the rate exchange to the current one at the time of your payment.
												<br><br>
												Here is a link where you can learn more about Wise: https://youtu.be/MLKKzRvOsLQ
												<br><br>
												In order to process your bank transactions, it is essential to send us your payment receipts. A screenshot of your mobile banking app or a document from your bank can do. An official bank statement still is the best medium for me. My team and I need these details attached to your name and subject of the transfer to organize these data and thus be up to date on your project progress.
												<br><br>
												Once we receive your payment, I will send you an email to notify you. If you wish to divide the sum between numerous people, it is totally possible as long as you send me all the detailed payment receipts with the number of transfer and their amounts.
												<br><br>
												I encourage you to contact me if you have any questions regarding the accounting and the payment of your project and remain at your entire disposal for further information.
												<br><br>
												I remain at your disposal by email or WhatsApp for any further information.
												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												Wishing you a good day,<br>
												Best regards.
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80 571
												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@endif
				@endif

				@if($field=='b2')
					@if($langue=='FR')
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Bonjour,
												<br><br>
												Je vous écris aujourd’hui dans le but de régler l’achat de votre terrain. Vous avez à ce jour validé toutes les modalités nécessaires à cette acquisition.
												<br><br>
												Ce paiement correspond à la 2ème facture de votre projet.
												<br><br>
												Il est aussi tout à fait possible d’effectuer un virement via Wise (anciennement TransferWise), cette plateforme étant sécurisée et très ergonomique, nous vous recommandons de l’utiliser. Cette plateforme, vous permet de réduire les temps d’attente et les frais bancaires des banques classiques, généralement longs et conséquents. Elle permet aussi de figer le taux de change au moment du transfert. 
												<br><br>
												Voici un lien vidéo expliquant son fonctionnement : https://youtu.be/70CimtSGwbo  
												<br><br>
												Afin de bien traiter vos opérations bancaires, il est très important de nous faire parvenir vos preuves de paiement. Une capture d’écran de votre application bancaire ou un email de votre banque peuvent suffirent. La preuve d’émission du transfert envoyé par votre banque reste le meilleur support d’information pour nous. En effet, je suis accompagné d’une équipe indonésienne, il devient très difficile pour mon équipe de retrouver des virements si ceux-ci n’ont pas pour objet votre nom et votre motif de paiement. Pour faciliter la lecture de l’opération bancaire, nous envoyer la preuve de transfert est impératif. 
												<br><br>
												Une fois votre paiement reçu, je vous contacterai par email pour vous faire part de sa bonne réception.
												<br><br>
												Si vous souhaitez payer à plusieurs en divisant la somme entre plusieurs personnes, je n’y vois aucun inconvénient dans la mesure où vous me ferez parvenir toutes les preuves de paiements et m’informerez du nombre de transferts ainsi que de leurs montants. 
												<br><br>
												Je vous invite à me contacter pour toute question ou inquiétude concernant la comptabilité et le paiement de votre projet.
												<br><br>
												Je reste à votre disposition par mail ou sur WhatsApp pour toute information complémentaire.
												<br><br>
												Paul BOYER - Administration et Communication Manager
												+62 812 3792 1435
												<br><br>
												En vous souhaitant une excellente journée!<br>
												Bien Cordialement,
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80571
												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@else
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Hello,
												<br><br>
												I am pleased that you could find the land that suited your needs!
												<br><br>
												During the time of your worksite, I will be sending you the invoices of your project and will be here to answer any questions about the financial aspect of it.
												<br><br>
												I am writing to you today concerning the payment of this land. You already confirmed with me the administrative side to create your investment company (PT PMA) and lease this land. The 5.000 euros you previously sent us are deducted from the price of the land on this invoice.
												<br><br>
												This payment is the 2nd invoice of your project.
												<br><br>
												You can send us this payment through an international transfer for which the terms of payments may differ depending on your bank, and thus I suggest that you ask your banker about your bank specifics terms.
												<br><br>
												It is also possible to pay through Wise (previously TransferWise), this secured website is easy to use and allows you to reduce the bank fees and waiting times. In addition, you can freeze the rate exchange to the current one at the time of your payment.
												<br>
												Here is a link where you can learn more about Wise: https://youtu.be/MLKKzRvOsLQ
												<br><br>
												In order to process your bank transactions, it is essential to send us your payment receipts. A screenshot of your mobile banking app or a document from your bank can do. An official bank statement still is the best medium for me. My team and I need these details attached to your name and subject of the transfer to organize these data and thus be up to date on your project progress.
												<br><br>
												Once we receive your payment, I will send you an email to notify you. If you wish to divide the sum between numerous people, it is totally possible as long as you send me all the detailed payment receipts with the number of transfer and their amounts.
												<br><br>
												I encourage you to contact me if you have any question regarding the accounting and the payment of your project and remain at your entire disposal for further information.
												<br><br>
												I remain at your disposal by email or WhatsApp for any further information.
												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												Wishing you a good day,<br>
												Best regards.
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80 571

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@endif
				@endif

				@if($field=='c2')
					@if($langue=='FR')
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Bonjour, 
												<br><br>
												Je vous écris aujourd’hui dans le but de régler le premier acompte de 40% du coût total de la construction de votre villa, permettant ainsi le démarrage de votre chantier dans les plus brefs délais possibles.
												<br><br>
												Ce paiement correspond à la facture 3 de votre projet.  Conformément au contrat de construction.
												<br><br>
												Vous pouvez nous faire parvenir ce montant par virement international, auquel cas les modalités diffèrent en fonction des banques, je vous invite à vous rapprocher de la vôtre. 
												<br><br>
												Il est aussi tout à fait possible d’effectuer un virement via Wise(anciennement TransferWise), cette plateforme étant sécurisée et très ergonomique, nous vous recommandons de l’utiliser. Cette plateforme, vous permet de réduire les temps d’attente et les frais bancaires des banques classiques, généralement longs et conséquents. Elle permet aussi de figer le taux de change au moment du transfert. 
												<br><br>
												Voici un lien vidéo expliquant son fonctionnement : https://youtu.be/70CimtSGwbo  
												<br><br>
												Afin de bien traiter vos opérations bancaires, il est très important de nous faire parvenir vos preuves de paiement. Une capture d’écran de votre application bancaire ou un email de votre banque peuvent suffirent. La preuve d’émission du transfert envoyé par votre banque reste le meilleur support d’information pour nous. En effet, je suis accompagné d’une équipe indonésienne, il devient très difficile pour mon équipe de retrouver des virements si ceux-ci n’ont pas pour objet votre nom et votre motif de paiement. Pour faciliter la lecture de l’opération bancaire, nous envoyer la preuve de transfert est impératif. 
												<br><br>
												Une fois votre paiement reçu, je vous contacterai par email pour vous faire part de sa bonne réception.
												<br><br>
												Si vous souhaitez payer à plusieurs en divisant la somme entre plusieurs personnes, je n’y vois aucun inconvénient dans la mesure où vous me ferez parvenir toutes les preuves de paiements et m’informerez du nombre de transferts ainsi que de leurs montants. 
												<br><br>
												Je vous invite à me contacter pour toute question ou inquiétude concernant la comptabilité et le paiement de votre projet.
												<br><br>
												Je reste à votre disposition par mail ou sur WhatsApp pour toute information complémentaire.
												<br><br>
												Paul BOYER - Administration et Communication Manager
												+62 812 3792 1435
												<br><br>
												En vous souhaitant une excellente journée!<br>
												Bien Cordialement,<br>
												<br><br>
												Magnitude Construction
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80571

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@else
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Hello,
												<br><br>
												I am to congratulate you in completing the design of your villa!
												<br><br>
												I am writing to you today concerning the payment of 40% of the total cost of your villa. This payment is very important since it marks the beginning of the worksite and therefore defines the date of delivery of the contract in accordance with the agreement established with Magnitude.
												<br><br>
												As your site contact, we will regularly inform you of the progress of your project and I will communicate with you concerning the main stages of it. You will therefore have a better overview of the progress of your villa, linked to the invoices that I will send you. Also, remember to follow the progress of your project on the "Mon Projet Bali" platform in your dedicated space.
												<br><br>
												This payment is the 3th invoice of your project. <br>
												You can send us this payment through an international transfer for which the terms of payments may differ depending on your bank, and thus I suggest that you ask your banker about your bank specifics terms.
												<br><br>
												It is also possible to pay through Wise (previously TransferWise), this secured website is easy to use and allows you to reduce the bank fees and waiting times. In addition, you can freeze the rate exchange to the current one at the time of your payment.<br>
												Here is a link where you can learn more about Wise : https://youtu.be/MLKKzRvOsLQ
												<br><br>
												In order to process your bank transactions, it is essential to send us your payment receipts. A screenshot of your mobile banking app or a document from your bank can do. An official bank statement still is the best medium for me. My team and I need these details attached to your name and subject of the transfer to organize these data and thus be up to date on your project progress.
												<br><br>
												Once we receive your payment, I will send you an email to notify you. If you wish to divide the sum between numerous people, it is totally possible as long as you send me all the detailed payment receipts with the number of transfer and their amounts.
												<br><br>
												I encourage you to contact me if you have any question regarding the accounting and the payment of your project and remain at your entire disposal for further information.
												<br><br>
												I remain at your disposal by email or WhatsApp for any further information.
												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												Wishing you a good day,<br>
												Best regards.
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80 571
	

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@endif
				@endif

				@if($field=='d2')
					@if($langue=='FR')
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Bonjour ,
												<br><br>
												Je vous écris aujourd’hui dans le but de régler le second acompte de 40% du coût total de la construction de votre villa, afin de poursuivre les travaux. 
												<br><br>
												Ce paiement correspond à la 4ème facture de votre projet. Conformément au contrat de construction.
												<br><br>
												Vous pouvez nous faire parvenir ce montant par virement international, auquel cas les modalités diffèrent en fonction des banques, je vous invite à vous rapprocher de la vôtre. 
												<br><br>
												Il est aussi tout à fait possible d’effectuer un virement via Wise (anciennement TransferWise), cette plateforme étant sécurisé et très ergonomique, nous vous recommandons de l’utiliser. Cette plateforme, vous permet de réduire les temps d’attente et les frais bancaire des banques classiques, généralement longs et conséquents. Elle permet aussi de figer le taux de change au moment du transfert. 
												<br><br>
												Voici un lien vidéo expliquant son fonctionnement : https://youtu.be/70CimtSGwbo
												<br><br>
												Afin de bien traiter vos opérations bancaires, il est très important de nous faire parvenir vos preuves de paiement. Une capture d’écran de votre application bancaire ou un email de votre banque peuvent suffirent. La preuve d’émission du transfert envoyé par votre banque reste le meilleur support d’information pour nous. En effet, je suis accompagné d’une équipe indonésienne, il devient très difficile pour mon équipe de retrouver des virements si ceux-ci n’ont pas pour objet votre nom et votre motif de paiement. Pour faciliter la lecture de l’opération bancaire, nous envoyer la preuve de transfert est impératif. 
												<br><br>
												Une fois votre paiement reçu, je vous contacterai par email pour vous faire part de sa bonne réception.
												<br><br>
												Si vous souhaitez payer à plusieurs en divisant la somme entre plusieurs personnes, je n’y vois aucun inconvénient dans la mesure où vous me ferez parvenir toutes les preuves de paiements et m’informerez du nombre de transferts ainsi que de leurs montants. 
												<br><br>
												Je vous invite à me contacter pour toute question ou inquiétude concernant la comptabilité et le paiement de votre projet.
												<br><br>
												Je reste à votre disposition par mail ou sur WhatsApp pour toute information complémentaire.

												<br><br>
												Paul BOYER - Administration et Communication Manager
												+62 812 3792 1435
												<br><br>
												En vous souhaitant une excellente journée!<br>
												Bien Cordialement,<br>
												<br><br>
												Magnitude Construction
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80571

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@else
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Hello
												<br><br>
												I come with good news: your project is reaching 50% of its completion.
												<br><br>
												The roof and the structure are done, now let us start with the finishing !
												<br><br>
												I am writing to you today concerning the payment of 40% of the total cost of your villa, in order to pursue these works.
												<br><br>
												This payment is the 4th invoice of your project. 
												<br><br>
												You can send us this payment through international transfer for which the terms of payments may differ depending on your bank, and thus I suggest that you ask your banker about your bank specifics terms.
												<br><br>
												It is also possible to pay through Wise (previously TransferWise), this secured website is easy to use and allows you to reduce the bank fees and waiting times. In addition, you can freeze the rate exchange to the current one at the time of your payment.
												<br><br>
												Here is a link where you can learn more about Wise :https://youtu.be/MLKKzRvOsLQ
												<br><br>
												In order to process your bank transactions, it is essential to send us your payment receipts. A screenshot of your mobile banking app or a document from your bank can do. An official bank statement still is the best medium for me. My team and I need these details attached to your name and subject of the transfer to organise these data and thus be up to date on your project progress.
												<br><br>
												Once we receive your payment, I will send you an email to notify you. If you wish to divide the sum between numerous people, it is totally possible as long as you send me all the detailed payment receipts with the number of transfer and their amounts.
												<br><br>
												I encourage you to contact me if you have any question regarding the accounting and the payment of your project and remain at your entire disposal for further information.
												<br><br>
												I remain at your disposal by email or WhatsApp for any further information.

												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												Wishing you a good day,<br>
												Best regards.
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80 571
	

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@endif
				@endif

				@if($field=='e2')
					@if($langue=='FR')
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Bonjour,
												<br><br>
												Nous sommes sur la dernière ligne droite de la construction de votre villa.
												<br><br>
												Pour optimiser au mieux la production et le transit du mobilier de votre villa et l’achat des équipements, je vous écris aujourd’hui dans le but de régler cette cinquième facture représentant  15% du coût total de la construction de votre villa, afin de finaliser les travaux.
												<br><br>
												Ce paiement correspond à la 5ème facture de votre projet. Conformément au contrat de construction.
												<br><br>
												Vous pouvez nous faire parvenir ce montant par virement international, auquel cas les modalités diffèrent en fonction des banques, je vous invite à vous rapprocher de la vôtre. 
												<br><br>
												Il est aussi tout à fait possible d’effectuer un virement via Wise (anciennement TransferWise), cette plateforme étant sécurisée et très ergonomique, nous vous recommandons de l’utiliser. Cette plateforme, vous permet de réduire les temps d’attente et les frais bancaires des banques classiques, généralement longs et conséquents. Elle permet aussi de figer le taux de change au moment du transfert. 
												<br><br>
												Voici un lien vidéo expliquant son fonctionnement : https://youtu.be/70CimtSGwbo 
												<br><br>
												Afin de bien traiter vos opérations bancaires, il est très important de nous faire parvenir vos preuves de paiement. Une capture d’écran de votre application bancaire ou un email de votre banque peuvent suffirent. La preuve d’émission du transfert envoyé par votre banque reste le meilleur support d’information pour nous. En effet, je suis accompagné d’une équipe indonésienne, il devient très difficile pour mon équipe de retrouver des virements si ceux-ci n’ont pas pour objet votre nom et votre motif de paiement. Pour faciliter la lecture de l’opération bancaire, nous envoyer la preuve de transfert est impératif. 
												<br><br>
												Une fois votre paiement reçu, je vous contacterai par email pour vous faire part de sa bonne réception.
												<br><br>
												Si vous souhaitez payer à plusieurs en divisant la somme entre plusieurs personnes, je n’y vois aucun inconvénient dans la mesure où vous me ferez parvenir toutes les preuves de paiements et m’informerez du nombre de transferts ainsi que de leurs montants. 
												<br><br>
												Je vous invite à me contacter pour toute question ou inquiétude concernant la comptabilité et le paiement de votre projet.
												<br><br>
												Je reste à votre disposition par mail ou sur WhatsApp pour toute information complémentaire.


												<br><br>
												Paul BOYER - Administration et Communication Manager
												+62 812 3792 1435
												<br><br>
												En vous souhaitant une excellente journée!<br>
												Bien Cordialement,<br>
												<br><br>
												Magnitude Construction
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80571

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@else
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Hello,
												<br><br>
												The finishing phase is almost over and all that remains is to furnish and settle the final details.
												<br><br>
												I am writing to you about this today so as to settle the third deposit – of 15% of the total construction cost of your villa – in order to finalize the works.
												<br><br>
												This payment is linked to the 5th invoice of your project. The price of your villa is XXX euros according to the construction contract, so this invoice amounts to a sum of XXX euros.
												<br><br>
												It is also possible to pay through Wise (previously TransferWise), this secured website is easy to use and allows you to reduce the bank fees and waiting times. In addition, you can freeze the rate exchange to the current one at the time of your payment.
												<br><br>
												Here is a link where you can learn more about Wise : https://youtu.be/MLKKzRvOsLQ
												<br><br>
												In order to process your bank transactions, it is essential to send us your payment receipts. A screenshot of your mobile banking app or a document from your bank can do. An official bank statement still is the best medium for me. My team and I need these details attached to your name and subject of the transfer to organize these data and thus be up to date on your project progress.
												<br><br>
												Once we receive your payment, I will send you an email to notify you. If you wish to divide the sum between numerous people, it is totally possible as long as you send me all the detailed payment receipts with the number of transfer and their amounts.
												<br><br>
												I encourage you to contact me if you have any questions regarding the accounting and the payment of your project and remain at your entire disposal for further information.
												<br><br>
												I remain at your disposal by email or WhatsApp for any further information.

												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												Wishing you a good day,<br>
												Best regards.
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80 571
	

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@endif
				@endif

				@if($field=='f2')
					@if($langue=='FR')
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Bonjour,
												<br><br>
												Je vous écris aujourd’hui pour vous faire parvenir votre dernière facture. C’est le moment de nous faire parvenir le règlement des derniers 5% du coût total de la construction de votre villa.
												<br><br>
												Vous avez surement été contacté par nos collègues de l’équipe de gestion pour préparer les modalités de mise en location de votre villa et j’espère que vous êtes heureux de votre expérience Magnitude.  
												<br><br>
												Celle-ci sera très prochainement mise en ligne et je vous encourage à vous rapprocher de l’équipe de gestion si vous désirez plus d’informations à ce sujet.
												<br><br>
												Ce paiement correspond à la 6ème facture de votre projet. Conformément au contrat de construction.
												<br><br>
												Vous pouvez nous faire parvenir ce montant par virement international, auquel cas les modalités diffèrent en fonction des banques, je vous invite à vous rapprocher de la vôtre. 
												<br><br>
												Il est aussi tout à fait possible d’effectuer un virement via Wise (anciennement TransferWise), cette plateforme étant sécurisé et très ergonomique, nous vous recommandons de l’utiliser. Cette plateforme, vous permet de réduire les temps d’attente et les frais bancaire des banques classiques, généralement longs et conséquents. Elle permet aussi de figer le taux de change au moment du transfert. 
												<br><br>
												Voici un lien vidéo expliquant son fonctionnement : https://youtu.be/70CimtSGwbo
												<br><br>
												Afin de bien traiter vos opérations bancaires, il est très important de nous faire parvenir vos preuves de paiement. Une capture d’écran de votre application bancaire ou un email de votre banque peuvent suffirent. La preuve d’émission du transfert envoyé par votre banque reste le meilleur support d’information pour nous. En effet, je suis accompagné d’une équipe indonésienne, il devient très difficile pour mon équipe de retrouver des virements si ceux-ci n’ont pas pour objet votre nom et votre motif de paiement. Pour faciliter la lecture de l’opération bancaire, nous envoyer la preuve de transfert est impératif. 
												<br><br>
												Une fois votre paiement reçu, je vous contacterai par email pour vous faire part de sa bonne réception.
												<br><br>
												Si vous souhaitez payer à plusieurs en divisant la somme entre plusieurs personnes, je n’y vois aucun inconvénient dans la mesure où vous me ferez parvenir toutes les preuves de paiements et m’informerez du nombre de transferts ainsi que de leurs montants. 
												<br><br>
												Je vous invite à me contacter pour toute question ou inquiétude concernant la comptabilité et le paiement de votre projet.
												<br><br>
												Je reste à votre disposition par mail ou sur WhatsApp pour toute information complémentaire.

												<br><br>
												Paul BOYER - Administration et Communication Manager
												+62 812 3792 1435
												<br><br>
												En vous souhaitant une excellente journée!<br>
												Bien Cordialement,<br>
												<br><br>
												Magnitude Construction
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80571

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@else
						<table style='padding: 6px '>
							<tr>
								<td>
									<table width='1200px' >
										<tr >
											<td width='100%' style='padding: 0px 6px; font-weight: normal;'>
												Hello,
												<br><br>
												I am pleased to announce that the construction of your villa is complete. You have surely been contacted by my colleague Magali to collect the keys to your villa and I hope you are happy with your Magnitude experience.
												<br><br>
												I am writing to you today to send you your latest invoice. Now is the time to send us payment for the last 5% of the total cost of building your villa.
												<br><br>
												This will be posted on the Airbnb platform very soon and I encourage you to contact Magali if you would like more information on this subject.
												<br><br>
												This payment corresponds to the 6th invoice for your project.
												<br><br>
												It is also possible to pay through Wise (previously TransferWise), this secured website is easy to use and allows you to reduce the bank fees and waiting times. In addition, you can freeze the rate exchange to the current one at the time of your payment.<br>
												Here is a link where you can learn more about Wise : https://youtu.be/MLKKzRvOsLQ
												<br><br>
												In order to process your bank transactions, it is essential to send us your payment receipts. A screenshot of your mobile banking app or a document from your bank can do. An official bank statement still is the best medium for me. My team and I need these details attached to your name and subject of the transfer to organize these data and thus be up to date on your project progress.
												<br><br>
												Once we receive your payment, I will send you an email to notify you. If you wish to divide the sum between numerous people, it is totally possible as long as you send me all the detailed payment receipts with the number of transfer and their amounts.
												<br><br>
												I encourage you to contact me if you have any questions regarding the accounting and the payment of your project and remain at your entire disposal for further information.
												<br><br>
												I remain at your disposal by email or WhatsApp for any further information.

												<br><br>
												Paul BOYER - Administration et Communication Manager<br>
												+62 812 3792 1435
												<br><br>
												Wishing you a good day,<br>
												Best regards.
												<br><br>
												Magnitude Construction<br>
												Jl. Monkey Forest, Ubud, Kabupaten Gianyar<br>
												Bali 80 571
	

												<br><br>
									          	<a href="https://villa.magnitudeconstruction.com/{{ $page }}">{{ $notif_txt2 }}</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					@endif
				@endif

				<table style='padding: 6px' bgcolor='black' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;text-algin:center;'>
										<a href='https://villa.magnitudeconstruction.com' target="_" style='text-decoration: none; font-weight: bold; color: white '>villa.magnitudeconstruction.com</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='margin-top: 20px '>
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td width='40%' style='padding: 0px ; font-weight: normal'>
										<span style='text-decoration: none; font-weight: normal; color: gray '>Magnitude &copy;</span>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
