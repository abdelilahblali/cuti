
<html>
<head>
	<title>EcomBladi</title>
</head>
<body style='font-family: arial '>
	<table style='border:1px solid #e2e2e2; padding: 10px; border-radius: 6px'>
		<tr >
			<td>
				<table width='' >
					<tr >
						<td><img src='https://monprojetbali.com/imgs/logo.png' width='200px'></td>
					</tr>
				</table>
				<table bgcolor='#0AA2A5' style='margin-top: 15px; padding: 6px '>
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td style='font-weight: bold; color: white; text-align: center;'>Nouvelles de votre projet à BALI</td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px '  bgcolor='#e2e2e2' width="100%">
					<tr>
						<td>
							<br/>
							Bonjour <br/>
							Nous vous annonçons des nouvelles de votre projet à BALI. <br/>
				          	<br/>
				          	<a href='https://monprojetbali.com' target='_blanc'>Cliquez ici pour y accéder.</a>
				          	<br/><br/>
				          	L'équipe Magnitude
				          	<br/>
						</td>
					</tr>
				</table>
				<table style='padding: 6px '  bgcolor='black'>
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;text-algin:center;'>
										<a href='https://www.monprojetbali.com' target="_" style='text-decoration: none; font-weight: bold; color: white '>www.monprojetbali.com</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='margin-top: 20px '>
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td width='40%' style='padding: 0px ; font-weight: normal'>
										<span style='text-decoration: none; font-weight: normal; color: gray '>Magnitude &copy;</span>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
