
<html>
<head>
	<title>EcomBladi</title>
</head>
<body style='font-family: arial '>
	<table style='border:1px solid #e2e2e2; padding: 10px; border-radius: 6px'>
		<tr >
			<td>
				<table width='' >
					<tr >
						<td><img src='https://villa.magnitudeconstruction.com/imgs/logo.png' width='200px'></td>
					</tr>
				</table>
				<table bgcolor='#0AA2A5' style='margin-top: 15px; padding: 6px'  width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td style='font-weight: bold; color: white; text-align: center;'>Demande de rendez-vous</td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px '  bgcolor='#e2e2e2' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;'>
										<br/>
										Bonjour <br/>
										Un client vient de demander un nouveau rendez-vous <br/>
							          	<br/>
							          	Client : <strong>{{ $client }}</strong>
							          	<br/>
							          	Date : <strong>{{ $dat }}</strong>
							          	<br/>
							          	Observations : <strong>{{ $obs }}</strong>
							          	<br/><br/>
							          	L'équipe Magnitude 
							          	<br/>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='padding: 6px' bgcolor='black' width="800px">
					<tr>
						<td>
							<table width='800px' >
								<tr >
									<td width='40%' style='padding: 0px 6px; font-weight: normal;text-algin:center;'>
										<a href='https://villa.magnitudeconstruction.com' target="_" style='text-decoration: none; font-weight: bold; color: white '>villa.magnitudeconstruction.com</a>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table style='margin-top: 20px '>
					<tr>
						<td>
							<table width='800px' >
								<tr>
									<td width='40%' style='padding: 0px ; font-weight: normal'>
										<span style='text-decoration: none; font-weight: normal; color: gray '>Magnitude &copy;</span>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
