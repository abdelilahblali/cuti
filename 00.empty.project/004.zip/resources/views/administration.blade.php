@extends('master.theme')


@section('content')

<style type="text/css">
  
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Administration</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      @include('master.aide')
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   @if(session()->has('yes'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('yes') }}
      </div>
    </div>
    @endif

    @if(session()->has('no'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('no') }}
      </div>
    </div>
    @endif
  </div>
</div>

<div class="container-xxl"> 

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start  col-md-4" style="float: left;">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page" style="border-top-right-radius: 0; border-bottom-right-radius: 0;">
      <div class="card-body" style="padding: 10px 10px;">
        <div class="card card-xxl-stretch" style="margin-top: 0 !important">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark">{{ __('administration.a2') }}</span>
              <span class="text-muted mt-1 fw-bold fs-7">{{ __('administration.a1') }}</span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                {{ __('administration.a3') }}
              </p>
            </div>
          </div>

          @foreach($reservation2 as $i) 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="{{ $urlWebSite }}/media/cli/{{ $i->url }}"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i>{{ __('administration.a4') }}</button></a>
              </div>
            </div>
          </div>
          @endforeach

          <div class="card-body" @foreach($reservation1 as $i) @if($i->valid==0) style="background-color: rgba(255,0,0,0.1)" @elseif($i->valid==1) style="background-color: rgba(0,255,0,0.1)" @endif @endforeach>
            <h3>
              <span @foreach($reservation1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach> {{ __('administration.a5') }}</span>
              @foreach($reservation1 as $i) @if($i->valid==0) 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a6') }}</span></span>
              @elseif($i->valid==1)
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a7') }}</span></span>
              @endif @endforeach
            </h3>
            <form method="POST" action="{{ route('administrationAdded') }}" enctype="multipart/form-data">
              {{ csrf_field() }}
              <div class="row" @foreach($reservation1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control"  required />
                      <input type="hidden" name="type" value="reservation">
                      <input type="hidden" name="cli" value="{{ Auth::user()->ref }}">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <button style="margin-bottom: 10px" type="submit" class="btn btn-success" @foreach($reservation1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach><i class="fa fa-upload" style="padding-right: 10px"></i>{{ __('administration.a8') }}</button>
                  @foreach($reservation1 as $i)
                    <a href="{{ $urlWebSite }}/media/cli/{{ $i->url }}" target="_blank"><button type="button" class="btn btn-success " style="margin-right: 10px; width: 100%"><i class="fa fa-eye" style="padding-right: 10px"></i>{{ __('administration.a9') }}</button></a>
                  @endforeach
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #3 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start  col-md-4" style="float: left;">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page" style="border-top-right-radius: 0; border-top-left-radius: 0;border-bottom-right-radius: 0;">
      <div class="card-body" style="padding: 10px 10px;">
        <div class="card card-xxl-stretch" style="margin-top: 0 !important">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark">{{ __('administration.a10') }}</span>
              <span class="text-muted mt-1 fw-bold fs-7">{{ __('administration.a1') }}</span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                {{ __('administration.a11') }}
              </p>
            </div>
          </div>

          @foreach($terrain2 as $i) 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="{{ $urlWebSite }}/media/cli/{{ $i->url }}"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i>{{ __('administration.a12') }}</button></a>
              </div>
            </div>
          </div>
          @endforeach

          <div class="card-body" @foreach($terrain1 as $i) @if($i->valid==0) style="background-color: rgba(255,0,0,0.1)" @elseif($i->valid==1) style="background-color: rgba(0,255,0,0.1)" @endif @endforeach>
            <h3>
              
              @foreach($terrain1 as $i) @if($i->valid==0) 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a13') }}</span></span>
              @elseif($i->valid==1)
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a14') }}</span></span>
              @endif @endforeach
            </h3>
            <form method="POST" action="{{ route('administrationAdded') }}" enctype="multipart/form-data">
              {{ csrf_field() }}
              <div class="row" @foreach($terrain1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control"  required />
                      <input type="hidden" name="type" value="terrain">
                      <input type="hidden" name="cli" value="{{ Auth::user()->ref }}">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <button type="submit" style="margin-bottom: 10px" class="btn btn-success" @foreach($terrain1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach><i class="fa fa-upload" style="padding-right: 10px"></i>{{ __('administration.a8') }}</button>
                  @foreach($terrain1 as $i)
                    <a href="{{ $urlWebSite }}/media/cli/{{ $i->url }}" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px; width: 100%"><i class="fa fa-eye" style="padding-right: 10px"></i>{{ __('administration.a9') }}</button></a>
                  @endforeach
                </div>
              </div>
            </form>
          </div>


            @foreach($quotation2 as $i) 
            <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
              <div class="row" style="margin-top: 0px">
                <div class="">
                  <a target="_" href="{{ $urlWebSite }}/media/cli/{{ $i->url }}"><button type="button" class="btn btn-success" style=" width: 100%"><i class="fa fa-download" style="padding-right: 10px"></i>{{ __('administration.a15') }}</button></a>
                </div>
              </div>
            </div>
            @endforeach 

          <div class="card-body" @foreach($quotation1 as $i) @if($i->valid==0) style="background-color: rgba(255,0,0,0.1)" @elseif($i->valid==1) style="background-color: rgba(0,255,0,0.1)" @endif @endforeach>
            <h3>
              
              @foreach($quotation1 as $i) @if($i->valid==0) 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a13') }}</span></span>
              @elseif($i->valid==1)
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a14') }}</span></span>
              @endif @endforeach
            </h3>
            <form method="POST" action="{{ route('administrationAdded') }}" enctype="multipart/form-data">
              {{ csrf_field() }}
              <div class="row" @foreach($quotation1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control"  required />
                      <input type="hidden" name="type" value="quotation">
                      <input type="hidden" name="cli" value="{{ Auth::user()->ref }}">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <button type="submit" style="margin-bottom: 10px" class="btn btn-success" @foreach($quotation1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach><i class="fa fa-upload" style="padding-right: 10px"></i>{{ __('administration.a8') }}</button>
                  @foreach($quotation1 as $i)
                    <a href="{{ $urlWebSite }}/media/cli/{{ $i->url }}" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px; width: 100%"><i class="fa fa-eye" style="padding-right: 10px"></i>{{ __('administration.a9') }}</button></a>
                  @endforeach
                </div>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<!-- Contrat #2 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start  col-md-4" style="float: left;">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page" style="border-top-left-radius: 0; border-bottom-left-radius: 0;">
      <div class="card-body" style="padding: 10px 10px;">
        <div class="card card-xxl-stretch" style="margin-top: 0 !important">

          <div class="card-header" style="padding-top: 20px">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark">{{ __('administration.a16') }}</span>
              <span class="text-muted mt-1 fw-bold fs-7">{{ __('administration.a1') }}</span>
            </h3>
            <div class="card-toolbar">
              <p style="text-align: justify;">
                {{ __('administration.a17') }}
              </p>
            </div>
          </div>

          @foreach($construction2 as $i) 
          <div class="card-body" style="border-bottom: 1px solid #eff2f5;" >
            <div class="row" style="margin-top: 0px">
              <div class="col-md-12">
                <a target="_" href="{{ $urlWebSite }}/media/cli/{{ $i->url }}"><button type="button" class="btn btn-success"><i class="fa fa-download" style="padding-right: 10px"></i>{{ __('administration.a18') }}</button></a>
              </div>
            </div>
          </div>
          @endforeach

          <div class="card-body" @foreach($construction1 as $i) @if($i->valid==0) style="background-color: rgba(255,0,0,0.1)" @elseif($i->valid==1) style="background-color: rgba(0,255,0,0.1)" @endif @endforeach>
            <h3>
              <span @foreach($construction1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach>{{ __('administration.a19') }} </span>
              @foreach($construction1 as $i) @if($i->valid==0) 
              <span class="menu-title"><span class="badge badge-changelog badge-light-danger bg-hover-danger text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a13') }}</span></span>
              @elseif($i->valid==1)
              <span class="menu-title"><span class="badge badge-changelog badge-light-success bg-hover-success text-hover-white fw-bold fs-9 px-2 ms-2">{{ __('administration.a20') }}</span></span>
              @endif @endforeach
            </h3>
            <form method="POST" action="{{ route('administrationAdded') }}" enctype="multipart/form-data">
              {{ csrf_field() }}
              <div class="row" @foreach($construction1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach>
                  <div class="col-md-12">
                      <h6><label for="url" class="control-label form-label label01"></label></h6>
                      <input type="file" name="url[]" id="url" class="form-control" required  />
                      <input type="hidden" name="type" value="construction">
                      <input type="hidden" name="cli" value="{{ Auth::user()->ref }}">
                  </div>
              </div>
              <div class="row" style="margin-top: 20px">
                <div class="col-md-12">
                  <button type="submit" style="margin-bottom: 10px" class="btn btn-success" @foreach($construction1 as $i) @if($i->valid==1) style="display:none;"  @endif @endforeach><i class="fa fa-upload" style="padding-right: 10px"></i>{{ __('administration.a8') }}</button>
                  @foreach($construction1 as $i)
                    <a href="{{ $urlWebSite }}/media/cli/{{ $i->url }}" target="_blank"><button type="button" class="btn btn-success" style="margin-right: 10px; width: 100%"><i class="fa fa-eye" style="padding-right: 10px"></i>{{ __('administration.a9') }}</button></a>
                  @endforeach
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</div>






@endsection
