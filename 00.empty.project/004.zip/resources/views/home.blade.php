@extends('master.admin')

@section('content')


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <a href="{{ route('clientAdd') }}" class="btn-right "><i class="fa fa-plus"></i> New customer </a>
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif

  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">
    <thead>
      <tr>
        <td>Full name</td>
        <td>Email</td>
        <td>Login</td>
        <td>Notification</td>
        <td width="130">Sent</td>
        <td>Doc</td>
        <td align="center" width="130">Options</td>
      </tr>
    </thead>
    <tbody>
      @foreach($clis as $cli)
      <tr>
        <td><span class="bold" style="color:black">{{ $cli->civ }} {{ $cli->nom }} {{ $cli->pre }}</span></td>
        <td><span class="bold">{{ $cli->mail }}</span></td>
        <td><span class="tel">{{ $cli->username }}</span></td>
        <td>
            @if($cli->sent==0)
            <a title="Send notification to customer" href="{{ route('clientNotification',[ 'mail' => $cli->mail ]) }}" onclick="return confirm('Are you sure you send a notification to the customer??');"><button class="btn btn-xs btn-default"><i class="fa fa-send a-icon"></i>Send</button></a>
            @else
            <a title="Send notification to customer" href="{{ route('clientNotification',[ 'mail' => $cli->mail ]) }}" onclick="return confirm('Are you sure you send a notification to the customer??');"><button class="btn btn-xs btn-success"><i class="fa fa-send a-icon"></i>Send</button></a>
            @endif
        </td>
        <td><span style="font-size:10px">{{ $cli->sent_dat }}</span>
        </td>
        <td align="center">
            @if($cli->doc==0)
            <a title="Authorize this client to view the documents" href="{{ route('docView',[ 'mail' => $cli->mail, 'vf' => 1 ]) }}" onclick="return confirm('Vous-êtes sûr d autoriser ce client à consulter les documents ?');"><i class="fa fa-times a-icon" style='color:red'></i></a>
            @else
            <a title="Do not allow this client to view documents" href="{{ route('docView',[ 'mail' => $cli->mail, 'vf' => 0 ]) }}" onclick="return confirm('Vous-êtes sûr de ne pas autoriser ce client à consulter les documents ?');"><i class="fa fa-check a-icon" style='color:green'></i></a>
            @endif
        </td>
        <td align="center">
          <a title="Documents management" href="{{ route('clientDocs',[ 'ref' => $cli->ref ]) }}"><i class="fa fa-file-o a-icon"></i></a>
          <a title="Pictures management" href="{{ route('clientPhotos',[ 'ref' => $cli->ref ]) }}"><i class="fa fa-picture-o a-icon"></i></a>
          <a title="Edit customer" href="{{ route('clientEdit',[ 'ref' => $cli->ref ]) }}"><i class="fa fa-edit a-icon"></i></a>
          <a title="Delete customer" href="{{ route('clientDelete',[ 'ref' => $cli->ref ]) }}" onclick="return confirm('Are you sure you want to delete this client?'); event.preventDefault(); document.getElementById('clientDelete').submit();"><i class="fa fa-trash a-icon"></i></a>
          <form id="clientDelete" action="{{ route('clientDelete',[ 'ref' => $cli->ref ]) }}" method="POST">
            {{ method_field('DELETE') }}
            @csrf
          </form>  
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>


<script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
	<script src="{{ url('js/datatables.min.js') }}"></script>
	<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "asc" ]] } ); } ); </script>

@endsection
