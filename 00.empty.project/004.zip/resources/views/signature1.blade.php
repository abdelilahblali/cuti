<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <title>MAGNITUDE CONSTRUCTION</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <meta property="og:locale" content="fr_FR" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="" />
  <meta property="og:url" content="https://keenthemes.com/products/ceres-html-pro" />
  <meta property="og:site_name" content="" />
  <link rel="canonical" href="" />
  <link rel="shortcut icon" href="{{ url('imgs/logo.png') }}" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
  <link href="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('theme/assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('theme/assets/css/style.bundle.css') }}" rel="stylesheet" type="text/css" />
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src= '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5FS8GGP');</script>

  <link href="{{ url('signatureAssets/css/bootstrap.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/font-awesome.min.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/bootstrap-select.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/app_style.css') }}" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  #signArea{ width:304px; margin: 15px auto; }
  .sign-container { width: 90%; margin: auto; }
  .sign-preview { width: 150px; height: 50px; margin: 10px 5px; }
  .center-text { text-align: center; }
  </style>

  <style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
  </style>
</head>
<body id="kt_body" style=" background-image: url('{{ url('theme/assets/media/patterns/header-bg-dark.png')  }}')" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled">


<?php
$txt1 = "Cliquer ici pour télécharger & consulter la facture";
$txt2 = "Souhaitez-vous êtres prélever sur vos revenus locatifs ?";
$txt3 = "Confirmez-vous cette facture ";
$txt4 = "Signature numérique";
$txt5 = "Je soussigné autorise Magnitude a prélevé le montant demandée via l’entreprise Bali Super Host sur le compte de société. ";
$txt6 = "Entegistrer & Envoyer";
$yes = "OUI";
$no = "NON";

if($langue!='FR') { 
  $txt1 = "Click here to download & view the invoice"; 
  $txt2 = "Would you like to be deducted from your rental income?"; 
  $txt3 = "Do you confirm this invoice"; 
  $txt4 = "Digital signature";
  $txt5 = "I, the undersigned, authorize Magnitude to deduct the amount requested via Bali Super Host from the company account.";
  $txt6 = "Save & Send";
  $yes = "YES";
  $no = "NO";
}
?>

<div class="d-flex flex-column flex-root">
  <div class="page d-flex flex-row flex-column-fluid">
    <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
      
      <div class="container" style="padding: 30px;">
          <center><img alt="Logo" src="{{ url('imgs/logo_noel.png') }}" style="width:260px;" /></center>
      </div>

      @foreach($items as $i)

        @if($i->sign1=='')
        <div id="">
          <div class="content flex-row-fluid" id="kt_content">
              <div class="card card-page">
                <div class="card-body" style="padding: 0px 38px 30px 33px">
                  <div class="col-md-8 col-md-offset-2">
                  <div class="card card-xxl-stretch">
                    @if($langue=='FR')
                    <p style="padding: 20px 50px  10px 50px ; text-align: center; ">
                      <br><br>
                      <strong>
                      Bonjour <b>{{ $i->civ }} {{ $i->nom }} {{ $i->pre }}</b>
                      </strong>
                      <br><br>
                      Sur la base du rapprochement des fonds reçus à notre compte, il apparait que nous n'avons pas reçu l’intégralité de la somme due à ce jour. Un règlement partiel, nous est bien parvenu, et a été encaissé. Il manque donc sur l’ensemble du projet la somme que vous trouverez sur la facture jointe. 
                      <br>
                      Ci-dessous vous trouverez le détail de vos paiements ;
                      <br><br>
                      Sur cette base, veuillez trouver en pièce jointe le détail de nos relevés bancaire ou figure vos versements. 
                      <br>
                      Afin de régulariser cette situation, 2 options s’offrent à vous : 
                      <br>
                      - Le paiement de la somme manquante sur notre compte bancaire,
                      <br>
                      - ou le prélèvement sur vos revenus locatif de votre villa. 
                      <br><br>
                      S’il y a prélèvement sur le compte bancaire de votre société celui- ci sera opéré par votre entreprise de gestion, 
                      <br><br>
                      Ci-dessous notre procuration pour le prélèvement sur votre compte bancaire de société ;
                      <br><br>
                      Je soussignée Marie Royère agissant en qualité de directeur de l’entreprise PT Magnitude Construction, donne à l’entreprise Bali Super host Management procuration pour retirer en son nom les fonds manquants comme subventionné et figurant sur la facture jointe. L’entreprise Bali super host se verra ainsi seul mandataire pour retirer et manager le compte bancaire de votre société. Magnitude se retire définitivement du projet et se rapprochera automatiquement de votre entreprise de management. 
                      <br>
                      <br>
                      Veuillez svp nous donner votre décisions et accords, 
                      <br>
                      Vous trouverez un formulaire à remplir afin de confirmer ces informations, 
                      <br>
                      Veuillez trouver le détail sur la facture que nous avons joint à ce courriel.
                      <br>
                      S'il vous plaît laissez-moi savoir si vous avez des questions, 
                      <br>
                      Vous adressant nos sincères salutations, 
                      <br><br>
                    </p>
                    @else
                    <p style="padding: 20px 50px  10px 50px ; text-align: center; ">
                      <br><br>
                      <strong>
                      Hello <b>{{ $i->civ }} {{ $i->nom }} {{ $i->pre }}</b>
                      </strong>
                      <br><br>
                      Based on the reconciliation of the funds received to our account, it appears that we have not received the full amount due to date. Partial payment has reached us and has been cashed. The sum that you will find on the attached invoice is therefore missing on the whole project.
                      <br>
                      Below you will find the details of your payments;
                      <br><br>
                      On this basis, please find attached the details of our bank statements or figure your payments.
                      <br>
                      In order to regularize this situation, 2 options are available to you:
                      <br>
                      - The payment of the missing sum on our bank account,
                      <br>
                      - or the levy on your rental income from your villa.
                      <br><br>
                      If there is a direct debit from your company's bank account, this will be operated by your management company,
                      <br><br>
                      Below is our power of attorney for the direct debit from your company bank account;
                      <br><br>
                      I, the undersigned Marie Royère acting as director of the company PT Magnitude Construction, give the company Bali Super host Management power of attorney to withdraw on its behalf the missing funds as subsidized and appearing on the attached invoice. The Bali super host company will thus be the sole agent to withdraw and manage your company's bank account. Magnitude is definitely withdrawing from the project and will automatically approach your management company.
                      <br>
                      <br>
                      Please give us your decisions and agreements,
                      <br>
                      You will find a form to fill in to confirm this information,
                      <br>
                      Please find the detail on the invoice that we have attached to this email.
                      <br>
                      Please let me know if you have any questions,
                      <br>
                      Sending you our sincere greetings,
                    </p>
                    @endif

                    <div class="col-md-8 col-md-offset-2" style="padding: 30px 10px">
                      <form method="POST" action="{{ route('signature1Saved',[ 'ref' => $i->ref ]) }}" enctype="multipart/form-data" style="background: transparent !important;">
                        {{ csrf_field() }}

                          <input type="hidden" id="reference" value="{{ $i->ref }}">

                          <a href="https://sales.magnitudeconstruction.com/public/media/signature/{{ $i->inv1 }}" target="_blank" style="color:white !important; font-weight: bold; ">
                            <button type="button" class="btn btn-success btn-block " style="color: white !important;"><i class="fa fa-arrow-right"></i> {{ $txt1 }}</a></button>
                          </a>

                          <br>
                          <br>

                          

                          <div class="col-md-12" style="padding: 30px 55px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 30px;">
                            <div class="mb-5">
                              <label for="sign1" class=" form-label"> {{ $txt2 }} </label>
                              <select  class="form-control" name="sign1" value="" required>
                                <option></option>
                                <option value="YES">{{ $yes }}</option>
                                <option value="NO">{{ $no }}</option>
                              </select>
                            </div>
                            <div class="mb-5">
                              <label for="confirm1" class=" form-label"> {{ $txt3 }}</label>
                              <select  class="form-control" name="confirm1" value="" required>
                                <option></option>
                                <option value="YES">{{ $yes }}</option>
                                <option value="NO">{{ $no }}</option>
                              </select>
                            </div>
                          </div>

                          <h3>{{ $txt4 }}</h3>
                          <div class="col-md-12" style="padding: 30px 0px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 20px;">
                            <div class="mb-5">
                              <div id="signArea" >
                                <p style="text-align: center;">{{ $txt5 }} </p>
                                <div class="sig sigWrapper" style="height:auto;">
                                  <div class="typed"></div>
                                  <canvas class="sign-pad" id="sign-pad" width="300" height="100"></canvas>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="mb-5">
                              <button class="btn btn-success btn-sm" style="margin-top: 10px"  id="btnSaveSign"><i class="fa fa-save"></i>{{ $txt6 }}</button>
                          </div>
                        </form>
                    </div>

                  </div>
                  </div>
                </div>
              </div> 
          </div>
        </div>
        @else
        <div id="">
          <div class="content flex-row-fluid" id="kt_content">
              <div class="card card-page">
                <div class="card-body" style="padding: 0px 38px 30px 33px">
                  <div class="col-md-8 col-md-offset-2">
                  <div class="card card-xxl-stretch" style="min-height: 800px; border-radius:0; padding:150px 80px">
                    
                    <div class="alert alert-danger" style="font-weight: bold; text-align:center;">Vous avez déja répondre sur notre formulaire, merci</div>

                  </div>
                  </div>
                </div>
              </div> 
          </div>
        </div>

        
        @endif

      @endforeach

    </div>
  </div>

  <div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
      <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-bold me-1"><?php echo date("Y"); ?> ©</span>
        <a href="https://magnitudeconstruction.com/" target="_blank" class="text-gray-800 text-hover-primary">Magnitude Construction</a>
      </div>
    </div>
  </div>
</div>


<script src="{{ url('signatureAssets/js/jquery.min.js') }}"></script>
<script src="{{ url('signatureAssets/js/bootstrap.min.js') }}"></script>
<script src="{{ url('signatureAssets/js/bootstrap-select.js') }}"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link href="{{ url('signatureAssets/css/jquery.signaturepad.css') }}" rel="stylesheet">
<script src="{{ url('signatureAssets/js/numeric-1.2.6.min.js') }}"></script> 
<script src="{{ url('signatureAssets/js/bezier.js') }}"></script>
<script src="{{ url('signatureAssets/js/jquery.signaturepad.js') }}"></script> 
<script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>
<script src="{{ url('signatureAssets/js/json2.min.js') }}"></script>
<script>
$(document).ready(function(e){
$(document).ready(function() { $('#signArea').signaturePad({drawOnly:true, drawBezierCurves:true, lineTop:90}); });
$("#btnSaveSign").click(function(e){ 
  html2canvas([document.getElementById('sign-pad')], {
    onrendered: function (canvas) {
      var canvas_img_data = canvas.toDataURL('image/png');
      var img_data = canvas_img_data.replace(/^data:image\/(png|jpg);base64,/, "");
      //ajax call to save image inside folder
      var reference = $("#reference").val(); 
      $.ajax({
        url: '../../save_signature1.php?reference='+reference,
        data: { img_data:img_data },
        type: 'post',
        dataType: 'json',
        success: function (response) {
           // window.location.reload(); 
        }
      });
    }
  });
});
});
</script>

</body> 
</html>

