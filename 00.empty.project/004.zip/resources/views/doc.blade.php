@extends('master.admin')



@section('content')





<div class="col-md-12">

  <div class="page-header">

    <ol class="breadcrumb">

      <li class="titrePage"><i class="fa fa-sitemap"></i> List of documents</li>

    </ol>

    <div class="right">

      <div class="btn-group" role="group">

        <a href="{{ route('docAdd') }}" class="btn-right "><i class="fa fa-plus"></i> New document </a>

      </div>

    </div>

  </div>

</div>





<div class="col-md-12">

  @if(session()->has('Suppression'))

  <div class="alert alert-success">

    {{ session()->get('Suppression') }}

  </div>

  @endif







  <table data-page-length='40' id="example0" class="table table-condensed table-striped table-primary table-vertical-center checkboxs tab01 bgWhite">

    <thead>

      <tr>

        <td>Designation</td>

        <td>Date</td>

        <td></td>

      </tr>

    </thead>

    <tbody>

      @foreach($docs as $doc)

      <tr>

        <td><span class="bold">{{ $doc->des }}</span></td>

        <td><span class="bold">{{ $doc->fait }}</span></td>

        <td align="right">
    
            <a href="https://monprojetbali.com/media/doc/{{ $doc->doc }}" target="_"><button class="btn btn-xs btn-default"><i class="fa fa-download a-icon"></i></button></a>

          	<a href="{{ route('docDelete',[ 'ref' => $doc->id ]) }}" onclick="return confirm('Are you sure you delete this document?'); event.preventDefault(); document.getElementById('docDelete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>

	        <form id="docDelete" action="{{ route('docDelete',[ 'ref' => $doc->id ]) }}" method="POST">
	            {{ method_field('DELETE') }}
	            @csrf
	        </form>  

        </td>

      </tr>

      @endforeach

    </tbody>

  </table>

</div>



@endsection

