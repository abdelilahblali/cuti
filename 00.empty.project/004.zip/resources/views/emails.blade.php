@extends('master.admin')

@section('content')

<style type="text/css">
  table .fa-times { color: red !important; }
  table .fa-check { color: green !important; }
  .tab1 tr:hover { background: rgba(0,0,0,0.1); }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> Notifications Management </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif


  <div class="col-md-12">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="{{ route('emailsAdded') }}">
      {{ csrf_field() }}

      <div class="row">
          <div class="col-md-12">
              <h6><label for="mail" class="control-label form-label label01">Email <span class="c3_color">*</span></label></h6>
              <input type="email" name="mail" id="mail" class="form-control" required />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
        </div>
      </div>
    </form>
  </div>
</div>

<div class="col-md-12">
  <table id="" class="cell-border display nowrap tab1"  style="width: 100%;">
      <tr>
        <td>Email</td>
        <td align='center'>RDV</td>
        <td align='center'>R. Contrat</td>
        <td align='center'>Rendering</td>
        <td align='center'>C. Contrat</td>
        <td align='center'>Name PTPMA</td>
        <td align='center'>Procuration</td>
        <td align='center'>Acte</td>
        <td align='center'>Bank</td>
        <td align='center'>P. attorney</td>
        <td align='center'>Lease A.</td>
        <td align='center'>D0</td>
        <td align='center'>D1</td>
        <td align='center'>D2</td>
        <td align='center'>D3</td>
        <td align='center'>Plan</td>
        <td align='center'>Add.</td>
        <td align='center'>Paiement</td>
        <td align='center'>Land</td>
        <td align='center'>40*1</td>
        <td align='center'>40*2</td>
        <td align='center'>15%</td>
        <td align='center'>5%</td>
        <td align='center'>Chat</td>
      </tr>
    </thead>
    <tbody>
      @foreach($emails as $i)
      <tr>
        <td><span class="bold">{{ $i->mail }}</span></td>
        <td align='center'>
          @if($i->rdv==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'rdv', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->rdv==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'rdv', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->adm1==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'adm1', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->adm1==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'adm1', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->adm2==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'adm2', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->adm2==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'adm2', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->adm3==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'adm3', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->adm3==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'adm3', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->ptpma1==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma1', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->ptpma1==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma1', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->ptpma2==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma2', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->ptpma2==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma2', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->ptpma3==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma3', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->ptpma3==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma3', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->ptpma4==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma4', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->ptpma4==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'ptpma4', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->land1==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'land1', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->land1==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'land1', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->land2==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'land2', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->land2==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'land2', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->arch1 ==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch1', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->arch1 ==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch1', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->arch2==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch2', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->arch2==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch2', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->arch3==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch3', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->arch3==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch3', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->arch4==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch4', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->arch4==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch4', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->arch5==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch5', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->arch5==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch5', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->arch6==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch6', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->arch6==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'arch6', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->fac1==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac1', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->fac1==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac1', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->fac2==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac2', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->fac2==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac2', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->fac3==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac3', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->fac3==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac3', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->fac4==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac4', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->fac4==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac4', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->fac5==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac5', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->fac5==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac5', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->fac6==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac6', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->fac6==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'fac6', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
        <td align='center'>
          @if($i->chat==0) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'chat', 'valid' => 1 ]) }}"><i class="fa fa-times"></i></a> @endif
          @if($i->chat==1) <a href="{{ route('emailsValid',[ 'ref' => $i->ref, 'tache' => 'chat', 'valid' => 0 ]) }}"><i class="fa fa-check"></i></a> @endif
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
</div>


<script type="text/javascript" src="{{ url('datatable/jquery-3.5.1.js') }}"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>

<script type="text/javascript">
     $(document).ready( function () {
    $('#table_id').DataTable();
} );

</script>

@endsection
