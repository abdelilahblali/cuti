@extends('master.admin')

@section('content')

<style type="text/css">
  .redBG { background: rgba(255, 0, 0, 0.3); !important; color: red !important; font-weight: bold; }
  .greenBG { background: rgba(0, 255, 0, 0.3); !important; color: green !important; font-weight: bold; }
</style>


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> Steps  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">

  <table id="tableExport" class="cell-border display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Full name</td>

        <td>Reservation Contrat (MC)</td>
        <td>Reservation Contrat (Client)</td>
        <td>Rendering (MC)</td>
        <td>Rendering (Client)</td>
        <td>Upload Rendering Quotation (MC)</td>
        <td>Upload Rendering Quotation (Client)</td>
        <td>Construction Contrat (MC)</td>
        <td>Construction Contrat (Client)</td>

        <td>Name PTPMA & Name Villa (MC)</td>
        <td>Name PTPMA & Name Villa (Client)</td>
        <td>Procuration PTPMA (MC)</td>
        <td>Procuration PTPMA (Client)</td>
        <td>Acte Constitutif de Société (MC)</td>
        <td>Acte Constitutif de Société (Client)</td>
        <td>Bank Document (MC)</td>
        <td>Bank Document (Client)</td>

        <td>Power of attorney (MC)</td>
        <td>Power of attorney (Client)</td>
        <td>Lease agreement (MC)</td>
        <td>Lease agreement (Client)</td>
        <td>Neighborhood (MC)</td>
        <td>Neighborhood (Client)</td>

        <td>Design D1</td>
        <td>Design D1 Devis</td>
        <td>Photos D1</td>
        <td>Design D2</td>
        <td>Design D2 Devis</td>
        <td>Photos D2</td>
        <td>Design D3</td>
        <td>Design D3 Devis</td>
        <td>Photos D3</td>

        <td>Construction Drawing (MC)</td>
        <td>Construction Drawing (Client)</td>
        <td>MEP Drawing (MC)</td>
        <td>MEP Drawing (Client)</td>
        <td>Structure Drawing (MC)</td>
        <td>Structure Drawing (Client)</td>

        <td>1.1 (DP, START) </td>
        <td>1.2 (Foundation) </td>
        <td>2 (Structure) </td>
        <td>2.5 (Wall) </td>
        <td>3 (Roof) </td>
        <td>4 (Plester aci) </td>
        <td>4.5 (Ceiting) </td>
        <td>5 (Granit) </td>
        <td>5.1 (Stone) </td>
        <td>Finition </td>
        <td>6 (End) </td>

        <td>Deposit Amount</td>
        <td>Deposit Invoice</td>
        <td>Deposit Paid Invoice</td>
        <td>Deposit Proof document </td>
        <td>Land Amount</td>
        <td>Land Invoice</td>
        <td>Land Paid Invoice</td>
        <td>Land Proof document </td>
        <td>40% (1) Amount</td>
        <td>40% (1) Invoice</td>
        <td>40% (1) Paid Invoice</td>
        <td>40% (1) Proof document </td>
        <td>40% (2) Amount</td>
        <td>40% (2) Invoice</td>
        <td>40% (2) Paid Invoice</td>
        <td>40% (2) Proof document </td>
        <td>15% Amount</td>
        <td>15% Invoice</td>
        <td>15% Paid Invoice</td>
        <td>15% Proof document </td>
        <td>5% Amount</td>
        <td>5% Invoice</td>
        <td>5% Paid Invoice</td>
        <td>5% Proof document </td>

      </tr>
    </thead>
    <tbody>
      @foreach($recaps as $i)
      <tr>
        <td><span class="ref bold" style="color:black">{{ $i['a1'] }}</span></td>
        <td><span class="bold" style="color:black">{{ $i['a2'] }} {{ $i['a3'] }} {{ $i['a4'] }}</span></td>

        <td class="@if($i['b1']=='YES') greenBG @else redBG @endif">{{ $i['b1'] }}</td>
        <td class="@if($i['b2']=='YES') greenBG @else redBG @endif">{{ $i['b2'] }}</td>
        <td class="@if($i['b3']=='YES') greenBG @else redBG @endif">{{ $i['b3'] }}</td>
        <td class="@if($i['b4']=='YES') greenBG @else redBG @endif">{{ $i['b4'] }}</td>
        <td class="@if($i['b5']=='YES') greenBG @else redBG @endif">{{ $i['b5'] }}</td>
        <td class="@if($i['b6']=='YES') greenBG @else redBG @endif">{{ $i['b6'] }}</td>
        <td class="@if($i['b7']=='YES') greenBG @else redBG @endif">{{ $i['b7'] }}</td>
        <td class="@if($i['b8']=='YES') greenBG @else redBG @endif">{{ $i['b8'] }}</td>

        <td class="@if($i['c1']=='YES') greenBG @else redBG @endif">{{ $i['c1'] }}</td>
        <td class="@if($i['c2']=='YES') greenBG @else redBG @endif">{{ $i['c2'] }}</td>
        <td class="@if($i['c3']=='YES') greenBG @else redBG @endif">{{ $i['c3'] }}</td>
        <td class="@if($i['c4']=='YES') greenBG @else redBG @endif">{{ $i['c4'] }}</td>
        <td class="@if($i['c5']=='YES') greenBG @else redBG @endif">{{ $i['c5'] }}</td>
        <td class="@if($i['c6']=='YES') greenBG @else redBG @endif">{{ $i['c5'] }}</td>
        <td class="@if($i['c7']=='YES') greenBG @else redBG @endif">{{ $i['c7'] }}</td>
        <td class="@if($i['c8']=='YES') greenBG @else redBG @endif">{{ $i['c8'] }}</td>

        <td class="@if($i['d1']=='YES') greenBG @else redBG @endif">{{ $i['d1'] }}</td>
        <td class="@if($i['d2']=='YES') greenBG @else redBG @endif">{{ $i['d2'] }}</td>
        <td class="@if($i['d3']=='YES') greenBG @else redBG @endif">{{ $i['d3'] }}</td>
        <td class="@if($i['d4']=='YES') greenBG @else redBG @endif">{{ $i['d4'] }}</td>
        <td class="@if($i['d5']=='YES') greenBG @else redBG @endif">{{ $i['d5'] }}</td>
        <td class="@if($i['d6']=='YES') greenBG @else redBG @endif">{{ $i['d6'] }}</td>

        <td class="@if($i['e1']=='YES') greenBG @else redBG @endif">{{ $i['e1'] }}</td>
        <td class="@if($i['e2']=='YES') greenBG @else redBG @endif">{{ $i['e2'] }}</td>
        <td class="@if($i['e3']=='YES') greenBG @else redBG @endif">{{ $i['e3'] }}</td>
        <td class="@if($i['e4']=='YES') greenBG @else redBG @endif">{{ $i['e4'] }}</td>
        <td class="@if($i['e5']=='YES') greenBG @else redBG @endif">{{ $i['e5'] }}</td>
        <td class="@if($i['e6']=='YES') greenBG @else redBG @endif">{{ $i['e6'] }}</td>
        <td class="@if($i['e7']=='YES') greenBG @else redBG @endif">{{ $i['e7'] }}</td>
        <td class="@if($i['e8']=='YES') greenBG @else redBG @endif">{{ $i['e8'] }}</td>
        <td class="@if($i['e9']=='YES') greenBG @else redBG @endif">{{ $i['e9'] }}</td>

        <td class="@if($i['f1']=='YES') greenBG @else redBG @endif">{{ $i['f1'] }}</td>
        <td class="@if($i['f2']=='YES') greenBG @else redBG @endif">{{ $i['f2'] }}</td>
        <td class="@if($i['f3']=='YES') greenBG @else redBG @endif">{{ $i['f3'] }}</td>
        <td class="@if($i['f4']=='YES') greenBG @else redBG @endif">{{ $i['f4'] }}</td>
        <td class="@if($i['f5']=='YES') greenBG @else redBG @endif">{{ $i['f5'] }}</td>
        <td class="@if($i['f6']=='YES') greenBG @else redBG @endif">{{ $i['f6'] }}</td>

        <td class="@if($i['g1']=='YES') greenBG @else redBG @endif">{{ $i['g1'] }}</td>
        <td class="@if($i['g2']=='YES') greenBG @else redBG @endif">{{ $i['g2'] }}</td>
        <td class="@if($i['g3']=='YES') greenBG @else redBG @endif">{{ $i['g3'] }}</td>
        <td class="@if($i['g4']=='YES') greenBG @else redBG @endif">{{ $i['g4'] }}</td>
        <td class="@if($i['g5']=='YES') greenBG @else redBG @endif">{{ $i['g5'] }}</td>
        <td class="@if($i['g6']=='YES') greenBG @else redBG @endif">{{ $i['g6'] }}</td>
        <td class="@if($i['g7']=='YES') greenBG @else redBG @endif">{{ $i['g7'] }}</td>
        <td class="@if($i['g8']=='YES') greenBG @else redBG @endif">{{ $i['g8'] }}</td>
        <td class="@if($i['g9']=='YES') greenBG @else redBG @endif">{{ $i['g9'] }}</td>
        <td class="@if($i['g10']=='YES') greenBG @else redBG @endif">{{ $i['g10'] }}</td>
        <td class="@if($i['g11']=='YES') greenBG @else redBG @endif">{{ $i['g11'] }}</td>

        <td class="@if($i['h1']=='YES') greenBG @else redBG @endif">{{ $i['h1'] }}</td>
        <td class="@if($i['h2']=='YES') greenBG @else redBG @endif">{{ $i['h2'] }}</td>
        <td class="@if($i['h3']=='YES') greenBG @else redBG @endif">{{ $i['h3'] }}</td>
        <td class="@if($i['h4']=='YES') greenBG @else redBG @endif">{{ $i['h4'] }}</td>
        <td class="@if($i['h5']=='YES') greenBG @else redBG @endif">{{ $i['h5'] }}</td>
        <td class="@if($i['h6']=='YES') greenBG @else redBG @endif">{{ $i['h6'] }}</td>
        <td class="@if($i['h7']=='YES') greenBG @else redBG @endif">{{ $i['h7'] }}</td>
        <td class="@if($i['h8']=='YES') greenBG @else redBG @endif">{{ $i['h8'] }}</td>
        <td class="@if($i['h9']=='YES') greenBG @else redBG @endif">{{ $i['h9'] }}</td>
        <td class="@if($i['h10']=='YES') greenBG @else redBG @endif">{{ $i['h10'] }}</td>
        <td class="@if($i['h11']=='YES') greenBG @else redBG @endif">{{ $i['h11'] }}</td>
        <td class="@if($i['h12']=='YES') greenBG @else redBG @endif">{{ $i['h12'] }}</td>
        <td class="@if($i['h13']=='YES') greenBG @else redBG @endif">{{ $i['h13'] }}</td>
        <td class="@if($i['h14']=='YES') greenBG @else redBG @endif">{{ $i['h14'] }}</td>
        <td class="@if($i['h15']=='YES') greenBG @else redBG @endif">{{ $i['h15'] }}</td>
        <td class="@if($i['h16']=='YES') greenBG @else redBG @endif">{{ $i['h16'] }}</td>
        <td class="@if($i['h17']=='YES') greenBG @else redBG @endif">{{ $i['h17'] }}</td>
        <td class="@if($i['h18']=='YES') greenBG @else redBG @endif">{{ $i['h18'] }}</td>
        <td class="@if($i['h19']=='YES') greenBG @else redBG @endif">{{ $i['h19'] }}</td>
        <td class="@if($i['h20']=='YES') greenBG @else redBG @endif">{{ $i['h20'] }}</td>
        <td class="@if($i['h21']=='YES') greenBG @else redBG @endif">{{ $i['h21'] }}</td>
        <td class="@if($i['h22']=='YES') greenBG @else redBG @endif">{{ $i['h22'] }}</td>
        <td class="@if($i['h23']=='YES') greenBG @else redBG @endif">{{ $i['h23'] }}</td>
        <td class="@if($i['h24']=='YES') greenBG @else redBG @endif">{{ $i['h24'] }}</td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>


<script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
<script src="{{ url('js/datatables.min.js') }}"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

@endsection
