@extends('master.theme')


@section('content')

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Construction / Photos / {{ $date }}</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <!-- <a href="#" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">Contact our team</a> -->
      <a href="{{ url('getPhotosAll') }}" class="btn btn-success my-2">Voir toutes les photos</a>
    </div>
  </div>
</div>

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <div class="card card-page">
      <div class="card-body">
        <div class="row">
        @foreach($pics as $img)
        @if($img->dat<'2022-01-10 00:00:00')
        <div class="col-lg-4"  style="margin-bottom: 20px">
          <a href="{{ $urlWebSite2 }}/media/cli/{{ $img->img }}" onclick="return hs.expand(this)">
            <div class="pho" style="width: 100%; height: 300px;  background: url('{{ $urlWebSite2 }}/media/cli/{{ $img->img }}'); background-size: cover !important;"></div>
          </a>
        </div>
        @else
        <div class="col-lg-4"  style="margin-bottom: 20px">
          <a href="{{ $urlWebSite }}/media/cli/{{ $img->img }}" onclick="return hs.expand(this)">
            <div class="pho" style="width: 100%; height: 300px;  background: url('{{ $urlWebSite }}/media/cli/{{ $img->img }}'); background-size: cover !important;"></div>
          </a>
        </div>
        @endif
        @endforeach
        </div>
      </div>
    </div>

    <div class="card card-page">
      <div class="card-body">
        {{ $pics->links() }}
      </div>
    </div>
   

  </div>
</div>


@endsection
