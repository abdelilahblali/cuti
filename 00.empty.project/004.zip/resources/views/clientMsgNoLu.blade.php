@extends('master.admin')

@section('content')


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>

<style type="text/css">
  #oneColumnTable .fa { color:#0D3A5D ; }
</style>


<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif


  

  <table id="oneColumnTable" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Full name</td>
        <td>Email</td>
        <td>Login</td>
        <td align="center">Conversation</td>
      </tr>
    </thead>
    <tbody>
      @foreach($clis as $cli)
      @foreach($msg_non_lu as $m) @if($m['cli']==$cli->ref && $m['nb']!=0)
      <tr>
        <td><a href="{{ route('clientChat',[ 'ref' => $cli->ref ]) }}"><span class="bold ref" style="color:black">{{ $cli->code }}</span></a></td>
        <td><span class="bold" style="color:black">{{ $cli->civ }} {{ $cli->nom }} {{ $cli->pre }}</span></td>
        <td><span class="bold">{{ $cli->mail }}</span></td>
        <td><span class="tel">{{ $cli->username }}</span></td>
        
        <td align="center">
          <a title="Chat" href="{{ route('clientChat',[ 'ref' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-envelope a-icon" style="color: red;"></i></a>
          
        </td>
      </tr>
      @endif @endforeach
      @endforeach
    </tbody>
  </table>
</div>


<script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
<script src="{{ url('js/datatables.min.js') }}"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

@endsection
