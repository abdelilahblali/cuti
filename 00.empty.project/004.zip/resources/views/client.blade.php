@extends('master.admin')

@section('content')


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> Clients List</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>

<style type="text/css">
  #oneColumnTable .fa { color:#0D3A5D ; }
</style>


<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif


  

  <table id="oneColumnTable" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Full name</td>
        <td>Email</td>
        <td>Login</td>
        <td align="center">Langue</td>
        <td align="center">Options</td>
      </tr>
    </thead>
    <tbody>
      @foreach($clis as $cli)
      <tr>
        <td><a href="{{ route('clientFolder',[ 'ref' => $cli->ref ]) }}"><span class="bold ref" style="color:black">{{ $cli->code }}</span></a></td>
        <td><span class="bold" style="color:black">{{ $cli->civ }} {{ $cli->nom }} {{ $cli->pre }}</span></td>
        <td><span class="bold">{{ $cli->mail }}</span></td>
        <td><span class="tel">{{ $cli->username }}</span></td>
        <td align="center"><img src="https://villa.magnitudeconstruction.com/imgs/flag/<?php echo $cli->langue; ?>.png" style="width: 20px;"></td>
        
        <td align="center">
          <a title="Notifications sent" href="{{ route('notifications',[ 'cli' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-info a-icon"></i></a>
          <a title="View" href="{{ route('clientFolder',[ 'ref' => $cli->ref ]) }}" style="margin-right: 4px; "><i class="fa fa-folder a-icon"></i></a>
          <a title="Documents management" href="{{ route('clientDocs',[ 'ref' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-file-o a-icon"></i></a>
          <a title="Pictures management" href="{{ route('clientPhotos',[ 'ref' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-picture-o a-icon"></i></a>
          <a title="Edit customer" href="{{ route('clientEdit',[ 'ref' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-edit a-icon"></i></a>
          <a title="Chat" href="{{ route('clientChat',[ 'ref' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-envelope a-icon" ></i></a>
          <a title="Comment" href="{{ route('clientComment',[ 'cli' => $cli->ref ]) }}" style="margin-right: 4px;"><i class="fa fa-comment a-icon" ></i></a>
          <!-- <a title="Delete customer" href="{{ route('clientDelete',[ 'ref' => $cli->ref ]) }}" onclick="return confirm('Are you sure you want to delete this client?'); event.preventDefault(); document.getElementById('clientDelete').submit();"><i class="fa fa-trash a-icon red"></i></a>
          <form id="clientDelete" action="{{ route('clientDelete',[ 'ref' => $cli->ref ]) }}" method="POST">
            {{ method_field('DELETE') }}
            @csrf
          </form>   -->
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>


<script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
<script src="{{ url('js/datatables.min.js') }}"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

@endsection
