@extends('master.admin')

@section('content')


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> Notifications sent to <strong><?php echo $client; ?></strong>  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>


<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif

  <table id="tableNoOrder" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Notification</td>
        <td>Date</td>
      </tr>
    </thead>
    <tbody>
      @foreach($notifications as $item)
      <tr>
        <td><span class="bold">{{ $item->msg }}</span></td>
        <td><span class="bold">{{ $item->fait }}</span></td>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>


<script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
<script src="{{ url('js/datatables.min.js') }}"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

@endsection
