@extends('master.theme')


@section('content')

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">{{ __('travaux.a1') }} </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   @if(session()->has('yes'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('yes') }}
      </div>
    </div>
    @endif

    @if(session()->has('no'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('no') }}
      </div>
    </div>
    @endif
  </div>
</div>
 
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl" >
  <div class="content flex-row-fluid" id="kt_content" >
      <div class="card card-page">
        <div class="card-body" style="padding: 0px 38px 30px 33px">
          @foreach($pdfs as $i)
          <div class="card card-xxl-stretch" style=" @if($i->valid==0) background:#ffdbdb @else background:#afedba @endif">
            <div class="" style="margin-top: 10px; padding-left: 0; padding: 10px">
              <p>{!! $i->dcr !!}</p>
              <a target="_blank" href="{{ $urlWebSite }}/media/d/{{ $i->url }}"><button class="btn btn-xs btn-success">{{ __('travaux.a2') }}</button></a>

              @if($i->valid==0)
              <a href="{{ route('clientFolderValidate',[ 'ref' => $i->ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'design_pdf' ]) }}" ><button type="button" class="btn btn-xs btn-danger" title="click to validate">{{ __('travaux.a3') }}</button></a>
              @elseif($i->valid==1)
              <a href="{{ route('clientFolderValidate',[ 'ref' => $i->ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'design_pdf' ]) }}" ><button type="button" class="btn btn-xs btn-success" title="click to cancel validation">{{ __('travaux.a4') }}</button></a>
              @endif

            </div>
          </div>
          @endforeach  
        </div>
      </div>
  </div>
</div>


@endsection
