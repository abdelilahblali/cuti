<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <title>MAGNITUDE CONSTRUCTION</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <meta property="og:locale" content="fr_FR" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="" />
  <meta property="og:url" content="https://keenthemes.com/products/ceres-html-pro" />
  <meta property="og:site_name" content="" />
  <link rel="canonical" href="" />
  <link rel="shortcut icon" href="{{ url('imgs/logo.png') }}" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
  <link href="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('theme/assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('theme/assets/css/style.bundle.css') }}" rel="stylesheet" type="text/css" />
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src= '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5FS8GGP');</script>

  <link href="{{ url('signatureAssets/css/bootstrap.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/font-awesome.min.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/bootstrap-select.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/app_style.css') }}" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  #signArea{ width:304px; margin: 15px auto; }
  .sign-container { width: 90%; margin: auto; }
  .sign-preview { width: 150px; height: 50px; margin: 10px 5px; }
  .center-text { text-align: center; }
  </style>

  <style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
  </style>
</head>
<body id="kt_body" style=" background-image: url('{{ url('theme/assets/media/patterns/header-bg-dark.png')  }}')" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled">
     
<div class="d-flex flex-column flex-root">
  <div class="page d-flex flex-row flex-column-fluid">
    <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
      
      <div class="container" style="padding: 30px;">
          <center><img alt="Logo" src="{{ url('imgs/logo_noel.png') }}" style="width:260px;" /></center>
      </div>

      <div id="">
        <div class="content flex-row-fluid" id="kt_content">
            <div class="card card-page">
              <div class="card-body" style="padding: 0px 38px 30px 33px; ">
                <div class="col-md-8 col-md-offset-2">
                <div class="card card-xxl-stretch">

                  
                    <h4 style="font-weight: bold; text-transform: uppercase; text-align:center; margin:100px 40px;"><div class="alert alert-success">Merci pour votre réponse</div></h4>
                  

                  <p style="padding: 20px 20px 10px 20px; text-align: center; min-height: 800px;">
                  </p>

                </div>
                </div>
              </div>
            </div> 
        </div>
      </div>

    </div>
  </div>

  <div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
      <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-bold me-1"><?php echo date("Y"); ?> ©</span>
        <a href="https://magnitudeconstruction.com/" target="_blank" class="text-gray-800 text-hover-primary">Magnitude Construction</a>
      </div>
    </div>
  </div>
</div>




</body> 
</html>

