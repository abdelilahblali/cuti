@extends('master.admin')

@section('content')

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-paint-brush"></i> Updating photos for the customer : <span class="bold black">{{ $client }}</span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif
</div>

<script type="text/javascript" src="{{ url('jquery-3.5.1.min.js')}}"></script>
<script type='text/javascript'>
$(document).ready(function(){
  $('#add').click(function(){ 
      $('#add').css('visibility', 'hidden');
      $('#load').css('visibility', 'visible');
  });
});
</script>

<div class="col-md-12">

  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="{{ route('clientPhotosAdd',[ 'ref' => $ref ]) }}" enctype="multipart/form-data">
      {{ csrf_field() }}
      <div class="row">
        <div class="col-md-12">
          <h6><label for="images" class="control-label form-label label01">Choose one or more images <span class="c3_color">*</span></label></h6>
          <input type="file" class="form-control" name="images[]" multiple />
          <!-- <input name="pic[]" id="pic" type="file" class="form-control" multiple/> -->
        </div>
      </div>
      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success" id="add"><i class="fa fa-upload" style="padding-right: 10px"></i>Add</button>
          <img src="{{ url('imgs/loading.gif') }}" style="width:40px; visibility: hidden;" id="load">
        </div>
      </div>
    </form>
  </div>
</div>

<div class="col-md-12">
  <div class="row">
    @foreach($photos as $img)
        @if($img->dat<'2022-01-10 00:00:00')
        <div class="col-md-2" style="margin-bottom: 30px">
          <img src="{{ $urlWebSite2 }}/media/cli/{{ $img->img }}" style="width: 100%; height: 200px" class="img-thumbnail">
          <a href="{{ route('clientPhotosDelete',[ 'ref' => $img->ref  ]) }}" onclick="return confirm('Are you sure you delete this photo?'); event.preventDefault(); document.getElementById('clientPhotosDelete').submit();"><i class="fa fa-times" style="color:red; position: absolute; right: 20px; top: 3px;"></i></a>
          <form id="clientPhotosDelete" action="{{ route('clientPhotosDelete',[ 'ref' => $img->ref  ]) }}" method="POST">
            {{ method_field('DELETE') }}
            @csrf
          </form>  
        </div>
        @else
          <div class="col-md-2" style="margin-bottom: 30px">
          <img src="{{ $urlWebSite }}/media/cli/{{ $img->img }}" style="width: 100%; height: 200px" class="img-thumbnail">
          <a href="{{ route('clientPhotosDelete',[ 'ref' => $img->ref  ]) }}" onclick="return confirm('Are you sure you delete this photo?'); event.preventDefault(); document.getElementById('clientPhotosDelete').submit();"><i class="fa fa-times" style="color:red; position: absolute; right: 20px; top: 3px;"></i></a>
          <form id="clientPhotosDelete" action="{{ route('clientPhotosDelete',[ 'ref' => $img->ref  ]) }}" method="POST">
            {{ method_field('DELETE') }}
            @csrf
          </form>  
        </div>
        @endif
    @endforeach
  </div>
</div>   

<div class="col-md-12">
  <div class="row">
    {{ $photos->links() }}
  </div>
</div>  

@endsection
