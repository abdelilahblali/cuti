@extends('master.theme')


@section('content')

<style type="text/css">
  .w-5 { display: none  }
  .text-gray-700 { text-align: right;  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Historiques des documents </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">



    <div class="card card-page">
      <div class="card-body">
        <div class="row">

        @foreach($docs as $d)
        @if($d->fait<'2022-01-10 00:00:00')
        <div class="col-lg-4"  style="margin-bottom: 20px; border:0.5px solid rgba(0,0,0,0.05); padding: 10px">
          <h6>{{ $d->des }}</h6>
          <a href="{{ $urlWebSite2 }}/media/clidoc/{{ $d->doc }}"  target="_blank">
            <img src="https://villa.magnitudeconstruction.com/imgs/pdf.png" width="100px">
          </a>
        </div>
        @else
        <div class="col-lg-4"  style="margin-bottom: 20px; border:0.5px solid rgba(0,0,0,0.05); padding: 10px">
          <h6>{{ $d->des }}</h6>
          <a href="{{ $urlWebSite }}/media/clidoc/{{ $d->doc }}"  target="_blank">
            <img src="https://villa.magnitudeconstruction.com/imgs/pdf.png" width="100px">
          </a>
        </div>
        @endif
        @endforeach


        </div>
      </div>
    </div>


  </div>
</div>



@endsection
