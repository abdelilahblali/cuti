<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<title>Magnitude Construction : My Bali Project</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta charset="utf-8" />
	<meta property="og:locale" content="fr_FR" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="" />
	<meta property="og:url" content="https://keenthemes.com/products/ceres-html-pro" />
	<meta property="og:site_name" content="" />
	<link rel="canonical" href="" />
	<link rel="shortcut icon" href="{{ url('imgs/logo.png') }}" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
	<link href="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ url('theme/assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ url('theme/assets/css/style.bundle.css') }}" rel="stylesheet" type="text/css" />
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src= '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5FS8GGP');</script>
	<style type="text/css">

		.iconPicture { 
			border:0; 
			background-color: transparent; 
			width: 20px; float: left;
		}
		.iconPicture:before {
			font-family: "Font Awesome 5 Free";
			content: "\f030"; /*f0e9*/
			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
			background-size: 40px 40px;
			font-size: 20px;
			color:black;
		}

		.umbrella { 
			border:0;  width: 20px; float: left;
			background-color: transparent; 
		}
		.umbrella:before {
			font-family: "Font Awesome 5 Free";
			content: "\2614"; /*f0e9*/
			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
			background-size: 40px 40px;
			font-size: 20px;
			color:black;
		}

		.ceremony { 
			border:0; 
			background-color: transparent; background-size: 20px 20px;
		}
		.ceremony:before {
			content: url('{{ url('imgs/cer.jpg')  }}');

			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
		}

		.holiday { 
			border:0; 
			background-color: transparent; background-size: 20px 20px;
		}
		.holiday:before {
			content: url('{{ url('imgs/flag.jpg')  }}');

			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
		}

		.whi { color: white !important }

			/*.holiday { 
				border:0; 
				background-color: transparent; 
			}
			.holiday:before {
				font-family: "Font Awesome 5 Free";
			    content: "\1F384";
			    display: block;
			    float: left;
			    margin: 0 6px 0 0;
			    font-weight: 900;
			    background-size: 40px 40px;
			    font-size: 20px;
			    color:black;
			    }*/

			    .header-fixed[data-kt-sticky-header="on"] .header { background: black !important  }
			    .h-lg-20px {  height: 46px !important;}

			    #kt_content_container { padding-top: 30px; }
			    #kt_content_container .card .card-xxl-stretch { margin-top: 30px; }

			    .menu-state-bg .menu-item.here > .menu-link, .menu-state-bg .menu-item.show > .menu-link { background: rgba(255,255,255,0.1);  }

			    @media only screen and (max-width: 820px) {
			    	.menu-column { background-color: #070F25; }
			    	.bs-stepper-header {  text-align: left !important; }
			    }

			    .connected { background: rgba(255,255,255,0.5); height: 35px; width: 300px }

			</style>
		</head>
		<body id="kt_body" style=" background-image: url('{{ url('theme/assets/media/patterns/header-bg-dark.png')  }}')" >
			

			<div class="d-flex flex-column flex-root">
				<div class="page d-flex flex-row flex-column-fluid">
					<div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">

									@yield('content') 

								</div>
							</div>

							<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
								<div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
									<div class="text-dark order-2 order-md-1">
										<span class="text-muted fw-bold me-1"><?php echo date("Y"); ?> ©</span>
										<a href="https://magnitudeconstruction.com/" target="_blank" class="text-gray-800 text-hover-primary">Magnitude Construction</a>
									</div>
									<ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">

										<li class="menu-item">
											<!-- <a href="https://magnitudeconstruction.com/contactez-nous/" target="_blank" class="menu-link px-2">{{ __('header.a11') }}</a> -->
										</li>
									</ul>
								</div>
							</div>

						</div>

						<div id="kt_activities" class="bg-body" data-kt-drawer="true" data-kt-drawer-name="activities" data-kt-drawer-activate="true" data-kt-drawer-overlay="true"  data-kt-drawer-direction="end" data-kt-drawer-toggle="#kt_activities_toggle" data-kt-drawer-close="#kt_activities_close" >
							<div class="card shadow-none rounded-0">
								<div class="card-header" id="kt_activities_header">
									<h3 class="card-title fw-bolder text-dark">{{ __('header.a12') }}</h3>
									<div class="card-toolbar">
										<a href="{{ url('markAllAsRead') }}" class="btn btn-outline btn-outline-dashed btn-outline-default me-2 mb-2">{{ __('header.a13') }}</a>
									</div>
								</div>
							</div>
						</div>


						<form method="POST" action="{{ route('rendezvous') }}" enctype="multipart/form-data">
							{{ csrf_field() }}
							<div class="modal fade" tabindex="-1" id="rendez-vous">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title">{{ __('header.a14') }}</h5>
											<div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
												<span class="svg-icon svg-icon-2x"></span>
											</div>
										</div>

										<div class="modal-body">
											<input type="date" class="form-control form-control-solid" name="dat" required />
											<br>
											<textarea class="form-control form-control-solid" name="obs" placeholder="Observations"></textarea>
										</div>

										<div class="modal-footer">
											<button type="button" class="btn btn-light" data-bs-dismiss="modal">{{ __('header.a15') }}</button>
											<button type="submit" class="btn btn-primary">{{ __('header.a16') }}</button>
										</div>
									</div>
								</div>
							</div>
						</form>


						


						<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
							<span class="svg-icon">
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
									<rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
									<path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
								</svg>
							</span>
						</div>

						@if(!Route::is('design0'))
						<script>var hostUrl = "{{ url('theme/assets/index.html') }}";</script>
						<script src="{{ url('theme/assets/plugins/global/plugins.bundle.js') }}"></script>
						<script src="{{ url('theme/assets/js/scripts.bundle.js') }}"></script>
						<script src="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.js') }}"></script>
						<script src="{{ url('theme/assets/plugins/custom/fullcalendar/lang-all.js') }}"></script>
						<!-- <script src="{{ url('theme/assets/js/custom/widgets.js') }}"></script> -->
						<script src="{{ url('theme/assets/js/custom/intro.js') }}"></script>
						<noscript>
							<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5FS8GGP" height="0" width="0" style="display:none;visibility:hidden"></iframe>
						</noscript>
						@endif

						@if(Route::is('construction'))

						<!-- Pour changer la langue du calendrier = Ajouter locale: "fr",	 -->

						<script type="text/javascript">
							"use strict";var KTWidgets=function(){var t=function(t,e,i,a){var o=document.querySelector(e);if(o){
								var r={series:[{name:"Profit",data:i}],chart:{fontFamily:"inherit",type:"bar",height:parseInt(KTUtil.css(o,"height")),toolbar:{show:!1}},plotOptions:{bar:{horizontal:!1,columnWidth:["30%"],borderRadius:4}},legend:{show:!1},dataLabels:{enabled:!1},stroke:{show:!0,width:2,colors:["transparent"]},xaxis:{crosshairs:{show:!1},categories:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],axisBorder:{show:!1},axisTicks:{show:!1},labels:{style:{colors:KTUtil.getCssVariableValue("--bs-gray-400"),fontSize:"12px"}}},yaxis:{crosshairs:{show:!1},labels:{style:{colors:KTUtil.getCssVariableValue("--bs-gray-400"),fontSize:"12px"}}},states:{normal:{filter:{type:"none",value:0}},hover:{filter:{type:"none"}},active:{allowMultipleDataPointsSelection:!1,filter:{type:"none",value:0}}},fill:{opacity:1},tooltip:{style:{fontSize:"12px"},y:{formatter:function(t){return"$"+t+"k"}}},colors:[KTUtil.getCssVariableValue("--bs-primary")],grid:{borderColor:KTUtil.getCssVariableValue("--bs-gray-300"),strokeDashArray:4,yaxis:{lines:{show:!0}}}},s=new ApexCharts(o,r),n=!1,l=document.querySelector(t);!0===a&&(s.render(),n=!0),l.addEventListener("shown.bs.tab",(function(t){0==n&&(s.render(),n=!0)}))}};return{init:function(){var e,i,a,o,r,s,n;(e=document.querySelector("#kt_user_menu_dark_mode_toggle"))&&e.addEventListener("click",(function(){window.location.href=this.getAttribute("data-kt-url")})),function(){if("undefined"!=typeof FullCalendar&&document.querySelector("#kt_calendar_widget_1")){var t=moment().startOf("day"),e=t.format("YYYY-MM"),i=t.clone().subtract(1,"day").format("YYYY-MM-DD"),a=t.format("YYYY-MM-DD"),o=t.clone().add(1,"day").format("YYYY-MM-DD"),r=document.getElementById("kt_calendar_widget_1");new FullCalendar.Calendar(r,{headerToolbar:{left:"prev,next today",center:"title",right:"dayGridMonth,timeGridWeek,timeGridDay,listMonth"},height:800,contentHeight:780,aspectRatio:3,nowIndicator:!0,now:a+"T09:25:00",views:{dayGridMonth:{buttonText:"Mois"},timeGridWeek:{buttonText:"Semaine"},timeGridDay:{buttonText:"Jour"}},initialView:"dayGridMonth",initialDate:a,locale: "fr",eventLimit: true,editable:!0,dayMaxEvents:!1,navLinks:!0,


									events : [ 

									@if($a0!="")
									<?php
									if($a1=="") {
										$z0 = date('Y-m-d', strtotime("+1 days"));
									} else { $z0 = $a1;   }
									?>
									{title:"Début du projet : <?php echo $a0; ?>",start:"<?php echo $a0; ?>",end:"<?php echo $z0; ?>",description:"",color:"#0aa2a5"},
									@endif

									@if($a1!="")
									<?php
									if($a2=="") {
										$z1 = date('Y-m-d', strtotime("+1 days"));
									} else { $z1 = $a2;   }
									?>
									{title:"Fondation : <?php echo $a1; ?>",start:"<?php echo $a1; ?>",end:"<?php echo $z1; ?>",description:"",color:"green"},
									@endif

									@if($a2!="")
									<?php
									if($a3=="") {
										$z2 = date('Y-m-d', strtotime("+1 days"));
									} else { $z2 = $a3;   }
									?>
									{title:"Structure : <?php echo $a2; ?>",start:"<?php echo $a2; ?>",end:"<?php echo $z2; ?>",description:"",color:"blue"},
									@endif

									@if($a3!="")
									<?php
									if($a4=="") {
										$z3 = date('Y-m-d', strtotime("+1 days"));
									} else { $z3 = $a4;   }
									?>
									{title:"Mur : <?php echo $a3; ?>",start:"<?php echo $a3; ?>",end:"<?php echo $z3; ?>",description:"",color:"orange"},
									@endif

									@if($a4!="")
									<?php
									if($a5=="") {
										$z4 = date('Y-m-d', strtotime("+1 days"));
									} else { $z4 = $a5;   }
									?>
									{title:"Toiture : <?php echo $a4; ?>",start:"<?php echo $a4; ?>",end:"<?php echo $z4; ?>",description:"",color:"brown"},
									@endif

									@if($a5!="")
									<?php
									if($a6=="") {
										$z5 = date('Y-m-d', strtotime("+1 days"));
									} else { $z5 = $a6;   }
									?>
									{title:"Plâtre aci : <?php echo $a5; ?>",start:"<?php echo $a5; ?>",end:"<?php echo $z5; ?>",description:"",color:"red"},
									@endif

									@if($a6!="")
									<?php
									if($a7=="") {
										$z6 = date('Y-m-d', strtotime("+1 days"));
									} else { $z6 = $a7;   }
									?>
									{title:"Plafond : <?php echo $a6; ?>",start:"<?php echo $a6; ?>",end:"<?php echo $z6; ?>",description:"",color:"pink"},
									@endif

									@if($a7!="")
									<?php
									if($a8=="") {
										$z7 = date('Y-m-d', strtotime("+1 days"));
									} else { $z7 = $a8;   }
									?>
									{title:"Granit : <?php echo $a7; ?>",start:"<?php echo $a7; ?>",end:"<?php echo $z7; ?>",description:"",color:"gray"},
									@endif

									@if($a8!="")
									<?php
									if($a9=="") {
										$z8 = date('Y-m-d', strtotime("+1 days"));
									} else { $z8 = $a9;   }
									?>
									{title:"Pierre : <?php echo $a8; ?>",start:"<?php echo $a8; ?>",end:"<?php echo $z8; ?>",description:"",color:"black"},
									@endif

									@if($a9!="")
									<?php
									if($a10=="") {
										$z9 = date('Y-m-d', strtotime("+1 days"));
									} else { $z9 = $a10;   }
									?>
									{title:"Finition : <?php echo $a9; ?>",start:"<?php echo $a9; ?>",end:"<?php echo $z9; ?>",description:"",color:"#6e10ea"},
									@endif

									@if($a10!="")
									<?php
									if($a10=="") {
										$z10 = date('Y-m-d', strtotime("+1 days"));
									} else { $z10 = $a10;   }
									?>
									{title:"Fin : <?php echo $a10; ?>",start:"<?php echo $a10; ?>",end:"<?php echo $z9; ?>",description:"",color:"#0aa2a5"},
									@endif

									@foreach($pics as $p)
									{url:"{{ url('getPhotosDay', ['date'=>$p->date]) }}",start:"<?php echo date("Y-m-d", strtotime($p->date)); ?>",className:"iconPicture"},
									@endforeach

									@foreach($days as $p)
									@if($p->typ=='Rainy days')
									{ start:"<?php echo date("Y-m-d", strtotime($p->dat)); ?>", className:"umbrella" },
									@elseif($p->typ=='Ceremony days')
									{ start:"<?php echo date("Y-m-d", strtotime($p->dat)); ?>", className:"ceremony" },
									@else
									{ start:"<?php echo date("Y-m-d", strtotime($p->dat)); ?>", className:"holiday" },
									@endif
									@endforeach

									]


								}).render().setOption('locale', 'es')}}(),i=document.getElementById("kt_lists_widget_3_chart"),a=KTUtil.getCssVariableValue("--bs-gray-500"),o=KTUtil.getCssVariableValue("--bs-gray-200"),r=KTUtil.getCssVariableValue("--bs-primary"),s=KTUtil.getCssVariableValue("--bs-info"),i&&(parseInt(KTUtil.css(i,"height")),new ApexCharts(i,{series:[{name:"Net Profit",data:[40,50,65,70,50,30]},{name:"Revenue",data:[-30,-40,-55,-60,-40,-20]}],chart:{fontFamily:"inherit",type:"bar",stacked:!0,height:350,toolbar:{show:!1}},plotOptions:{bar:{borderRadius:8,horizontal:!1,columnWidth:["12%"],borderRadius:4}},legend:{show:!1},dataLabels:{enabled:!1},stroke:{show:!0,width:2,colors:["transparent"]},xaxis:{categories:["Feb","Mar","Apr","May","Jun","Jul"],axisBorder:{show:!1},axisTicks:{show:!1},labels:{style:{colors:a,fontSize:"12px"}}},yaxis:{min:-80,max:80,labels:{style:{colors:a,fontSize:"12px"}}},fill:{opacity:1},states:{normal:{filter:{type:"none",value:0}},hover:{filter:{type:"none",value:0}},active:{allowMultipleDataPointsSelection:!1,filter:{type:"none",value:0}}},tooltip:{style:{fontSize:"12px"},y:{formatter:function(t){return"$"+t+" thousands"}}},colors:[r,s],grid:{borderColor:o,strokeDashArray:4,yaxis:{lines:{show:!0}}}}).render()),function(){var t=document.getElementById("kt_mixed_widget_1_chart");if(t){var e={series:[68],chart:{fontFamily:"inherit",height:parseInt(t.getAttribute("data-kt-height")),type:"radialBar",toolbar:{show:!1}},grid:{padding:{}},plotOptions:{radialBar:{borderRadius:4,startAngle:-90,endAngle:90,hollow:{margin:0,size:"70%"},dataLabels:{showOn:"always",name:{show:!0,fontFamily:"inherit",fontSize:"13px",fontWeight:500,offsetY:-4,color:KTUtil.getCssVariableValue("--bs-gray-400")},value:{color:KTUtil.getCssVariableValue("--bs-info"),fontFamily:"inherit",fontSize:"30px",fontWeight:700,offsetY:-40,show:!0}},track:{background:KTUtil.getCssVariableValue("--bs-light-info"),strokeWidth:"100%"}}},colors:[KTUtil.getCssVariableValue("--bs-info")],stroke:{lineCap:"round"},labels:["Weekly Followers"],grid:{padding:{bottom:0}}};new ApexCharts(t,e).render()}}(),function(){var t=document.getElementById("kt_mixed_widget_2_chart");if(t){var e=parseInt(KTUtil.css(t,"height"));new ApexCharts(t,{series:[{name:"Inflation",data:[2.3,3.1,4,10.1,4,3.6,3.2]}],chart:{fontFamily:"inherit",height:e,type:"bar",toolbar:{show:!1}},grid:{show:!1,padding:{top:0,bottom:-5}},plotOptions:{bar:{borderRadius:10,dataLabels:{position:"top"}}},dataLabels:{enabled:!1,formatter:function(t){return t+"%"},offsetY:-20,style:{fontSize:"12px",colors:["#304758"]}},xaxis:{labels:{show:!1},categories:["Jan","Feb","Mar","Apr","May","Jun","Jul"],position:"top",axisBorder:{show:!1},axisTicks:{show:!1},crosshairs:{show:!1},tooltip:{enabled:!1}},yaxis:{show:!1,axisTicks:{show:!1},labels:{show:!1,formatter:function(t){return t+"%"}}},title:{text:"Monthly Inflation in Argentina, 2002",floating:!0,offsetY:330,align:"center",style:{color:"#444"}}}).render()}}(),n=document.querySelectorAll(".statistics-widget-1-chart"),[].slice.call(n).map((function(t){var e=parseInt(KTUtil.css(t,"height"));if(t){var i=t.getAttribute("data-kt-chart-color"),a=KTUtil.getCssVariableValue("--bs-gray-800"),o=KTUtil.getCssVariableValue("--bs-"+i),r=KTUtil.getCssVariableValue("--bs-light-"+i);new ApexCharts(t,{series:[{name:"Net Profit",data:[30,45,32,70,40]}],chart:{fontFamily:"inherit",type:"area",height:e,toolbar:{show:!1},zoom:{enabled:!1},sparkline:{enabled:!0}},plotOptions:{},legend:{show:!1},dataLabels:{enabled:!1},fill:{type:"solid",opacity:.3},stroke:{curve:"smooth",show:!0,width:3,colors:[o]},xaxis:{categories:["Feb","Mar","Apr","May","Jun","Jul"],axisBorder:{show:!1},axisTicks:{show:!1},labels:{show:!1,style:{colors:a,fontSize:"12px"}},crosshairs:{show:!1,position:"front",stroke:{color:"#E4E6EF",width:1,dashArray:3}},tooltip:{enabled:!0,formatter:void 0,offsetY:0,style:{fontSize:"12px"}}},yaxis:{min:0,max:80,labels:{show:!1,style:{colors:a,fontSize:"12px"}}},states:{normal:{filter:{type:"none",value:0}},hover:{filter:{type:"none",value:0}},active:{allowMultipleDataPointsSelection:!1,filter:{type:"none",value:0}}},tooltip:{style:{fontSize:"12px"},y:{formatter:function(t){return"$"+t+" thousands"}}},colors:[o],markers:{colors:[o],strokeColor:[r],strokeWidth:3}}).render()}})),t("#kt_charts_widget_2_tab_1","#kt_charts_widget_2_chart_1",[30,40,30,25,40,45,30,20,40,25,20,30],!0),t("#kt_charts_widget_2_tab_2","#kt_charts_widget_2_chart_2",[25,30,25,45,30,40,30,25,40,20,25,30],!1)}}}();KTUtil.onDOMContentLoaded((function(){KTWidgets.init()}));

							</script>

							@endif

						</body> 

						</html>