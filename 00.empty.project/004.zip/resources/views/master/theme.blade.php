<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
	<title>Magnitude Construction : My Bali Project</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta charset="utf-8" />
	<meta property="og:locale" content="fr_FR" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="" />
	<meta property="og:url" content="https://keenthemes.com/products/ceres-html-pro" />
	<meta property="og:site_name" content="" />
	<link rel="canonical" href="" />
	<link rel="shortcut icon" href="{{ url('imgs/logo.png') }}" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
	<link href="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ url('theme/assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet" type="text/css" />
	<link href="{{ url('theme/assets/css/style.bundle.css') }}" rel="stylesheet" type="text/css" />
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src= '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5FS8GGP');</script>
	<style type="text/css">

		.iconPicture { 
			border:0; 
			background-color: transparent; 
			width: 20px; float: left;
		}
		.iconPicture:before {
			font-family: "Font Awesome 5 Free";
			content: "\f030"; /*f0e9*/
			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
			background-size: 40px 40px;
			font-size: 20px;
			color:black;
		}

		.umbrella { 
			border:0;  width: 20px; float: left;
			background-color: transparent; 
		}
		.umbrella:before {
			font-family: "Font Awesome 5 Free";
			content: "\2614"; /*f0e9*/
			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
			background-size: 40px 40px;
			font-size: 20px;
			color:black;
		}

		.ceremony { 
			border:0; 
			background-color: transparent; background-size: 20px 20px;
		}
		.ceremony:before {
			content: url('{{ url('imgs/cer.jpg')  }}');

			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
		}

		.holiday { 
			border:0; 
			background-color: transparent; background-size: 20px 20px;
		}
		.holiday:before {
			content: url('{{ url('imgs/flag.jpg')  }}');

			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
		}

		.cloud { 
			border:0; 
			background-color: transparent; background-size: 20px 20px;
		}
		.cloud:before {
			content: url('{{ url('imgs/cloud.jpg')  }}');

			display: block;
			float: left;
			margin: 0 6px 0 0;
			font-weight: 900;
		}

		.whi { color: white !important }

			/*.holiday { 
				border:0; 
				background-color: transparent; 
			}
			.holiday:before {
				font-family: "Font Awesome 5 Free";
			    content: "\1F384";
			    display: block;
			    float: left;
			    margin: 0 6px 0 0;
			    font-weight: 900;
			    background-size: 40px 40px;
			    font-size: 20px;
			    color:black;
			    }*/

			    .header-fixed[data-kt-sticky-header="on"] .header { background: black !important  }
			    .h-lg-20px {  height: 46px !important;}

			    #kt_content_container { padding-top: 30px; }
			    #kt_content_container .card .card-xxl-stretch { margin-top: 30px; }

			    .menu-state-bg .menu-item.here > .menu-link, .menu-state-bg .menu-item.show > .menu-link { background: rgba(255,255,255,0.1);  }

			    @media only screen and (max-width: 820px) {
			    	.menu-column { background-color: #070F25; }
			    	.bs-stepper-header {  text-align: left !important; }
			    }

			    .connected { background: rgba(255,255,255,0.5); height: 35px; width: 300px }

			    @keyframes flickerAnimation {
				  0%   { opacity:1; }
				  50%  { opacity:0; }
				  100% { opacity:1; }
				}
				@-o-keyframes flickerAnimation{
				  0%   { opacity:1; }
				  50%  { opacity:0; }
				  100% { opacity:1; }
				}
				@-moz-keyframes flickerAnimation{
				  0%   { opacity:1; }
				  50%  { opacity:0; }
				  100% { opacity:1; }
				}
				@-webkit-keyframes flickerAnimation{
				  0%   { opacity:1; }
				  50%  { opacity:0; }
				  100% { opacity:1; }
				}
				.animate-flicker {
				   -webkit-animation: flickerAnimation 1s infinite;
				   -moz-animation: flickerAnimation 1s infinite;
				   -o-animation: flickerAnimation 1s infinite;
				    animation: flickerAnimation 1s infinite;
				}

			</style>

			<style type="text/css">
			  #kt_drawer_chat .accordion-button:not(.collapsed) { color:black !important;  }
			  #kt_drawer_chat .accordion span {  margin-left: 10px; color: rgba(0,0,0,0.6)  }
			  #kt_drawer_chat audio { border-radius: 5px; }
			  #kt_drawer_chat .blue1 { color: #1DA2A4; }
  			  #kt_drawer_chat .gray1 { color: gray !important; }
			  #kt_drawer_chat .fa-check { font-size: 10px; }

			  red {
			    color: red;
			}

			.chat #controls {
			  display: flex;
			  margin-top: 2rem;
			  max-width: 28em;
			} 

			.chat #controls button {
			  flex-grow: 1;
			  height: 30px;
			  min-width: 30px;
			  border: none;
			  border-radius: 0.15rem;
			  background: #ed341d;
			  margin-left: 2px;
			  box-shadow: inset 0 -0.15rem 0 rgba(0, 0, 0, 0.2);
			  cursor: pointer;
			  display: flex;
			  justify-content: center;
			  align-items: center;
			  color:#ffffff;
			  font-weight: bold;
			  font-size: 1rem;
			}

			.chat #controls button:hover, button:focus {
			  outline: none;
			  background: #c72d1c;
			}

			.chat #controls button::-moz-focus-inner {
			  border: 0;
			}

			.chat #controls button:active {
			  box-shadow: inset 0 1px 0 rgba(0, 0, 0, 0.2);

			}

			.chat #controls button:disabled {
			  pointer-events: none;
			  background: lightgray;
			}
			.chat #controls button:first-child {
			  margin-left: 0;
			}

			.chat audio {
			  display: block;
			  width: 100%;
			  margin-top: 0.2rem;
			}

			.chat li {
			  list-style: none;
			  margin-bottom: 1rem;
			}

			.chat #formats {
			  margin-top: 0.5rem;
			  font-size: 80%;
			}

			.chat #recordingsList{
			    max-width: 28em;
			}
			</style>

		</head>
		<body id="kt_body" style=" background-image: url('{{ url('theme/assets/media/patterns/header-bg-dark.png')  }}')" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled">
			
			<!-- <div class="support" style="position: fixed; bottom: 10px; left: 10px; z-index: 999 !important">
				<a href="https://api.whatsapp.com/send?phone=6282145099752" target="_" class="btn btn-light-dark" title="Vous avez des problèmes techniques ? contactez notre support technique en cliquant ici"><i class="fas fa-lightbulb  fs-4 me-2"></i> Support Technique</a>
			</div> -->

			@if($nom_villa_Global=='' or $nom_ptpma_Global='')
			<div style="width: 300px; position: fixed; bottom: 10px; left: 10px; z-index: 999 ">
				<div class="alert alert-dismissible bg-primary d-flex flex-column flex-sm-row w-100 ">
					<span class="svg-icon svg-icon-2hx svg-icon-light me-4 mb-5 mb-sm-0">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<path opacity="0.3" d="M12 22C13.6569 22 15 20.6569 15 19C15 17.3431 13.6569 16 12 16C10.3431 16 9 17.3431 9 19C9 20.6569 10.3431 22 12 22Z" fill="black"></path>
							<path d="M19 15V18C19 18.6 18.6 19 18 19H6C5.4 19 5 18.6 5 18V15C6.1 15 7 14.1 7 13V10C7 7.6 8.7 5.6 11 5.1V3C11 2.4 11.4 2 12 2C12.6 2 13 2.4 13 3V5.1C15.3 5.6 17 7.6 17 10V13C17 14.1 17.9 15 19 15ZM11 10C11 9.4 11.4 9 12 9C12.6 9 13 8.6 13 8C13 7.4 12.6 7 12 7C10.3 7 9 8.3 9 10C9 10.6 9.4 11 10 11C10.6 11 11 10.6 11 10Z" fill="black"></path>
						</svg>
					</span>
					<div class="d-flex flex-column text-light pe-0 pe-sm-10">
						<span style="font-weight: bold;">{{ __('header.a18') }} <a style="color:#07153A" href="https://villa.magnitudeconstruction.com/ptpma#Villa_PTPMA">{{ __('header.a19') }}</a></span>
					</div>
					<button type="button" class="position-absolute position-sm-relative m-2 m-sm-0 top-0 end-0 btn btn-icon ms-sm-auto" data-bs-dismiss="alert">
						<span class="svg-icon svg-icon-2x svg-icon-light">
							<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
								<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black"></rect>
								<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black"></rect>
							</svg>
						</span>
					</button>
				</div>
			</div>
			@endif



			<div class="d-flex flex-column flex-root">
				<div class="page d-flex flex-row flex-column-fluid">
					<div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
						<div id="kt_header" class="header align-items-stretch" data-kt-sticky="true" data-kt-sticky-name="header" data-kt-sticky-offset="{default: '200px', lg: '300px'}">
							<div class="container-xxl d-flex align-items-center">
								<div class="d-flex align-items-center d-lg-none ms-n2 me-3" title="Show aside menu">
									<div class="btn btn-icon btn-custom w-30px h-30px w-md-40px h-md-40px" id="kt_header_menu_mobile_toggle">
										<span class="svg-icon svg-icon-2x">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
												<path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black" />
												<path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black" />
											</svg>
										</span>
									</div>
								</div>
								<div class="header-logo me-5 me-md-10 flex-grow-1 flex-lg-grow-0">
									<a href="{{ url('dashboard') }}">
										<img alt="Logo" src="{{ url('imgs/logo_noel.png') }}" class="h-15px h-lg-20px logo-default" style="height: 52px !important;" />
										<img alt="Logo" src="{{ url('imgs/logo_noel.png') }}" class="h-15px h-lg-20px logo-sticky" />
									</a>
								</div>
								<div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1">
									<div class="d-flex align-items-stretch" id="kt_header_nav">
										<div class="header-menu align-items-stretch" data-kt-drawer="true" data-kt-drawer-name="header-menu" data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true" data-kt-drawer-width="{default:'200px', '300px': '250px'}" data-kt-drawer-direction="start" data-kt-drawer-toggle="#kt_header_menu_mobile_toggle" data-kt-swapper="true" data-kt-swapper-mode="prepend" data-kt-swapper-parent="{default: '#kt_body', lg: '#kt_header_nav'}">
											<div class="menu menu-lg-rounded menu-column menu-lg-row menu-state-bg menu-title-gray-700 menu-state-icon-primary menu-state-bullet-primary menu-arrow-gray-400 fw-bold my-5 my-lg-0 align-items-stretch" id="#kt_header_menu" data-kt-menu="true">

												<a href="{{ url('dashboard') }}" style="color: white"><div class="menu-item @if(Route::is('dashboard')) show @endif  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a1') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>

												<a href="{{ url('administration') }}" style="color: white"><div class="menu-item  @if(Route::is('administration')) show @endif menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a2') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>

												<a href="{{ url('ptpma') }}" style="color: white"><div class="menu-item @if(Route::is('ptpma')) show @endif  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a3') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>

												<a href="{{ url('land') }}" style="color: white"><div class="menu-item  @if(Route::is('land')) show @endif menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a4') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>

												<a href="{{ url('architecture') }}" style="color: white"><div class="menu-item @if(Route::is('architecture') or Route::is('plan') or Route::is('design')  or Route::is('design1') or Route::is('design0') or Route::is('interior') ) show @endif  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a5') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>

												<a href="{{ url('construction') }}" style="color: white"><div class="menu-item  @if( Route::is('construction') or Route::is('getPhotosDay') ) show @endif menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a6') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>

												<a href="{{ url('invoices') }}" style="color: white"><div class="menu-item  @if( Route::is('invoices') ) show @endif menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a7') }}</span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>


												@if($nbOldDocs!=0 or $nbOldPics!=0)
												<div data-kt-menu-trigger="{default: 'click', lg: 'hover'}" data-kt-menu-placement="bottom-start" class="@if(Route::is('historyPics') or Route::is('historyDocs')) show @endif menu-item menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi">{{ __('header.a8') }}</span>
														<span class="menu-arrow d-lg-none"></span>
													</span>
													<div class="menu-sub menu-sub-lg-down-accordion menu-sub-lg-dropdown menu-rounded-0 py-lg-4 w-lg-225px">
														@if($nbOldPics!=0)
														<div class="menu-item">
															<a class="menu-link py-3" href="{{ route('historyPics') }}" >
																<span class="menu-bullet"><i class="fa fa-camera"></i></span>
																<span class="menu-title" style="color: black">{{ __('header.a9') }}</span>
															</a>
														</div>
														@endif

														@if($nbOldDocs!=0)
														<div class="menu-item">
															<a class="menu-link py-3" href="{{ route('historyDocs') }}" >
															<span class="menu-bullet"><i class="fa fa-file"></i></span>
															<span class="menu-title" style="color: black">{{ __('header.a10') }}</span>
															</a>
														</div>
														@endif
													</div>
												</div>
												
												@endif

												


												<a href="{{ route('logout') }}" style="color: white" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><div class="menu-item  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi"><i class="fa fa-power-off" style="margin-top: 4px;"></i></span><span class="menu-arrow d-lg-none"></span>
													</span>
												</div></a>
												<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
													@csrf
												</form> 

											</div>
										</div>
									</div>

									<style type="text/css">
										.filter-red{ filter: grayscale(100%) brightness(50%) sepia(100%) hue-rotate(-50deg) saturate(600%) contrast(1); }
									</style>

									<div class="d-flex align-items-stretch flex-shrink-0">
										<div class="topbar d-flex align-items-stretch flex-shrink-0">

											
											<span style="color:white; margin-top: 13px; font-weight: bold;">
												<a href="{{ route('myAccount') }}" style="color:white">{{ Auth::user()->nom }} {{ Auth::user()->pre }}</a>
											</span>
											

											<div class="d-flex align-items-center ms-1 ms-lg-3">
												<div class="btn btn-icon btn-custom btn-active-light w-30px h-30px w-md-40px h-md-40px" id="kt_activities_toggle">
													<span class="svg-icon svg-icon-1 @if($noRead!=0) animate-flicker @endif"  >
														<svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" @if($noRead!=0) class="filter-red" @endif>
															<rect  x="8" y="9" width="3" height="10" rx="1.5" fill="black" />
															<rect opacity="0.5" x="13" y="5" width="3" height="14" rx="1.5" fill="black" />
															<rect x="18" y="11" width="3" height="8" rx="1.5" fill="black" />
															<rect x="3" y="13" width="3" height="6" rx="1.5" fill="black" />
														</svg>
													</span>
												</div>
											</div>

											@if(session()->has('locale') && session()->get('locale')=='en')
											<a href="{{ url('locale/fr') }}" title="Français" >
												<div class="menu-item  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi"><img src="{{ url('imgs/fr.png') }}" style="margin-top: 4px; width: 20px"></span>
														<span class="menu-arrow d-lg-none"></span>
													</span>
												</div>
											</a>
											@elseif(session()->has('locale') && session()->get('locale')=='fr')
											<a href="{{ url('locale/en') }}" title="English" >
												<div class="menu-item  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi"><img src="{{ url('imgs/en.png') }}" style="margin-top: 4px; width: 20px"></span>
														<span class="menu-arrow d-lg-none"></span>
													</span>
												</div>
											</a>
											@else
											<a href="{{ url('locale/en') }}" title="English" >
												<div class="menu-item  menu-lg-down-accordion me-lg-1">
													<span class="menu-link py-3">
														<span class="menu-title whi"><img src="{{ url('imgs/en.png') }}" style="margin-top: 4px; width: 20px"></span>
														<span class="menu-arrow d-lg-none"></span>
													</span>
												</div>
											</a>
											@endif


											<!-- <div class="d-flex align-items-center ms-1 ms-lg-3">
												<div onclick="showChat();" class="btn btn-icon btn-custom btn-active-light position-relative w-30px h-30px w-md-40px h-md-40px" data-bs-toggle="tooltip" title="Messagerie" data-bs-html="true" data-bs-placement="bottom" id="kt_drawer_chat_toggle">
													<span class="svg-icon svg-icon-1" >
														<svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" >
															<path style="@if($chat_msg_nb!=0) fill:red; @endif " id="iconChat" opacity="0.3" d="M20 3H4C2.89543 3 2 3.89543 2 5V16C2 17.1046 2.89543 18 4 18H4.5C5.05228 18 5.5 18.4477 5.5 19V21.5052C5.5 22.1441 6.21212 22.5253 6.74376 22.1708L11.4885 19.0077C12.4741 18.3506 13.6321 18 14.8167 18H20C21.1046 18 22 17.1046 22 16V5C22 3.89543 21.1046 3 20 3Z" fill="black" />
															<rect x="6" y="12" width="7" height="2" rx="1" fill="black" />
															<rect x="6" y="7" width="12" height="2" rx="1" fill="black" />
														</svg>
													</span>
													<span class="bullet bullet-dot bg-success h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink"></span>
												</div>
											</div> -->

										</div>
									</div>
								</div>

											

										</div>
									</div>

									

									@yield('content') 


								</div>
							</div>

							<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
								<div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
									<div class="text-dark order-2 order-md-1">
										<span class="text-muted fw-bold me-1"><?php echo date("Y"); ?> ©</span>
										<a href="https://magnitudeconstruction.com/" target="_blank" class="text-gray-800 text-hover-primary">Magnitude Construction</a>
									</div>
									<ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">

										<li class="menu-item">
											<!-- <a href="https://magnitudeconstruction.com/contactez-nous/" target="_blank" class="menu-link px-2">{{ __('header.a11') }}</a> -->
										</li>
									</ul>
								</div>
							</div>

						</div>

						<div id="kt_activities" class="bg-body" data-kt-drawer="true" data-kt-drawer-name="activities" data-kt-drawer-activate="true" data-kt-drawer-overlay="true"  data-kt-drawer-direction="end" data-kt-drawer-toggle="#kt_activities_toggle" data-kt-drawer-close="#kt_activities_close" >
							<div class="card shadow-none rounded-0">
								<div class="card-header" id="kt_activities_header">
									<h3 class="card-title fw-bolder text-dark">{{ __('header.a12') }}</h3>
									<div class="card-toolbar">
										<a href="{{ url('markAllAsRead') }}" class="btn btn-outline btn-outline-dashed btn-outline-default me-2 mb-2">{{ __('header.a13') }}</a>
									</div>
								</div>
								<div class="card-body position-relative" id="kt_activities_body">
									<div id="kt_activities_scroll" class="position-relative scroll-y me-n5 pe-5" data-kt-scroll="true" data-kt-scroll-height="auto" data-kt-scroll-wrappers="#kt_activities_body" data-kt-scroll-dependencies="#kt_activities_header, #kt_activities_footer" data-kt-scroll-offset="5px" style="width: 440px !important">
										<div class="timeline">
											@foreach($notification as $n)
											@if($n->par!=Auth::user()->ref )
											<div class="timeline-item">
												<div class="timeline-line w-40px"></div>
												<div class="timeline-icon symbol symbol-circle symbol-40px" >
													<div class="symbol-label bg-light"  style="background:@if($n->lu==0 ) rgba(255,0,0,0.05) @endif  !important">
														<span class="svg-icon svg-icon-2 svg-icon-gray-500">
															<svg  xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																<path d="M6 8.725C6 8.125 6.4 7.725 7 7.725H14L18 11.725V12.925L22 9.725L12.6 2.225C12.2 1.925 11.7 1.925 11.4 2.225L2 9.725L6 12.925V8.725Z" fill="black" />
																<path opacity="0.3" d="M22 9.72498V20.725C22 21.325 21.6 21.725 21 21.725H3C2.4 21.725 2 21.325 2 20.725V9.72498L11.4 17.225C11.8 17.525 12.3 17.525 12.6 17.225L22 9.72498ZM15 11.725H18L14 7.72498V10.725C14 11.325 14.4 11.725 15 11.725Z" fill="black" />
															</svg>
														</span>
													</div>
												</div>
												<div class="timeline-content mb-10 mt-n1">
													<div class="pe-3 mb-5">
														<div class="fs-5 fw-bold mb-2" style="font-size: 13px !important; font-weight: @if($n->lu==1 ) normal @else bold @endif !important;">{{ $n->msg }}</div>
														<div class="d-flex align-items-center mt-1 fs-6">
															<div class="text-muted me-2 fs-7">{{ $n->fait }}</div>
														</div>
													</div>
												</div>
											</div>
											@endif
											@endforeach
										</div>
									</div>
								</div>
							</div>
						</div>


						<form method="POST" action="{{ route('rendezvous') }}" enctype="multipart/form-data">
							{{ csrf_field() }}
							<div class="modal fade" tabindex="-1" id="rendez-vous">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<h5 class="modal-title">{{ __('header.a14') }}</h5>
											<div class="btn btn-icon btn-sm btn-active-light-primary ms-2" data-bs-dismiss="modal" aria-label="Close">
												<span class="svg-icon svg-icon-2x"></span>
											</div>
										</div>

										<div class="modal-body">
											<input type="date" class="form-control form-control-solid" name="dat" required />
											<br>
											<textarea class="form-control form-control-solid" name="obs" placeholder="Observations"></textarea>
										</div>

										<div class="modal-footer">
											<button type="button" class="btn btn-light" data-bs-dismiss="modal">{{ __('header.a15') }}</button>
											<button type="submit" class="btn btn-primary">{{ __('header.a16') }}</button>
										</div>
									</div>
								</div>
							</div>
						</form>


						


						<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
							<span class="svg-icon">
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
									<rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
									<path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
								</svg>
							</span>
						</div>

						@if(!Route::is('design0'))
						<script>var hostUrl = "{{ url('theme/assets/index.html') }}";</script>
						<script src="{{ url('theme/assets/plugins/global/plugins.bundle.js') }}"></script>
						<script src="{{ url('theme/assets/js/scripts.bundle.js') }}"></script>
						<script src="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.js') }}"></script>
						<script src="{{ url('theme/assets/plugins/custom/fullcalendar/lang-all.js') }}"></script>
						<!-- <script src="{{ url('theme/assets/js/custom/widgets.js') }}"></script> -->
						<script src="{{ url('theme/assets/js/custom/intro.js') }}"></script>
						<noscript>
							<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5FS8GGP" height="0" width="0" style="display:none;visibility:hidden"></iframe>
						</noscript>
						@endif

						@if(Route::is('construction'))

						<!-- Pour changer la langue du calendrier = Ajouter locale: "fr",	 -->

						<script type="text/javascript">
							var gray =  KTUtil.getCssVariableValue("--kt-success-active");
							"use strict";var KTWidgets=function(){var t=function(t,e,i,a){var o=document.querySelector(e);if(o){
								var r={series:[{name:"Profit",data:i}],chart:{fontFamily:"inherit",type:"bar",height:parseInt(KTUtil.css(o,"height")),toolbar:{show:!1}},plotOptions:{bar:{horizontal:!1,columnWidth:["30%"],borderRadius:4}},legend:{show:!1},dataLabels:{enabled:!1},stroke:{show:!0,width:2,colors:["transparent"]},xaxis:{crosshairs:{show:!1},categories:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],axisBorder:{show:!1},axisTicks:{show:!1},labels:{style:{colors:KTUtil.getCssVariableValue("--bs-gray-400"),fontSize:"12px"}}},yaxis:{crosshairs:{show:!1},labels:{style:{colors:KTUtil.getCssVariableValue("--bs-gray-400"),fontSize:"12px"}}},states:{normal:{filter:{type:"none",value:0}},hover:{filter:{type:"none"}},active:{allowMultipleDataPointsSelection:!1,filter:{type:"none",value:0}}},fill:{opacity:1},tooltip:{style:{fontSize:"12px"},y:{formatter:function(t){return"$"+t+"k"}}},colors:[KTUtil.getCssVariableValue("--bs-primary")],grid:{borderColor:KTUtil.getCssVariableValue("--bs-gray-300"),strokeDashArray:4,yaxis:{lines:{show:!0}}}},s=new ApexCharts(o,r),n=!1,l=document.querySelector(t);!0===a&&(s.render(),n=!0),l.addEventListener("shown.bs.tab",(function(t){0==n&&(s.render(),n=!0)}))}};return{init:function(){var e,i,a,o,r,s,n;(e=document.querySelector("#kt_user_menu_dark_mode_toggle"))&&e.addEventListener("click",(function(){window.location.href=this.getAttribute("data-kt-url")})),function(){if("undefined"!=typeof FullCalendar&&document.querySelector("#kt_calendar_widget_1")){var t=moment().startOf("day"),e=t.format("YYYY-MM"),i=t.clone().subtract(1,"day").format("YYYY-MM-DD"),a=t.format("YYYY-MM-DD"),o=t.clone().add(1,"day").format("YYYY-MM-DD"),r=document.getElementById("kt_calendar_widget_1");new FullCalendar.Calendar(r,{headerToolbar:{left:"prev,next today",center:"title",right:"dayGridMonth,timeGridWeek,timeGridDay,listMonth"},height:800,contentHeight:780,aspectRatio:3,nowIndicator:!0,now:a+"T09:25:00",views:{dayGridMonth:{buttonText:"Mois"},timeGridWeek:{buttonText:"Semaine"},timeGridDay:{buttonText:"Jour"}},initialView:"dayGridMonth",initialDate:a,locale: "fr",eventLimit: true,editable:!0,dayMaxEvents:!1,navLinks:!0,


									events : [ 								

									@if($a0!="")
									<?php
									if($a1=="") {
										$z0 = date('Y-m-d', strtotime("+1 days"));
									} else { $z0 = $a1;   }
									?>
									{title:"Début du projet : <?php echo $a0; ?>",start:"<?php echo $a0; ?>",end:"<?php echo $z0; ?>",description:"",color:"#0aa2a5"},
									@endif

									@if($a1!="")
									<?php
									if($a2=="") {
										$z1 = date('Y-m-d', strtotime("+1 days"));
									} else { $z1 = $a2;   }
									?>
									{title:"Fondation : <?php echo $a1; ?>",start:"<?php echo $a1; ?>",end:"<?php echo $z1; ?>",description:"",color:"green"},
									@endif

									@if($a2!="")
									<?php
									if($a3=="") {
										$z2 = date('Y-m-d', strtotime("+1 days"));
									} else { $z2 = $a3;   }
									?>
									{title:"Structure : <?php echo $a2; ?>",start:"<?php echo $a2; ?>",end:"<?php echo $z2; ?>",description:"",color:"blue"},
									@endif

									@if($a3!="")
									<?php
									if($a4=="") {
										$z3 = date('Y-m-d', strtotime("+1 days"));
									} else { $z3 = $a4;   }
									?>
									{title:"Mur : <?php echo $a3; ?>",start:"<?php echo $a3; ?>",end:"<?php echo $z3; ?>",description:"",color:"orange"},
									@endif

									@if($a4!="")
									<?php
									if($a5=="") {
										$z4 = date('Y-m-d', strtotime("+1 days"));
									} else { $z4 = $a5;   }
									?>
									{title:"Toiture : <?php echo $a4; ?>",start:"<?php echo $a4; ?>",end:"<?php echo $z4; ?>",description:"",color:"brown"},
									@endif

									@if($a5!="")
									<?php
									if($a6=="") {
										$z5 = date('Y-m-d', strtotime("+1 days"));
									} else { $z5 = $a6;   }
									?>
									{title:"Plâtre aci : <?php echo $a5; ?>",start:"<?php echo $a5; ?>",end:"<?php echo $z5; ?>",description:"",color:"red"},
									@endif

									@if($a6!="")
									<?php
									if($a7=="") {
										$z6 = date('Y-m-d', strtotime("+1 days"));
									} else { $z6 = $a7;   }
									?>
									{title:"Plafond : <?php echo $a6; ?>",start:"<?php echo $a6; ?>",end:"<?php echo $z6; ?>",description:"",color:"pink"},
									@endif

									@if($a7!="")
									<?php
									if($a8=="") {
										$z7 = date('Y-m-d', strtotime("+1 days"));
									} else { $z7 = $a8;   }
									?>
									{title:"Granit : <?php echo $a7; ?>",start:"<?php echo $a7; ?>",end:"<?php echo $z7; ?>",description:"",color:"gray"},
									@endif

									@if($a8!="")
									<?php
									if($a9=="") {
										$z8 = date('Y-m-d', strtotime("+1 days"));
									} else { $z8 = $a9;   }
									?>
									{title:"Pierre : <?php echo $a8; ?>",start:"<?php echo $a8; ?>",end:"<?php echo $z8; ?>",description:"",color:"black"},
									@endif

									@if($a9!="")
									<?php
									if($a10=="") {
										$z9 = date('Y-m-d', strtotime("+1 days"));
									} else { $z9 = $a10;   }
									?>
									{title:"Finition : <?php echo $a9; ?>",start:"<?php echo $a9; ?>",end:"<?php echo $z9; ?>",description:"",color:"#6e10ea"},
									@endif

									@if($a10!="")
									<?php
									if($a10=="") {
										$z10 = date('Y-m-d', strtotime("+1 days"));
									} else { $z10 = $a10;   }
									?>
									{title:"Fin : <?php echo $a10; ?>",start:"<?php echo $a10; ?>",end:"<?php echo $z9; ?>",description:"",color:"#0aa2a5"},
									@endif

									@foreach($pics as $p)
									{url:"{{ url('getPhotosDay', ['date'=>$p->date]) }}",start:"<?php echo date("Y-m-d", strtotime($p->date)); ?>",className:"iconPicture"},
									@endforeach

									@foreach($days as $p)
									@if($p->typ=='Rainy days')
									{ start:"<?php echo date("Y-m-d", strtotime($p->dat)); ?>", className:"umbrella" },
									@elseif($p->typ=='Ceremony days')
									{ start:"<?php echo date("Y-m-d", strtotime($p->dat)); ?>", className:"ceremony" },
									@else
									{ start:"<?php echo date("Y-m-d", strtotime($p->dat)); ?>", className:"holiday" },
									@endif
									@endforeach


									<?php 
									$start = new DateTime('2022-11-15');
									$end = new DateTime('2023-03-15');
									foreach (new DatePeriod($start, new DateInterval('P1D'), $end) as $dt) { ?>
									    {
								            start: "<?php echo $dt->format('Y-m-d'); ?>",
								            className:"cloud",
								        },
									<?php } ?>

									

									]


								}).render().setOption('locale', 'es')}}(),i=document.getElementById("kt_lists_widget_3_chart"),a=KTUtil.getCssVariableValue("--bs-gray-500"),o=KTUtil.getCssVariableValue("--bs-gray-200"),r=KTUtil.getCssVariableValue("--bs-primary"),s=KTUtil.getCssVariableValue("--bs-info"),i&&(parseInt(KTUtil.css(i,"height")),new ApexCharts(i,{series:[{name:"Net Profit",data:[40,50,65,70,50,30]},{name:"Revenue",data:[-30,-40,-55,-60,-40,-20]}],chart:{fontFamily:"inherit",type:"bar",stacked:!0,height:350,toolbar:{show:!1}},plotOptions:{bar:{borderRadius:8,horizontal:!1,columnWidth:["12%"],borderRadius:4}},legend:{show:!1},dataLabels:{enabled:!1},stroke:{show:!0,width:2,colors:["transparent"]},xaxis:{categories:["Feb","Mar","Apr","May","Jun","Jul"],axisBorder:{show:!1},axisTicks:{show:!1},labels:{style:{colors:a,fontSize:"12px"}}},yaxis:{min:-80,max:80,labels:{style:{colors:a,fontSize:"12px"}}},fill:{opacity:1},states:{normal:{filter:{type:"none",value:0}},hover:{filter:{type:"none",value:0}},active:{allowMultipleDataPointsSelection:!1,filter:{type:"none",value:0}}},tooltip:{style:{fontSize:"12px"},y:{formatter:function(t){return"$"+t+" thousands"}}},colors:[r,s],grid:{borderColor:o,strokeDashArray:4,yaxis:{lines:{show:!0}}}}).render()),function(){var t=document.getElementById("kt_mixed_widget_1_chart");if(t){var e={series:[68],chart:{fontFamily:"inherit",height:parseInt(t.getAttribute("data-kt-height")),type:"radialBar",toolbar:{show:!1}},grid:{padding:{}},plotOptions:{radialBar:{borderRadius:4,startAngle:-90,endAngle:90,hollow:{margin:0,size:"70%"},dataLabels:{showOn:"always",name:{show:!0,fontFamily:"inherit",fontSize:"13px",fontWeight:500,offsetY:-4,color:KTUtil.getCssVariableValue("--bs-gray-400")},value:{color:KTUtil.getCssVariableValue("--bs-info"),fontFamily:"inherit",fontSize:"30px",fontWeight:700,offsetY:-40,show:!0}},track:{background:KTUtil.getCssVariableValue("--bs-light-info"),strokeWidth:"100%"}}},colors:[KTUtil.getCssVariableValue("--bs-info")],stroke:{lineCap:"round"},labels:["Weekly Followers"],grid:{padding:{bottom:0}}};new ApexCharts(t,e).render()}}(),function(){var t=document.getElementById("kt_mixed_widget_2_chart");if(t){var e=parseInt(KTUtil.css(t,"height"));new ApexCharts(t,{series:[{name:"Inflation",data:[2.3,3.1,4,10.1,4,3.6,3.2]}],chart:{fontFamily:"inherit",height:e,type:"bar",toolbar:{show:!1}},grid:{show:!1,padding:{top:0,bottom:-5}},plotOptions:{bar:{borderRadius:10,dataLabels:{position:"top"}}},dataLabels:{enabled:!1,formatter:function(t){return t+"%"},offsetY:-20,style:{fontSize:"12px",colors:["#304758"]}},xaxis:{labels:{show:!1},categories:["Jan","Feb","Mar","Apr","May","Jun","Jul"],position:"top",axisBorder:{show:!1},axisTicks:{show:!1},crosshairs:{show:!1},tooltip:{enabled:!1}},yaxis:{show:!1,axisTicks:{show:!1},labels:{show:!1,formatter:function(t){return t+"%"}}},title:{text:"Monthly Inflation in Argentina, 2002",floating:!0,offsetY:330,align:"center",style:{color:"#444"}}}).render()}}(),n=document.querySelectorAll(".statistics-widget-1-chart"),[].slice.call(n).map((function(t){var e=parseInt(KTUtil.css(t,"height"));if(t){var i=t.getAttribute("data-kt-chart-color"),a=KTUtil.getCssVariableValue("--bs-gray-800"),o=KTUtil.getCssVariableValue("--bs-"+i),r=KTUtil.getCssVariableValue("--bs-light-"+i);new ApexCharts(t,{series:[{name:"Net Profit",data:[30,45,32,70,40]}],chart:{fontFamily:"inherit",type:"area",height:e,toolbar:{show:!1},zoom:{enabled:!1},sparkline:{enabled:!0}},plotOptions:{},legend:{show:!1},dataLabels:{enabled:!1},fill:{type:"solid",opacity:.3},stroke:{curve:"smooth",show:!0,width:3,colors:[o]},xaxis:{categories:["Feb","Mar","Apr","May","Jun","Jul"],axisBorder:{show:!1},axisTicks:{show:!1},labels:{show:!1,style:{colors:a,fontSize:"12px"}},crosshairs:{show:!1,position:"front",stroke:{color:"#E4E6EF",width:1,dashArray:3}},tooltip:{enabled:!0,formatter:void 0,offsetY:0,style:{fontSize:"12px"}}},yaxis:{min:0,max:80,labels:{show:!1,style:{colors:a,fontSize:"12px"}}},states:{normal:{filter:{type:"none",value:0}},hover:{filter:{type:"none",value:0}},active:{allowMultipleDataPointsSelection:!1,filter:{type:"none",value:0}}},tooltip:{style:{fontSize:"12px"},y:{formatter:function(t){return"$"+t+" thousands"}}},colors:[o],markers:{colors:[o],strokeColor:[r],strokeWidth:3}}).render()}})),t("#kt_charts_widget_2_tab_1","#kt_charts_widget_2_chart_1",[30,40,30,25,40,45,30,20,40,25,20,30],!0),t("#kt_charts_widget_2_tab_2","#kt_charts_widget_2_chart_2",[25,30,25,45,30,40,30,25,40,20,25,30],!1)}}}();KTUtil.onDOMContentLoaded((function(){KTWidgets.init()}));

							</script>

							@endif









<!-- Chat Panel -->
<div id="kt_drawer_chat" class="chat bg-body drawer drawer-end drawer-off" data-kt-drawer="true" data-kt-drawer-name="chat" data-kt-drawer-activate="true" data-kt-drawer-overlay="true" data-kt-drawer-width="{default:'300px', 'md': '500px'}" data-kt-drawer-direction="end" data-kt-drawer-toggle="#kt_drawer_chat_toggle" data-kt-drawer-close="#kt_drawer_chat_close" style="width: 500px !important;">
    <div class="card w-100 rounded-0 border-0" id="kt_drawer_chat_messenger">
        <div class="card-header pe-5" id="kt_drawer_chat_messenger_header">
            <div class="card-title">
                <div class="d-flex justify-content-center flex-column me-3">
                    <a href="#" class="fs-4 fw-bolder text-gray-900 text-hover-primary me-1 mb-2 lh-1">{{ Auth::user()->nom }} {{ Auth::user()->pre }}</a>
                    <div class="mb-0 lh-1">
                        <span class="badge badge-success badge-circle w-10px h-10px me-1"></span>
                        <span class="fs-7 fw-bold text-muted">Active</span>
                    </div>
                </div>
            </div>
            <div class="card-toolbar">
                <div class="btn btn-sm btn-icon btn-active-light-primary" id="kt_drawer_chat_close">
                    <span class="svg-icon svg-icon-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor"></rect>
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"></rect>
                        </svg>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="card-body" id="kt_drawer_chat_messenger_body">
            <div class="scroll-y me-n5 pe-5" id="messages" data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_drawer_chat_messenger_header, #kt_drawer_chat_messenger_footer" data-kt-scroll-wrappers="#kt_drawer_chat_messenger_body" data-kt-scroll-offset="0px" style="height: 688px;">
                @foreach($chat_msg as $m)
                    @if($m->via==Auth::user()->ref)
                        @if($m->msg_typ!='audio')
                        <div class="d-flex justify-content-end mb-10">
                            <div class="d-flex flex-column align-items-end">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="me-3">
                                        <span class="text-muted fs-7 mb-1">{{ date('d.m.Y H:i:s', strtotime($m->fait)) }}  </span>
                                        <span class="fs-5 fw-bolder text-gray-900 ms-1">@if($m->vu==1)<i class="fa fa-check blue1"></i>@else <i class="fa fa-clock"></i> @endif</span>
                                    </div>
                                </div>
                                <div class="p-5 rounded bg-light-primary text-dark fw-bold mw-lg-400px text-end" data-kt-element="message-text">{{ $m->msg }}</div>
                            </div>
                        </div>
                        @else
                        <div class="d-flex justify-content-end mb-10">
                            <div class="d-flex flex-column align-items-end">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="me-3">
                                        <span class="text-muted fs-7 mb-1">{{ date('d.m.Y H:i:s', strtotime($m->fait)) }}</span>
                                        <span href="#" class="fs-5 fw-bolder text-gray-900 ms-1">@if($m->vu==1)<i class="fa fa-check blue1"></i>@else <i class="fa fa-clock"></i> @endif</span>
                                    </div>
                                </div>
                                    <audio controls="" src="{{ url('media/audio/') }}/{{ $m->audio }}"></audio>
                            </div>
                        </div>
                        @endif
                    @elseif($m->to==Auth::user()->ref)
                        @if($m->msg_typ!='audio')
                        <div class="d-flex justify-content-start mb-10">
                            <div class="d-flex flex-column align-items-start">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="ms-3">
                                        <a href="#" class="fs-5 fw-bolder text-gray-900 me-1">Magnitude</a>
                                        <span class="text-muted fs-7 mb-1">{{ date('d.m.Y H:i:s', strtotime($m->fait)) }}</span>
                                    </div>
                                </div>
                                <div class="p-5 rounded bg-light-info text-dark fw-bold mw-lg-400px text-start" data-kt-element="message-text">{{ $m->msg }}</div>
                            </div>
                        </div>
                        @else
                        <div class="d-flex justify-content-start mb-10">
                            <div class="d-flex flex-column align-items-start">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="ms-3">
                                        <a href="#" class="fs-5 fw-bolder text-gray-900 me-1">Magnitude</a>
                                        <span class="text-muted fs-7 mb-1">{{ date('d.m.Y H:i:s', strtotime($m->fait)) }}</span>
                                    </div>
                                </div>
                                <audio controls="" src="{{ url('media/audio/') }}/{{ $m->audio }}"></audio>
                            </div>
                        </div>
                        @endif
                    @endif
                @endforeach
                <div id="last"></div>
            </div>
        </div>
        
        <form method="POST" action="{{ route('chatAdded') }}" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="card-footer pt-4" id="kt_drawer_chat_messenger_footer">
                <input type="hidden" name="to" value="Magnitude">
                <textarea class="form-control form-control-flush mb-3" rows="1" data-kt-element="input" placeholder="Votre message" name="msg" id="msg"></textarea>
                <div class="d-flex flex-stack">
                    <button class="btn btn-primary" id="sendMessageText" type="button" data-kt-element="send">Envoyer</button>
                    <div class="holder">
                        <div id="controls">
                            <button type="button" id="recordButton"><i class="fa fa-microphone" id='record' style="font-size: 16px; color: white;"></i></button>
                            <button type="button" id="pauseButton" disabled><i class="fa fa-pause" id='pause' style="font-size: 16px; color: white;"></i></button>
                            <button type="button" id="stopButton" disabled><i class="fa fa-stop" id='stop' style="font-size: 16px; color: white;"></i></button>
                        </div>
                        <div id="formats"></div>
                        <p><strong></strong></p>
                        <ol id="recordingsList"></ol>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript" src="https://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript" src="{{ url('audio/recorder.js') }}"></script>
<script type="text/javascript">
URL = window.URL || window.webkitURL;

var gumStream; var rec; var input;                          

var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext 

var recordButton = document.getElementById("recordButton");
var stopButton = document.getElementById("stopButton");
var pauseButton = document.getElementById("pauseButton");

recordButton.addEventListener("click", startRecording);
stopButton.addEventListener("click", stopRecording);
pauseButton.addEventListener("click", pauseRecording);

function startRecording() {
    console.log("recordButton clicked");
    var constraints = { audio: true, video:false }
    recordButton.disabled = true;
    stopButton.disabled = false;
    pauseButton.disabled = false
    navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
        console.log("getUserMedia() success, stream created, initializing Recorder.js ...");
        audioContext = new AudioContext();
        gumStream = stream;
        input = audioContext.createMediaStreamSource(stream);
        rec = new Recorder(input,{numChannels:1})
        rec.record()
        console.log("Recording started");
    }).catch(function(err) {
        recordButton.disabled = false;
        stopButton.disabled = true;
        pauseButton.disabled = true
    });
}

function pauseRecording(){
    console.log("pauseButton clicked rec.recording=",rec.recording );
    if (rec.recording){
        rec.stop();
        pauseButton.innerHTML='<i class="fa fa-pause" id="play" style="font-size: 16px; color: white;"></i>';
    }else{
        rec.record()
        pauseButton.innerHTML='<i class="fa fa-pause" id="pause" style="font-size: 16px; color: white;"></i>';
    }
}

function stopRecording() {
    console.log("stopButton clicked");
    stopButton.disabled = true;
    recordButton.disabled = false;
    pauseButton.disabled = true;
    pauseButton.innerHTML='<i class="fa fa-pause" id="pause" style="font-size: 16px; color: white;"></i>';
    rec.stop();
    gumStream.getAudioTracks()[0].stop();
    rec.exportWAV(createDownloadLink);
}

function shuffle(string) {
    var parts = string.split('');
    for (var i = parts.length; i > 0;) {
        var random = parseInt(Math.random() * i);
        var temp = parts[--i];
        parts[i] = parts[random];
        parts[random] = temp;
    }
    return parts.join('');
}

function createDownloadLink(blob) {
    var url = URL.createObjectURL(blob);
    var au = document.createElement('audio');
    var li = document.createElement('li');
    var link = document.createElement('a');
    var filename = shuffle('1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890');
    au.controls = true;
    au.src = url;
    link.href = url;
    link.download = filename+".wav"; 
    filenameOk = filename+".wav"; 
      var xhr=new XMLHttpRequest();
      xhr.onload=function(e) {
          if(this.readyState === 4) {
              console.log("Server returned: ",e.target.responseText);
          }
      }; 
      var fd=new FormData();
      fd.append("audio_data",blob, filename);
      xhr.open("POST","save_audio.php",true);
      xhr.send(fd);
      var sale = $("#sale").val();
      $.ajax({
        url: '../chatAudio/'+filenameOk,
        type: 'get',
        dataType: 'json',
        success: function(response){
            document.getElementById("messages").innerHTML = response; 
            document.querySelector('#last').scrollIntoView() ;
        }
      });
}

$(document).ready(function(){
  $('#sendMessageText').click(function(){  
      var msg = $("#msg").val(); 
     $.ajax({
        url: '../chatAddedGet/'+msg,
        type: 'get',
        dataType: 'json',
        success: function(response){
        	$("#msg").val('');
        	$("#msg").focus('');
        	document.getElementById("messages").innerHTML = response; 
    		document.querySelector('#last').scrollIntoView() ;
       }
    });
    
  });
});

document.querySelector('#last').scrollIntoView() ;
</script>

<script type="text/javascript">
	function showChat(){
		document.getElementById("iconChat").style.fill = 'white';
		$.ajax({
	        url: '../chatVu', type: 'get', dataType: 'json',
	        success: function(response){ }
	    });

	  	var element = document.getElementById("kt_drawer_chat");
	  	element.classList.remove("drawer-off");
	  	element.classList.add("drawer-on");
	}
</script>

</body> 

</html>