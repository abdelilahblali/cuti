<span style="background:white; padding-left: 20px; border-radius: 4px 4px 4px 4px; margin-right: 20px;">
<a href="{{ route('documentation') }}" style="font-weight: bold; color:black">{{ __('header.a17') }}</a>
<a href="{{ route('documentation') }}" class="btn btn-icon btn-light pulse pulse-success" style="background:transparent !important;">
  <span class="svg-icon svg-icon-1"><svg></svg></span>
  <span class="pulse-ring"> </span> 
</a>
</span>