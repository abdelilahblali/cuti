@extends('master.admin')

@section('content')

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }

  h4 { font-weight: bold; font-size: 13px;  }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black">{{ $client }}</span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs @if(Route::is('clientFolder')) active @endif"><a href="{{ route('clientFolder',[ 'ref' => $ref ]) }}">Administration</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_ptpma')) active @endif"><a href="{{ route('clientFolder_ptpma',[ 'ref' => $ref ]) }}">PTPMA</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_land')) active @endif"><a href="{{ route('clientFolder_land',[ 'ref' => $ref ]) }}">Land</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3') or Route::is('clientFolder_travaux') ) active @endif"><a href="{{ route('clientFolder_architecture',[ 'ref' => $ref ]) }}">Architecture</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_construction')) active @endif"><a href="{{ route('clientFolder_construction',[ 'ref' => $ref ]) }}">Construction</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_factures')) active @endif"><a href="{{ route('clientFolder_factures',[ 'ref' => $ref ]) }}">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">Architecture : Travaux suplémentaires</h4>

<div class="col-md-12">
  <div class="panel panel-default client-content"  style="padding-top: 2px;">
    <h4>Add new document</h4>
    <form method="POST" action="{{ route('clientFolder_design_AddPdf',[ 'ref' => $ref ] ) }}" enctype="multipart/form-data" class="form-inline">
      {{ csrf_field() }}
      <input type="hidden" name="cli" value="{{ $ref }}">
      <div class="form-group" style="width: 100% !important;" >
          <textarea class="form-control" name="dcr" style="width: 100% !important; margin-top: 10px; margin-bottom: 10px" placeholder="Text"></textarea>
      </div>
      <div class="form-group">
          <input type="hidden" name="d" value="5">
          <input type="hidden" name="typ" value="5">
          <input type="file" name="url[]" id="url" class="form-control" multiple  />
      </div>
      <div class="form-group" >
          <button type="submit" class="btn btn-default" style="float: right;"><i class="fa fa-plus" style="padding-right: 10px;"></i>Add</button>
      </div>
    </form>
    <hr>
    <h4>Documents uploaded</h4>
    @foreach($pdfs as $i)
    <div class="" style="margin-top: 10px; padding-left: 0;  padding: 10px; @if($i->valid==0) background:#ffdbdb @else background:#afedba @endif" >
      @if($i->valid==0)
        <span style="color:red; font-weight: bold;">Document no validated by the client</span>
      @else
        <span style="color:green; font-weight: bold;">Document validated by the client</span>
      @endif
      <p>{{ $i->dcr }}</p>
      <a target="_blank" href="{{ $urlWebSite }}/media/d/{{ $i->url }}"><button style="font-weight: bold; color: black">View Document</button></a>
      <a href="{{ route('clientFolder_design_DeletePdf',[ 'ref' => $i->ref ]) }}" onclick="return confirm('Are you sure you delete this item?'); event.preventDefault(); document.getElementById('clientFolder_design_DeletePdf').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
      <form id="clientFolder_design_DeletePdf" action="{{ route('clientFolder_design_DeletePdf',[ 'ref' => $i->ref ]) }}" method="POST">
          {{ method_field('DELETE') }}
          @csrf
      </form>  
    </div>
    <hr> 
    @endforeach
    </div>
</div>




@endsection
