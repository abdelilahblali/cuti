@extends('master.admin')

@section('content')

<div class="col-md-12">
  <div class="page-header">
      <ol class="breadcrumb">
        <li class="titrePage"><i class="fa fa-calendar"></i> New day</li>
      </ol>
  </div>
</div>

<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif

<div class="col-md-6">
  <div class="panel panel-default client-content" style="padding:7px 30px 20px">
    <form method="POST" action="{{ route('daysAdd') }}">
      {{ csrf_field() }}

      <div class="row">
          <div class="col-md-12">
              <h6><label for="typ" class="control-label form-label label01">Type <span class="c3_color">*</span></label></h6>
              <select name="typ" id="typ" class="form-control" required>
                <option>{{ $typ }}</option>
              </select>
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="dat" class="control-label form-label label01">Date <span class="c3_color">*</span></label></h6>
              <input type="date" name="dat" id="dat" class="form-control" required  />
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <h6><label for="des" class="control-label form-label label01">Designation </label></h6>
              <input type="text" name="des" id="des" class="form-control"  />
          </div>
      </div>

      <div class="row" style="margin-top: 20px">
        <div class="col-md-8">
          <button type="submit" class="btn btn-success"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
        </div>
      </div>

    </form>
  </div>
</div>

<div class="col-md-6">
  <table id="oneColumnTable" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Type</td>
        <td>Date</td>
        <td>Designation</td>
        <td align="center">Options</td>
      </tr>
    </thead>
    <tbody>
      @foreach($days as $day)
      <tr>
        <td><span class="bold ref">{{ $day->typ }}</span></td>
        <td><span class="bold">{{ $day->dat }}</span></td>
        <td><span class="bold">{{ $day->des }}</span></td>
        
        <td align="center">
          <a title="Delete customer" href="{{ route('daysDelete',[ 'ref' => $day->ref ]) }}" onclick="return confirm('Are you sure you want to delete this item?'); event.preventDefault(); document.getElementById('daysDelete').submit();"><i class="fa fa-trash a-icon"></i></a>
          <form id="daysDelete" action="{{ route('daysDelete',[ 'ref' => $day->ref ]) }}" method="POST">
            {{ method_field('DELETE') }}
            @csrf
          </form>  
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>


@endsection
