@extends('master.theme')


@section('content')

<style type="text/css">
  .w-5 { display: none  }
  .text-gray-700 { text-align: right;  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">Historiques des photos </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <div class="card card-page">
      <div class="card-body">
        <div class="row">
        @foreach($pics as $img)
        @if($img->dat<'2022-01-10 00:00:00')
        <div class="col-lg-4"  style="margin-bottom: 20px">
          <a href="{{ $urlWebSite2 }}/media/cli/{{ $img->img }}" onclick="return hs.expand(this)">
            <div class="pho" style="width: 100%; height: 300px;  background: url('{{ $urlWebSite2 }}/media/cli/{{ $img->img }}'); background-size: cover !important;"></div>
          </a>
        </div>
        @else
        <div class="col-lg-4"  style="margin-bottom: 20px">
          <a href="{{ $urlWebSite }}/media/cli/{{ $img->img }}" onclick="return hs.expand(this)">
            <div class="pho" style="width: 100%; height: 300px;  background: url('{{ $urlWebSite }}/media/cli/{{ $img->img }}'); background-size: cover !important;"></div>
          </a>
        </div>
        @endif
        @endforeach
        </div>
      </div>
    </div>

    <div class="card card-page">
      <div class="card-body">
        {{ $pics->links() }}
      </div>
    </div>



  </div>
</div>


<script type="text/javascript" src="{{ url('highslide/highslide-with-gallery.js') }}"></script>
<link rel="stylesheet" type="text/css" href="{{ url('highslide/highslide.css') }}" />
<script type="text/javascript">



  hs.graphicsDir = 'highslide/graphics/';

  hs.align = 'center';

  hs.transitions = ['expand', 'crossfade'];

  hs.wrapperClassName = 'dark borderless floating-caption';

  hs.fadeInOut = true;

  hs.dimmingOpacity = .75;



  // Add the controlbar

  if (hs.addSlideshow) hs.addSlideshow({

    //slideshowGroup: 'group1',

    interval: 5000,

    repeat: false,

    useControls: true,

    fixedControls: 'fit',

    overlayOptions: {

      opacity: .6,

      position: 'bottom center',

      hideOnMouseOut: true

    }

  });

</script>

@endsection
