@extends('master.theme')


@section('content')

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="{{ url('chosen2/chosen.css') }}">

<style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">{{ __('design0.a1') }} </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   @if(session()->has('yes'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('yes') }}
      </div>
    </div>
    @endif

    @if(session()->has('no'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('no') }}
      </div>
    </div>
    @endif
  </div>
</div>
 




<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
      <div class="card card-page">
        <div class="card-body" style="padding: 0px 38px 30px 33px">
          <div class="card card-xxl-stretch">
            <p style="padding: 20px 20px 10px 20px; ">
              {!! __('design0.a2') !!}              
            </p>
          </div>
        </div>
      </div> 
  </div>
</div>

<!-- PDF ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl" >
  <div class="content flex-row-fluid" id="kt_content" >
      <div class="card card-page">
        <div class="card-body" style="padding: 0px 38px 30px 33px">
          @foreach($pdfs as $i)
          <div class="card card-xxl-stretch" style=" @if($i->valid==0) background:#ffdbdb @else background:#afedba @endif">
            <div class="" style="margin-top: 10px; padding-left: 0; padding: 10px">
              <p><?php echo nl2br($i->dcr); ?></p>
              <a target="_blank" href="{{ $urlWebSite }}/media/d/{{ $i->url }}"><button class="btn btn-xs btn-success">{{ __('design0.a3') }}</button></a>

              @if($i->valid==0)
              <a href="{{ route('clientFolderValidate',[ 'ref' => $i->ref, 'item' => $i->ref, 'valid' => 1, 'table' => 'design_pdf' ]) }}" ><button type="button" class="btn btn-xs btn-danger" title="click to validate">{{ __('design0.a4') }}</button></a>
              @elseif($i->valid==1)
              <a href="{{ route('clientFolderValidate',[ 'ref' => $i->ref, 'item' => $i->ref, 'valid' => 0, 'table' => 'design_pdf' ]) }}" ><button type="button" class="btn btn-xs btn-success" title="click to cancel validation">{{ __('design0.a5') }}</button></a>
              @endif

            </div>
          </div>
          @endforeach  
        </div>
      </div>
  </div>
</div>


<!-- Form ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl" style="margin-top: 0px">
  <div class="content flex-row-fluid" id="kt_content">
      <div class="card card-page">
        <div class="card-body" style="padding-top: 0;">
          <div class="card card-xxl-stretch">

            <div class="alert alert-warning" style="margin-bottom: 15px;">- Notez bien, vous ne pourrez faire qu’une seule sauvegarde du formulaire</div>

           
            <form method="POST" action="{{ route('form_added') }}" enctype="multipart/form-data">
            {{ csrf_field() }}

              <div class="imgShow"></div>

              <h1>{{ __('design0.a6') }}</h1>

              <h2>{{ __('design0.a7') }}</h2>
              

              <div class="mb-5">
                <label for="v1" class=" form-label">{{ __('design0.a8') }}</label>
                <select class="form-select" aria-label="Select example" name="v1">
                  <option>{{ $v1 }}</option>
                  <option>{{ __('design0.a9') }}</option>
                  <option>{{ __('design0.a10') }}</option>
                </select>
              </div>

              <div class="mb-5">
                <label for="v2" class=" form-label">{{ __('design0.a11') }} </label>
                <select class="form-select" aria-label="Select example" name="v2">
                  <option>{{ $v2 }}</option>
                  <option>{{ __('design0.a9') }}</option>
                  <option>{{ __('design0.a10') }}</option>
                </select>
              </div>

              <h3>P05 -  Porte d'entrée</h3>

              <div class="mb-5">
                <div class="form-group" data-toggle="popover" data-html="true" data-content="
                <table>
                  <tr>
                    <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                  </tr>
                  <tr>
                    <td>Porte simple 1.0m sur charnières ou pivot</td>
                    <td>Porte double 1.4m sur charnières</td>
                    <td>Porte simple 1.4m sur charnières ou pivot</td>
                    <td>Porte double carrée (prix supplémentaire calculé sur mesure)</td>
                  </tr>
                </table>
                " data-trigger="hover" data-placement="auto top">
                  <label for="v3" class=" form-label">{{ __('design0.a12') }}</label>
                   <select class="form-select"  id="select1"  name="v3">
                      <option>{{ $v3 }}</option>
                      <option>{{ __('design0.a13') }}</option>
                      <option>{{ __('design0.a14') }}</option>
                      <option>{{ __('design0.a15') }}</option>
                      <option>{{ __('design0.a16') }}</option>
                   </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v4" class=" form-label">{{ __('design0.a17') }} </label>
                <select class="form-select" aria-label="Select example" name="v4">
                  <option>{{ $v4 }}</option>
                  <option>{{ __('design0.a18') }}</option>
                  <option>{{ __('design0.a10') }}</option>
                </select>
              </div>

              <h3>{{ __('design0.a21') }}</h3>

              <div class="mb-5">
                <label for="v5" class=" form-label">{{ __('design0.a19') }} </label>
                <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Pierre naturelle Palimanan</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v5">
                    <option>{{ $v5 }}</option>
                    <option>{{ __('design0.a20') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v6" class=" form-label">{{ __('design0.a22') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Bois Ulin à raison de 4m² (78€/m² / 88$/m²)</td>
                      <td>Béton bouchardé (41€/m² / 46$/m²)</td>
                      <td>Opus grande taille (24€/m² / 27$/m²)</td>
                      <td>Opus petite taille (31€/m² / 34$/m²)</td>
                      <td>Béton désactivé (41€/m² / 46$/m²)</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v6">
                    <option>{{ $v6 }}</option>
                    <option>{{ __('design0.a23') }}</option>
                    <option>{{ __('design0.a24') }}</option>
                    <option>{{ __('design0.a25') }}</option>
                    <option>{{ __('design0.a26') }}</option>
                    <option>{{ __('design0.a27') }}</option>
                    <option>{{ __('design0.a28') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v7" placeholder="Autres" value="{{ $v7 }}">
              </div>

              <h3>P10 -  Toitures </h3>

              <div class="mb-5">
                <label for="v8" class=" form-label">{{ __('design0.a29') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Tuiles de terre cuite finition naturelle ou peinture</td>
                      <td>Bardeau d’asphalte </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v8">
                    <option>{{ $v8 }}</option>
                    <option>{{ __('design0.a30') }} </option>
                    <option>{{ __('design0.a31') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v9" class=" form-label">{{ __('design0.a32') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Toiture plate en béton avec finition galet ou gazon synthétique (29€/m² / 33$/m²) </td>
                      <td>Sirap / tuiles en bois de fer (50€/m² / 56$/m²) </td>
                      <td>Alang-alang / chaume de Bali (39€/m² / 44$/m²) </td>
                      <td>Décoration sculptée (uniquement sur couverture en tuile </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v9">
                    <option>{{ $v9 }}</option>
                    <option>{{ __('design0.a33') }} </option>
                    <option>{{ __('design0.a34') }} </option>
                    <option>{{ __('design0.a35') }} </option>
                    <option>{{ __('design0.a36') }} </option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.a37') }}</h3>

              <div class="mb-5">
                <label for="v10" class=" form-label">{{ __('design0.a38') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Pierre Palimanan (beige) </td>
                      <td>Pierre Kerobokan </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v10">
                    <option>{{ $v10 }}</option>
                    <option>{{ __('design0.a39') }}</option>
                    <option>{{ __('design0.a40') }}) </option>
                    <option>{{ __('design0.a41') }} </option>
                    <option>{{ __('design0.a42') }} </option>
                    <option>{{ __('design0.a43') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v11" class=" form-label">{{ __('design0.a44') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Aluminium noir </td>
                      <td>Aluminium blanc </td>
                      <td>Pierre Kerobokan </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v11">
                    <option>{{ $v11 }}</option>
                    <option>{{ __('design0.a45') }} </option>
                    <option>{{ __('design0.a46') }} </option>
                    <option>{{ __('design0.a47') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v12" class=" form-label">{{ __('design0.a48') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v12">
                    <option>{{ $v12 }}</option>
                    <option>{{ __('design0.a9') }}</option>
                    <option>{{ __('design0.a10') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v13" placeholder="Autres" value="{{ $v13 }}">
              </div>

              <h3>{{ __('design0.a49') }} </h3>

              <div class="mb-5">
                <label for="v14" class=" form-label">{{ __('design0.a50') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v14">
                    <option>{{ $v14 }}</option>
                    <option>{{ __('design0.a51') }} </option>
                    <option>{{ __('design0.a52') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v15" class=" form-label">{{ __('design0.a53') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v15">
                    <option>{{ $v15 }}</option>
                    <option>{{ __('design0.a54') }} </option>
                    <option>{{ __('design0.a10') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v16" placeholder="Autres" value="{{ $v16 }}">
              </div>

              <div class="mb-5">
                <label for="v17" class=" form-label">{{ __('design0.a55') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v17">
                    <option>{{ $v17 }}</option>
                    <option>{{ __('design0.a56') }}  </option>
                    <option>{{ __('design0.a57') }}  </option>
                    <option>{{ __('design0.a58') }} </option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.a59') }}</h3>

              <div class="mb-5">
                <label for="v18" class=" form-label">{{ __('design0.a60') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v18">
                    <option>{{ $v18 }}</option>
                    <option>{{ __('design0.a61') }}</option>
                    <option>{{ __('design0.a62') }}</option>
                    <option>{{ __('design0.a63') }}</option>
                    <option>{{ __('design0.a64') }}</option>
                    <option>{{ __('design0.a65') }}</option>
                    <option>{{ __('design0.a66') }}</option>
                    <option>{{ __('design0.a67') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v19" class=" form-label">{{ __('design0.a68') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v19">
                    <option>{{ $v19 }}</option>
                    <option>{{ __('design0.a9') }}</option>
                    <option>{{ __('design0.a10') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v20" placeholder="Autres" value="{{ $v20 }}">
              </div>

              <h3>{{ __('design0.a69') }} </h3>

              <div class="mb-5">
                <label for="v21" class=" form-label">{{ __('design0.a70') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v21">
                    <option>{{ $v21 }}</option>
                    <option>{{ __('design0.a71') }}</option>
                    <option>{{ __('design0.a72') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v22" class=" form-label">{{ __('design0.a73') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v22">
                    <option>{{ $v22 }}</option>
                    <option>{{ __('design0.a9') }}</option>
                    <option>{{ __('design0.a10') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v23" placeholder="Autres" value="{{ $v23 }}">
              </div>

              <h3>{{ __('design0.a74') }}  </h3>

              <div class="mb-5">
                <label for="v24" class=" form-label">{{ __('design0.a75') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Acier </td>
                      <td>Acier + bois </td>
                      <td>Acier + cordage </td>
                      <td>Acier + verre - image 27 (104€/m² / 118$/m²)</td>
                      <td>Acier + cable tendu (57€/m² / 65$/m²)</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v24">
                    <option>{{ $v24 }}</option>
                    <option>Acier </option>
                    <option>Acier + bois </option>
                    <option>Acier + cordage  </option>
                    <option>Acier + verre - image 27 (104€/m² / 118$/m²)</option>
                    <option>Acier + cable tendu (57€/m² / 65$/m²)</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="v25" class=" form-label">{{ __('design0.a76') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Acier </td>
                      <td>Bois </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v25">
                    <option>{{ $v25 }}</option>
                    <option>Acier </option>
                    <option>Bois </option>
                    <option>Sans main-courante</option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.a77') }} </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a78') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v26">
                    <option>{{ $v26 }}</option>
                    <option>Oui (à partir de 301€/m² / 340$/m²)</option>
                    <option>{{ __('design0.a10') }}</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a79') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v27">
                    <option>{{ $v27 }}</option>
                    <option>Une vitre plexiglass (2 438€ / 2755$)- </option>
                    <option>Une douche </option>
                    <option>Une banquette relaxante intégrée à la piscine (sans bulles) (à partir de 4063€ / 4591$)</option>
                  </select>
                </div>
              </div>

              <h2>{{ __('design0.a80') }} </h2>

              <h3>{{ __('design0.a81') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a82') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/b.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Carrelage Cemento (lisse) 60cmx60cm gris </td>
                      <td>Carrelage Infinity (effet pierre) 60cmx60cm gris  </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v28">
                    <option>{{ $v28 }}</option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm gris</option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm gris foncé </option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm noir </option>
                    <option>Carrelage Cemento (lisse) 60cmx60cm crème </option>
                    <option>Carrelage Infinity (effet pierre) 60cmx60cm gris</option>
                    <option>Carrelage Infinity (effet pierre) 60cmx60cm blanc </option>
                    <option>Carrelage Infinity (effet pierre) 60cmx60cm crème </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a83') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Revêtement en béton bouchardé (41€/m² / 46$/m²) </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v29">
                    <option>{{ $v29 }}</option>
                    <option>Carrelage Cemento gris (lisse) 100cmx100cm </option>
                    <option>Carrelage Infinity (effet pierre) 60cmx120cm</option>
                    <option>Revêtement en béton bouchardé (41€/m² / 46$/m²) </option>
                    <option>Parquet -(78€/m² / 88$/m²) </option>
                    <option>Autre </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v30" placeholder="Autres" value="{{ $v30 }}">
              </div>

              <h3>{{ __('design0.a84') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a85') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Pierre Palimanan</td>
                      <td>Pierre Palimanan</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v31">
                    <option>{{ $v31 }}</option>
                    <option>Pierre Palimanan</option>
                    <option>Pierre Kerobokan (35€/m² / 40$/m</option>
                    <option>Lambris de bois (à partir de 82€/m² / 92$/m²)</option>
                    <option>Autre </option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.a86') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a87') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Porte de 0.8x2.30m en contre-plaqué au dessin géométrique</td>
                      <td>{{ __('design0.a10') }}</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v32">
                    <option>{{ $v32 }}</option>
                    <option>Porte de 0.8x2.30m en contre-plaqué au dessin géométrique</option>
                    <option>{{ __('design0.a10') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a88') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Panneau de bois sculpté (569€/unité / 643$/unité) </td>
                      <td>Porte coulissante (650€/unité / 735$/unité) </td>
                      <td>Double porte (732€/unité / 827$/unité)- </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v33">
                    <option>{{ $v33 }}</option>
                    <option>Panneau de bois sculpté (569€/unité / 643$/unité)  </option>
                    <option>Porte coulissante (650€/unité / 735$/unité)  </option>
                    <option>Double porte (732€/unité / 827$/unité)-  </option>
                    <option>Autre </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v34" placeholder="Autres" value="{{ $v34 }}">
              </div>

              <h3>{{ __('design0.a89') }} </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a90') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Plafond de 3m20 dans le séjour et de 2m80 dans les chambres </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v35">
                    <option>{{ $v35 }}</option>
                    <option>Plafond de 3m20 dans le séjour et de 2m80 dans les chambres   </option>
                    <option>{{ __('design0.a10') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a91') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Plafond plat en lambris bois (36€/m² / 41$/m²) </td>
                      <td>Plafond plat avec structure bois apparente sur lambris bois (45€/m² /  59$/m²)- </td>
                      <td>Charpente bois apparente sur lambris bois (57€/m² / 65$/m </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v36">
                    <option>{{ $v36 }}</option>
                    <option>Plafond plat en lambris bois (51€/m² ) </option>
                    <option>Plafond plat avec structure bois apparente sur lambris bois (45€/m² /  59$/m²)- </option>
                    <option>Charpente bois apparente sur lambris bois (57€/m² / 65$/m </option>
                    <option>Autres </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v37" placeholder="Autres" value="{{ $v37 }}">
              </div>

              <h3>{{ __('design0.a92') }}  </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a93') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v38">
                    <option>{{ $v38 }}</option>
                    <option>Oui </option>
                    <option>{{ __('design0.a10') }} </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v39" placeholder="Autres" value="{{ $v39 }}">
              </div>

              <h3>{{ __('design0.a94') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a95') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v40">
                    <option>{{ $v40 }}</option>
                    <option>Agencement fermé (tout en placard) </option>
                    <option>Agencement semi fermé (placard + étagères avec fond en bois) </option>
                    <option>Agencement semi ouvert (placard + étagères sans fond avec mur apparent) </option>
                    <option>Agencement ouvert (tout en étagère sans fond avec mur apparent) </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a96') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v41">
                    <option>{{ $v41 }}</option>
                    <option>Teck clair  </option>
                    <option>Teck foncé  </option>
                    <option>Teck teinté couleur au choix (prix supplémentaire calculé sur mesure)</option>
                    <option>Teck laqué couleur au choix (prix supplémentaire calculé sur mesure)</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a97') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v42">
                    <option>{{ $v42 }}</option>
                    <option>Marbre noir</option>
                    <option>Marbre blanc</option>
                    <option>Granit noir</option>
                    <option>Composite blanc</option>
                    <option>Céramique (prix supplémentaire calculé sur mesure)</option>
                    <option>Terrazzo couleur au choix (prix supplémentaire calculé sur mesure)</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.a98') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v43">
                    <option>{{ $v43 }}</option>
                    <option>Oui </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v44" placeholder="Autres" value="{{ $v44 }}">
              </div>

              <h3>{{ __('design0.a99') }} </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b1') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v45">
                    <option>{{ $v45 }}</option>
                    <option>Oui </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v46" placeholder="Autres" value="{{ $v46 }}">
              </div>

              <h3>{{ __('design0.b2') }} </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b3') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v47">
                    <option>{{ $v47 }}</option>
                    <option>Oui </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b4') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v48">
                    <option>{{ $v48 }}</option>
                    <option>Agencement maçonné avec plateau en marbre (prix supplémentaire calculé sur mesure)  </option>
                    <option>Agencement maçonné avec revêtement en terrazzo (488€/unité / 551$/unité)  </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b5') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Céramique rectangulaire  </td>
                      <td>Céramique circulaire </td>
                      <td>Terrazzo rectangulaire </td>
                      <td>Pierre de rivière (grise)  </td>
                      <td>Pierre Onix (beige)  </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v49">
                    <option>{{ $v49 }}</option>
                    <option>Céramique rectangulaire  </option>
                    <option>Céramique circulaire </option>
                    <option>Terrazzo rectangulaire </option>
                    <option>Pierre de rivière (grise)  </option>
                    <option>Pierre Onix (beige)  </option>
                  </select>
                </div>
              </div> 

               <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b6') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Terrazzo (tous coloris) </td>
                      <td>Marbre</td>
                      <td>Limestone  </td>
                      <td>Susun Siri (petite pierre taillée horizontale) </td>
                      <td>Pierre taillée Palimanan</td>
                      <td>Pierre taillée Batu Candi</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v50">
                    <option>{{ $v50 }}</option>
                    <option>Terrazzo (tous coloris) </option>
                    <option>Marbre</option>
                    <option>Limestone  </option>
                    <option>Susun Siri (petite pierre taillée horizontale) </option>
                    <option>Pierre taillée Palimanan</option>
                    <option>Pierre taillée Batu Candi</option>
                  </select>
                </div>
              </div>  

              <h2>{{ __('design0.b7') }}</h2>

              <h3>{{ __('design0.b8') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b9') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v51">
                    <option>{{ $v51 }}</option>
                    <option>Deux tables de massage </option>
                    <option>Deux tables de massage et un lavabo </option>
                    <option>Deux tables de massage, un lavabo et une douche </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.b10') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b11') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v52">
                    <option>{{ $v52 }}</option>
                    <option>Oui </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b12') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v53">
                    <option>{{ $v53 }}</option>
                    <option>A Vélo </option>
                    <option>B Vélo elliptique</option>
                    <option>C Tapis de course</option>
                    <option>D Machine de musculation</option>
                    <option>E Banc de musculation</option>
                    <option>F Ballon de gym</option>
                    <option> G Demi ballon de gym</option>
                    <option>H Poids fitness</option>
                    <option>I Step de fitness</option>
                    <option>J Tapis de gym</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b13') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v54">
                    <option>{{ $v54 }}</option>
                    <option>Oui  </option>
                    <option>{{ __('design0.a10') }}</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v55" placeholder="Autres" value="{{ $v55 }}">
              </div>

              <h3>{{ __('design0.b14') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b15') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v56">
                    <option></option>
                    <option>Toiture avec plafond en lambris  </option>
                    <option>Toiture avec charpente bois apparente</option>
                    <option>Structure en bambou</option>
                    <option>Pergola</option>
                    <option>{{ __('design0.a10') }}</option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.b16') }} </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b17') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v57">
                    <option>{{ $v57 }}</option>
                    <option>Oui</option>
                    <option>{{ __('design0.a10') }}</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b18') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Bois </td>
                      <td>Acier </td>
                      <td>Béton   </td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v58">
                    <option>{{ $v58 }}</option>
                    <option>Bois  </option>
                    <option>Acier </option>
                    <option>Béton   </option>
                  </select>
                </div>
              </div> 

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b19') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Bois manufacturé  </td>
                      <td>Bois flotté  </td>
                      <td>Métal</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v59">
                    <option>{{ $v59 }}</option>
                    <option>Bois manufacturé   </option>
                    <option>Bois flotté</option>
                    <option>Métal</option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b20') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="
                  <table>
                    <tr>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                      <td><img class='imgShow' src='{{ url('select/a.jpg') }}'></td>
                    </tr>
                    <tr>
                      <td>Sans protection </td>
                      <td>Verre </td>
                      <td>Polycarbonate fumé</td>
                    </tr>
                  </table>
                  " data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v60">
                    <option>{{ $v60 }}</option>
                    <option>Sans protection</option>
                    <option>Verre </option>
                    <option>Polycarbonate fumé</option>
                  </select>
                </div>
              </div>  

              <h3>{{ __('design0.b21') }} </h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b22') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v61">
                    <option>{{ $v61 }}</option>
                    <option>Oui </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v62" placeholder="Autres" value="{{ $v62 }}">
              </div>

              <h3>{{ __('design0.b23') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b24') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v63">
                    <option>{{ $v63 }}</option>
                    <option>Oui, au nombre de  </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v64" placeholder="Autres" value="{{ $v64 }}">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b25') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v65">
                    <option>{{ $v65 }}</option>
                    <option>Baignoire en faïence -page 53 au nombre de </option>
                    <option>Baignoire en terrazzo , au nombre de </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v66" placeholder="Autres" value="{{ $v66 }}">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b26') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v67">
                    <option>{{ $v67 }}</option>
                    <option>Jacuzzi manufacturé 2 places </option>
                    <option>Jacuzzi manufacturé 4 places  </option>
                    <option>Jacuzzi manufacturé 6 places </option>
                    <option>Jacuzzi construit taille au choix </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <h3>{{ __('design0.b27') }}</h3>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b28') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v68">
                    <option>{{ $v68 }}</option>
                    <option>Intérieur </option>
                    <option>Extérieur  </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b29') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v69">
                    <option>{{ $v69 }}</option>
                    <option>Oui  </option>
                    <option>{{ __('design0.a10') }} </option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b30') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v70">
                    <option>{{ $v70 }}</option>
                    <option>Mur d’eau - image 59 (122€ / 138$)  </option>
                    <option>Sculpture (prix supplémentaire calculé sur mesure </option>
                    <option>{{ __('design0.a10') }}</option>
                    </option>
                  </select>
                  </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b31') }} </label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-select" aria-label="Select example" name="v71">
                    <option>{{ $v71 }}</option>
                    <option>{{ __('design0.a10') }}</option>
                    <option>Oui</option>
                    </option>
                  </select>
                </div>
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b32') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control chosen-select" multiple aria-label="Select example" name="v72[]">

                    <?php $array_v72=array('Hamac','Filet hamac sur structure construite','Balançoire','Structure Coeur','Structure Nid','Autre',__('design0.a10'),); ?>

                    @foreach($array_v72 as $i)
                        <?php $vf=0; foreach($ops as $o) { if($o->case=='v72') { if($i==$o->val) { $vf=1; }  } } ?>
                        <option <?php if($vf==1){ echo "selected"; $vf=0; } ?> >{{ $i }}</option>
                    @endforeach

                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v73" placeholder="Autres" value="{{ $v73 }}">
              </div>

              <div class="mb-5">
                <label for="" class=" form-label">{{ __('design0.b33') }}</label>
                  <div class="form-group" data-toggle="popover" data-html="true" data-content="" data-trigger="hover" data-placement="auto top">
                  <select class="form-control chosen-select" multiple aria-label="Select example" name="v74[]">

                    <?php $array_v74=array('Écran TV 55” dans le séjour', 'Écran TV 43” dans les chambres (au lieu de 33”)', 'Vidéo projecteur', 'Ecran motorisé pour projection', 'Enceinte Sonos bluetooth au nombre de', 'Ampli pour système son',
                     'Enceinte connectée pour ampli au nombre de', 'Machine-à-laver', 'Machine-à-laver / sécher', 'Lave-vaisselle', 'Lumière RVB dans la piscine', 'Autre', ); ?>

                    @foreach($array_v74 as $i)
                        <?php $vf=0; foreach($ops as $o) { if($o->case=='v74') { if($i==$o->val) { $vf=1; }  } } ?>
                        <option <?php if($vf==1){ echo "selected"; $vf=0; } ?> >{{ $i }}</option>
                    @endforeach

                  </select>
                </div>
              </div>

              <div class="mb-5">
                  <input type="text" class="form-control" name="v75" placeholder="Autres" value="{{ $v75 }}">
              </div>

              @if($nb==0)
              <div class="mb-5">
                  <button class="btn btn-success" style="margin-top: 10px"><i class="fa fa-save"></i>{{ __('design0.b34') }}</button>
              </div>
              @endif

            </form>
          </div>
        </div>
      </div>
  </div>
</div>



<script src="{{ url('chosen2/jquery-3.2.1.min.js') }}" type="text/javascript"></script>
<script src="{{ url('chosen2/chosen.jquery.js') }}" type="text/javascript"></script>
<script src="{{ url('chosen2/init.js') }}" type="text/javascript" charset="utf-8"></script>


@endsection
