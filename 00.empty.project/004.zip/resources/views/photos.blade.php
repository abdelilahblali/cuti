@extends('master.admin')

@section('content')

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-paint-brush"></i> List of site photos</li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">

      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  <div class="row">
    @foreach($photos as $img)
    <div class="col-md-3" style="margin-bottom: 30px">
      <a href="https://monprojetbali.com/media/cli/{{ $img->img }}" onclick="return hs.expand(this)">
        <img src="https://monprojetbali.com/media/cli/{{ $img->img }}" style="width: 100%; height: 360px" class="img-thumbnail">
      </a>
    </div>
    @endforeach
  </div>
</div>    


<div class="col-md-12">
  <div class="row">
    {{ $photos->links() }}
  </div>
</div>  


<script type="text/javascript" src="{{ url('highslide/highslide-with-gallery.js') }}"></script>
<link rel="stylesheet" type="text/css" href="{{ url('highslide/highslide.css') }}" />
<script type="text/javascript">



  hs.graphicsDir = 'highslide/graphics/';

  hs.align = 'center';

  hs.transitions = ['expand', 'crossfade'];

  hs.wrapperClassName = 'dark borderless floating-caption';

  hs.fadeInOut = true;

  hs.dimmingOpacity = .75;



  // Add the controlbar

  if (hs.addSlideshow) hs.addSlideshow({

    //slideshowGroup: 'group1',

    interval: 5000,

    repeat: false,

    useControls: true,

    fixedControls: 'fit',

    overlayOptions: {

      opacity: .6,

      position: 'bottom center',

      hideOnMouseOut: true

    }

  });

</script>

@endsection
