@extends('master.admin')

@section('content')

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }
</style>

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black">{{ $client }}</span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs @if(Route::is('clientFolder')) active @endif"><a href="{{ route('clientFolder',[ 'ref' => $ref ]) }}">Administration</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_ptpma')) active @endif"><a href="{{ route('clientFolder_ptpma',[ 'ref' => $ref ]) }}">PTPMA</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_land')) active @endif"><a href="{{ route('clientFolder_land',[ 'ref' => $ref ]) }}">Land</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')) active @endif"><a href="{{ route('clientFolder_architecture',[ 'ref' => $ref ]) }}">Architecture</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_construction')) active @endif"><a href="{{ route('clientFolder_construction',[ 'ref' => $ref ]) }}">Construction</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_factures')) active @endif"><a href="{{ route('clientFolder_factures',[ 'ref' => $ref ]) }}">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 20px">Architecture : Design D2</h4>

<div class="col-md-4">
  <div class="panel panel-default client-content"  style="padding-top: 2px;">
  <h5 style="font-size: 14px; font-weight: bold;"><i class="fa fa-plus"></i> Design D2</h5>
    <form method="POST" action="{{ route('clientFolder_design_AddPdf',[ 'ref' => $ref ] ) }}" enctype="multipart/form-data" class="form-inline">
      {{ csrf_field() }}
      <input type="hidden" name="cli" value="{{ $ref }}">
      <div class="form-group">
          <input type="hidden" name="d" value="2">
          <input type="hidden" name="typ" value="1">
          <input type="file" name="url[]" id="url" class="form-control" multiple  />
      </div>
      <div class="form-group" >
          <button type="submit" class="btn btn-default"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
      </div>
    </form>

    @foreach($pdfs as $img)
    @if($img->typ==1)
    <div class="container" style="margin-top: 10px; padding-left: 0">
      <a target="_blank" href="{{ $urlWebSite }}/media/d/{{ $img->url }}"><button style="font-weight: bold; color: black">View Document</button></a>
      <a href="{{ route('clientFolder_design_DeletePdf',[ 'ref' => $img->ref ]) }}" onclick="return confirm('Are you sure you delete this item?'); event.preventDefault(); document.getElementById('clientFolder_design_DeletePdf').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
      <form id="clientFolder_design_DeletePdf" action="{{ route('clientFolder_design_DeletePdf',[ 'ref' => $img->ref ]) }}" method="POST">
          {{ method_field('DELETE') }}
          @csrf
      </form>  
    </div> 
    @endif
    @endforeach

  </div>
</div>

<div class="col-md-4">
  <div class="panel panel-default client-content"  style="padding-top: 2px;">
  <h5 style="font-size: 14px; font-weight: bold;"><i class="fa fa-plus"></i> Design D2 Devis</h5>
    <form method="POST" action="{{ route('clientFolder_design_AddPdf',[ 'ref' => $ref ] ) }}" enctype="multipart/form-data" class="form-inline">
      {{ csrf_field() }}
      <input type="hidden" name="cli" value="{{ $ref }}">
      <div class="form-group">
          <input type="hidden" name="d" value="2">
          <input type="hidden" name="typ" value="2">
          <input type="file" name="url[]" id="url" class="form-control" multiple  />
      </div>
      <div class="form-group" >
          <button type="submit" class="btn btn-default"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
      </div>
    </form>

    @foreach($pdfs as $img)
    @if($img->typ==2)
    <div class="container" style="margin-top: 10px; padding-left: 0">
      <a target="_blank" href="{{ $urlWebSite }}/media/d/{{ $img->url }}"><button style="font-weight: bold; color: black">View Document</button></a>
      <a href="{{ route('clientFolder_design_DeletePdf',[ 'ref' => $img->ref ]) }}" onclick="return confirm('Are you sure you delete this item?'); event.preventDefault(); document.getElementById('clientFolder_design_DeletePdf').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
      <form id="clientFolder_design_DeletePdf" action="{{ route('clientFolder_design_DeletePdf',[ 'ref' => $img->ref ]) }}" method="POST">
          {{ method_field('DELETE') }}
          @csrf
      </form>  
    </div> 
    @endif
    @endforeach

  </div>
</div>




<div class="col-md-12">
  <div class="panel panel-default client-content"  style="padding-top: 2px;">
  <h5 style="font-size: 14px; font-weight: bold;"><i class="fa fa-plus"></i> New Photos</h5>
    <form method="POST" action="{{ route('clientFolder_design_AddImg',[ 'ref' => $ref ] ) }}" enctype="multipart/form-data" class="form-inline">
      {{ csrf_field() }}
      <input type="hidden" name="cli" value="{{ $ref }}">
      <div class="form-group">
          <div class="col-md-12" style="padding-top: 20px">
              <input type="hidden" name="d" value="2">
              <input type="file" name="url[]" id="url" class="form-control" multiple  />
          </div>
      </div>
      <div class="form-group" style="margin-top: 20px">
          <button type="submit" class="btn btn-default"><i class="fa fa-plus" style="padding-right: 10px"></i>Add</button>
      </div>
    </form>
  </div>
</div>

@foreach($photos as $img)
<div class="col-md-12">
  <div class="panel panel-default client-content" style="overflow: hidden;">
    <div class="col-md-7">
      <div class="row">
        <img src="{{ $urlWebSite }}/media/d/{{ $img->url }}" width="600px" id="pointer_div{{ $img->ref }}" onclick="clickcoord{{ $img->ref }}(event)">
        
        <br>
        <a href="{{ route('cliEntfolder_design_Delete',[ 'ref' => $img->ref ]) }}" onclick="return confirm('Are you sure you delete this item?'); event.preventDefault(); document.getElementById('cliEntfolder_design_Delete').submit();"><button class="btn btn-xs btn-danger"><i class="fa fa-trash a-icon"></i></button></a>
        <form id="cliEntfolder_design_Delete" action="{{ route('cliEntfolder_design_Delete',[ 'ref' => $img->ref ]) }}" method="POST">
            {{ method_field('DELETE') }}
            @csrf
        </form>  

        @foreach($cmt as $c)
        @if($c->img==$img->ref)
        <div onclick="document.getElementById('comment{{ $c->ref }}').style.background='#b8edee'; setTimeout(function(){ document.getElementById('comment{{ $c->ref }}').style.background = 'white';  }, 2000);" id="tagged{{ $img->ref }}" title="{{ $c->cmt }}" class="tag tag{{ $img->ref }}" style="left: {{ ($c->x)-13 }}px; top: {{ ($c->y)-13 }}px; visibility: visible; background: red">
          <a href="#"><span id="span-id{{ $img->ref }}"></span></a>
        </div>
        @endif
        @endforeach 
      </div> 
    </div>

    <div class="col-md-5">
      <table class="table">
        @foreach($cmt as $c)
          @if($c->img==$img->ref)
          <tr style="background: rgba(0,0,0,0.05); padding: 6p" id="comment{{ $c->ref }}" >
            <td style="font-weight: bold;">{{ $c->cmt }}</td>
          </tr>
          <tr>
            <td>
              <table class="table">
                @foreach($answer as $a)
                  @if($a->cmt==$c->ref)
                  <tr>
                    <td>{{ $a->msg }}</td>
                    <td>
                      <a href="{{ route('answerDelete',[ 'answer' => $a->ref ]) }}" onclick="return confirm('Are you sure you delete this answer?'); event.preventDefault(); document.getElementById('answerDelete').submit();"><i class="fa fa-trash a-icon" style="color: red"></i></a>
                      <form id="answerDelete" action="{{ route('answerDelete',[ 'answer' => $a->ref ]) }}" method="POST">
                          {{ method_field('DELETE') }}
                          @csrf
                      </form>  
                    </td>
                  </tr>
                  @endif
                @endforeach 
              </table>
            </td>
          </tr>
          <tr>
            <td>
              <form method="POST" action="{{ route('answerAdd') }}" class="inline" name="form{{ $c->ref }}">
                {{ csrf_field() }}

                <input type="hidden" name="cmt" value="{{ $c->ref }}">

                <div class="row">
                    <div class="col-md-11">
                        <input type="text" name="msg" class="form-control" placeholder="votre réponse" />
                    </div>
                  <div class="col-md-1">
                    <button type="submit" class="btn btn-s"><i class="fa fa-plus" style="padding-right: 10px"></i></button>
                  </div>
                </div>
              </form>
            </td>
          </tr>
          @endif
        @endforeach 
      </table>
    </div>
  </div>
</div>
@endforeach






@endsection
