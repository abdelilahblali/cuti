@extends('master.theme')


@section('content')

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">{{ __('architecture.a1') }}</h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      @include('master.aide')
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   @if(session()->has('yes'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('yes') }}
      </div>
    </div>
    @endif

    @if(session()->has('no'))
    <div class="col-md-12">
      <div class="alert alert-success">
        {{ session()->get('no') }}
      </div>
    </div>
    @endif
  </div>
</div>
 
<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">



    <div class="card card-page">
      <div class="card-body">
        <div class="card card-xxl-stretch">
          <div class="row">
            <a href="{{ url('design') }}" class="btn btn-secondary">{{ __('architecture.a2') }}</a>
          </div>
          <div class="row" style="margin-top: 10px">
            <a href="{{ url('plan') }}" class="btn btn-secondary">{{ __('architecture.a3') }}</a>
          </div>
          <div class="row" style="margin-top: 10px">
            <a href="{{ url('interior') }}" class="btn btn-secondary">{{ __('architecture.a4') }}</a>
          </div>
          <div class="row" style="margin-top: 10px">
            <a href="{{ url('travaux') }}" class="btn btn-secondary">{{ __('architecture.a5') }}</a>
          </div>
        </div>
      </div>
    </div>



  </div>
</div>


@endsection
