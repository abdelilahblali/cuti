<!DOCTYPE html>
<html lang="en">
<head>
  <title>Magnitude Construction : Mon Projet Bali</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="{{ url('imgs/logo.png') }}" rel="icon">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/vendor/bootstrap/css/bootstrap.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/fonts/font-awesome-4.7.0/css/font-awesome.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/fonts/Linearicons-Free-v1.0.0/icon-font.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/vendor/animate/animate.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/vendor/css-hamburgers/hamburgers.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/vendor/animsition/css/animsition.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/vendor/select2/select2.min.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/vendor/daterangepicker/daterangepicker.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/css/util.css') }}">
  <link rel="stylesheet" type="text/css" href="{{ url('loginAssets/css/main.css') }}">
</head>
<body style="background-color: #666666;">
  
  <div class="limiter">
    <div class="container-login100">
      <div class="wrap-login100">
        <form method="POST" action="{{ route('login') }}" class="login100-form validate-form">
        @csrf
          <span class="login100-form-title p-b-43">
           <a href="{{ route('home') }}"><img src="{{ url('imgs/logo.png') }}" style="width: 250px; margin-top: 16px"></a>
          </span>
          
          <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
            <input class="input100" type="text" name="username">
            <span class="focus-input100"></span>
            <span class="label-input100">Identifiant</span>
          </div>
          
          <div class="wrap-input100 validate-input" data-validate="Password is required">
            <input class="input100" type="password" name="password">
            <span class="focus-input100"></span>
            <span class="label-input100">Mot de passe</span>
          </div>

          <div class="flex-sb-m w-full p-t-3 p-b-32">
            <div class="contact100-form-checkbox">
              <!-- <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
              <label class="label-checkbox100" for="ckb1">
                Remember me
              </label> -->
            </div>

            <div>
              <a href="{{ route('forgot') }}" class="txt1">
                Mot de passe oublié ?
              </a>
            </div>
          </div>
      

          <div class="container-login100-form-btn">
            <button class="login100-form-btn" style="background-color:#0AA2A5">
              Se connecter
            </button>
          </div>
          
          <div class="text-center p-t-46 p-b-20">
            <span class="txt2">
              Rejoignez-nous
            </span>
          </div>

          <div class="login100-form-social flex-c-m">
            <a href="https://www.facebook.com/magnitudeconstructionbali/" class="login100-form-social-item flex-c-m bg1 m-r-5" target="_blank">
              <i class="fa fa-facebook-f" aria-hidden="true"></i>
            </a>

            <a href="https://www.instagram.com/magnitudeconstruction/?hl=fr" class="login100-form-social-item flex-c-m bg2 m-r-5" target="_blank" style="background-color:#C6208C">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>

            <a href="https://fr.linkedin.com/company/magnitudeconstruction" class="login100-form-social-item flex-c-m bg2 m-r-5" target="_blank">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>

            <a href="https://www.youtube.com/channel/UC5BrkX7Hi4BDrsxRw-k8otg" class="login100-form-social-item flex-c-m bg2 m-r-5" target="_blank" style="background-color:#F70000">
              <i class="fa fa-youtube" aria-hidden="true"></i>
            </a>
          </div>
        </form>
        <?php $array = array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40); $k = array_rand($array); $v = $array[$k]; ?>
        <div class="login100-more" style='background-image: url("https://villa.magnitudeconstruction.com/loginAssets/imgs/<?php echo $v.".jpg"; ?>");'>
        </div>
      </div>
    </div>
  </div>
  
  

  
  
  <script src="{{ url('loginAssets/vendor/jquery/jquery-3.2.1.min.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/animsition/js/animsition.min.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/bootstrap/js/popper.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/select2/select2.min.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/daterangepicker/moment.min.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/daterangepicker/daterangepicker.js') }}"></script>
  <script src="{{ url('loginAssets/vendor/countdowntime/countdowntime.js') }}"></script>
  <script src="{{ url('loginAssets/js/main.js') }}"></script>

</body>
</html>