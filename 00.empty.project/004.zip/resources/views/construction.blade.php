@extends('master.theme')


@section('content')

<style type="text/css">
  .iconTitle { border: 1px solid rgba(0,0,0,0.1); padding: 5px; height: 45px; }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">{{ __('construction.a1') }} / <span style="font-size: 13px"><?php echo $a0." - ".$z; ?></span></h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      <!-- <a href="#" class="btn btn-custom btn-color-white btn-active-color-success my-2 me-2 me-lg-6" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">Contact our team</a> -->
      @include('master.aide')
      <a href="{{ url('getPhotosAll') }}" class="btn btn-success my-2">{{ __('construction.a2') }}</a>
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
    <div class="card card-page">
      <div class="card-body">


        
        <div class="card card-xxl-stretch">
          <div class="card-header">
            <h3 class="card-title align-items-start flex-column">
              <span class="card-label fw-bolder text-dark">{{ __('construction.a3') }}</span>
              <span class="text-muted mt-1 fw-bold fs-7">{{ __('construction.a4') }}</span>
            </h3>
            <div class="card-toolbar">
              <!-- <span style="margin-right:10px">Total : </span> -->
              <div class="iconTitle">
                <div class="holiday" style="margin-right: 5px; float: left;"></div>Vacances publiques : {{ $days_hol }} <span style="padding: 0 5px;"></span>
              </div>
              <div class="iconTitle">
                <div class="ceremony" style="margin-right: 5px; float: left"></div>Cérémonie : {{ $days_cer }} <span style="padding: 0 5px;"></span>
              </div>
              <div class="iconTitle">
                <div class="umbrella" style="margin-right: 15px; float: left"></div>Jours de pluie :  {{ $days_rai }} <span style="padding: 0 5px;"></span>
              </div>
              <div class="iconTitle">  
                <div class="cloud" style="margin-right: 15px; float: left"></div> Saison des pluies <span style="padding: 0 5px;"></span>
              </div>
            </div>
          </div>
          <div class="card-body">
            <div id="kt_calendar_widget_1"></div>
          </div>

          <!-- <div class="card-body" style="background: rgba(0,0,0,0.05);">
            <a class="fc-daygrid-event fc-daygrid-block-event fc-h-event fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-past holiday" style="float: left; margin-right: 20px">Vacances publiques</a>
            <a class="fc-daygrid-event fc-daygrid-block-event fc-h-event fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-past umbrella" style="float: left; margin-right: 20px">Jours de pluie</a> 
            <a class="fc-daygrid-event fc-daygrid-block-event fc-h-event fc-event fc-event-draggable fc-event-resizable fc-event-start fc-event-end fc-event-past ceremony" style="float: left;">Jours de cérémonie</a>   
          </div> -->
        </div>
      </div>
    </div>
  </div>
</div>

          
@endsection
