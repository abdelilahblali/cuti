@extends('master.theme')


@section('content')

<style type="text/css">
  .tag {
    position:absolute;
    background: red;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    border:2px solid #FFFFFF;
    visibility: hidden;
    height:22px;
    width:22px;
    //padding:11px;
    z-index:2;
  }
  .tag span {
    position:absolute;
    width:20px;
    color: #FFFFFF;
    font-family: Helvetica, Arial, Sans-Serif;
    font-size: .8rem;
    text-align:center;
    margin:4px 0;
  }
</style>

<div class="toolbar py-5 py-lg-15" id="kt_toolbar">
  <div id="kt_toolbar_container" class="container-xxl d-flex flex-stack flex-wrap">
    <h3 class="text-white fw-bolder fs-2qx me-5">{{ __('design1.a1') }} </h3>
    <div class="d-flex align-items-center flex-wrap py-2">
      
    </div>
  </div>
</div>

<div id="kt_content_container" class="d-flex align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">
   @if(session()->has('yes'))
   <div class="col-md-12">
    <div class="alert alert-success">
      {{ session()->get('yes') }}
    </div>
  </div>
  @endif

  @if(session()->has('no'))
  <div class="col-md-12">
    <div class="alert alert-success">
      {{ session()->get('no') }}
    </div>
  </div>
  @endif
</div>
</div>

<!-- Contrat #1 ################## -->
<div id="kt_content_container" class="d-flex flex-column-fluid align-items-start container-xxl">
  <div class="content flex-row-fluid" id="kt_content">

    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">
      <div class="col-xxl-12">  
        <div class="card card-page">
          <div class="card-body" style="padding: 0px 38px 30px 33px">
            <div class="card card-xxl-stretch">
              <p style="padding: 20px 20px 10px 20px; ">
                {!! __('design1.a2') !!}
                
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">
      <div class="col-xxl-12">  
        <div class="card card-page">
          <div class="card-body" style="padding-top: 0">
            <div class="card card-xxl-stretch">
              <div class="row">
              @foreach($pdfs as $p)
              @if($p->typ==1)
              <div class="col-md-6">
              <a href="{{ $urlWebSite }}/media/d/{{ $p->url }}" target="_" class="btn btn-light-primary" style="width: 100%; background: #1da2a4; color:white">{{ __('design1.a3') }}</a>
              </div>
              @endif
              @endforeach

              @foreach($pdfs as $p)
              @if($p->typ==2)
              <div class="col-md-6">
              <a href="{{ $urlWebSite }}/media/d/{{ $p->url }}" target="_" class="btn btn-light-primary" style="width: 100%; background: #1da2a4; color:white">{{ __('design1.a4') }}</a>
              </div>
              @endif
              @endforeach

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    @foreach($photos as $img)
    <div class="row gy-5 g-xl-8" style="margin-bottom: 30px">

      <div class="col-xxl-7">  
        <div class="card card-page">
          <div class="card-body">
            <div class="card card-xxl-stretch">
              <form name="pointform{{ $img->ref }}" method="POST" action="{{ route('designAddCmt') }}">
                {{ csrf_field() }}
                <div style="position: relative;">
                  <div id="tagged{{ $img->ref }}" class="tag">
                    <span id="span-id{{ $img->ref }}">0</span>
                  </div>
                  <img src="{{ $urlWebSite }}/media/d/{{ $img->url }}" width="600px" id="pointer_div{{ $img->ref }}" onclick="clickcoord{{ $img->ref }}(event)">
                  <div class="col-md-12">
                    <div id="cloth{{ $img->ref }}" style="visibility:hidden;">
                      <hr>
                      <textarea rows="2" placeholder="{{ __('design1.a5') }}" id="cmt" name="cmt" class="form-control" style="width: 600px !important;"></textarea>
                      <input type="hidden" id="x" name="x"/>
                      <input type="hidden" id="y" name="y"/>
                      <input type="hidden" id="img" name="img" value="{{ $img->ref }}" />
                      <button class="btn btn-success" style="margin-top: 10px"><i class="fa fa-plus"></i> {{ __('design1.a6') }}</button>
                    </div>
                  </div>
                </div>
                <div></div>
              </form>

              @foreach($cmt as $c)
              @if($c->img==$img->ref)
              <div onclick="document.getElementById('comment{{ $c->ref }}').style.background='#b8edee'; setTimeout(function(){ document.getElementById('comment{{ $c->ref }}').style.background = 'white';  }, 2000);" id="tagged{{ $img->ref }}" title="{{ $c->cmt }}" class="tag tag{{ $img->ref }}" style="left: {{ ($c->x)-13 }}px; top: {{ ($c->y)-13 }}px; visibility: visible; background: red">
                <a href="#"><span id="span-id{{ $img->ref }}"></span></a>
              </div>
              @endif
              @endforeach  

            </div>
          </div>
        </div>
      </div>

      <div class="col-xxl-5">  
        <div class="card card-page">
          <div class="card-body">
            <div class="card card-xxl-stretch">
              
              <div class="bg-body" >
                <div class="card shadow-none rounded-0">
                  <div class="card-header" id="kt_activities_header">
                    <h3 class="card-title fw-bolder text-dark">{{ __('design1.a7') }}</h3>
                  </div>

                  <div class="card-body position-relative" id="kt_activities_body">
                    <div id="kt_activities_scroll" class="position-relative scroll-y me-n5 pe-5" data-kt-scroll="true" data-kt-scroll-height="auto" data-kt-scroll-wrappers="#kt_activities_body" data-kt-scroll-dependencies="#kt_activities_header, #kt_activities_footer" data-kt-scroll-offset="5px" >
                      <div class="timeline">

                        @foreach($cmt as $c)
                        @if($c->img==$img->ref)
                        <div class="timeline-item" id="comment{{ $c->ref }}" style="padding: 6px">
                          <div class="timeline-line w-40px"></div>
                          <div class="timeline-icon symbol symbol-circle symbol-40px me-4">
                            <div class="symbol-label bg-light">
                              <span class="svg-icon svg-icon-2 svg-icon-gray-500" onclick="document.getElementById('tagged89200352161221125035').style.background='green'; ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                  <path opacity="0.3" d="M2 4V16C2 16.6 2.4 17 3 17H13L16.6 20.6C17.1 21.1 18 20.8 18 20V17H21C21.6 17 22 16.6 22 16V4C22 3.4 21.6 3 21 3H3C2.4 3 2 3.4 2 4Z" fill="black" />
                                  <path d="M18 9H6C5.4 9 5 8.6 5 8C5 7.4 5.4 7 6 7H18C18.6 7 19 7.4 19 8C19 8.6 18.6 9 18 9ZM16 12C16 11.4 15.6 11 15 11H6C5.4 11 5 11.4 5 12C5 12.6 5.4 13 6 13H15C15.6 13 16 12.6 16 12Z" fill="black" />
                                </svg>
                              </span>
                            </div>
                          </div>
                          <div class="timeline-content mb-10 mt-n1" >
                            <div class="pe-3 mb-5">
                              <div class="fs-5 fw-bold mb-2"  >
                                {{ $c->cmt }}
                              </div>

                              <table>
                                <tr>
                                  <td>
                                    <table class="table">
                                      @foreach($answer as $a)
                                        @if($a->cmt==$c->ref)
                                        <tr>
                                          <td> <i class="fa fa-reply"></i> {{ $a->msg }}</td>
                                        </tr>
                                        @endif
                                      @endforeach 
                                    </table>
                                  </td>
                                </tr>
                              </table>
                              <div class="d-flex align-items-center mt-1 fs-6">
                                <div class="text-muted me-2 fs-7">
                                    {{ $c->fait }}
                                    <a style="margin-left: 20px" title="Delete comment" href="{{ url('designDeleteCmt', [ 'cmt'=> $c->ref ]) }}" onclick="return confirm('Are you sure you want to delete this comment?'); event.preventDefault(); document.getElementById('designDeleteCmt').submit();"><i style="color:red" class="fa fa-times a-icon"></i></a>
                                    <form id="designDeleteCmt" action="{{ url('designDeleteCmt', [ 'cmt'=> $c->ref ]) }}" method="POST">
                                      {{ method_field('DELETE') }}
                                      @csrf
                                    </form>  
                                </div>
                                <div class="symbol symbol-circle symbol-25px" data-bs-toggle="tooltip" data-bs-boundary="window" data-bs-placement="top" title="Nina Nilson">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        @endif
                        @endforeach 

                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script type="text/javascript">
        function clickcoord{{ $img->ref }}(event){
          var i = parseInt(document.getElementById("span-id{{ $img->ref }}").innerHTML);

          var image = document.getElementById("pointer_div{{ $img->ref }}");
          var tag = document.getElementById("tagged{{ $img->ref }}");
          var clothes = document.getElementById("cloth{{ $img->ref }}");

          var pos_x = event.offsetX?(event.offsetX):event.pageX-image.offsetLeft;
          var pos_y = event.offsetY?(event.offsetY):event.pageY-image.offsetTop;

          tag.style.left = (pos_x-13).toString() + 'px';
          tag.style.top = (pos_y-13).toString() + 'px';
          tag.style.visibility = "visible";

          clothes.style.visibility = "visible";

          document.getElementById("span-id{{ $img->ref }}").innerHTML = "";

          document.pointform{{ $img->ref }}.x.value = pos_x;
          document.pointform{{ $img->ref }}.y.value = pos_y;

        }


       

      </script>
    @endforeach

      

      @endsection
