@extends('master.admin')

@section('content')

<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-folder"></i> Customer : <span class="bold black">{{ $client }}</span></li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
        <button class="btn btn-xs @if(Route::is('clientFolder')) active @endif"><a href="{{ route('clientFolder',[ 'ref' => $ref ]) }}">Administration</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_ptpma')) active @endif"><a href="{{ route('clientFolder_ptpma',[ 'ref' => $ref ]) }}">PTPMA</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_land')) active @endif"><a href="{{ route('clientFolder_land',[ 'ref' => $ref ]) }}">Land</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_architecture') or Route::is('clientFolder_plan') or Route::is('clientFolder_design0') or Route::is('clientFolder_design1') or Route::is('clientFolder_design2') or Route::is('clientFolder_design3')) active @endif"><a href="{{ route('clientFolder_architecture',[ 'ref' => $ref ]) }}">Architecture</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_construction')) active @endif"><a href="{{ route('clientFolder_construction',[ 'ref' => $ref ]) }}">Construction</a></button>
        <button class="btn btn-xs @if(Route::is('clientFolder_factures')) active @endif"><a href="{{ route('clientFolder_factures',[ 'ref' => $ref ]) }}">Invoices</a></button>
      </div>
    </div>
  </div>
</div>

<div class="col-md-12">
  @if(session()->has('Validation'))
  <div class="alert alert-success">
    {{ session()->get('Validation') }}
  </div>
  @endif

  @if(session()->has('Suppression'))
  <div class="alert alert-success">
    {{ session()->get('Suppression') }}
  </div>
  @endif
</div>

<h4 style="margin-left: 15px; font-weight: bold; margin-bottom: 5px">Architecture</h4>

<div class="row" style="padding: 13px">
  <div class="col-md-3">
    <a href="{{ route('clientFolder_design0',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Design 0</button></a>
  </div>

  <div class="col-md-3">
    <a href="{{ route('clientFolder_design1',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Design 1</button></a>
  </div>

  <div class="col-md-3">
    <a href="{{ route('clientFolder_design2',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Design 2</button></a>
  </div>

  <div class="col-md-3">
    <a href="{{ route('clientFolder_design3',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Design 3</button></a>
  </div>
</div>


<div class="row" style="padding: 13px">
  <div class="col-md-4">
    <a href="{{ route('clientFolder_plan',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Plan</button></a>
  </div>
  <div class="col-md-4">
    <a href="{{ route('clientFolder_travaux',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Travaux supplémentaires</button></a>
  </div>
  <div class="col-md-4">
    <a href="{{ route('clientFolder_interior',[ 'ref' => $ref ]) }}"><button class=" btn-block" style="color:gray; font-weight:bold;">Interior Design</button></a>
  </div>
</div>


@endsection
