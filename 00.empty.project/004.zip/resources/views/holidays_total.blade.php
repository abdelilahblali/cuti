@extends('master.admin')

@section('content')


<div class="col-md-12">
  <div class="page-header">
    <ol class="breadcrumb">
      <li class="titrePage"><i class="fa fa-sitemap"></i> List  </li>
    </ol>
    <div class="right">
      <div class="btn-group" role="group">
      </div>
    </div>
  </div>
</div>

<style type="text/css">
  #oneColumnTable .fa { color:#0D3A5D ; }
</style>


<div class="col-md-12">
  <table id="oneColumnTable" class="display nowrap" style="width: 100%;">
    <thead>
      <tr>
        <td>Code</td>
        <td>Name</td>
        <td>Start</td>
        <td>End</td>
        <td>Rainy days</td>
        <td>Ceremony days</td>
        <td>Public Holidays</td>
        <td>Total</td>
      </tr>
    </thead>
    <tbody>
      @foreach($totals as $t)
      <tr>
        <td><span class="bold ref">{{ $t['code'] }}</span></td>
        <td><span class="bold" style="color:black">{{ $t['nom'] }}</span></td>
        <td><span class="bold black">{{ $t['de'] }}</span></td>
        <td><span class="bold black">{{ $t['a'] }}</span></td>
        <td><span class="bold non">{{ $t['rai'] }}</span></td>
        <td><span class="bold non">{{ $t['cer'] }}</span></td>
        <td><span class="bold non">{{ $t['hol'] }}</span></td>
        <td><span class="bold oui">{{ $t['rai']+$t['cer']+$t['hol'] }}</span></td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>


<script type="text/javascript" src="{{ url('js/jquery.min.js') }}"></script>
<script src="{{ url('js/datatables.min.js') }}"></script>
<script> $(document).ready(function() { $('#example0').DataTable( { "order": [[ 0, "desc" ]] } ); } ); </script>

@endsection
