<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <title>MAGNITUDE CONSTRUCTION</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <meta property="og:locale" content="fr_FR" />
  <meta property="og:type" content="article" />
  <meta property="og:title" content="" />
  <meta property="og:url" content="https://keenthemes.com/products/ceres-html-pro" />
  <meta property="og:site_name" content="" />
  <link rel="canonical" href="" />
  <link rel="shortcut icon" href="{{ url('imgs/logo.png') }}" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
  <link href="{{ url('theme/assets/plugins/custom/fullcalendar/fullcalendar.bundle.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('theme/assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('theme/assets/css/style.bundle.css') }}" rel="stylesheet" type="text/css" />
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&amp;l='+l:'';j.async=true;j.src= '../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-5FS8GGP');</script>

  <link href="{{ url('signatureAssets/css/bootstrap.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/font-awesome.min.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/bootstrap-select.css') }}" rel="stylesheet" />
  <link href="{{ url('signatureAssets/css/app_style.css') }}" rel="stylesheet" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  #signArea{ width:304px; margin: 15px auto; }
  .sign-container { width: 90%; margin: auto; }
  .sign-preview { width: 150px; height: 50px; margin: 10px 5px; }
  .center-text { text-align: center; }
  </style>

  <style type="text/css">
  form  { background: #F7F8FA !important;  }
  form h1 { text-align: left; margin-bottom: 20px; font-size: 30px; font-weight: bold  }
  form h2 { text-align: left; margin-bottom: 30px; font-size: 20px   }
  form h3 { text-align: left; margin-bottom: 30px; font-size: 16px; font-weight: bold   }
  .imgShow { width: 120px !important;   }
  .popover{ background: white !important; min-width: 800px; overflow: hidden; }
  .popover-content{ background: white !important; min-width: 520px }
  td { padding-right: 10px  }
  </style>
</head>
<body id="kt_body" style=" background-image: url('{{ url('theme/assets/media/patterns/header-bg-dark.png')  }}')" class="header-fixed header-tablet-and-mobile-fixed toolbar-enabled">
 
<?php
$txt1 = "Cliquer ici pour télécharger & consulter la facture";
$txt2 = "Souhaitez-vous êtres prélever sur vos revenus locatifs ?";
$txt3 = "Confirmez-vous cette facture ";
$txt4 = "Signature numérique";
$txt5 = "Je soussigné autorise Magnitude a prélevé le montant demandée via l’entreprise Bali Super Host sur le compte de société. ";
$txt6 = "Entegistrer & Envoyer";
$yes = "OUI";
$no = "NON";

if($langue!='FR') { 
  $txt1 = "Click here to download & view the invoice"; 
  $txt2 = "Would you like to be deducted from your rental income?"; 
  $txt3 = "Do you confirm this invoice"; 
  $txt4 = "Digital signature";
  $txt5 = "I, the undersigned, authorize Magnitude to deduct the amount requested via Bali Super Host from the company account.";
  $txt6 = "Save & Send";
  $yes = "YES";
  $no = "NO";
}
?>

@if( $sale!='44660544071221030342' && $sale!='99217794071221030342' )    
<div class="d-flex flex-column flex-root">
  <div class="page d-flex flex-row flex-column-fluid">
    <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
      
      <div class="container" style="padding: 30px;">
          <center><img alt="Logo" src="{{ url('imgs/logo_noel.png') }}" style="width:260px;" /></center>
      </div>

      @foreach($items as $i)

        @if($i->sign2=='')
        <div id="">
          <div class="content flex-row-fluid" id="kt_content">
              <div class="card card-page">
                <div class="card-body" style="padding: 0px 38px 30px 33px">
                  <div class="col-md-8 col-md-offset-2">
                  <div class="card card-xxl-stretch">
                    @if($langue=='FR')
                    <p style="padding: 20px 50px  10px 50px ; text-align: center; font-size: 14px;">
                      <br><br>
                      <img src="{{ url('imgs/before_after.png') }}" style="width:100%">
                      <i style="font-size: 13px; color: black; "><br>Cette photo est à titre d'exemple, une fois que la route sera terminée nous vous enverrons le rendu final</i>
                      <br><br>
                      <br><br>
                      <strong>
                      Bonjour <b>{{ $i->civ }} {{ $i->nom }} {{ $i->pre }}</b>
                      </strong>
                      <br><br>
                      Dans le cadre de l’amélioration continue, suite à 3 ans d’expérience locative, nous avons constaté que la servitude de vos villas est un sujet sensible pour les locataires.
                      <br>
                      Poussé par un grand nombre de propriétaires et dans le but de toujours améliorer la rentabilité de vos villas, nous avons décidé de reprendre une à une toutes les routes qui desservent celle-ci.
                      <br>
                      Ainsi, tous les chemins d’accès seront pavés avec des réseaux d’évacuation pour une utilisation facile en voiture et scooters.
                      <br>
                      L’évacuation des eaux pluviales des routes permettra également d’éviter d’éventuelles inondations.
                      <br>
                      Le projet est divisé entre tous les propriétaires magnitude concernés et les autorités locales.
                      <br>
                      Concernant la participation financière de celle-ci, deux solutions vous sont proposées :
                      <br>
                      - Un paiement à réception de la facture,
                      <br>
                      - Un paiement par prélèvement sur vos loyers locatifs
                      <br>
                      Veuillez trouver un lien formulaire pour enregistrer votre réponse, merci de le remplir,
                      <br><br>
                      Nous vous adressons, nos sincères salutations, 
                      <br><br>
                    </p>
                    @else
                    <p style="padding: 20px 50px  10px 50px ; text-align: center; font-size: 14px;">
                      <br><br>
                      <img src="{{ url('imgs/before_after.png') }}" style="width:100%">
                      <i style="font-size: 13px; color: black; "><br>Cette photo est à titre d'exemple, une fois que la route sera terminée nous vous enverrons le rendu final</i>
                      <br><br>
                      <br><br>
                      <strong>
                      Hello <b>{{ $i->civ }} {{ $i->nom }} {{ $i->pre }}</b>
                      </strong>
                      <br><br>
                      As part of continuous improvement, following 3 years of rental experience, we have found that the easement of your villas is a sensitive subject for tenants.
                      <br>
                      Driven by a large number of owners and with the aim of always improving the profitability of your villas, we have decided to take over all the roads that serve this one one by one.
                      <br>
                      Thus, all access roads will be paved with drainage networks for easy use by car and scooters.
                      <br>
                      The evacuation of rainwater from the roads will also help to avoid possible flooding.
                      <br>
                      The project is divided between all affected magnitude owners and local authorities.
                      <br>
                      Concerning the financial participation of this one, two solutions are proposed to you:
                      <br>
                      - Payment upon receipt of the invoice,
                      <br>
                      - A payment by direct debit from your rental rents
                      <br>
                      Please find a form link to register your answer, please fill it out,
                      <br><br>
                      We send you our sincere greetings
                    </p>
                    @endif

                    <div class="col-md-8 col-md-offset-2" style="padding: 30px 10px">
                      <form method="POST" action="{{ route('signature2Saved',[ 'ref' => $i->ref ]) }}" enctype="multipart/form-data" style="background: transparent !important;">
                        {{ csrf_field() }}

                          <input type="hidden" id="reference" value="{{ $i->ref }}">

                          <a href="https://sales.magnitudeconstruction.com/public/media/signature/{{ $i->inv2 }}" target="_blank" style="color:white !important; font-weight: bold; ">
                            <button type="button" class="btn btn-success btn-block " style="color: white !important;"><i class="fa fa-arrow-right"></i> {{ $txt1 }}</a></button>
                          </a>

                          <br>
                          <br>

                          <div class="col-md-12" style="padding: 30px 55px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 20px;">
                            <div class="mb-5">
                              <label for="sign2" class=" form-label">{{ $txt2 }} </label>
                              <select  class="form-control" name="sign2" value="" required>
                                <option></option>
                                <option value="YES">{{ $yes }}</option>
                                <option value="NO">{{ $no }}</option>
                              </select>
                            </div>
                            <div class="mb-5">
                              <label for="confirm2" class=" form-label">{{ $txt3 }}</label>
                              <select  class="form-control" name="confirm2" value="" required>
                                <option></option>
                                <option value="YES">{{ $yes }}</option>
                                <option value="NO">{{ $no }}</option>
                              </select>
                            </div>
                          </div>

                          <h3>{{ $txt4 }}</h3>
                          <div class="col-md-12" style="padding: 30px 0px; border:1px solid rgba(0,0,0,0.1); border-radius: 5px; margin-bottom: 20px;">
                            <div class="mb-5">
                              <div id="signArea" >
                                <p style="text-align: center;">{{ $txt5 }}</p>
                                <div class="sig sigWrapper" style="height:auto;">
                                  <div class="typed"></div>
                                  <canvas class="sign-pad" id="sign-pad" width="300" height="100"></canvas>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="mb-5">
                              <button class="btn btn-success btn-sm" style="margin-top: 10px"  id="btnSaveSign"><i class="fa fa-save"></i>{{ $txt6 }}</button>
                          </div>
                        </form>
                    </div>

                  </div>
                  </div>
                </div>
              </div> 
          </div>
        </div>
        @else
        <div id="">
          <div class="content flex-row-fluid" id="kt_content">
              <div class="card card-page">
                <div class="card-body" style="padding: 0px 38px 30px 33px">
                  <div class="col-md-8 col-md-offset-2">
                  <div class="card card-xxl-stretch" style="min-height: 800px; border-radius:0; padding:150px 80px">
                    
                    <div class="alert alert-danger" style="font-weight: bold; text-align:center;">Vous avez déja répondre sur notre formulaire, merci</div>

                  </div>
                  </div>
                </div>
              </div> 
          </div>
        </div>

        
        @endif

      @endforeach

    </div>
  </div>

  <div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
    <div class="container-xxl d-flex flex-column flex-md-row align-items-center justify-content-between">
      <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-bold me-1"><?php echo date("Y"); ?> ©</span>
        <a href="https://magnitudeconstruction.com/" target="_blank" class="text-gray-800 text-hover-primary">Magnitude Construction</a>
      </div>
    </div>
  </div>
</div>

@else
<div class="d-flex flex-column flex-root">
  <div class="page d-flex flex-row flex-column-fluid">
    <div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">

      <div class="container" style="padding: 30px;">
          <center><img alt="Logo" src="{{ url('imgs/logo_noel.png') }}" style="width:260px; margin-top: 80px;" /></center>
      </div>

      <div class="container" style="margin-top: 150px;">
        <div class="alert alert-danger" style="text-align: center; font-weight: bold;">Un problème est survenu. <br> Veuillez réessayer plus tard.</div>
      </div>
    </div>
  </div>
</div>
@endif

<script src="{{ url('signatureAssets/js/jquery.min.js') }}"></script>
<script src="{{ url('signatureAssets/js/bootstrap.min.js') }}"></script>
<script src="{{ url('signatureAssets/js/bootstrap-select.js') }}"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link href="{{ url('signatureAssets/css/jquery.signaturepad.css') }}" rel="stylesheet">
<script src="{{ url('signatureAssets/js/numeric-1.2.6.min.js') }}"></script> 
<script src="{{ url('signatureAssets/js/bezier.js') }}"></script>
<script src="{{ url('signatureAssets/js/jquery.signaturepad.js') }}"></script> 
<script type='text/javascript' src="https://github.com/niklasvh/html2canvas/releases/download/0.4.1/html2canvas.js"></script>
<script src="{{ url('signatureAssets/js/json2.min.js') }}"></script>
<script>
$(document).ready(function(e){
$(document).ready(function() { $('#signArea').signaturePad({drawOnly:true, drawBezierCurves:true, lineTop:90}); });
$("#btnSaveSign").click(function(e){ 
  html2canvas([document.getElementById('sign-pad')], {
    onrendered: function (canvas) {
      var canvas_img_data = canvas.toDataURL('image/png');
      var img_data = canvas_img_data.replace(/^data:image\/(png|jpg);base64,/, "");
      //ajax call to save image inside folder
      var reference = $("#reference").val(); 
      $.ajax({
        url: '../../save_signature2.php?reference='+reference,
        data: { img_data:img_data },
        type: 'post',
        dataType: 'json',
        success: function (response) {
           // window.location.reload(); 
        }
      });
    }
  });
});
});
</script>

</body> 
</html>

