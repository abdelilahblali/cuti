<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Home;
use App\Http\Controllers\Admin;
use App\Http\Controllers\CatalogForm;
use App\Http\Controllers\SendEmailController;
use App\Http\Controllers\Chat;
use App\Http\Controllers\Auth\LoginController;

use App\Http\Controllers\Signature;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Web

Route::get('/', function () {
    return view('home');
});


Auth::routes(['verify' => true]);

Route::get('locale/{locale}', function ($locale) {
    session()->put('locale', $locale);
    return Redirect::back();
});




Route::get('/', [App\Http\Controllers\Admin::class, 'index'])->name('index');

Route::get('/home', [App\Http\Controllers\Admin::class, 'index'])->name('home');



Route::get('photos', [Home::class, 'photos'])->name('photos');

Route::get('docs', [Home::class, 'docs'])->name('docs');



Route::get('client', [Admin::class, 'client'])->name('client');

Route::get('clientAdd', [Admin::class, 'clientAdd'])->name('clientAdd');

Route::post('clientAdded', [Admin::class, 'clientAdded'])->name('clientAdded');

Route::get('clientEdit/{ref}', [Admin::class, 'clientEdit'])->name('clientEdit');

Route::get('clientDelete/{ref}', [Admin::class, 'clientDelete'])->name('clientDelete');

Route::post('clientEdited/{ref}', [Admin::class, 'clientEdited'])->name('clientEdited');

Route::get('clientPhotos/{ref}', [Admin::class, 'clientPhotos'])->name('clientPhotos');

Route::post('clientPhotosAdd/{ref}', [Admin::class, 'clientPhotosAdd'])->name('clientPhotosAdd');

Route::get('clientPhotosDelete/{ref}', [Admin::class, 'clientPhotosDelete'])->name('clientPhotosDelete');



Route::get('clientDocs/{ref}', [Admin::class, 'clientDocs'])->name('clientDocs');

Route::post('clientDocsAdd/{ref}', [Admin::class, 'clientDocsAdd'])->name('clientDocsAdd');

Route::get('clientDocsDelete/{id}/{ref}', [Admin::class, 'clientDocsDelete'])->name('clientDocsDelete');





Route::get('clientNotification/{mail}', [Admin::class, 'clientNotification'])->name('clientNotification');

Route::get('docView/{mail}/{vf}', [Admin::class, 'docView'])->name('docView');



Route::get('documents', [Admin::class, 'documents'])->name('documents');



Route::get('doc', [Admin::class, 'doc'])->name('doc');

Route::get('docAdd', [Admin::class, 'docAdd'])->name('docAdd');

Route::post('docAdded', [Admin::class, 'docAdded'])->name('docAdded');

Route::get('docDelete/{ref}', [Admin::class, 'docDelete'])->name('docDelete');



Route::get('password', [Admin::class, 'password'])->name('password');

Route::post('passwordEdited', [Admin::class, 'passwordEdited'])->name('passwordEdited');



// Admin

Route::get('/admin', [App\Http\Controllers\Admin::class, 'index'])->name('admin');

Route::get('forgot', [Admin::class, 'forgot'])->name('forgot');



// client ##############################



// ClientFolder

Route::get('clientFolder/{ref}', [Admin::class, 'clientFolder'])->name('clientFolder');

Route::get('clientFolder_ptpma/{ref}', [Admin::class, 'clientFolder_ptpma'])->name('clientFolder_ptpma');

Route::get('clientFolder_land/{ref}', [Admin::class, 'clientFolder_land'])->name('clientFolder_land');

Route::get('clientFolder_architecture/{ref}', [Admin::class, 'clientFolder_architecture'])->name('clientFolder_architecture');

Route::get('clientFolder_plan/{ref}', [Admin::class, 'clientFolder_plan'])->name('clientFolder_plan');
Route::get('clientFolder_travaux/{ref}', [Admin::class, 'clientFolder_travaux'])->name('clientFolder_travaux');

Route::get('clientFolder_interior/{ref}', [Admin::class, 'clientFolder_interior'])->name('clientFolder_interior');

Route::get('cliEntfolder_design_Delete/{ref}', [Admin::class, 'cliEntfolder_design_Delete'])->name('cliEntfolder_design_Delete');

Route::get('clientFolder_design0/{ref}', [Admin::class, 'clientFolder_design0'])->name('clientFolder_design0');

Route::post('clientFolder_design0_addVideo/{cli}', [Admin::class, 'clientFolder_design0_addVideo'])->name('clientFolder_design0_addVideo');

Route::get('clientFolder_design1/{ref}', [Admin::class, 'clientFolder_design1'])->name('clientFolder_design1');

Route::get('clientFolder_design2/{ref}', [Admin::class, 'clientFolder_design2'])->name('clientFolder_design2');

Route::get('clientFolder_design3/{ref}', [Admin::class, 'clientFolder_design3'])->name('clientFolder_design3');



Route::get('clientFolder_construction/{ref}', [Admin::class, 'clientFolder_construction'])->name('clientFolder_construction');

Route::post('clientFolder_construction_updated', [Admin::class, 'clientFolder_construction_updated'])->name('clientFolder_construction_updated');



Route::get('clientFolder_factures/{ref}', [Admin::class, 'clientFolder_factures'])->name('clientFolder_factures');

Route::post('clientFolder_factures_updated', [Admin::class, 'clientFolder_factures_updated'])->name('clientFolder_factures_updated');

Route::post('clientFolder_factures_updated_byClient', [Admin::class, 'clientFolder_factures_updated_byClient'])->name('clientFolder_factures_updated_byClient');



Route::post('clientFolder_design_AddImg/{ref}', [Admin::class, 'clientFolder_design_AddImg'])->name('clientFolder_design_AddImg');
Route::get('clientFolder_design_DeleteImg/{ref}', [Admin::class, 'clientFolder_design_DeleteImg'])->name('clientFolder_design_DeleteImg');


Route::post('clientFolder_design_AddPdf/{ref}', [Admin::class, 'clientFolder_design_AddPdf'])->name('clientFolder_design_AddPdf');
Route::get('clientFolder_design_DeletePdf/{ref}', [Admin::class, 'clientFolder_design_DeletePdf'])->name('clientFolder_design_DeletePdf');



Route::get('clientFolderValidate/{ref}/{item}/{valid}/{table}', [Admin::class, 'clientFolderValidate'])->name('clientFolderValidate');
Route::get('emailsValid/{ref}/{tache}/{valid}', [Admin::class, 'emailsValid'])->name('emailsValid');



// Dashboard

Route::get('dashboard', [Admin::class, 'dashboard'])->name('dashboard');

Route::get('markAllAsRead', [Admin::class, 'markAllAsRead'])->name('markAllAsRead');



// Administration

Route::get('administration', [Admin::class, 'administration'])->name('administration');

Route::post('administrationAdded', [Admin::class, 'administrationAdded'])->name('administrationAdded');



// PTPMA

Route::get('ptpma', [Admin::class, 'ptpma'])->name('ptpma');

Route::post('ptpmaAdded', [Admin::class, 'ptpmaAdded'])->name('ptpmaAdded');



// Land
Route::get('land', [Admin::class, 'land'])->name('land');
Route::post('landAdded', [Admin::class, 'landAdded'])->name('landAdded');

// Architecture
Route::get('architecture', [Admin::class, 'architecture'])->name('architecture');
Route::get('design', [Admin::class, 'design'])->name('design');
Route::post('designAddCmt', [Admin::class, 'designAddCmt'])->name('designAddCmt');
Route::get('designDeleteCmt/{cmt}', [Admin::class, 'designDeleteCmt'])->name('designDeleteCmt');

Route::post('answerAdd', [Admin::class, 'answerAdd'])->name('answerAdd');
Route::get('answerDelete/{answer}', [Admin::class, 'answerDelete'])->name('answerDelete');

Route::get('design0', [Admin::class, 'design0'])->name('design0');

Route::get('design1', [Admin::class, 'design1'])->name('design1');
Route::get('design2', [Admin::class, 'design2'])->name('design2');
Route::get('design3', [Admin::class, 'design3'])->name('design3');
Route::get('interior', [Admin::class, 'interior'])->name('interior');
Route::get('travaux', [Admin::class, 'travaux'])->name('travaux');
Route::get('plan', [Admin::class, 'plan'])->name('plan');
Route::post('planAdded', [Admin::class, 'planAdded'])->name('planAdded');

// Construction
Route::get('construction', [Admin::class, 'construction'])->name('construction');
Route::get('getPhotosDay/{date}', [Admin::class, 'getPhotosDay'])->name('getPhotosDay');
Route::get('getPhotosAll', [Admin::class, 'getPhotosAll'])->name('getPhotosAll');

// Invoices
Route::get('invoices', [Admin::class, 'invoices'])->name('invoices');
Route::get('deleteProof/{inv}', [Admin::class, 'deleteProof'])->name('deleteProof');
Route::get('deleteInvoice/{cli}/{inv}', [Admin::class, 'deleteInvoice'])->name('deleteInvoice');
Route::get('deletePaid/{cli}/{inv}', [Admin::class, 'deletePaid'])->name('deletePaid');

// Days
Route::get('days/{typ}', [Admin::class, 'days'])->name('days');
Route::post('daysAdd', [Admin::class, 'daysAdd'])->name('daysAdd');
Route::get('daysDelete/{ref}', [Admin::class, 'daysDelete'])->name('daysDelete');

// form
Route::post('form_added', [Admin::class, 'form_added'])->name('form_added');

// History
Route::get('historyPics', [Admin::class, 'historyPics'])->name('historyPics');
Route::get('historyDocs', [Admin::class, 'historyDocs'])->name('historyDocs');

// Rendez-vous
Route::post('rendezvous', [Admin::class, 'rendezvous'])->name('rendezvous');

// Documentation
Route::get('documentation', [Admin::class, 'documentation'])->name('documentation');

// Passports
Route::post('passportAdded', [Admin::class, 'passportAdded'])->name('passportAdded');
Route::get('passportDelete/{ref}', [Admin::class, 'passportDelete'])->name('passportDelete');

// nameVillaPtpma
Route::post('nameVillaPtpma', [Admin::class, 'nameVillaPtpma'])->name('nameVillaPtpma');

// Notifications page
Route::get('notifications/{cli}', [Admin::class, 'notifications'])->name('notifications');

Route::get('forgot', [Home::class, 'forgot'])->name('forgot');

// print catalog
Route::get('catalog/{cli}', [Admin::class, 'catalog'])->name('catalog');

// Notifications
Route::get('emails', [Admin::class, 'emails'])->name('emails');
Route::post('emailsAdded', [Admin::class, 'emailsAdded'])->name('emailsAdded');

Route::get('deleteFile/{ref}/{table}/{champ}', [Admin::class, 'deleteFile'])->name('deleteFile');


// CatalogForm
Route::get('catalogForm', [CatalogForm::class, 'catalogForm'])->name('catalogForm');
Route::post('catalogForm_add', [CatalogForm::class, 'catalogForm_add'])->name('catalogForm_add');
Route::get('catalogFormPrint/{ref}', [CatalogForm::class, 'catalogFormPrint'])->name('catalogFormPrint');


// Account
Route::get('myAccount', [Admin::class, 'myAccount'])->name('myAccount');
Route::post('myAccountUpdated', [Admin::class, 'myAccountUpdated'])->name('myAccountUpdated');


Route::get('steps', [Admin::class, 'steps'])->name('steps');
Route::get('recap', [Admin::class, 'recap'])->name('recap');



// send email
Route::get('send-email', [SendEmailController::class, 'index']);


// Import All Photos
Route::get('importAllPhotos', [Admin::class, 'importAllPhotos'])->name('importAllPhotos');
Route::post('importAllPhotosAdded', [Admin::class, 'importAllPhotosAdded'])->name('importAllPhotosAdded');


// Chat
Route::get('chat', [Chat::class, 'chat'])->name('chat');
Route::post('chatAdded', [Chat::class, 'chatAdded'])->name('chatAdded');
Route::get('chatAddedGet/{msg}', [Chat::class, 'chatAddedGet'])->name('chatAddedGet');
Route::get('clientChat/{ref}', [Chat::class, 'clientChat'])->name('clientChat');
Route::get('chatAudio/{audio}', [Chat::class, 'chatAudio'])->name('chatAudio');
Route::get('chatAudioAdmin/{audio}/{to}', [Chat::class, 'chatAudioAdmin'])->name('chatAudioAdmin');
Route::get('chatVu', [Chat::class, 'chatVu'])->name('chatVu');
Route::get('clientMsgNoLu', [Chat::class, 'clientMsgNoLu'])->name('clientMsgNoLu');
Route::get('clientComment/{cli}', [Chat::class, 'clientComment'])->name('clientComment');
Route::post('clientCommentAdded/{cli}', [Chat::class, 'clientCommentAdded'])->name('clientCommentAdded');


Route::get('holidays_total', [Admin::class, 'holidays_total'])->name('holidays_total');



Route::post('login', [LoginController::class, 'login'])->name('login');


// Signature ##################################################################
Route::get('signature1/{ref}/{val}', [Signature::class, 'signature1'])->name('signature1');
Route::post('signature1Saved/{ref}', [Signature::class, 'signature1Saved'])->name('signature1Saved');

Route::get('signature2/{ref}/{val}', [Signature::class, 'signature2'])->name('signature2');
Route::post('signature2Saved/{ref}', [Signature::class, 'signature2Saved'])->name('signature2Saved');

Route::get('signatureDone', [Signature::class, 'signatureDone'])->name('signatureDone');



