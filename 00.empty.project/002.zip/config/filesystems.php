<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application. Just store away!
    |
    */

    'default' => env('FILESYSTEM_DRIVER', 'local'),

    /*
    |--------------------------------------------------------------------------
    | Default Cloud Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Many applications store files both locally and in the cloud. For this
    | reason, you may specify a default "cloud" driver here. This driver
    | will be bound as the Cloud disk implementation in the container.
    |
    */

    'cloud' => env('FILESYSTEM_CLOUD', 's3'),

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Here you may configure as many filesystem "disks" as you wish, and you
    | may even configure multiple disks of the same driver. Defaults have
    | been setup for each driver as an example of the required options.
    |
    | Supported Drivers: "local", "ftp", "sftp", "s3"
    |
    */

    'disks' => [

        'local' => [
            'driver' => 'local',
            'root' => storage_path('app'),
        ],

        'public' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/cli',
            'url' => env('APP_URL').'/public',
            'visibility' => 'public',
        ],

        'doc' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/doc',
            'url' => env('APP_URL').'/doc',
            'visibility' => 'public',
        ],

        's3' => [
            'driver' => 's3',
            'key' => env('AWS_ACCESS_KEY_ID'),
            'secret' => env('AWS_SECRET_ACCESS_KEY'),
            'region' => env('AWS_DEFAULT_REGION'),
            'bucket' => env('AWS_BUCKET'),
            'url' => env('AWS_URL'),
            'endpoint' => env('AWS_ENDPOINT'),
        ],



        'd' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/d',
            'url' => env('APP_URL').'/d',
            'visibility' => 'public',
        ],

        'invoice' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/invoice',
            'url' => env('APP_URL').'/invoice',
            'visibility' => 'public',
        ],

        'clidoc' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/clidoc',
            'url' => env('APP_URL').'/clidoc',
            'visibility' => 'public',
        ],


        'passport' => [
            'driver' => 'local',
            'root'   => public_path() . '/../../sales.magnitudeconstruction.com/public/media/cli',
            'url' => env('APP_URL').'/cli',
            'visibility' => 'public',
        ],

        'sales' => [
            'driver' => 'local',
            'root'   => public_path() . '/../../sales.magnitudeconstruction.com/public/media/cli',
            'url' => env('APP_URL').'/cli',
            'visibility' => 'public',
        ],

        'sample' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/sample',
            'url' => env('APP_URL').'/sample',
            'visibility' => 'public',
        ],

        'audio' => [
            'driver' => 'local',
            'root'   => public_path() . '/../media/audio',
            'url' => env('APP_URL').'/audio',
            'visibility' => 'public',
        ],




    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` Artisan command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    |
    */

    'links' => [
        public_path('storage') => storage_path('app/public'),
    ],

];
