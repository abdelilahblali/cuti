<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use auth;
use Twilio\Rest\Client; 
use  App\Mail\Notification;
use Carbon\Carbon;
use  App\Mail\NotifSignature;

class Signature extends Controller
{
    /**
    * Create a new controller instance.
    *
    * @return void
    */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
    * Show the application dashboard.
    *
    * @return \Illuminate\Contracts\Support\Renderable
    */


    public function signature1($ref)
    {

        $items = DB::connection('mysql2')->table('ventes')
        ->select('inv1_total', 'inv2_total', 'sent1', 'sent2',  'sign1', 'sign1_dat', 'confirm1', 'confirm1_dat', 'paid1', 'paid1_dat', 'inv1', 'sign2', 'sign2_dat', 'confirm2', 'confirm2_dat', 'paid2', 'paid2_dat', 'inv2', 'received', 'percent13', 'final', 'sale_date', 'AccountActive', 'montant_add', 'ventes.ref as ref', 'cod', 'seller', 'ventes.civ as civ', 'ventes.nom as nom', 'ventes.pre as pre', 'ventes.tel as tel', 'ventes.mail as mail', 'passeport', 'ares', 'lease', 'position', 'chambre', 'basee', 'template', 'inspiration', 'extra', 'extras', 'prix', 'unite', 'ventes.fait', 'username as par', 'salevillaname')
        ->leftjoin('suivis', 'ventes.ref', '=', 'suivis.vente')
        ->leftjoin('payment', 'ventes.ref', '=', 'payment.vente')
        ->leftjoin('progress', 'ventes.ref', '=', 'progress.vente')
        ->leftjoin('signature', 'ventes.ref', '=', 'signature.vente')
        ->join('clis', 'clis.ref', '=', 'ventes.par')
        ->where('ventes.ref', $ref)
        ->orderBy('ventes.fait', 'desc')
        ->get();

        DB::connection('mysql2')->table('signature')->where('vente', $ref)->update([ 'vu1' => "on", ]); 

        $code = DB::connection('mysql2')->table('ventes')->where('ref', $ref)->value("cod");
        $langue = DB::table('clis')->where('code', $code)->value('langue');

        $sale = DB::connection('mysql2')->table('bank')->where('ref', $ref)->value('vente');
        $ventes = DB::connection('mysql2')->table('ventes')->where('ventes.ref', $sale)->leftjoin('infos', 'ventes.ref', '=', 'infos.vente')->leftjoin('lands', 'ventes.ref', '=', 'lands.vente')->get(); //GetClient
        return view('signature1', ['ventes' => $ventes, 'items' => $items , 'sale' => $sale, 'langue' => $langue  ]);
    }

    public function signature1Saved(Request $req, $ref)
    {
        $fait=date("Y/m/d H:i:s");

        $codeClient = DB::connection('mysql2')->table('ventes')->where('ref', $ref)->value('cod');

        DB::connection('mysql2')->table('signature')
        ->where('vente', $ref)
        ->update([
            'sign1' => $req->input('sign1'),
            'sign1_dat' => $fait,
            'confirm1' => $req->input('confirm1'),
            'confirm1_dat' => $fait,
            'paid1' =>$req->input('paid1'),
            'signature1_img' => $ref.".png",
        ]); 

        //Send notification ********************************************************************
        $emails = array(); 
        rray_push($emails, "financemagnitude@gmail.com");
        array_push($emails, "futur.developer@gmail.com");
        array_push($emails, "accounting@magnitudeconstruction.com");
        $v1 = $ref;  $v2="v2"; 
        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifSignature($v1, $v2, $codeClient) ); } } }  

        session()->flash('yes',"Email has been successfully sent to client");
        return redirect('signatureDone');
    }

    public function signature2($ref)
    {

        $items = DB::connection('mysql2')->table('ventes')
        ->select('inv1_total', 'inv2_total', 'sent1', 'sent2', 'sign1', 'sign1_dat', 'confirm1', 'confirm1_dat', 'paid1', 'paid1_dat', 'inv1', 'sign2', 'sign2_dat', 'confirm2', 'confirm2_dat', 'paid2', 'paid2_dat', 'inv2', 'received', 'percent13', 'final', 'sale_date', 'AccountActive', 'montant_add', 'ventes.ref as ref', 'cod', 'seller', 'ventes.civ as civ', 'ventes.nom as nom', 'ventes.pre as pre', 'ventes.tel as tel', 'ventes.mail as mail', 'passeport', 'ares', 'lease', 'position', 'chambre', 'basee', 'template', 'inspiration', 'extra', 'extras', 'prix', 'unite', 'ventes.fait', 'username as par', 'salevillaname')
        ->leftjoin('suivis', 'ventes.ref', '=', 'suivis.vente')
        ->leftjoin('payment', 'ventes.ref', '=', 'payment.vente')
        ->leftjoin('progress', 'ventes.ref', '=', 'progress.vente')
        ->leftjoin('signature', 'ventes.ref', '=', 'signature.vente')
        ->join('clis', 'clis.ref', '=', 'ventes.par')
        ->where('ventes.ref', $ref)
        ->orderBy('ventes.fait', 'desc')
        ->get();

        DB::connection('mysql2')->table('signature')->where('vente', $ref)->update([ 'vu2' => "on", ]); 

        $code = DB::connection('mysql2')->table('ventes')->where('ref', $ref)->value("cod");
        $langue = DB::table('clis')->where('code', $code)->value('langue');

        $sale = DB::connection('mysql2')->table('bank')->where('ref', $ref)->value('vente');
        $ventes = DB::connection('mysql2')->table('ventes')->where('ventes.ref', $sale)->leftjoin('infos', 'ventes.ref', '=', 'infos.vente')->leftjoin('lands', 'ventes.ref', '=', 'lands.vente')->get(); //GetClient
        return view('signature2', ['ventes' => $ventes, 'items' => $items, 'sale' => $sale, 'langue' => $langue  ]);
    }

    public function signature2Saved(Request $req, $ref)
    {
        $fait=date("Y/m/d H:i:s");

        $codeClient = DB::connection('mysql2')->table('ventes')->where('ref', $ref)->value('cod');

        DB::connection('mysql2')->table('signature')
        ->where('vente', $ref)
        ->update([
            'sign2' => $req->input('sign2'),
            'sign2_dat' => $fait,
            'confirm2' => $req->input('confirm2'),
            'confirm2_dat' => $fait,
            'paid2' => $req->input('paid2'),
            'paid2_dat' => $fait,
            'signature2_img' => $ref.".png",
        ]); 

        //Send notification ********************************************************************
        $emails = array(); 
        array_push($emails, "financemagnitude@gmail.com");
        array_push($emails, "futur.developer@gmail.com");
        array_push($emails, "accounting@magnitudeconstruction.com");
        $v1 = $ref;  $v2="v2"; 
        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifSignature($v1, $v2, $codeClient) ); } } }  

        session()->flash('yes',"Email has been successfully sent to client");
        return redirect('signatureDone');
    }

    public function signatureDone()
    {
        return view('signatureDone');
    }

}