<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use auth;
use Twilio\Rest\Client; 
use  App\Mail\Notification;
use  App\Mail\Notif;

class Chat extends Controller
{
    /**
    * Create a new controller instance.
    *
    * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');
        
    }

    /**
    * Show the application dashboard.
    *
    * @return \Illuminate\Contracts\Support\Renderable
    */

    public function chat()
    {
        return view("chat");
    }

    public function chatAdded(Request $req)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");
        DB::table('chat')->insert([ 
            'ref' => $ref, 
            'via' => Auth::user()->ref,
            'to' => $req->input('to'),
            'msg' => $req->input('msg'),
            'fait' => $fait,
            'vu' => 0,
            ]
        );

        // send email
        $code = DB::table('clis')->where('ref', $req->input('to'))->value('code');
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);
        $msg = "New message from Magnitude"; $page="dashboard";
        foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page) ); } }

        return back();
    }

    public function chatAddedGet($msg)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");
        DB::table('chat')->insert([ 
            'ref' => $ref, 
            'via' => Auth::user()->ref,
            'to' => "Magnitude",
            'msg' => $msg,
            'fait' => $fait,
            'vu' => 0,
            ]
        );

        // send email
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        $msg = Auth::user()->code." : New message"; $emails = getEmails('chat'); $page="chat";
        foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page) ); } }

        // refresh messages box
        $a = "";
        $chats = DB::table('chat')
        ->join('clis', 'clis.ref', '=', 'chat.via')
        ->orderBy('chat.fait','asc')->get();
        foreach($chats as $m){ 
            if($m->via==Auth::user()->ref) {
                if($m->msg_typ!='audio') {
                $a.="<div class='d-flex justify-content-end mb-10'>
                    <div class='d-flex flex-column align-items-end'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='me-3'>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                                <span class='fs-5 fw-bolder text-gray-900 ms-1'>"; if($m->vu==1) { $a.="<i class='fa fa-check blue1'></i>"; } else {  $a.="<i class='fa fa-clock'></i>"; } $a.="</span>
                            </div>
                        </div>
                        <div class='p-5 rounded bg-light-primary text-dark fw-bold mw-lg-400px text-end' data-kt-element='message-text'>".$m->msg."</div>
                    </div>
                </div>";
                } else { 
                $a.="<div class='d-flex justify-content-end mb-10'>
                    <div class='d-flex flex-column align-items-end'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='me-3'>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                                <span class='fs-5 fw-bolder text-gray-900 ms-1'>"; if($m->vu==1) { $a.="<i class='fa fa-check blue1'></i>"; } else {  $a.="<i class='fa fa-clock'></i>"; } $a.="</span>
                            </div>
                        </div>
                        <audio controls='' src='https://villa.magnitudeconstruction.com/media/audio/".$m->audio."'></audio>
                    </div>
                </div>";
                }
            }
            elseif($m->to==Auth::user()->ref) {
                if($m->msg_typ!='audio') {
                $a.="<div class='d-flex justify-content-start mb-10'>
                    <div class='d-flex flex-column align-items-start'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='ms-3'>
                                <a href='#' class='fs-5 fw-bolder text-gray-900 me-1'>Magnitude</a>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                            </div>
                        </div>
                        <div class='p-5 rounded bg-light-primary text-dark fw-bold mw-lg-400px text-end' data-kt-element='message-text'>".$m->msg."</div>
                    </div>
                </div>";
                } else { 
                $a.="<div class='d-flex justify-content-start mb-10'>
                    <div class='d-flex flex-column align-items-start'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='ms-3'>
                                <a href='#' class='fs-5 fw-bolder text-gray-900 me-1'>Magnitude</a>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                            </div>
                        </div>
                        <audio controls='' src='https://villa.magnitudeconstruction.com/media/audio/".$m->audio."'></audio>
                    </div>
                </div>";
                }
            }
        }
        $a.="<div id='last'></div>";

        return json_encode($a);
    }

    public function chatAudio($audio)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");
        DB::table('chat')->insert([ 
            'ref' => $ref, 
            'via' => Auth::user()->ref,
            'to' => "Magnitude",
            'msg_typ' => "audio",
            'audio' => $audio,
            'fait' => $fait,
            'vu' => 0,
            ]
        );

        // send email
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        $msg = Auth::user()->code." : New message"; $emails = getEmails('chat'); $page="chat";
        foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page) ); } }

        // refresh messages box
        $a = "";
        $chats = DB::table('chat')
        ->join('clis', 'clis.ref', '=', 'chat.via')
        ->orderBy('chat.fait','asc')->get();
        foreach($chats as $m){ 
            if($m->via==Auth::user()->ref) {
                if($m->msg_typ!='audio') {
                $a.="<div class='d-flex justify-content-end mb-10'>
                    <div class='d-flex flex-column align-items-end'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='me-3'>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                                <span class='fs-5 fw-bolder text-gray-900 ms-1'>"; if($m->vu==1) { $a.="<i class='fa fa-check blue1'></i>"; } else {  $a.="<i class='fa fa-clock'></i>"; } $a.="</span>
                            </div>
                        </div>
                        <div class='p-5 rounded bg-light-primary text-dark fw-bold mw-lg-400px text-end' data-kt-element='message-text'>".$m->msg."</div>
                    </div>
                </div>";
                } else { 
                $a.="<div class='d-flex justify-content-end mb-10'>
                    <div class='d-flex flex-column align-items-end'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='me-3'>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                                <span class='fs-5 fw-bolder text-gray-900 ms-1'>"; if($m->vu==1) { $a.="<i class='fa fa-check blue1'></i>"; } else {  $a.="<i class='fa fa-clock'></i>"; } $a.="</span>
                            </div>
                        </div>
                        <audio controls='' src='https://villa.magnitudeconstruction.com/media/audio/".$m->audio."'></audio>
                    </div>
                </div>";
                }
            }
            elseif($m->to==Auth::user()->ref) {
                if($m->msg_typ!='audio') {
                $a.="<div class='d-flex justify-content-start mb-10'>
                    <div class='d-flex flex-column align-items-start'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='ms-3'>
                                <a href='#' class='fs-5 fw-bolder text-gray-900 me-1'>Magnitude</a>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                            </div>
                        </div>
                        <div class='p-5 rounded bg-light-primary text-dark fw-bold mw-lg-400px text-end' data-kt-element='message-text'>".$m->msg."</div>
                    </div>
                </div>";
                } else { 
                $a.="<div class='d-flex justify-content-start mb-10'>
                    <div class='d-flex flex-column align-items-start'>
                        <div class='d-flex align-items-center mb-2'>
                            <div class='ms-3'>
                                <a href='#' class='fs-5 fw-bolder text-gray-900 me-1'>Magnitude</a>
                                <span class='text-muted fs-7 mb-1'>".$m->fait."</span>
                            </div>
                        </div>
                        <audio controls='' src='https://villa.magnitudeconstruction.com/media/audio/".$m->audio."'></audio>
                    </div>
                </div>";
                }
            }
        }
        $a.="<div id='last'></div>";

        return json_encode($a);
    }

    public function chatAudioAdmin($audio, $to)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");
        DB::table('chat')->insert([ 
            'ref' => $ref, 
            'via' => Auth::user()->ref,
            'to' => $to,
            'msg_typ' => "audio",
            'audio' => $audio,
            'fait' => $fait,
            'vu' => 0,
            ]
        );

        // send email
        $code = DB::table('clis')->where('ref', $to)->value('code');
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);
        $msg = "New message from Magnitude"; $page="dashboard";
        foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page) ); } }
        
        return json_encode("ok");
    }

    public function clientChat($ref)
    {
        $clis = DB::table('clis')
        ->where('ref', $ref)
        ->get();
        DB::table('chat')->where('via', $ref)->update([ 'vu' => 1 ]);
        return view('clientChat', ['clis' => $clis  ]);

    }

    public function chatVu()
    {
        DB::table('chat')->where('to', Auth::user()->ref)->update([ 'vu' => 1 ]);
    }

    public function clientMsgNoLu()
    {
        $clients = DB::table('clis')->get();
        foreach ($clients as $c) {
            DB::table('clis')->where('mail', $c->mail)->update([ 'email' => $c->mail ]); 
        }

        if (Auth::user()->type!='admin') { return redirect('dashboard');  }
        $clis = DB::table('clis')
        ->where('type', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();

        $msg_non_lu = array ( array('cli' => '1', 'nb' => '1'), );

        foreach($clis as $c) {
            $nb = DB::table('chat')->where('via', $c->ref)->where('vu',0)->count();
            $newdata =  array ( 'cli' => $c->ref, 'nb' => $nb );
            array_push($msg_non_lu, $newdata);
        }


        return view('clientMsgNoLu', ['clis' => $clis, 'msg_non_lu' => $msg_non_lu ]);
    }

    // Comment
    public function clientComment($cli)
    {
        $clis = DB::table('clis')->where('ref', $cli)->get();
        $cmts = DB::table('comment')->where('cli', $cli)->orderBy('fait', 'desc')->get();
        return view('clientComment', [ 'cmts' => $cmts, 'clis' => $clis  ]);
    }

    public function clientCommentAdded(Request $req, $cli)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");
        DB::table('comment')->insert([ 
            'ref' => $ref, 
            'cli' => $cli,
            'cmt' => $req->input('cmt'),
            'fait' => $fait,
            'par' => Auth::user()->ref,
            ]
        );
        return back();
    }

}
