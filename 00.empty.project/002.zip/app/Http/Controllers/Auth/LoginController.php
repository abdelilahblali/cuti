<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use auth;
use DB;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');

    }


    public function username()
    {
        return 'username'; // or whatever field you use to login
    }

    public function login(Request $req)
    {
        $type = DB::table('clis')->where('username', $req->input('username'))->value('type');

        if($type=='admin') {
            if(\Auth::attempt($req->only('username', 'password'))){
                return redirect('home');
            }
            return redirect('login')->withError('Login details are not valid');
        } elseif($type=='user') {
            $code = DB::table('clis')->where('username', $req->input('username'))->value('code');
            $AccountActive = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('AccountActive');

            if($AccountActive==1){
                if(\Auth::attempt($req->only('username', 'password'))){
                    return redirect('home');
                }
            }
            return redirect('login')->withError('Login details are not valid');
        }
    }
   

}
