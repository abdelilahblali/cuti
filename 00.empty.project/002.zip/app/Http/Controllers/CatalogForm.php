<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use auth;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

use  App\Mail\Notification;
use  App\Mail\Rendezvous;
use  App\Mail\Notif;

use PDF;

use Illuminate\Support\Facades\Route;

class CatalogForm extends Controller
{
    /**
    * Create a new controller instance.
    *
    * @return void
    */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
    * Show the application dashboardboard.
    *
    * @return \Illuminate\Contracts\Support\Renderable
    */

    // emails
    public function catalogForm()
    {   
        return view('catalogForm');
    }


    // Form Add
    public function catalogForm_add(Request $req)
    {

        for ($i=1;$i<=79;$i++) {
          $vardyn = "v".$i;
          $$vardyn = $req->input($vardyn);
        }

        // Notifications
        // $code = Auth::user()->code;
        // function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        // $emails = getEmails('arch1');
        // $msg=$code." - D0 : The form has been updated"; $page="design0";
        // if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \ Mail::to($em)->send(new Notif($msg, $page) ); } } }  

        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
        $fait=date("Y/m/d H:i:s");

        DB::table('catalogForm')
        ->insert([
            'ref' => $id,
            'cli' => $id,

            'v1' => $v1,
            'v2' => $v2,
            'v3' => $v3,
            'v4' => $v4,
            'v5' => $v5,
            'v6' => $v6,
            'v7' => $v7,
            'v8' => $v8,
            'v9' => $v9,
            'v10' => $v10,

            'v11' => $v11,
            'v12' => $v12,
            'v13' => $v13,
            'v14' => $v14,
            'v15' => $v15,
            'v16' => $v16,
            'v17' => $v17,
            'v18' => $v18,
            'v19' => $v19,
            'v20' => $v20,

            'v21' => $v21,
            'v22' => $v22,
            'v23' => $v23,
            'v24' => $v24,
            'v25' => $v25,
            'v26' => $v26,
            // 'v27' => $v27,
            'v28' => $v28,
            'v29' => $v29,
            'v30' => $v30,

            'v31' => $v31,
            'v32' => $v32,
            'v33' => $v33,
            'v34' => $v34,
            'v35' => $v35,
            'v36' => $v36,
            'v37' => $v37,
            'v38' => $v38,
            'v39' => $v39,
            'v40' => $v40,

            'v41' => $v41,
            'v42' => $v42,
            'v43' => $v43,
            'v44' => $v44,
            'v45' => $v45,
            'v46' => $v46,
            'v47' => $v47,
            'v48' => $v48,
            'v49' => $v49,
            'v50' => $v50,

            'v51' => $v51,
            'v52' => $v52,
            // 'v53' => $v53,
            'v54' => $v54,
            'v55' => $v55,
            'v56' => $v56,
            'v57' => $v57,
            'v58' => $v58,
            'v59' => $v59,
            'v60' => $v60,

            'v61' => $v61,
            'v62' => $v62,
            'v63' => $v63,
            'v64' => $v64,
            'v65' => $v65,
            'v66' => $v66,
            'v67' => $v67,
            'v68' => $v68,
            'v69' => $v69,
            'v70' => $v70,

            'v71' => $v71,
            // 'v72' => $v72,
            'v73' => $v73,
            // 'v74' => $v74,
            'v75' => $v75,

            'v76' => $v76,
            'v77' => $v77,
            'v78' => $v78,

            'v79' => $v79,

            'vu' => 0,
            'fait' => $fait,
            'par' => 'form',
        ]); 

        // update catalogFormOptions
        $cases = array("v72", "v74", "v27", "v53");
        foreach ($cases as $case) {
            DB::table('catalogFormOptions')->where('sale', $id)->where('case', $case)->delete();
            $options=$req->input($case);
            if($options) { 
                for ($i=0; $i <count($options) ; $i++) { 
                    DB::table('catalogFormOptions')->insert( ['sale' => $id, 'case' => $case, 'val' => $options[$i] ] );
                }
            }
        }  

        session()->flash('yes',"Informations has been successfully saved");
        return redirect()->route('catalogFormPrint', ['ref'=>$id ]);
        
    }

    // get pdf formulaire
    public function catalogFormPrint($ref)
    {   

        for ($i=1;$i<=79;$i++) {
          $vardyn = "v".$i;
          $$vardyn = DB::table('catalogForm')->where('cli', $ref)->value($vardyn);
        }

        $client = DB::table('catalogForm')->where('ref', $ref)->value('v76')." ".DB::table('catalogForm')->where('ref', $ref)->value('v77')." ".DB::table('catalogForm')->where('ref', $ref)->value('v78');

        $options = DB::table('catalogFormOptions')->where('sale', $ref)->get();

        $pdf = \PDF::loadView('catalogFormPrint', ['client' => $client, 'ref' => $ref,  'options' => $options, 
        'v1' => $v1,
                'v2' => $v2,
                'v3' => $v3,
                'v4' => $v4,
                'v5' => $v5,
                'v6' => $v6,
                'v7' => $v7,
                'v8' => $v8,
                'v9' => $v9,
                'v10' => $v10,

                'v11' => $v11,
                'v12' => $v12,
                'v13' => $v13,
                'v14' => $v14,
                'v15' => $v15,
                'v16' => $v16,
                'v17' => $v17,
                'v18' => $v18,
                'v19' => $v19,
                'v20' => $v20,

                'v21' => $v21,
                'v22' => $v22,
                'v23' => $v23,
                'v24' => $v24,
                'v25' => $v25,
                'v26' => $v26,
                'v27' => $v27,
                'v28' => $v28,
                'v29' => $v29,
                'v30' => $v30,

                'v31' => $v31,
                'v32' => $v32,
                'v33' => $v33,
                'v34' => $v34,
                'v35' => $v35,
                'v36' => $v36,
                'v37' => $v37,
                'v38' => $v38,
                'v39' => $v39,
                'v40' => $v40,

                'v41' => $v41,
                'v42' => $v42,
                'v43' => $v43,
                'v44' => $v44,
                'v45' => $v45,
                'v46' => $v46,
                'v47' => $v47,
                'v48' => $v48,
                'v49' => $v49,
                'v50' => $v50,

                'v51' => $v51,
                'v52' => $v52,
                'v53' => $v53,
                'v54' => $v54,
                'v55' => $v55,
                'v56' => $v56,
                'v57' => $v57,
                'v58' => $v58,
                'v59' => $v59,
                'v60' => $v60,

                'v61' => $v61,
                'v62' => $v62,
                'v63' => $v63,
                'v64' => $v64,
                'v65' => $v65,
                'v66' => $v66,
                'v67' => $v67,
                'v68' => $v68,
                'v69' => $v69,
                'v70' => $v70,

                'v71' => $v71,
                'v72' => $v72,
                'v73' => $v73,
                'v74' => $v74,
                'v75' => $v75,

                'v76' => $v76,
                'v77' => $v77,
                'v78' => $v78,

                'v79' => $v79,

             ]);

        
        return $pdf->stream();
    }


}
