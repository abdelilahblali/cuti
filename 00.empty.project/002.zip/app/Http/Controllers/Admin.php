<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use auth;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

use  App\Mail\Notification;
use  App\Mail\Rendezvous;
use  App\Mail\Notif;
use  App\Mail\NotifInvoices;
use PDF;
use Illuminate\Support\Facades\Route;

use \Statickidz\GoogleTranslate;

class Admin extends Controller
{
    /**
    * Create a new controller instance.
    *
    * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
    * Show the application dashboardboard.
    *
    * @return \Illuminate\Contracts\Support\Renderable
    */

    // myAccount
    public function myAccount()
    {   
        return view('myAccount');
    }

    public function myAccountUpdated(Request $req)
    {
        if ($req->input('pas2') == $req->input('pas1')) {
        DB::table('clis')
        ->where('username', Auth::user()->username)  
        ->update(['password' => Hash::make($req->input('pas1')) ]);  
        session()->flash('yes',"Le mot de passe a été changé avec succès");
        return back(); 
        }   else {
        session()->flash('no',"Les mots de passe ne sont pas les mêmes!");
        return back();
        }
    }   


    // emails
    public function emails()
    {   
        $emails = DB::table('emails')
        ->orderBy('fait', 'desc')
        ->get();
        return view('emails', [ 'emails'=>$emails, ]);
    }

    // add emails
    public function emailsAdded(Request $req)
    {
        
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
        $fait=date("Y/m/d H:i:s");

        $mail = $req->input('mail');

        DB::table('emails')
        ->insert([
            'ref' => $id,
            'mail' => $mail,
            'par' => Auth::user()->ref,
        ]); 
        session()->flash('Validation',"Email has been successfully added");
        return back();
    }

    // valide
    public function emailsValid($ref, $tache, $valid)
    {
        DB::table("emails")->where('ref', $ref)->update([ $tache => $valid,  ]);
        return back();
    }





    // get pdf formulaire
    public function catalog($cli)
    {   
        $ref = $cli;

        for ($i=1;$i<=75;$i++) {
          $vardyn = "v".$i;
          $$vardyn = DB::table('form')->where('cli', $ref)->value($vardyn);
        }

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        $pdf = \PDF::loadView('catalog', ['client' => $client, 'ref' => $ref, 
        'v1' => $v1,
                'v2' => $v2,
                'v3' => $v3,
                'v4' => $v4,
                'v5' => $v5,
                'v6' => $v6,
                'v7' => $v7,
                'v8' => $v8,
                'v9' => $v9,
                'v10' => $v10,

                'v11' => $v11,
                'v12' => $v12,
                'v13' => $v13,
                'v14' => $v14,
                'v15' => $v15,
                'v16' => $v16,
                'v17' => $v17,
                'v18' => $v18,
                'v19' => $v19,
                'v20' => $v20,

                'v21' => $v21,
                'v22' => $v22,
                'v23' => $v23,
                'v24' => $v24,
                'v25' => $v25,
                'v26' => $v26,
                'v27' => $v27,
                'v28' => $v28,
                'v29' => $v29,
                'v30' => $v30,

                'v31' => $v31,
                'v32' => $v32,
                'v33' => $v33,
                'v34' => $v34,
                'v35' => $v35,
                'v36' => $v36,
                'v37' => $v37,
                'v38' => $v38,
                'v39' => $v39,
                'v40' => $v40,

                'v41' => $v41,
                'v42' => $v42,
                'v43' => $v43,
                'v44' => $v44,
                'v45' => $v45,
                'v46' => $v46,
                'v47' => $v47,
                'v48' => $v48,
                'v49' => $v49,
                'v50' => $v50,

                'v51' => $v51,
                'v52' => $v52,
                'v53' => $v53,
                'v54' => $v54,
                'v55' => $v55,
                'v56' => $v56,
                'v57' => $v57,
                'v58' => $v58,
                'v59' => $v59,
                'v60' => $v60,

                'v61' => $v61,
                'v62' => $v62,
                'v63' => $v63,
                'v64' => $v64,
                'v65' => $v65,
                'v66' => $v66,
                'v67' => $v67,
                'v68' => $v68,
                'v69' => $v69,
                'v70' => $v70,

                'v71' => $v71,
                'v72' => $v72,
                'v73' => $v73,
                'v74' => $v74,
                'v75' => $v75,
             ]);

        
        return $pdf->stream();
    }

    // notifications
    public function notifications($cli)
    {
        $notifications = DB::table('notification')
        ->where('cli', $cli)
        ->where('par', '00000000')
        ->orderBy('fait','desc')
        ->get();

        $client = DB::table('clis')
        ->where('ref', $cli)
        ->value("nom");

        return view('notifications', ['notifications'=>$notifications, 'client'=>$client, ]);
    }

    public function passportAdded(Request $req)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");

        // Add in database Sales (Clients)
        $sale = DB::connection('mysql2')->table('ventes')
        ->where('cod', Auth::user()->code)
        ->value('ref');

        DB::connection('mysql2')->table('clients')->insert([
            'ref' => $ref, 
            'vente' => $sale, 

            'civ' => $req->input('civ'),
            'nom' => $req->input('nom'),
            'pre' => $req->input('pre'),
            'mail' => $req->input('mail'),
            'phone' => $req->input('phone'),
            'nationality' => $req->input('nationality'),
            'passport' => "",

            'cli1' => $req->input('adr'),
            'cli2' => $req->input('nai1'),
            'cli3' => $req->input('nai2'),
            'cli4' => $req->input('number'),

            'pos' => $req->input('pos'),
            'part' => $req->input('part'),
            'val' => $req->input('val'),
            'act' => 0,

            'whatsapp' => $req->input('whatsapp'),
            'mere' => $req->input('mere'),
            'fiscal' => $req->input('fiscal'),

            'fait' => $fait,
            'par' => Auth::user()->ref
            ]
        );



        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        $passport = "";
        // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $passport=array();
        if($files=$req->file('passport')){
            foreach($files as $file){
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('passport')->put("PSPR".$id.'.'.$extension,  File::get($file));
                $passport = "PSPR".$id.'.'.$extension;
                DB::connection('mysql2')->table('clients')->where('ref', $ref)->update([ 'passport' => $passport,  ]); 
            }
        }

        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        $tin = "";
        // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $tin=array();
        if($files=$req->file('tin')){
            foreach($files as $file){
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('passport')->put("TIN".$id.'.'.$extension,  File::get($file));
                $tin = "TIN".$id.'.'.$extension;
                DB::connection('mysql2')->table('clients')->where('ref', $ref)->update([ 'tin' => $tin,  ]); 
            }
        }
        

        // Send Notification to Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        $emails = getEmails('ptpma1');
        $code = auth::user()->code;
        $msg = $code." - PTPMA : Passport has been added."; $page="ptpma";  $emails = getEmails('adm1');
        $langue = "FR";
        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  

        session()->flash('yes',"Informations enregistrées");
        return back();
    }

    // Passport Delete
    public function passportDelete(Request $req, $ref )
    {
        DB::connection('mysql2')->table('clients')->where('ref', $ref)->delete();
        session()->flash('yes',"Le passeport a été supprimé avec succés");
        return back();
    }





    public function documentation()
    {   
        return view('documentation');
    }

    
    public function rendezvous()
    {   
        // Send Notification to Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        $emails = getEmails('rdv');
        $code = auth::user()->code;
        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Rendezvous("") ); } } }  

        session()->flash('yes',"Votre demande a été envoyé avec succés");
        return back();
    }


    // days
    public function days($typ)
    {
        $days = DB::table('days')
        ->where('typ', $typ)
        ->orderBy('dat','desc')
        ->get();

        return view('days', ['days'=>$days, 'typ'=>$typ, ]);
    }

    // add Days
    public function daysAdd(Request $req)
    {
        
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
        $fait=date("Y/m/d H:i:s");

        $typ = $req->input('typ');
        $dat = $req->input('dat');
        $des = $req->input('des');

        DB::table('days')
        ->insert([
            'ref' => $id,
            'typ' => $typ,
            'dat' => $dat,
            'des' => $des,
            'fait' => $fait,
            'par' => Auth::user()->ref,
        ]); 
        session()->flash('Validation',"Day has been successfully updated");
        return back();
    }

    // days Delete
    public function daysDelete(Request $req, $ref )
    {
        DB::table('days')->where('ref', $ref)->delete();
        session()->flash('Validation',"Day has been successfully deleted");
        return back();
    }

    // dashboard
    public function dashboard()
    {
        $pics = DB::table('cli_pic')
        ->where('cli', Auth::user()->ref)
        ->orderBy('dat','desc')
        ->limit(6)
        ->get();

        $etape=1;
        $ref = Auth::user()->ref;
        $code = Auth::user()->code;

        // 1
        $admin = DB::table('administration')->where('type', "reservation2")->where('cli', $ref)->count();
        if($admin!=0 )
        { $etape=1; }

        // 2
        $a2 = DB::table('factures')->where('cli', $ref)->value("a2");
        if($a2!="" )
        { $etape=2; }

        // 3
        $a3 = DB::table('factures')->where('cli', $ref)->value("a3");
        if($a3!="" )
        { $etape=3; }

        // 4
        $a4 = DB::table('factures')->where('cli', $ref)->value("a3");
        if($a3!="" )
        { $etape=4; }

        // 5
        $a5 = DB::connection('mysql2')->table('lands')->rightjoin('ventes', 'ventes.ref', '=', 'lands.vente')->where('cod', $code)->value('landname'); 
        if($a5!="" )
        { $etape=5; }

        // 6
        $a6 = DB::table('land')->where('type', "reservation2")->where('cli', $ref)->count();
        if($a6!="" )
        { $etape=6; }

        // 7
        $a7 = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('salevillaname'); 
        if($a7!="" )
        { $etape=7; }

        // 8
        $a8 = DB::table('factures')->where('cli', $ref)->value("b2");
        if($a8!="" )
        { $etape=8; }

        // 9
        $a9 = DB::table('ptpma')->where('type', "acte2")->where('cli', $ref)->count();
        if($a9!="" )
        { $etape=9; }

        // 10
        $a10 = DB::table('factures')->where('cli', $ref)->value("b3");
        if($a10!="" )
        { $etape=10; }

        // 11
        $a11 = DB::table('land')->where('type', "construction2")->where('cli', $ref)->count();
        if($a11!="" )
        { $etape=11; }

        // 12
        $a12 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('send_catalog'); 
        if($a12!="" )
        { $etape=12; }

        // 13
        $a13 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('get_catalog'); 
        if($a13!="" )
        { $etape=13; }

        // 14
        $a14 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('d1'); 
        if($a14!="")
        { $etape=14; }

        // 15
        $a15 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('d2'); 
        if($a15!="")
        { $etape=15; }

        // 16
        $a16 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('d3'); 
        if($a16!="")
        { $etape=16; }

        // 17
        $a17 = DB::table('administration')->where('type', "terrain2")->where('cli', $ref)->count();
        if($a17!="")
        { $etape=17; }

        // 18
        $a18 = DB::table('administration')->where('type', "terrain")->where('cli', $ref)->count();
        if($a18!="")
        { $etape=18; }

        // 19
        $a19 = DB::table('administration')->where('type', "construction2")->where('cli', $ref)->count();
        if($a19!="")
        { $etape=19; }

        // 20
        $a20 = DB::table('factures')->where('cli', $ref)->value("c2");
        if($a20!="")
        { $etape=20; }

        // 21
        $a21 = DB::table('factures')->where('cli', $ref)->value("c3");
        if($a21!="")
        { $etape=21; }

        // 22
        $a22 = DB::table('cli_pic')->where('cli', $ref)->count();
        if($a22!=0)
        { $etape=22; }

        // 23
        $a23 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp12');
        if($a23!="")
        { $etape=23; }

        // 24
        $a24 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp21');
        if($a24!="")
        { $etape=24; }

        // 25
        $a25 = DB::table('factures')->where('cli', $ref)->value("d2");
        if($a25!="")
        { $etape=25; }

        // 26
        $a26 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp31');
        if($a26!="")
        { $etape=26; }

        // 27
        $a27 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp32');
        if($a27!="")
        { $etape=27; }

        // 28
        $a28 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('meet');
        if($a28!="")
        { $etape=28; }

        // 29
        $a29 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp4');
        if($a29!="")
        { $etape=29; }

        // 30
        $a30 = DB::table('factures')->where('cli', $ref)->value("e2");
        if($a30!="")
        { $etape=30; }

        // 31
        $a31 = DB::table('factures')->where('cli', $ref)->value("e3");
        if($a31!="")
        { $etape=31; }

        // 32
        $a32 = DB::connection('mysql2')->table('worksite')->rightjoin('ventes', 'ventes.ref', '=', 'worksite.vente')->where('cod', $code)->value("a36");
        if($a32!="")
        { $etape=32; }

        // 33
        $a33 = DB::table('factures')->where('cli', $ref)->value("f2");
        if($a33!="")
        { $etape=33; }

        // 34
        $a34 = DB::connection('mysql2')->table('worksite')->rightjoin('ventes', 'ventes.ref', '=', 'worksite.vente')->where('cod', $code)->value("a56");
        if($a34!="")
        { $etape=34; }

        // 35
        $a35 = DB::table('factures')->where('cli', $ref)->value("f3");
        if($a35!="")
        { $etape=35; }

        // 36
        $a36 = DB::connection('mysql2')->table('worksite')->rightjoin('ventes', 'ventes.ref', '=', 'worksite.vente')->where('cod', $code)->value("mise");
        if($a36!="")
        { $etape=36; }








    

        // // 1
        // $admin = DB::table('administration')->where('type', "reservation2")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 )
        // { $etape=1; }

        // // 2
        // $a2 = DB::table('factures')->where('cli', Auth::user()->ref)->value("a2");
        // if($admin!=0 && $a2!="" )
        // { $etape=2; }

        // // 3
        // $a3 = DB::table('factures')->where('cli', Auth::user()->ref)->value("a3");
        // if($admin!=0 && $a2!="" && $a3!="" )
        // { $etape=3; }

        // // 4
        // $a4 = DB::table('factures')->where('cli', Auth::user()->ref)->value("a3");
        // if($admin!=0 && $a2!="" && $a3!="" )
        // { $etape=4; }

        // // 5
        // $a5 = DB::connection('mysql2')->table('lands')->where('ref', Auth::user()->ref)->value('landname'); 
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" )
        // { $etape=5; }

        // // 6
        // $a6 = DB::table('land')->where('type', "reservation2")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" )
        // { $etape=6; }

        // // 7
        // $a7 = DB::connection('mysql2')->table('ventes')->where('ref', Auth::user()->ref)->value('salevillaname'); 
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" )
        // { $etape=7; }

        // // 8
        // $a8 = DB::table('factures')->where('cli', Auth::user()->ref)->value("b2");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" )
        // { $etape=8; }

        // // 9
        // $a9 = DB::table('ptpma')->where('type', "acte2")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" )
        // { $etape=9; }

        // // 10
        // $a10 = DB::table('factures')->where('cli', Auth::user()->ref)->value("b3");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" )
        // { $etape=10; }

        // // 11
        // $a11 = DB::table('land')->where('type', "construction2")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" )
        // { $etape=11; }

        // // 12
        // $a12 = DB::connection('mysql2')->table('architecture')->where('ref', Auth::user()->ref)->value('send_catalog'); 
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" )
        // { $etape=12; }

        // // 13
        // $a13 = DB::connection('mysql2')->table('architecture')->where('ref', Auth::user()->ref)->value('get_catalog'); 
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" )
        // { $etape=13; }

        // // 14
        // $a14 = DB::table('design')->where('d', 1)->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="")
        // { $etape=14; }

        // // 15
        // $a15 = DB::table('design')->where('d', 2)->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="")
        // { $etape=15; }

        // // 16
        // $a16 = DB::table('design')->where('d', 3)->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="")
        // { $etape=16; }

        // // 17
        // $a17 = DB::table('administration')->where('type', "terrain2")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="")
        // { $etape=17; }

        // // 18
        // $a18 = DB::table('administration')->where('type', "terrain")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="")
        // { $etape=18; }

        // // 19
        // $a19 = DB::table('administration')->where('type', "construction2")->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="")
        // { $etape=19; }

        // // 20
        // $a20 = DB::table('factures')->where('cli', Auth::user()->ref)->value("c2");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="")
        // { $etape=20; }

        // // 21
        // $a21 = DB::table('factures')->where('cli', Auth::user()->ref)->value("c3");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="")
        // { $etape=21; }

        // // 22
        // $a22 = DB::table('cli_pic')->where('cli', Auth::user()->ref)->count();
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0)
        // { $etape=22; }

        // // 23
        // $a23 = DB::connection('mysql2')->table('progress')->where('ref', Auth::user()->ref)->value('dp12');
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="")
        // { $etape=23; }

        // // 24
        // $a24 = DB::connection('mysql2')->table('progress')->where('ref', Auth::user()->ref)->value('dp21');
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="")
        // { $etape=24; }

        // // 25
        // $a25 = DB::table('factures')->where('cli', Auth::user()->ref)->value("d2");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="")
        // { $etape=25; }

        // // 26
        // $a26 = DB::connection('mysql2')->table('progress')->where('ref', Auth::user()->ref)->value('dp31');
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="")
        // { $etape=26; }

        // // 27
        // $a27 = DB::connection('mysql2')->table('progress')->where('ref', Auth::user()->ref)->value('dp32');
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="")
        // { $etape=27; }

        // // 28
        // $a28 = DB::connection('mysql2')->table('architecture')->where('ref', Auth::user()->ref)->value('meet');
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="")
        // { $etape=28; }

        // // 29
        // $a29 = DB::connection('mysql2')->table('progress')->where('ref', Auth::user()->ref)->value('dp4');
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="")
        // { $etape=29; }

        // // 30
        // $a30 = DB::table('factures')->where('cli', Auth::user()->ref)->value("e2");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="")
        // { $etape=30; }

        // // 31
        // $a31 = DB::table('factures')->where('cli', Auth::user()->ref)->value("e3");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="" && $a31!="")
        // { $etape=31; }

        // // 32
        // $a32 = DB::connection('mysql2')->table('worksite')->where('ref', Auth::user()->ref)->value("a36");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="" && $a31!="" && $a32!="")
        // { $etape=32; }

        // // 33
        // $a33 = DB::table('factures')->where('cli', Auth::user()->ref)->value("f2");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="" && $a31!="" && $a32!="" && $a33!="")
        // { $etape=33; }

        // // 34
        // $a34 = DB::connection('mysql2')->table('worksite')->where('ref', Auth::user()->ref)->value("a56");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="" && $a31!="" && $a32!="" && $a33!="" && $a34!="")
        // { $etape=34; }

        // // 35
        // $a35 = DB::table('factures')->where('cli', Auth::user()->ref)->value("f3");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="" && $a31!="" && $a32!="" && $a33!="" && $a34!="" && $a35!="")
        // { $etape=35; }

        // // 36
        // $a36 = DB::connection('mysql2')->table('worksite')->where('ref', Auth::user()->ref)->value("mise");
        // if($admin!=0 && $a2!="" && $a3!="" && $a4!="" && $a5!="" && $a6!="" && $a7!="" && $a8!="" && $a9!="" && $a10!="" && $a11!="" && $a12!="" && $a13!="" && $a14!="" && $a15!="" && $a16!="" && $a17!="" && $a18!="" && $a19!="" && $a20!="" && $a21!="" && $a22!=0 && $a23!="" && $a24!="" && $a25!="" && $a26!="" && $a27!="" && $a28!="" && $a29!="" && $a30!="" && $a31!="" && $a32!="" && $a33!="" && $a34!="" && $a35!="" && $a36!="")
        // { $etape=36; }

        return view('dashboard', [ 'pics' => $pics, 'etape' => $etape ]);
    }

    // dashboard
    public function markAllAsRead()
    {
        DB::table('notification')
        ->where('cli', Auth::user()->ref)
        ->where('par', '!=', Auth::user()->ref)
        ->update([ 'lu' => 1,  ]); 
        return back();
    }

    // invoices
    public function invoices()
    {
        $cli = Auth::user()->ref;

        $a1 = DB::table('factures')->where('cli', $cli)->value("a1");
        $a2 = DB::table('factures')->where('cli', $cli)->value("a2");
        $a3 = DB::table('factures')->where('cli', $cli)->value("a3");
        $a4 = DB::table('factures')->where('cli', $cli)->value("a4");

        $b1 = DB::table('factures')->where('cli', $cli)->value("b1");
        $b2 = DB::table('factures')->where('cli', $cli)->value("b2");
        $b3 = DB::table('factures')->where('cli', $cli)->value("b3");
        $b4 = DB::table('factures')->where('cli', $cli)->value("b4");

        $c1 = DB::table('factures')->where('cli', $cli)->value("c1");
        $c2 = DB::table('factures')->where('cli', $cli)->value("c2");
        $c3 = DB::table('factures')->where('cli', $cli)->value("c3");
        $c4 = DB::table('factures')->where('cli', $cli)->value("c4");

        $d1 = DB::table('factures')->where('cli', $cli)->value("d1");
        $d2 = DB::table('factures')->where('cli', $cli)->value("d2");
        $d3 = DB::table('factures')->where('cli', $cli)->value("d3");
        $d4 = DB::table('factures')->where('cli', $cli)->value("d4");

        $e1 = DB::table('factures')->where('cli', $cli)->value("e1");
        $e2 = DB::table('factures')->where('cli', $cli)->value("e2");
        $e3 = DB::table('factures')->where('cli', $cli)->value("e3");
        $e4 = DB::table('factures')->where('cli', $cli)->value("e4");

        $f1 = DB::table('factures')->where('cli', $cli)->value("f1");
        $f2 = DB::table('factures')->where('cli', $cli)->value("f2");
        $f3 = DB::table('factures')->where('cli', $cli)->value("f3");
        $f4 = DB::table('factures')->where('cli', $cli)->value("f4");

        $g1 = DB::table('factures')->where('cli', $cli)->value("g1");
        $g2 = DB::table('factures')->where('cli', $cli)->value("g2");
        $g3 = DB::table('factures')->where('cli', $cli)->value("g3");
        $g4 = DB::table('factures')->where('cli', $cli)->value("g4");

        $h1 = DB::table('factures')->where('cli', $cli)->value("h1");
        $h2 = DB::table('factures')->where('cli', $cli)->value("h2");
        $h3 = DB::table('factures')->where('cli', $cli)->value("h3");
        $h4 = DB::table('factures')->where('cli', $cli)->value("h4");

        $i1 = DB::table('factures')->where('cli', $cli)->value("i1");
        $i2 = DB::table('factures')->where('cli', $cli)->value("i2");
        $i3 = DB::table('factures')->where('cli', $cli)->value("i3");
        $i4 = DB::table('factures')->where('cli', $cli)->value("i4");

        $j1 = DB::table('factures')->where('cli', $cli)->value("j1");
        $j2 = DB::table('factures')->where('cli', $cli)->value("j2");
        $j3 = DB::table('factures')->where('cli', $cli)->value("j3");
        $j4 = DB::table('factures')->where('cli', $cli)->value("j4");

        $k1 = DB::table('factures')->where('cli', $cli)->value("k1");
        $k2 = DB::table('factures')->where('cli', $cli)->value("k2");
        $k3 = DB::table('factures')->where('cli', $cli)->value("k3");
        $k4 = DB::table('factures')->where('cli', $cli)->value("k4");

        $cur1 = DB::table('factures')->where('cli', $cli)->value("cur1");
        $cur2 = DB::table('factures')->where('cli', $cli)->value("cur2");
        $cur3 = DB::table('factures')->where('cli', $cli)->value("cur3");
        $cur4 = DB::table('factures')->where('cli', $cli)->value("cur4");
        $cur5 = DB::table('factures')->where('cli', $cli)->value("cur5");
        $cur6 = DB::table('factures')->where('cli', $cli)->value("cur6");
        $cur7 = DB::table('factures')->where('cli', $cli)->value("cur7");
        $cur8 = DB::table('factures')->where('cli', $cli)->value("cur8");
        $cur9 = DB::table('factures')->where('cli', $cli)->value("cur9");
        $cur10 = DB::table('factures')->where('cli', $cli)->value("cur10");
        $cur11 = DB::table('factures')->where('cli', $cli)->value("cur11");

        $codeClient = Auth::user()->code;
        $airbnb = DB::connection('mysql2')->table('ventes')
        ->where('cod', $codeClient)
        ->value('airbnb'); 


        return view('invoices', [
            'a1' => $a1, 'a2' => $a2, 'a3' => $a3, 'a4' => $a4,
            'b1' => $b1, 'b2' => $b2, 'b3' => $b3, 'b4' => $b4,
            'c1' => $c1, 'c2' => $c2, 'c3' => $c3, 'c4' => $c4,
            'd1' => $d1, 'd2' => $d2, 'd3' => $d3, 'd4' => $d4,
            'e1' => $e1, 'e2' => $e2, 'e3' => $e3, 'e4' => $e4,
            'f1' => $f1, 'f2' => $f2, 'f3' => $f3, 'f4' => $f4,
            'g1' => $g1, 'g2' => $g2, 'g3' => $g3, 'g4' => $g4,
            'h1' => $h1, 'h2' => $h2, 'h3' => $h3, 'h4' => $h4,
            'i1' => $i1, 'i2' => $i2, 'i3' => $i3, 'i4' => $i4,
            'j1' => $j1, 'j2' => $j2, 'j3' => $j3, 'j4' => $j4,
            'k1' => $k1, 'k2' => $k2, 'k3' => $k3, 'k4' => $k4,
            'cur1' => $cur1, 'cur2' => $cur2, 'cur3' => $cur3, 'cur4' => $cur4, 'cur5' => $cur5, 'cur6' => $cur6, 'cur7' => $cur7, 'cur8' => $cur8, 'cur9' => $cur9, 'cur10' => $cur10, 'cur11' => $cur11,
            'airbnb' => $airbnb
          ]);
    }

    // Delete Proof
    public function deleteProof($inv )
    {
        $cli = Auth::user()->ref;
        if($inv==1) { DB::table('factures')->where('cli', $cli)->update([ 'a4' => '' ]);   }
        if($inv==2) { DB::table('factures')->where('cli', $cli)->update([ 'b4' => '' ]);   }
        if($inv==3) { DB::table('factures')->where('cli', $cli)->update([ 'c4' => '' ]);   }
        if($inv==4) { DB::table('factures')->where('cli', $cli)->update([ 'd4' => '' ]);   }
        if($inv==5) { DB::table('factures')->where('cli', $cli)->update([ 'e4' => '' ]);   }
        if($inv==6) { DB::table('factures')->where('cli', $cli)->update([ 'f4' => '' ]);   }
        if($inv==7) { DB::table('factures')->where('cli', $cli)->update([ 'g4' => '' ]);   }

        if($inv==8) { DB::table('factures')->where('cli', $cli)->update([ 'h4' => '' ]);   }
        if($inv==9) { DB::table('factures')->where('cli', $cli)->update([ 'i4' => '' ]);   }
        if($inv==10) { DB::table('factures')->where('cli', $cli)->update([ 'j4' => '' ]);   }
        if($inv==11) { DB::table('factures')->where('cli', $cli)->update([ 'k4' => '' ]);   }

        session()->flash('Validation',"Operation effectuée");
        return back();
    }

    // Delete Invoice
    public function deleteInvoice($cli, $inv)
    {
        if($inv==1) { DB::table('factures')->where('cli', $cli)->update([ 'a2' => '' ]);   }
        if($inv==2) { DB::table('factures')->where('cli', $cli)->update([ 'b2' => '' ]);   }
        if($inv==3) { DB::table('factures')->where('cli', $cli)->update([ 'c2' => '' ]);   }
        if($inv==4) { DB::table('factures')->where('cli', $cli)->update([ 'd2' => '' ]);   }
        if($inv==5) { DB::table('factures')->where('cli', $cli)->update([ 'e2' => '' ]);   }
        if($inv==6) { DB::table('factures')->where('cli', $cli)->update([ 'f2' => '' ]);   }

        if($inv==7) { DB::table('factures')->where('cli', $cli)->update([ 'g2' => '' ]);   }
        if($inv==8) { DB::table('factures')->where('cli', $cli)->update([ 'h2' => '' ]);   }
        if($inv==9) { DB::table('factures')->where('cli', $cli)->update([ 'i2' => '' ]);   }
        if($inv==10) { DB::table('factures')->where('cli', $cli)->update([ 'j2' => '' ]);   }
        if($inv==11) { DB::table('factures')->where('cli', $cli)->update([ 'k2' => '' ]);   }

        session()->flash('Validation',"File deleted");
        return back();
    }

    // Delete Paid
    public function deletePaid($cli, $inv)
    {
        if($inv==1) { DB::table('factures')->where('cli', $cli)->update([ 'a3' => '' ]);   }
        if($inv==2) { DB::table('factures')->where('cli', $cli)->update([ 'b3' => '' ]);   }
        if($inv==3) { DB::table('factures')->where('cli', $cli)->update([ 'c3' => '' ]);   }
        if($inv==4) { DB::table('factures')->where('cli', $cli)->update([ 'd3' => '' ]);   }
        if($inv==5) { DB::table('factures')->where('cli', $cli)->update([ 'e3' => '' ]);   }
        if($inv==6) { DB::table('factures')->where('cli', $cli)->update([ 'f3' => '' ]);   }

        if($inv==7) { DB::table('factures')->where('cli', $cli)->update([ 'g3' => '' ]);   }
        if($inv==8) { DB::table('factures')->where('cli', $cli)->update([ 'h3' => '' ]);   }
        if($inv==9) { DB::table('factures')->where('cli', $cli)->update([ 'i3' => '' ]);   }
        if($inv==10) { DB::table('factures')->where('cli', $cli)->update([ 'j3' => '' ]);   }
        if($inv==11) { DB::table('factures')->where('cli', $cli)->update([ 'k3' => '' ]);   }

        session()->flash('Validation',"File deleted");
        return back();
    }

    // dashboard
    public function construction()
    {
        $a0 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a0");
        $a1 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a1");
        $a2 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a2");
        $a3 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a3");
        $a4 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a4");
        $a5 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a5");
        $a6 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a6");
        $a7 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a7");
        $a8 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a8");
        $a9 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a9");
        $a10 = DB::table('construction')->where('cli', Auth::user()->ref)->value("a10");

        $pics = DB::table('cli_pic')
        ->select(DB::raw('Date(dat) AS date'))
        ->where('cli', Auth::user()->ref)
        ->groupBy('date')
        ->get();

        $days = DB::table('days')
        ->orderBy('dat','desc')
        ->get();

        $lyouma = date("Y-m-d");
        $z = date("Y-m-d");

        // rain
        if($a1!='') { $z = $a1; } else { $z = $lyouma; }
        if($a2!='') { $z = $a2; } else { $z = $lyouma; }
        if($a3!='') { $z = $a3; } else { $z = $lyouma; }
        if($a4!='') { $z = $a4; } else { $z = $lyouma; }
        if($a5!='') { $z = $a5; } else { $z = $lyouma; }
        if($a6!='') { $z = $a6; } else { $z = $lyouma; }
        if($a7!='') { $z = $a7; } else { $z = $lyouma; }
        if($a8!='') { $z = $a8; } else { $z = $lyouma; }
        if($a9!='') { $z = $a9; } else { $z = $lyouma; }
        if($a10!='') { $z = $a10; } else { $z = $lyouma; }
            
        $days_rai = DB::table('days')->where('typ', 'Rainy days')->whereBetween('dat', [$a0, $z])->count();
        $days_cer = DB::table('days')->where('typ', 'Ceremony days')->whereBetween('dat', [$a0, $z])->count();
        $days_hol = DB::table('days')->where('typ', 'Public Holidays')->whereBetween('dat', [$a0, $z])->count();

        return view('construction', [ 'a0' => $a0, 'a1' => $a1, 'a2' => $a2, 'a3' => $a3, 'a4' => $a4, 'a5' => $a5, 'a6' => $a6, 'a7' => $a7, 'a8' => $a8, 'a9' => $a9, 'a10' => $a10 , 'z' => $z , 'pics' => $pics, 'days' => $days,
        'days_rai' => $days_rai, 'days_cer' => $days_cer, 'days_hol' => $days_hol, ]);
    }

    // getPhotosDay
    public function getPhotosDay($date)
    {
        $d=date("Y-m-d", strtotime($date));
        $pics = DB::table('cli_pic')
        ->where('cli', Auth::user()->ref)
        ->where(DB::raw('Date(dat)'), $d)
        ->orderBy('dat','desc')
        ->paginate(10);

        return view('getPhotosDay', [ 'pics' => $pics, 'date' => $date ]);
    }

    // getPhotosAll
    public function getPhotosAll()
    {
        $pics = DB::table('cli_pic')
        ->where('cli', Auth::user()->ref)
        ->orderBy('dat','desc')
        ->paginate(10);

        return view('getPhotosAll', [ 'pics' => $pics ]);
    }

    // History
    public function historyPics()
    {
        $pics = DB::table('cli_pic')
        ->where('cli', Auth::user()->ref)
        ->where('dat', '<', '2022-01-10 00:00:00')
        ->orderBy('dat','desc')
        ->paginate(10);

        return view('historyPics', [ 'pics' => $pics ]);
    }

    public function historyDocs()
    {
        $ref = Auth::user()->ref;
        $docs = DB::table('clidoc')
        ->where('cli', $ref)
        ->orderBy('fait', 'desc')
        ->get();

        return view('historyDocs', [ 'docs' => $docs ]);
    }


    // clientFolder
    public function clientFolder($ref)
    {
        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        
        // Administration *******************************************

        // reservation 1
        $reservation1 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $reservation2 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $construction1 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $construction2 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $terrain1 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $terrain2 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        // quotation 1
        $quotation1 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "quotation")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $quotation2 = DB::table('administration')
        ->where('cli', $ref)
        ->where('type', "quotation2")
        ->orderBy('fait', 'desc')
        ->get();


        return view('clientFolder', ['client' => $client, 'ref' => $ref, 
            'quotation1' => $quotation1, 'quotation2' => $quotation2, 
            'reservation1' => $reservation1, 'reservation2' => $reservation2, 'construction1' => $construction1, 'construction2' => $construction2, 'terrain1' => $terrain1, 'terrain2' => $terrain2, 
             ]);
    }

    // clientFolder_factures
    public function clientFolder_factures($ref)
    {
        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        // reservation 1
        $a1 = DB::table('factures')->where('cli', $ref)->value("a1");
        $a2 = DB::table('factures')->where('cli', $ref)->value("a2");
        $a3 = DB::table('factures')->where('cli', $ref)->value("a3");
        $a4 = DB::table('factures')->where('cli', $ref)->value("a4");

        $b1 = DB::table('factures')->where('cli', $ref)->value("b1");
        $b2 = DB::table('factures')->where('cli', $ref)->value("b2");
        $b3 = DB::table('factures')->where('cli', $ref)->value("b3");
        $b4 = DB::table('factures')->where('cli', $ref)->value("b4");

        $c1 = DB::table('factures')->where('cli', $ref)->value("c1");
        $c2 = DB::table('factures')->where('cli', $ref)->value("c2");
        $c3 = DB::table('factures')->where('cli', $ref)->value("c3");
        $c4 = DB::table('factures')->where('cli', $ref)->value("c4");

        $d1 = DB::table('factures')->where('cli', $ref)->value("d1");
        $d2 = DB::table('factures')->where('cli', $ref)->value("d2");
        $d3 = DB::table('factures')->where('cli', $ref)->value("d3");
        $d4 = DB::table('factures')->where('cli', $ref)->value("d4");

        $e1 = DB::table('factures')->where('cli', $ref)->value("e1");
        $e2 = DB::table('factures')->where('cli', $ref)->value("e2");
        $e3 = DB::table('factures')->where('cli', $ref)->value("e3");
        $e4 = DB::table('factures')->where('cli', $ref)->value("e4");

        $f1 = DB::table('factures')->where('cli', $ref)->value("f1");
        $f2 = DB::table('factures')->where('cli', $ref)->value("f2");
        $f3 = DB::table('factures')->where('cli', $ref)->value("f3");
        $f4 = DB::table('factures')->where('cli', $ref)->value("f4");

        $g1 = DB::table('factures')->where('cli', $ref)->value("g1");
        $g2 = DB::table('factures')->where('cli', $ref)->value("g2");
        $g3 = DB::table('factures')->where('cli', $ref)->value("g3");
        $g4 = DB::table('factures')->where('cli', $ref)->value("g4");

        $h1 = DB::table('factures')->where('cli', $ref)->value("h1");
        $h2 = DB::table('factures')->where('cli', $ref)->value("h2");
        $h3 = DB::table('factures')->where('cli', $ref)->value("h3");
        $h4 = DB::table('factures')->where('cli', $ref)->value("h4");

        $i1 = DB::table('factures')->where('cli', $ref)->value("i1");
        $i2 = DB::table('factures')->where('cli', $ref)->value("i2");
        $i3 = DB::table('factures')->where('cli', $ref)->value("i3");
        $i4 = DB::table('factures')->where('cli', $ref)->value("i4");

        $j1 = DB::table('factures')->where('cli', $ref)->value("j1");
        $j2 = DB::table('factures')->where('cli', $ref)->value("j2");
        $j3 = DB::table('factures')->where('cli', $ref)->value("j3");
        $j4 = DB::table('factures')->where('cli', $ref)->value("j4");

        $k1 = DB::table('factures')->where('cli', $ref)->value("k1");
        $k2 = DB::table('factures')->where('cli', $ref)->value("k2");
        $k3 = DB::table('factures')->where('cli', $ref)->value("k3");
        $k4 = DB::table('factures')->where('cli', $ref)->value("k4");

        $cur1 = DB::table('factures')->where('cli', $ref)->value("cur1");
        $cur2 = DB::table('factures')->where('cli', $ref)->value("cur2");
        $cur3 = DB::table('factures')->where('cli', $ref)->value("cur3");
        $cur4 = DB::table('factures')->where('cli', $ref)->value("cur4");
        $cur5 = DB::table('factures')->where('cli', $ref)->value("cur5");
        $cur6 = DB::table('factures')->where('cli', $ref)->value("cur6");
        $cur7 = DB::table('factures')->where('cli', $ref)->value("cur7");
        $cur8 = DB::table('factures')->where('cli', $ref)->value("cur8");
        $cur9 = DB::table('factures')->where('cli', $ref)->value("cur9");
        $cur10 = DB::table('factures')->where('cli', $ref)->value("cur10");
        $cur11 = DB::table('factures')->where('cli', $ref)->value("cur11");

        $codeClient = DB::table('clis')->where('ref', $ref)->value('code');
        $airbnb = DB::connection('mysql2')->table('ventes')
        ->where('cod', $codeClient)
        ->value('airbnb'); 


        return view('clientFolder_factures', ['client' => $client, 'ref' => $ref,
            'a1' => $a1, 'a2' => $a2, 'a3' => $a3, 'a4' => $a4,
            'b1' => $b1, 'b2' => $b2, 'b3' => $b3, 'b4' => $b4,
            'c1' => $c1, 'c2' => $c2, 'c3' => $c3, 'c4' => $c4,
            'd1' => $d1, 'd2' => $d2, 'd3' => $d3, 'd4' => $d4,
            'e1' => $e1, 'e2' => $e2, 'e3' => $e3, 'e4' => $e4,
            'f1' => $f1, 'f2' => $f2, 'f3' => $f3, 'f4' => $f4,
            'g1' => $g1, 'g2' => $g2, 'g3' => $g3, 'g4' => $g4,
            'h1' => $h1, 'h2' => $h2, 'h3' => $h3, 'h4' => $h4,
            'i1' => $i1, 'i2' => $i2, 'i3' => $i3, 'i4' => $i4,
            'j1' => $j1, 'j2' => $j2, 'j3' => $j3, 'j4' => $j4,
            'k1' => $k1, 'k2' => $k2, 'k3' => $k3, 'k4' => $k4,
            'cur1' => $cur1, 'cur2' => $cur2, 'cur3' => $cur3, 'cur4' => $cur4, 'cur5' => $cur5, 'cur6' => $cur6, 'cur7' => $cur7, 'cur8' => $cur8, 'cur9' => $cur9, 'cur10' => $cur10, 'cur11' => $cur11,
            'airbnb' => $airbnb
          ]);
    }

    // clientFolder Construction
    public function clientFolder_factures_updated(Request $req)
    {
        $cli = $req->input('cli');
        $nb = DB::table('factures')->where('cli', $cli)->count();

        $codeClient = DB::table('clis')->where('ref', $cli)->value("code");

        $a1 = $req->input('a1');
        $b1 = $req->input('b1');
        $c1 = $req->input('c1');
        $d1 = $req->input('d1');
        $e1 = $req->input('e1');
        $f1 = $req->input('f1');
        $g1 = $req->input('g1');
        $h1 = $req->input('h1');
        $i1 = $req->input('i1');
        $j1 = $req->input('j1');
        $k1 = $req->input('k1');

        $cur1 = $req->input('cur1');
        $cur2 = $req->input('cur2');
        $cur3 = $req->input('cur3');
        $cur4 = $req->input('cur4');
        $cur5 = $req->input('cur5');
        $cur6 = $req->input('cur6');
        $cur7 = $req->input('cur7');
        $cur8 = $req->input('cur8');
        $cur9 = $req->input('cur9');
        $cur10 = $req->input('cur10');
        $cur11 = $req->input('cur11');

        if($nb==0) { 
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
            $fait=date("Y/m/d H:i:s");

            DB::table('factures')
            ->insert([
                'ref' => $id,
                'cli' => $cli,

                'a1' => $a1,
                'b1' => $b1,
                'c1' => $c1,
                'd1' => $d1,
                'e1' => $e1,
                'f1' => $f1,
                'g1' => $g1,
                'h1' => $h1,
                'i1' => $i1,
                'j1' => $j1,
                'k1' => $k1,

                'cur1' => $cur1,
                'cur2' => $cur2,
                'cur3' => $cur3,
                'cur4' => $cur4,
                'cur5' => $cur5,
                'cur6' => $cur6,
                'cur7' => $cur7,
                'cur8' => $cur8,
                'cur9' => $cur9,
                'cur10' => $cur10,
                'cur11' => $cur11,

                'fait' => $fait,
                'par' => Auth::user()->ref,
            ]); 

            // a2
            if($files=$req->file('a2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $a2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'a2' => $a2 ]);  } } 

            // a3
            if($files=$req->file('a3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $a3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'a3' => $a3 ]);  } } 
            
            // b2
            if($files=$req->file('b2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $b2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'b2' => $b2 ]);  } } 

            // b3
            if($files=$req->file('b3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $b3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'b3' => $b3 ]);  } } 

            // c2
            if($files=$req->file('c2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $c2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'c2' => $c2 ]);  } } 

            // c3
            if($files=$req->file('c3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $c3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'c3' => $c3 ]);  } } 

            // d2
            if($files=$req->file('d2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $d2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'd2' => $d2 ]);  } } 

            // d3
            if($files=$req->file('d3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $d3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'd3' => $d3 ]);  } } 

            // e2
            if($files=$req->file('e2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $e2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'e2' => $e2 ]);  } } 

            // e3
            if($files=$req->file('e3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $e3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'e3' => $e3 ]);  } } 

            // f2
            if($files=$req->file('f2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $f2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'f2' => $f2 ]);  } } 

            // f3
            if($files=$req->file('f3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $f3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'f3' => $f3 ]);  } }

            // g2
            if($files=$req->file('g2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $g2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'g2' => $g2 ]);  } } 

            // g3
            if($files=$req->file('g3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $g3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'g3' => $g3 ]);  } }

            // h2
            if($files=$req->file('h2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $h2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'h2' => $h2 ]);  } } 

            // h3
            if($files=$req->file('h3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $h3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'h3' => $h3 ]);  } }

            // i2
            if($files=$req->file('i2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $i2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'i2' => $i2 ]);  } } 

            // i3
            if($files=$req->file('i3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $i3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'i3' => $i3 ]);  } }

            // j2
            if($files=$req->file('j2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $j2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'j2' => $j2 ]);  } } 

            // j3
            if($files=$req->file('j3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $j3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'j3' => $j3 ]);  } }

            // k2
            if($files=$req->file('k2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $k2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'k2' => $k2 ]);  } } 

            // k3
            if($files=$req->file('k3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $k3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'k3' => $k3 ]);  } }
            
        } else {
            $url = $req->input('url');
            $id = DB::table('factures')->where('cli', $cli)->value('ref');
            $fait=date("Y/m/d H:i:s");

            DB::table('factures')->where('ref', $id)->update([ 
                'a1' => $a1,
                'b1' => $b1,
                'c1' => $c1,
                'd1' => $d1,
                'e1' => $e1,
                'f1' => $f1,
                'g1' => $g1,
                'h1' => $h1,
                'i1' => $i1,
                'j1' => $j1,
                'k1' => $k1,

                'cur1' => $cur1,
                'cur2' => $cur2,
                'cur3' => $cur3,
                'cur4' => $cur4,
                'cur5' => $cur5,
                'cur6' => $cur6,
                'cur7' => $cur7,
                'cur8' => $cur8,
                'cur9' => $cur9,
                'cur10' => $cur10,
                'cur11' => $cur11,
            ]); 

            // a2
            if($files=$req->file('a2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $a2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'a2' => $a2 ]);  } } 

            // a3
            if($files=$req->file('a3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $a3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'a3' => $a3 ]);  } } 

            // b2
            if($files=$req->file('b2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $b2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'b2' => $b2 ]);  } } 

            // b3
            if($files=$req->file('b3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $b3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'b3' => $b3 ]);  } } 

            // c2
            if($files=$req->file('c2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $c2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'c2' => $c2 ]);  } } 

            // c3
            if($files=$req->file('c3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $c3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'c3' => $c3 ]);  } } 

            // d2
            if($files=$req->file('d2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $d2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'd2' => $d2 ]);  } } 

            // d3
            if($files=$req->file('d3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $d3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'd3' => $d3 ]);  } } 

            // e2
            if($files=$req->file('e2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $e2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'e2' => $e2 ]);  } } 

            // e3
            if($files=$req->file('e3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $e3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'e3' => $e3 ]);  } } 

            // f2
            if($files=$req->file('f2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $f2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'f2' => $f2 ]);  } } 

            // f3
            if($files=$req->file('f3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $f3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'f3' => $f3 ]);  } } 

            // g2
            if($files=$req->file('g2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $g2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'g2' => $g2 ]);  } } 

            // g3
            if($files=$req->file('g3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $g3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'g3' => $g3 ]);  } } 

            // h2
            if($files=$req->file('h2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $h2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'h2' => $h2 ]);  } } 

            // h3
            if($files=$req->file('h3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $h3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'h3' => $h3 ]);  } } 

            // i2
            if($files=$req->file('i2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $i2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'i2' => $i2 ]);  } } 

            // i3
            if($files=$req->file('i3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $i3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'i3' => $i3 ]);  } } 

            // j2
            if($files=$req->file('j2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $j2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'j2' => $j2 ]);  } } 

            // j3
            if($files=$req->file('j3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $j3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'j3' => $j3 ]);  } } 

            // k2
            if($files=$req->file('k2')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $k2 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'k2' => $k2 ]);  } } 

            // k3
            if($files=$req->file('k3')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $k3 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('ref', $id)->update([ 'k3' => $k3 ]);  } } 

        }

        // Edit in mysql 2
        if($files=$req->file('a3')){
            DB::connection('mysql2')->table('payment')
            ->rightjoin('ventes', 'ventes.ref', '=', 'payment.vente')
            ->where('cod', $codeClient)
            ->update([ 'five' => "on",  ]); 
        }

        // Edit in mysql 2
        if($files=$req->file('b3')){
            DB::connection('mysql2')->table('payment')
            ->rightjoin('ventes', 'ventes.ref', '=', 'payment.vente')
            ->where('cod', $codeClient)
            ->update([ 'terrain' => "on",  ]); 
        }

        // Edit in mysql 2
        if($files=$req->file('c3')){
            // DB::connection('mysql2')->table('payment')
            // ->rightjoin('ventes', 'ventes.ref', '=', 'payment.vente')
            // ->where('cod', $codeClient)
            // ->update([ 'four1' => "on",  ]); 
        }

        // Edit in mysql 2
        if($files=$req->file('d3')){
            DB::connection('mysql2')->table('payment')
            ->rightjoin('ventes', 'ventes.ref', '=', 'payment.vente')
            ->where('cod', $codeClient)
            ->update([ 'four2' => "on",  ]); 
        }

        // Edit in mysql 2
        if($files=$req->file('e3')){
            DB::connection('mysql2')->table('payment')
            ->rightjoin('ventes', 'ventes.ref', '=', 'payment.vente')
            ->where('cod', $codeClient)
            ->update([ 'v15' => "on",  ]); 
        }

        // Edit in mysql 2
        if($files=$req->file('f3')){
            DB::connection('mysql2')->table('payment')
            ->rightjoin('ventes', 'ventes.ref', '=', 'payment.vente')
            ->where('cod', $codeClient)
            ->update([ 'final' => "on",  ]); 
        }






        // Start Notification #####################################################################################

            // Get Emails Clients ********************************************************************************************************************
            $code = $codeClient;
            $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
            $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
            $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
            $langue = DB::table('clis')->where('code', $code)->value('langue');
            array_push($emails, $email);


            if($files=$req->file('a2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture de ( 5000€ ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifInvoices($msg, $page, $langue, 'a2') ); } } }  
            }

            if($files=$req->file('b2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture de ( Terrain ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifInvoices($msg, $page, $langue, 'b2') ); } } }   
            }

            if($files=$req->file('c2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture de ( 40% 1 ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifInvoices($msg, $page, $langue, 'c2') ); } } }    
            }

            if($files=$req->file('d2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture de ( 40% 2 ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifInvoices($msg, $page, $langue, 'd2') ); } } }  
            }

            if($files=$req->file('e2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture de ( 15% ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifInvoices($msg, $page, $langue, 'e2') ); } } }   
            }

            if($files=$req->file('f2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture de ( 5% ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new NotifInvoices($msg, $page, $langue, 'f2') ); } } }   
            }


            if($files=$req->file('h2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture Extra 1 a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }

            if($files=$req->file('i2')){
                // Variables notification
                $page = "invoices";  $msg="Facture : La facture Extra 2 a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }

            if($files=$req->file('j2')){
                // Variables notification
                $page = "invoices";  $msg="FLa facture Extra 3 a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }

            if($files=$req->file('k2')){
                // Variables notification
                $page = "invoices";  $msg="La facture de la banque a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }





            if($files=$req->file('a3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de ( 5000€ ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('b3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de ( Terrain ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('c3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de ( 40% 1 ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('d3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de ( 40% 2 ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('e3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de ( 15% ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('f3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de ( 5% ) a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('h3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée extra 1 a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('i3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée extra 2 a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('j3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée extra 3 a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('k3')){
                // Variables notification
                $page = "invoices";  $msg="La facture payée de la banque a été ajoutée"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            // End Notification #####################################################################################

            session()->flash('Validation',"Informations has been successfully updated : ".$codeClient);
            return back();

    }

    // clientFolder Construction
    public function clientFolder_factures_updated_byClient(Request $req)
    {
        $cli = $req->input('cli');
        $nb = DB::table('factures')->where('cli', $cli)->count();

        if($nb==1) { 

            // a4
            if($files=$req->file('a4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $a4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'a4' => $a4 ]);  } } 

            // b4
            if($files=$req->file('b4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $b4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'b4' => $b4 ]);  } } 

            // c4
            if($files=$req->file('c4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $c4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'c4' => $c4 ]);  } } 

            // d4
            if($files=$req->file('d4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $d4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'd4' => $d4 ]);  } } 

            // e4
            if($files=$req->file('e4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $e4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'e4' => $e4 ]);  } } 

            // f4
            if($files=$req->file('f4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $f4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'f4' => $f4 ]);  } } 

            // g4
            if($files=$req->file('g4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $g4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'g4' => $g4 ]);  } } 

            // h4
            if($files=$req->file('h4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $h4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'h4' => $h4 ]);  } } 

            // i4
            if($files=$req->file('i4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $i4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'i4' => $i4 ]);  } } 

            // j4
            if($files=$req->file('j4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $j4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'j4' => $j4 ]);  } } 

            // k4
            if($files=$req->file('k4')){
            foreach($files as $file){
            $idFile = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $idFile = $idFile.$b; $extension = $file->getClientOriginalExtension();
            Storage::disk('invoice')->put("Invoice".$idFile.'.'.$extension,  File::get($file));
            $k4 = "Invoice".$idFile.'.'.$extension; 
            DB::table('factures')->where('cli', $cli)->update([ 'k4' => $k4 ]);  } } 


            // Start Notification #####################################################################################
            $fait=date("Y/m/d H:i:s");

            // Get Emails Clients ********************************************************************************************************************
            $code = DB::table("clis")->where('ref', $cli)->value('code');
            $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
            $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
            $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
            array_push($emails, $email);

            $langue = DB::table('clis')->where('code', $code)->value('langue');

            // Function Get Emails Admin
            function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }

            if($files=$req->file('a4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice: Proof Document (Deposit) has been added"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac1'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            if($files=$req->file('b4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice: Proof Document (Land) has been added";
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac2'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            if($files=$req->file('c4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice: Proof Document (40% *1) has been added"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac3'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            if($files=$req->file('d4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice: Proof Document (40% *2) has been added"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac4'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }

            if($files=$req->file('e4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice: Proof Document (15% *1) has been added"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac5'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }

            if($files=$req->file('f4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice: Proof Document (5% *1) has been added"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac6'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }

            if($files=$req->file('k4')){
                // Variables notification
                $page = "invoices";  $msg=$code." - Invoice : Proof Document (Banque) has been added"; 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert( ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Invoice', 'msg' => $msg, 'cat' => "notification", 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 
                // ###### Notification (Email)***************************
                $emails = getEmails('fac6'); 
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            }


            // End Notification #####################################################################################


            session()->flash('Validation',"Informations has been successfully updated");
            return back();
        } 
    }

    // clientFolder_PTPMA
    public function clientFolder_ptpma($ref)
    {
        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        // PTPMA *******************************************

        // reservation 1
        $ptpma_reservation1 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $ptpma_reservation2 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $ptpma_construction1 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $ptpma_construction2 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $ptpma_terrain1 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $ptpma_terrain2 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $ptpma_acte2 = DB::table('ptpma')
        ->where('cli', $ref)
        ->where('type', "acte2")
        ->orderBy('fait', 'desc')
        ->get();

        return view('clientFolder_ptpma', ['client' => $client, 'ref' => $ref,   
            'ptpma_reservation1' => $ptpma_reservation1, 'ptpma_reservation2' => $ptpma_reservation2, 'ptpma_construction1' => $ptpma_construction1, 'ptpma_construction2' => $ptpma_construction2, 'ptpma_terrain1' => $ptpma_terrain1, 'ptpma_terrain2' => $ptpma_terrain2, 'ptpma_acte2' => $ptpma_acte2,
             ]);
    }

    // clientFolder Land
    public function clientFolder_land($ref)
    {
        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        
        // LAND *******************************************

        // reservation 1
        $land_reservation1 = DB::table('land')
        ->where('cli', $ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $land_reservation2 = DB::table('land')
        ->where('cli', $ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $land_construction1 = DB::table('land')
        ->where('cli', $ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $land_construction2 = DB::table('land')
        ->where('cli', $ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $land_terrain1 = DB::table('land')
        ->where('cli', $ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $land_terrain2 = DB::table('land')
        ->where('cli', $ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        return view('clientFolder_land', ['client' => $client, 'ref' => $ref, 
            'land_reservation1' => $land_reservation1, 'land_reservation2' => $land_reservation2, 'land_construction1' => $land_construction1, 'land_construction2' => $land_construction2, 'land_terrain1' => $land_terrain1, 'land_terrain2' => $land_terrain2,
             ]);
    }

    // clientFolder Land
    public function clientFolder_plan($ref)
    {
        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        
        // PLAN *******************************************

        // reservation 1
        $plan_reservation1 = DB::table('plan')
        ->where('cli', $ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $plan_reservation2 = DB::table('plan')
        ->where('cli', $ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $plan_construction1 = DB::table('plan')
        ->where('cli', $ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $plan_construction2 = DB::table('plan')
        ->where('cli', $ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $plan_terrain1 = DB::table('plan')
        ->where('cli', $ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $plan_terrain2 = DB::table('plan')
        ->where('cli', $ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        return view('clientFolder_plan', ['client' => $client, 'ref' => $ref, 
            'plan_reservation1' => $plan_reservation1, 'plan_reservation2' => $plan_reservation2, 'plan_construction1' => $plan_construction1, 'plan_construction2' => $plan_construction2, 'plan_terrain1' => $plan_terrain1, 'plan_terrain2' => $plan_terrain2
             ]);
    }

    // clientFolder Construction
    public function clientFolder_construction($ref)
    {
        $a0 = DB::table('construction')->where('cli', $ref)->value("a0");
        $a1 = DB::table('construction')->where('cli', $ref)->value("a1");
        $a2 = DB::table('construction')->where('cli', $ref)->value("a2");
        $a3 = DB::table('construction')->where('cli', $ref)->value("a3");
        $a4 = DB::table('construction')->where('cli', $ref)->value("a4");
        $a5 = DB::table('construction')->where('cli', $ref)->value("a5");
        $a6 = DB::table('construction')->where('cli', $ref)->value("a6");
        $a7 = DB::table('construction')->where('cli', $ref)->value("a7");
        $a8 = DB::table('construction')->where('cli', $ref)->value("a8");
        $a9 = DB::table('construction')->where('cli', $ref)->value("a9");
        $a10 = DB::table('construction')->where('cli', $ref)->value("a10");

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_construction', ['client' => $client, 'ref' => $ref, 'a0' => $a0, 'a1' => $a1, 'a2' => $a2, 'a3' => $a3, 'a4' => $a4, 'a5' => $a5, 'a6' => $a6, 'a7' => $a7, 'a8' => $a8, 'a9' => $a9, 'a10' => $a10 ]);
    }

    // clientFolder Construction
    public function clientFolder_construction_updated(Request $req)
    {
        $cli = $req->input('cli');
        $nb = DB::table('construction')->where('cli', $cli)->count();

        $a1 = $req->input('a1');
        $a2 = $req->input('a2');
        $a3 = $req->input('a3');
        $a4 = $req->input('a4');
        $a5 = $req->input('a5');
        $a6 = $req->input('a6');
        $a7 = $req->input('a7');
        $a8 = $req->input('a8');
        $a9 = $req->input('a9');
        $a10 = $req->input('a10');

        if($nb==0) { 
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
            $fait=date("Y/m/d H:i:s");

            DB::table('construction')
            ->insert([
                'ref' => $id,
                'cli' => $cli,
                'a1' => $a1,
                'a2' => $a2,
                'a3' => $a3,
                'a4' => $a4,
                'a5' => $a5,
                'a6' => $a6,
                'a7' => $a7,
                'a8' => $a8,
                'a9' => $a9,
                'a10' => $a10,
                'fait' => $fait,
                'par' => Auth::user()->ref,
            ]); 
            session()->flash('Validation',"Informations has been successfully updated");
            return back();
        } else {
            $url = $req->input('url');
            $ref = DB::table('construction')->where('cli', $cli)->value('ref');
            DB::table('construction')->where('ref', $ref)->update([ 
            'a1' => $a1,
            'a2' => $a2,
            'a3' => $a3,
            'a4' => $a4,
            'a5' => $a5,
            'a6' => $a6,
            'a7' => $a7,
            'a8' => $a8,
            'a9' => $a9,
            'a10' => $a10,
            ]); 
            session()->flash('Validation',"Informations has been successfully updated");
            return back();
        }
    }

    // clientFolder Architecture
    public function clientFolder_architecture($ref)
    {
        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_architecture', ['client' => $client, 'ref' => $ref]);
    }

    // days Delete
    public function clientFolder_design_Delete(Request $req, $ref )
    {
        DB::table('design')->where('ref', $ref)->delete();
        session()->flash('Validation',"Item has been successfully deleted");
        return back();
    }


    // clientFolder Design0
    public function clientFolder_travaux($ref)
    {

        $pdfs = DB::table('design_pdf')
        ->where('cli', $ref)
        ->where('d', 5)
        ->orderBy('fait', 'desc')
        ->get();

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_travaux', ['client' => $client, 'ref' => $ref, 'pdfs' => $pdfs, ]);
    }

    // clientFolder Design0
    public function clientFolder_design0($ref)
    {
        $items = DB::table('design0')
        ->where('cli', $ref)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', $ref)
        ->where('d', 0)
        ->orderBy('fait', 'desc')
        ->get();

        for ($i=1;$i<=75;$i++) {
          $vardyn = "v".$i;
          $$vardyn = DB::table('form')->where('cli', $ref)->value($vardyn);
        }

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_design0', ['client' => $client, 'ref' => $ref, 'items' => $items, 'pdfs' => $pdfs,
        'v1' => $v1,
                'v2' => $v2,
                'v3' => $v3,
                'v4' => $v4,
                'v5' => $v5,
                'v6' => $v6,
                'v7' => $v7,
                'v8' => $v8,
                'v9' => $v9,
                'v10' => $v10,

                'v11' => $v11,
                'v12' => $v12,
                'v13' => $v13,
                'v14' => $v14,
                'v15' => $v15,
                'v16' => $v16,
                'v17' => $v17,
                'v18' => $v18,
                'v19' => $v19,
                'v20' => $v20,

                'v21' => $v21,
                'v22' => $v22,
                'v23' => $v23,
                'v24' => $v24,
                'v25' => $v25,
                'v26' => $v26,
                'v27' => $v27,
                'v28' => $v28,
                'v29' => $v29,
                'v30' => $v30,

                'v31' => $v31,
                'v32' => $v32,
                'v33' => $v33,
                'v34' => $v34,
                'v35' => $v35,
                'v36' => $v36,
                'v37' => $v37,
                'v38' => $v38,
                'v39' => $v39,
                'v40' => $v40,

                'v41' => $v41,
                'v42' => $v42,
                'v43' => $v43,
                'v44' => $v44,
                'v45' => $v45,
                'v46' => $v46,
                'v47' => $v47,
                'v48' => $v48,
                'v49' => $v49,
                'v50' => $v50,

                'v51' => $v51,
                'v52' => $v52,
                'v53' => $v53,
                'v54' => $v54,
                'v55' => $v55,
                'v56' => $v56,
                'v57' => $v57,
                'v58' => $v58,
                'v59' => $v59,
                'v60' => $v60,

                'v61' => $v61,
                'v62' => $v62,
                'v63' => $v63,
                'v64' => $v64,
                'v65' => $v65,
                'v66' => $v66,
                'v67' => $v67,
                'v68' => $v68,
                'v69' => $v69,
                'v70' => $v70,

                'v71' => $v71,
                'v72' => $v72,
                'v73' => $v73,
                'v74' => $v74,
                'v75' => $v75,
             ]);
    }

    // clientFolder Design0
    public function clientFolder_design0_addVideo(Request $req, $cli)
    {
        // Variables notification
        $page = "design0"; 
        $msg = "DESIGN 0 : Vidéo a été ajoutée";

        $fait=date("Y/m/d H:i:s");

        $nb = DB::table('design0')->where('cli', $cli)->count();
        if($nb==0) { 
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;

            $url = $req->input('url');

            DB::table('design0')
            ->insert([
                'ref' => $id,
                'cli' => $cli,
                'url' => $url,
                'fait' => $fait,
                'par' => Auth::user()->ref,
            ]); 
            session()->flash('Validation',"Url has been successfully updated");
        } else {
            $url = $req->input('url');
            $ref = DB::table('design0')->where('cli', $cli)->value('ref');
            DB::table('design0')->where('ref', $ref)->update([ 'url' => $url,  ]); 
            session()->flash('Validation',"Url has been successfully updated");
        }

        // Notification (Classic)***************************
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('notification')->insert(
        ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Video',
        'msg' => $msg,
        'cat' => "notification",
        'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 

        // ###### Notification (Email)***************************
        $email = DB::table('clis')->where('ref', $cli)->value('mail');
        $langue = DB::table('clis')->where('ref', $cli)->value('langue');
        \Mail::to($email)->send(new Notif($msg, $page, $langue) ); 

        return back();

    }

    // clientFolder Design1
    public function clientFolder_design1($ref)
    {
        $photos = DB::table('design')
        ->where('cli', $ref)
        ->where('d', 1)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', $ref)
        ->where('d', 1)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_design1', ['client' => $client, 'ref' => $ref, 'photos' => $photos, 'pdfs' => $pdfs, 'cmt' => $cmt, 'answer' => $answer ]);
    }

    // clientFolder Design2
    public function clientFolder_design2($ref)
    {
        $photos = DB::table('design')
        ->where('cli', $ref)
        ->where('d', 2)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', $ref)
        ->where('d', 2)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_design2', ['client' => $client, 'ref' => $ref, 'photos' => $photos, 'pdfs' => $pdfs, 'cmt' => $cmt, 'answer' => $answer  ]);
    }

    // clientFolder Design3
    public function clientFolder_design3($ref)
    {
        $photos = DB::table('design')
        ->where('cli', $ref)
        ->where('d', 3)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', $ref)
        ->where('d', 3)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_design3', ['client' => $client, 'ref' => $ref, 'photos' => $photos, 'pdfs' => $pdfs, 'cmt' => $cmt, 'answer' => $answer ]);
    }

    // clientFolder Interior
    public function clientFolder_interior($ref)
    {
        $photos = DB::table('design')
        ->where('cli', $ref)
        ->where('d', 10)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', $ref)
        ->where('d', 10)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        return view('clientFolder_interior', ['client' => $client, 'ref' => $ref, 'photos' => $photos, 'pdfs' => $pdfs,  'cmt' => $cmt, 'answer' => $answer ]);
    }

    // clientFolder Design1
    public function clientFolder_design_AddImg(Request $req, $ref)
    {
        $fait=date("Y/m/d H:i:s");
        $d = $req->input('d');

        $url = "";
        // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $images=array();
        if($files=$req->file('url')){
            foreach($files as $file){
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
                
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('d')->put("D".$d.$id.'.'.$extension,  File::get($file));
                $url = "D".$d.$id.'.'.$extension;

                DB::table('design')
                ->insert([
                    'ref' => $id,
                    'cli' => $ref,
                    'd' => $d,
                    'url' => $url,
                    'fait' => $fait,
                    'par' => Auth::user()->ref,
                ]); 
                
            }
        }  

        // Variables notification
        $page = "design".$d; 
        if($d==10) { $page="interior";  }
        if($d==10) { $d=" Interieur";  }
        $msg = "DESIGN ".$d." : Nouvelles photos sont ajoutées";
        $cli = $ref;

        // Notification (Classic)***************************
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('notification')->insert(
        ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => "DESIGN".$d,
        'msg' => $msg,
        'cat' => "notification",
        'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 

        // ###### Notification (Email)***************************
        $code = DB::table("clis")->where('ref', $cli)->value('code');
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);

        $langue = DB::table('clis')->where('code', $code)->value('langue');

        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 




        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        session()->flash('Validation',"Photos has been successfully updated");
        return back();
    }

    public function clientFolder_design_DeleteImg($ref)
    {
        
        DB::table('design')->where('ref', $ref)->delete();
        session()->flash('Suppression',"Image has been successfully deleted");
        return back();
    }



    // clientFolder Design1
    public function clientFolder_design_AddPdf(Request $req, $ref)
    {
        $fait=date("Y/m/d H:i:s");
        $d = $req->input('d');
        $typ = $req->input('typ');
        $dcr = $req->input('dcr');

        $url = "";
        // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $images=array();
        if($files=$req->file('url')){
            foreach($files as $file){
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
                
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('d')->put("PDF_D".$d.$id.'.'.$extension,  File::get($file));
                $url = "PDF_D".$d.$id.'.'.$extension;

                DB::table('design_pdf')
                ->insert([
                    'ref' => $id,
                    'typ' => $typ,
                    'cli' => $ref,
                    'd' => $d,
                    'url' => $url,
                    'dcr' => $dcr,
                    'fait' => $fait,
                    'par' => Auth::user()->ref,
                ]); 
                
            }
        }  

        // Notification
        // Get Emails Clients ********************************************************************************************************************
        if($d==0 or $d==1 or $d==2 or $d==3) { 
            $code = DB::table("clis")->where('ref', $ref)->value('code');
            $langue = DB::table('clis')->where('code', $code)->value('langue');
            $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
            $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
            $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
            array_push($emails, $email);
            $page = "design".$d;  $msg="D".$d." : Un nouveau document a été ajouté"; 
            
            if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
        }

        if($d==5) { 
            $code = DB::table("clis")->where('ref', $ref)->value('code');
            $langue = DB::table('clis')->where('code', $code)->value('langue');
            $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
            $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
            $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
            array_push($emails, $email);
            $page = "travaux";  $msg="Travaux supplémentaires : Un nouveau document a été ajouté"; 
            if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
        }


        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');
        session()->flash('Validation',"Pdf has been successfully updated");
        return back();
    }

    public function clientFolder_design_DeletePdf($ref)
    {
        DB::table('design_pdf')->where('ref', $ref)->delete();
        session()->flash('Suppression',"Pdf has been successfully deleted");
        return back();
    }



    public function clientFolderValidate($ref, $item, $valid, $table)
    {
        DB::table($table)->where('ref', $item)->update([ 'valid' => $valid,  ]);

        // Notifications
        if($table=='design_pdf' && $valid==1)
        {
            $d = DB::table("design_pdf")->where('ref', $item)->value('d');
            $code = DB::table("clis")->join('design_pdf', 'clis.ref', '=', 'design_pdf.cli')->where('design_pdf.ref', $item)->value('code');

            $langue = DB::table('clis')->where('code', $code)->value('langue');
            
            if($d==0) { 
                function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
                $emails = getEmails('arch1');
                $msg=$code." - D0 : Document validated"; $page="design0";
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            } 

            if($d==1) { 
                function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
                $emails = getEmails('arch2');
                $msg=$code." - D1 : Document validated"; $page="design1";
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }   

            if($d==2) { 
                function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
                $emails = getEmails('arch3');
                $msg=$code." - D2 : Document validated"; $page="design2";
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }  

            if($d==3) { 
                function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
                $emails = getEmails('arch4');
                $msg=$code." - D3 : Document validated"; $page="design3";
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            } 
            if($d==5) { 
                function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
                $emails = getEmails('arch6');
                $msg=$code." - Additional works : Document validated"; $page="travaux";
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
            }      
        }

        return back();
    }

    // administration ################
    public function administration()
    {   
        // reservation 1
        $reservation1 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $reservation2 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $construction1 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $construction2 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $terrain1 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $terrain2 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $quotation1 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "quotation")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $quotation2 = DB::table('administration')
        ->where('cli', Auth::user()->ref)
        ->where('type', "quotation2")
        ->orderBy('fait', 'desc')
        ->get();

        return view('administration', ['quotation1' => $quotation1, 'quotation2' => $quotation2, 'reservation1' => $reservation1, 'reservation2' => $reservation2, 'construction1' => $construction1, 'construction2' => $construction2, 'terrain1' => $terrain1, 'terrain2' => $terrain2 ]);
    }

    public function administrationAdded(Request $req)
    {

        $type = $req->input('type');
        $cli = $req->input('cli');
        $signed = $req->input('signed');
        $code = DB::table('clis')->where('ref', $cli)->value('code');
        $langue = DB::table('clis')->where('code', $code)->value('langue');

        // Get Emails Clients ********************************************************************************************************************
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);

        // Function Get Emails Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }

        // Variables notification
        $page = "administration"; $msg="";  

        if($type=='reservation2') { $msg = "Administration : Contrat de réservation a été ajouté";  }
        if($type=='construction2') { $msg = "Administration : Contrat de construction a été ajouté";  }
        if($type=='terrain2') { $msg = "Administration : Rendering a été ajouté";  }
        if($type=='quotation2') { $msg = "Administration : Rendering Quotation a été ajouté";  }

        if($type=='reservation') { $msg = $code." - Administration : Reservation contract has been added.";     $emails = getEmails('adm1');  }
        if($type=='construction') { $msg = $code." - Administration : Construction contract has been added.";   $emails = getEmails('adm3'); }
        if($type=='terrain') { $msg = $code." - Administration : Rendering has been added.";                    $emails = getEmails('adm2'); }
        if($type=='quotation') { $msg = $code." - Administration : Rendering Quotation has been added.";        $emails = getEmails('adm2'); }

        // add to sales application ( reservation contrat )
        if($type=='reservation' or $type=='reservation2') {
            $sale = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('ref');
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('sales')->put("CR".$id.'.'.$extension,  File::get($file));
                    $url = "CR".$id.'.'.$extension;

                    DB::connection('mysql2')->table('suivis')
                    ->where('vente', $sale)
                    ->update([
                        'pdf' => $url,
                    ]); 
                }
            } 
        }

        // add to sales application ( construction contrat )
        if($type=='construction' or $type=='construction2') {
            $sale = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('ref');
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('sales')->put("CC".$id.'.'.$extension,  File::get($file));
                    $url = "CC".$id.'.'.$extension;

                    DB::connection('mysql2')->table('suivis')
                    ->where('vente', $sale)
                    ->update([
                        'pdf2' => $url,
                    ]); 
                }
            } 
        }

        $nb = DB::table('administration')->where('cli', $cli)->where('type', $type)->orderBy('fait', 'desc')->count();

        if($nb==0) { 
            $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
            $fait=date("Y/m/d H:i:s");
            $type = $req->input('type');
            
            DB::table('administration')->insert(
            ['ref' => $ref, 
            'cli' => $cli, 
            'url' => "",
            'valid' => 0,
            'type' => $type,
            'fait' => $fait,
            'par' => Auth::user()->ref ]
            );

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('administration')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') { 
                // Notification (Classic)***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 

                // ###### Notification (Email)***************************   
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }     
            }
                       
            session()->flash('yes',"File has been added successfully");
            if($signed!='1') { 
                if($type=="reservation" or $type=="construction" or $type=="terrain") { return redirect('administration'); }
                elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2") { return back(); }
            }
        } else {
            $ref = DB::table('administration')->where('cli', $cli)->where('type', $type)->value('ref');
            $u = DB::table('administration')->where('cli', $cli)->where('type', $type)->value('url');

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('administration')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') { 
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );

                // ###### Notification (Email)***************************                
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); echo $em."____"; } } }  
            }

            session()->flash('yes',"File has been added successfully");
            if($signed!='1') { 
                if($type=="reservation" or $type=="construction" or $type=="terrain") { return redirect('administration'); }
                elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2") { return back(); } 
            }
        }


        // Add if already signed
        if($signed=='1') { 
            $type =str_replace("2", "", $type); 
            
            $nb = DB::table('administration')->where('cli', $cli)->where('type', $type)->orderBy('fait', 'desc')->count();

            if($nb==0) { 

                $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
                $fait=date("Y/m/d H:i:s");
                
                DB::table('administration')->insert(
                ['ref' => $ref, 
                'cli' => $cli, 
                'url' => "",
                'valid' => 0,
                'type' => $type,
                'fait' => $fait,
                'par' => Auth::user()->ref ]
                );

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $url = "";
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('administration')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            } else {

                $ref = DB::table('administration')->where('cli', $cli)->where('type', $type)->value('ref');
                $u = DB::table('administration')->where('cli', $cli)->where('type', $type)->value('url');

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('administration')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            }

            session()->flash('yes',"File has been added successfully");
            return back();
        }
        return back();
    }


    // ptpma ################
    public function ptpma()
    {   

        // reservation 1
        $reservation1 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $reservation2 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $construction1 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $construction2 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $terrain1 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $terrain2 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        // acte 2
        $acte2 = DB::table('ptpma')
        ->where('cli', Auth::user()->ref)
        ->where('type', "acte2")
        ->orderBy('fait', 'desc')
        ->get();

        // Passport
        $passport = DB::connection('mysql2')->table('clients')
        ->where('vente', Auth::user()->ref)
        ->orderBy('fait', 'desc')
        ->get();

        // Nom de la villa
        $nom_villa = DB::connection('mysql2')->table('ventes')->where('cod', Auth::user()->code)->value('salevillaname');

        // Nom de PTPMA
        $nom_ptpma = DB::connection('mysql2')->table('ptpma')
        ->select('ptpmaname')
        ->rightjoin('ventes', 'ventes.ref', '=', 'ptpma.vente')
        ->where('cod', auth::user()->code)
        ->value("ptpmaname");

        // Confirmed
        $confirmed = DB::connection('mysql2')->table('ptpma')
        ->select('confirmed')
        ->rightjoin('ventes', 'ventes.ref', '=', 'ptpma.vente')
        ->where('cod', auth::user()->code)
        ->value("confirmed");

        return view('ptpma', ['confirmed' => $confirmed, 'nom_ptpma' => $nom_ptpma, 'nom_villa' => $nom_villa, 'reservation1' => $reservation1, 'reservation2' => $reservation2, 'construction1' => $construction1, 'construction2' => $construction2, 'terrain1' => $terrain1, 'terrain2' => $terrain2, 'acte2' => $acte2, 'passport' => $passport ]);
    }

    public function nameVillaPtpma(Request $req)
    {
        $nom_ptpma = strtoupper($req->input('nom_ptpma'));
        $nom_villa = strtoupper($req->input('nom_villa'));

        DB::connection('mysql2')->table('ventes')->where('cod', Auth::user()->code)->update([ 'salevillaname' => $nom_villa,  ]); 

        DB::connection('mysql2')->table('ptpma')
        ->rightjoin('ventes', 'ventes.ref', '=', 'ptpma.vente')
        ->where('cod', auth::user()->code)
        ->update([ 'ptpmaname' => $nom_ptpma,  ]); 

        // Send Notification to Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        $emails = getEmails('ptpma1');
        $code = auth::user()->code;
        $langue = "FR";
        $msg = $code." - PTPMA : Villa name and PTPMA name has been added."; $page="ptpma";  $emails = getEmails('adm1');
        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }     


        session()->flash('yes',"Informations sauvegardées");
        return back();

    }


    public function ptpmaAdded(Request $req)
    {

        $type = $req->input('type');
        $cli = $req->input('cli');
        $signed = $req->input('signed');
        $code = DB::table('clis')->where('ref', $cli)->value('code');
        $langue = DB::table('clis')->where('code', $code)->value('langue');

        // Get Emails Clients ********************************************************************************************************************
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);


        // Function Get Emails Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }


        // Variables notification
        $page = "ptpma"; $msg=""; 

        if($type=='reservation2') { $msg = "PTPMA : Procuration a été ajoutée";  }
        if($type=='construction2') { $msg = "PTPMA : Document de nom de votre PTPMA et votre Villa a été ajouté";  }
        if($type=='terrain2') { $msg = "PTPMA : Document bancaire a été ajouté";  }
        if($type=='acte2') { $msg = "PTPMA : Acte constitutif de société a été ajouté";  }

        if($type=='reservation') { $msg = $code." - PTPMA : Power of Attorney has been added."; $emails = getEmails('ptpma2'); }
        if($type=='construction') { $msg = $code." - PTPMA : Document of Name of your PTPMA and your Villa has been added"; $emails = getEmails('ptpma3'); }
        if($type=='terrain') { $msg = $code." - PTPMA : Bank document has been added"; $emails = getEmails('ptpma4'); }
        if($type=='acte2') { $msg = $code." - PTPMA : Memorandum of Association has been added."; $emails = getEmails('ptpma3'); }

        // add to sales application ( reservation contrat )
        if($type=='acte2') {
            $sale = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('ref');
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('sales')->put("AKTA".$id.'.'.$extension,  File::get($file));
                    $url = "AKTA".$id.'.'.$extension;

                    DB::connection('mysql2')->table('ptpma')
                    ->where('vente', $sale)
                    ->update([
                        'pdfakta' => $url,
                    ]); 
                }
            } 
        }

        $nb = DB::table('ptpma')
        ->where('cli', $cli)
        ->where('type', $type)
        ->orderBy('fait', 'desc')
        ->count();

        if($nb==0) { 
            $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
            $fait=date("Y/m/d H:i:s");
            $type = $req->input('type');
            
            DB::table('ptpma')->insert(
            ['ref' => $ref, 
            'cli' => $cli, 
            'url' => "",
            'valid' => 0,
            'type' => $type,
            'fait' => $fait,
            'par' => Auth::user()->ref ]
            );

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('ptpma')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') { 
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );

                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            session()->flash('yes',"File has been added successfully");
            if($signed!='1') { 
                if($type=="reservation" or $type=="construction" or $type=="terrain" or $type=="acte") { return redirect('ptpma'); }
                elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2" or $type=="acte2") { return back(); }
            }
        } else {
            $ref = DB::table('ptpma')->where('cli', $cli)->where('type', $type)->value('ref');
            $u = DB::table('ptpma')->where('cli', $cli)->where('type', $type)->value('url');

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('ptpma')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }
            
            if($signed!='1') {
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );

                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            session()->flash('yes',"File has been added successfully");
            if($signed!='1') { 
                if($type=="reservation" or $type=="construction" or $type=="terrain" or $type=="acte") { return redirect('ptpma'); }
                elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2" or $type=="acte2") { return back(); }
            }
        }

        // Add if already signed
        if($signed=='1') { 
            $type =str_replace("2", "", $type); 
            
            $nb = DB::table('ptpma')->where('cli', $cli)->where('type', $type)->orderBy('fait', 'desc')->count();

            if($nb==0) { 

                $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
                $fait=date("Y/m/d H:i:s");
                
                DB::table('ptpma')->insert(
                ['ref' => $ref, 
                'cli' => $cli, 
                'url' => "",
                'valid' => 0,
                'type' => $type,
                'fait' => $fait,
                'par' => Auth::user()->ref ]
                );

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $url = "";
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('ptpma')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            } else {

                $ref = DB::table('ptpma')->where('cli', $cli)->where('type', $type)->value('ref');
                $u = DB::table('ptpma')->where('cli', $cli)->where('type', $type)->value('url');

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('ptpma')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            }

            session()->flash('yes',"File has been added successfully");
            return back();
        }
    }

    // land ################
    public function land()
    {   
        // reservation 1
        $reservation1 = DB::table('land')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $reservation2 = DB::table('land')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $construction1 = DB::table('land')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $construction2 = DB::table('land')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $terrain1 = DB::table('land')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $terrain2 = DB::table('land')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        return view('land', ['reservation1' => $reservation1, 'reservation2' => $reservation2, 'construction1' => $construction1, 'construction2' => $construction2, 'terrain1' => $terrain1, 'terrain2' => $terrain2 ]);
    }

    public function landAdded(Request $req)
    {

        $type = $req->input('type');
        $cli = $req->input('cli');
        $signed = $req->input('signed');
        $code = DB::table('clis')->where('ref', $cli)->value('code');
        $langue = DB::table('clis')->where('code', $code)->value('langue');

        // Get Emails Clients ********************************************************************************************************************
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);

        // Function Get Emails Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }

        // Variables notification
        $page = "land"; $msg=""; 

        if($type=='reservation2') { $msg = "Terrain : Procuration a été ajoutée"; }
        if($type=='construction2') { $msg = "Terrain : Contrat de location notarié a été ajouté"; }
        if($type=='terrain2') { $msg = "Terrain : Implantation du terrain"; }

        if($type=='reservation') { $msg = $code." - LAND : Power of attorney has been added"; $emails = getEmails('land1'); }
        if($type=='construction') { $msg = $code." - LAND : Notarized rental agreement has been added"; $emails = getEmails('land2'); }
        if($type=='terrain') { $msg = $code." - LAND : Land Neighborhood has been added"; $emails = getEmails('land3'); }

        $nb = DB::table('land')
        ->where('cli', $cli)
        ->where('type', $type)
        ->orderBy('fait', 'desc')
        ->count();

        if($nb==0) { 
            $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
            $fait=date("Y/m/d H:i:s");
            $type = $req->input('type');
            
            DB::table('land')->insert(
            ['ref' => $ref, 
            'cli' => $cli, 
            'url' => "",
            'valid' => 0,
            'type' => $type,
            'fait' => $fait,
            'par' => Auth::user()->ref ]
            );

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('land')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') {
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );
                
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            if($signed!='1') {
            session()->flash('yes',"File has been added successfully");
            if($type=="reservation" or $type=="construction" or $type=="terrain") { return redirect('land'); }
            elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2") { return back(); }
            }
        } else {
            $ref = DB::table('land')->where('cli', $cli)->where('type', $type)->value('ref');
            $u = DB::table('land')->where('cli', $cli)->where('type', $type)->value('url');

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('land')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') {
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );

                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } } 
            }

            if($signed!='1') {
            session()->flash('yes',"File has been added successfully");
            if($type=="reservation" or $type=="construction" or $type=="terrain") { return redirect('land'); }
            elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2") { return back(); }
            }
        }

        // Add if already signed
        if($signed=='1') { 
            $type =str_replace("2", "", $type); 
            
            $nb = DB::table('land')->where('cli', $cli)->where('type', $type)->orderBy('fait', 'desc')->count();

            if($nb==0) { 

                $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
                $fait=date("Y/m/d H:i:s");
                
                DB::table('land')->insert(
                ['ref' => $ref, 
                'cli' => $cli, 
                'url' => "",
                'valid' => 0,
                'type' => $type,
                'fait' => $fait,
                'par' => Auth::user()->ref ]
                );

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $url = "";
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('land')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            } else {

                $ref = DB::table('land')->where('cli', $cli)->where('type', $type)->value('ref');
                $u = DB::table('land')->where('cli', $cli)->where('type', $type)->value('url');

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('land')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            }

            session()->flash('yes',"File has been added successfully");
            return back();
        }
    }

    // architecture ################
    public function architecture()
    {
        return view('architecture');
    }

    // plan ################
    public function plan()
    {   
        // reservation 1
        $reservation1 = DB::table('plan')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation")
        ->orderBy('fait', 'desc')
        ->get();

        // reservation 2
        $reservation2 = DB::table('plan')
        ->where('cli', Auth::user()->ref)
        ->where('type', "reservation2")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 1
        $construction1 = DB::table('plan')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction")
        ->orderBy('fait', 'desc')
        ->get();

        // construction 2
        $construction2 = DB::table('plan')
        ->where('cli', Auth::user()->ref)
        ->where('type', "construction2")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 1
        $terrain1 = DB::table('plan')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain")
        ->orderBy('fait', 'desc')
        ->get();

        // terrain 2
        $terrain2 = DB::table('plan')
        ->where('cli', Auth::user()->ref)
        ->where('type', "terrain2")
        ->orderBy('fait', 'desc')
        ->get();

        return view('plan', ['reservation1' => $reservation1, 'reservation2' => $reservation2, 'construction1' => $construction1, 'construction2' => $construction2, 'terrain1' => $terrain1, 'terrain2' => $terrain2 ]);
    }

    public function planAdded(Request $req)
    {

        $type = $req->input('type');
        $cli = $req->input('cli');
        $signed = $req->input('signed');
        $code = DB::table('clis')->where('ref', $cli)->value('code');
        $langue = DB::table('clis')->where('code', $code)->value('langue');

        // Get Emails Clients ********************************************************************************************************************
        $emailsTable = DB::connection('mysql2')->table('ventes')->join('clients', 'ventes.ref', '=', 'clients.vente')->where('cod', $code)->get();
        $emails = array(); foreach ($emailsTable as $e) { $emails = array(); array_push($emails, $e->mail); }
        $email = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('mail');
        array_push($emails, $email);

        // Function Get Emails Admin
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }


        // Variables notification
        $page = "plan"; $msg=""; 

        if($type=='reservation2') { $msg = "PLAN : Plans généraux sont ajoutés"; }
        if($type=='construction2') { $msg = "PLAN : Plans de plomberie et électricité sont ajoutées"; }
        if($type=='terrain2') { $msg = "PLAN : Plans structure sont ajoutées"; }

        if($type=='reservation') { $msg = $code." - PLAN : General plans are added."; $emails = getEmails('arch5'); }
        if($type=='construction') { $msg = $code." - PLAN : Plumbing and electrical plans are added."; $emails = getEmails('arch5'); }
        if($type=='terrain') { $msg = $code." - PLAN : Structure Drawing are added."; $emails = getEmails('arch5'); }

        $nb = DB::table('plan')
        ->where('cli', $cli)
        ->where('type', $type)
        ->orderBy('fait', 'desc')
        ->count();

        if($nb==0) { 
            $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
            $fait=date("Y/m/d H:i:s");
            $type = $req->input('type');
            
            DB::table('plan')->insert(
            ['ref' => $ref, 
            'cli' => $cli, 
            'url' => "",
            'valid' => 0,
            'type' => $type,
            'fait' => $fait,
            'par' => Auth::user()->ref ]
            );

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            $url = "";
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('plan')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') { 
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );

                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }   
            } 

            session()->flash('yes',"File has been added successfully");
            if($signed!='1') {
                if($type=="reservation" or $type=="construction" or $type=="terrain") { return redirect('plan'); }
                elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2") { return back(); }
            }
        } else {
            $ref = DB::table('plan')->where('cli', $cli)->where('type', $type)->value('ref');
            $u = DB::table('plan')->where('cli', $cli)->where('type', $type)->value('url');

            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
            // NB ! Change fichier config/filesystems.php
            $input=$req->all();
            $url=array();
            if($files=$req->file('url')){
                foreach($files as $file){
                    $fait=date("Y/m/d H:i:s");
                    $extension = $file->getClientOriginalExtension();
                    Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                    $url = $type.$id.'.'.$extension;
                    DB::table('plan')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                }
            }

            if($signed!='1') { 
                // Notification ***************************
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                DB::table('notification')->insert(
                ['ref' => $id,  'cli' => $cli,  'code' => $ref, 'type' => $type,
                'msg' => $msg,
                'cat' => "notification",
                'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] );
                
                // ###### Notification (Email)***************************
                if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }     
            }

            session()->flash('yes',"File has been added successfully");
            if($signed!='1') { 
                if($type=="reservation" or $type=="construction" or $type=="terrain") { return redirect('plan'); }
                elseif($type=="reservation2" or $type=="construction2" or $type=="terrain2") { return back(); }
            }
        }

        // Add if already signed
        if($signed=='1') { 
            $type =str_replace("2", "", $type); 
            
            $nb = DB::table('plan')->where('cli', $cli)->where('type', $type)->orderBy('fait', 'desc')->count();

            if($nb==0) { 

                $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
                $fait=date("Y/m/d H:i:s");
                
                DB::table('plan')->insert(
                ['ref' => $ref, 
                'cli' => $cli, 
                'url' => "",
                'valid' => 0,
                'type' => $type,
                'fait' => $fait,
                'par' => Auth::user()->ref ]
                );

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $url = "";
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('plan')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            } else {

                $ref = DB::table('plan')->where('cli', $cli)->where('type', $type)->value('ref');
                $u = DB::table('plan')->where('cli', $cli)->where('type', $type)->value('url');

                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                // NB ! Change fichier config/filesystems.php
                $input=$req->all();
                $url=array();
                if($files=$req->file('url')){
                    foreach($files as $file){
                        $fait=date("Y/m/d H:i:s");
                        $extension = $file->getClientOriginalExtension();
                        Storage::disk('public')->put($type.$id.'.'.$extension,  File::get($file));
                        $url = $type.$id.'.'.$extension;
                        DB::table('plan')->where('ref', $ref)->update([ 'url' => $url,  ]); 
                    }
                }
            }

            session()->flash('yes',"File has been added successfully");
            return back();
        }
    }

    // design ################
    public function design()
    {
        return view('design');
    }

    // design Comment ################
    public function designAddCmt(Request $req)
    {
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
        $fait=date("Y/m/d H:i:s");
        $cmt = $req->input('cmt');
        $img = $req->input('img');
        $x = $req->input('x');
        $y = $req->input('y');

        DB::table('cmt')
        ->insert([
            'ref' => $id,
            'img' => $img,
            'cli' => Auth::user()->ref,
            'cmt' => $cmt,
            'vu' => 0,
            'x' => $x,
            'y' => $y,
            'fait' => $fait,
            'par' => Auth::user()->ref,
        ]); 

        // Notifications
        $d = DB::table('cmt')->join('design', 'design.ref', '=', 'cmt.img')->where('cmt.ref', $id)->value('d');
        $code = Auth::user()->code;
        $langue = DB::table('clis')->where('code', $code)->value('langue');
        if($d==1) {
            $code = Auth::user()->code;
            function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
            $emails = getEmails('arch2');
            $msg=$code." - D1 : New comment added"; $page="design1";
            if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
        }
        if($d==2) {
            $code = Auth::user()->code;
            function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
            $emails = getEmails('arch2');
            $msg=$code." - D2 : New comment added"; $page="design2";
            if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
        }
        if($d==3) {
            $code = Auth::user()->code;
            function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
            $emails = getEmails('arch3');
            $msg=$code." - D3 : New comment added"; $page="design3";
            if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
        }
        if($d==10) {
            $code = Auth::user()->code;
            function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
            $emails = getEmails('arch6');
            $msg=$code." - Interior Design : New comment added"; $page="interior";
            if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  
        }

        session()->flash('Validation',"Your comment has been successfully added");
        return back();
    }

    // design Comment Delete ################
    public function designDeleteCmt($cmt)
    {
        DB::table('cmt')->where('ref', $cmt)->delete();
        session()->flash('Validation',"Your comment has been successfully deleted");
        return back();
    }

    // answer ################
    public function answerAdd(Request $req)
    {
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
        $fait=date("Y/m/d H:i:s");
        
        $msg = $req->input('msg');
        $cmt = $req->input('cmt');

        DB::table('answer')
        ->insert([
            'ref' => $id,
            'cmt' => $cmt,
            'msg' => $msg,
            'vu' => 0,
            'fait' => $fait,
            'par' => Auth::user()->ref,
        ]); 

        session()->flash('Validation',"Your answer has been successfully added");
        return back();
    }

    // answer Delete ################
    public function answerDelete($answer)
    {
        DB::table('answer')->where('ref', $answer)->delete();
        session()->flash('Validation',"Your answer has been successfully deleted");
        return back();
    }

    // design0 ################
    public function travaux()
    {   

        $pdfs = DB::table('design_pdf')
        ->where('cli', Auth::user()->ref)
        ->where('d', 5)
        ->orderBy('fait', 'desc')
        ->get();

        return view('travaux', [ 'pdfs'=>$pdfs, ]);
    }

    // design0 ################
    public function design0()
    {
        $items = DB::table('design0')
        ->where('cli', Auth::user()->ref)
        ->orderBy('fait', 'desc')
        ->get(); 

        $nb = DB::table('form')
        ->where('cli', Auth::user()->ref)
        ->count(); 
             

        $pdfs = DB::table('design_pdf')
        ->where('cli', Auth::user()->ref)
        ->where('d', 0)
        ->orderBy('fait', 'desc')
        ->get();

        $ops = DB::table('options')->select('sale','case','val')->where('sale', Auth::user()->ref)->get();

        for ($i=1;$i<=75;$i++) {
          $vardyn = "v".$i;
          $$vardyn = DB::table('form')->where('cli', Auth::user()->ref)->value($vardyn);
        }

        return view('design0', [ 'items'=>$items, 'pdfs'=>$pdfs,  'ops'=>$ops, 

                'nb' => $nb,
                
                'v1' => $v1,
                'v2' => $v2,
                'v3' => $v3,
                'v4' => $v4,
                'v5' => $v5,
                'v6' => $v6,
                'v7' => $v7,
                'v8' => $v8,
                'v9' => $v9,
                'v10' => $v10,

                'v11' => $v11,
                'v12' => $v12,
                'v13' => $v13,
                'v14' => $v14,
                'v15' => $v15,
                'v16' => $v16,
                'v17' => $v17,
                'v18' => $v18,
                'v19' => $v19,
                'v20' => $v20,

                'v21' => $v21,
                'v22' => $v22,
                'v23' => $v23,
                'v24' => $v24,
                'v25' => $v25,
                'v26' => $v26,
                'v27' => $v27,
                'v28' => $v28,
                'v29' => $v29,
                'v30' => $v30,

                'v31' => $v31,
                'v32' => $v32,
                'v33' => $v33,
                'v34' => $v34,
                'v35' => $v35,
                'v36' => $v36,
                'v37' => $v37,
                'v38' => $v38,
                'v39' => $v39,
                'v40' => $v40,

                'v41' => $v41,
                'v42' => $v42,
                'v43' => $v43,
                'v44' => $v44,
                'v45' => $v45,
                'v46' => $v46,
                'v47' => $v47,
                'v48' => $v48,
                'v49' => $v49,
                'v50' => $v50,

                'v51' => $v51,
                'v52' => $v52,
                'v53' => $v53,
                'v54' => $v54,
                'v55' => $v55,
                'v56' => $v56,
                'v57' => $v57,
                'v58' => $v58,
                'v59' => $v59,
                'v60' => $v60,

                'v61' => $v61,
                'v62' => $v62,
                'v63' => $v63,
                'v64' => $v64,
                'v65' => $v65,
                'v66' => $v66,
                'v67' => $v67,
                'v68' => $v68,
                'v69' => $v69,
                'v70' => $v70,

                'v71' => $v71,
                'v72' => $v72,
                'v73' => $v73,
                'v74' => $v74,
                'v75' => $v75,

         ]);
    }

    // design1 ################
    public function design1()
    {
        $photos = DB::table('design')
        ->where('cli', Auth::user()->ref)
        ->where('d', 1)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', Auth::user()->ref)
        ->where('d', 1)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        return view('design1', [ 'photos'=>$photos, 'pdfs'=>$pdfs, 'cmt'=>$cmt, 'answer'=>$answer ]);
    }

    // design2 ################
    public function design2()
    {
        $photos = DB::table('design')
        ->where('cli', Auth::user()->ref)
        ->where('d', 2)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', Auth::user()->ref)
        ->where('d', 2)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        return view('design2', [ 'photos'=>$photos, 'pdfs'=>$pdfs, 'cmt'=>$cmt, 'answer'=>$answer ]);
    }

    // design3 ################
    public function design3()
    {
        $photos = DB::table('design')
        ->where('cli', Auth::user()->ref)
        ->where('d', 3)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', Auth::user()->ref)
        ->where('d', 3)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        return view('design3', [ 'photos'=>$photos, 'pdfs'=>$pdfs, 'cmt'=>$cmt, 'answer'=>$answer ]);
    }

    // design interior ################
    public function interior()
    {
        $photos = DB::table('design')
        ->where('cli', Auth::user()->ref)
        ->where('d', 10)
        ->orderBy('fait', 'desc')
        ->get();

        $pdfs = DB::table('design_pdf')
        ->where('cli', Auth::user()->ref)
        ->where('d', 10)
        ->orderBy('fait', 'desc')
        ->get();

        $cmt = DB::table('cmt')
        ->orderBy('fait', 'desc')
        ->get();

        $answer = DB::table('answer')->orderBy('fait', 'desc')->get();

        return view('interior', [ 'photos'=>$photos, 'pdfs'=>$pdfs, 'cmt'=>$cmt, 'answer'=>$answer ]);
    }

    public function index()
    {
        $clis = DB::connection('mysql2')
        ->table('clis')
        ->where('username', '!=', 'admin')
        ->get();



        foreach($clis as $c) {
            $nb = DB::table('clis')->where('username', $c->username)->count();
            if($nb==0) { 
                DB::table('clis')
                ->insert([                
                    'ref' => $c->ref,
                    'username' => $c->username,
                    'password' => $c->password,
                    'civ' => $c->civ,
                    'nom' => $c->nom,
                    'pre' => $c->pre,
                    'tel' => $c->tel,
                    'mail' => $c->mail,
                    'dat' => $c->dat,
                    'type' => 'admin',
                    'sent' => 0,
                    'doc' => 0,
                    'email' => "",
                ]);
            }
        }

        if (Auth::user()->type!='admin') { return redirect('dashboard');  }
        $clis = DB::table('clis')
        ->where('type', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();   

        return view('client', [ 'clis' => $clis ]);
    }

    public function home()
    {
        if (Auth::user()->type!='admin') { return redirect('dashboard');  }
        $clis = DB::table('clis')
        ->where('type', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();
        return view('client', ['clis' => $clis ]);
    }
        
    public function client()
    {
        $clients = DB::table('clis')->get();
        foreach ($clients as $c) {
            DB::table('clis')->where('mail', $c->mail)->update([ 'email' => $c->mail ]); 
        }

        if (Auth::user()->type!='admin') { return redirect('dashboard');  }
        $clis = DB::table('clis')
        ->where('type', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();


        return view('client', ['clis' => $clis ]);
    }

    public function steps()
    {
        $clients = DB::table('clis')->get();
        foreach ($clients as $c) {
            DB::table('clis')->where('mail', $c->mail)->update([ 'email' => $c->mail ]); 
        }

        if (Auth::user()->type!='admin') { return redirect('dashboard');  }
        $clis = DB::table('clis')
        ->where('type', '!=', 'admin')
        ->orderBy('nom', 'asc')
        ->get();


        $steps = array (
          array('ref' => '1', 'step' => '1'),
        );

        foreach ($clients as $c) { 
            $etape=1;
            $ref = $c->ref;
            $code = $c->code;

            // 1
            $admin = DB::table('administration')->where('type', "reservation2")->where('cli', $ref)->count();
            if($admin!=0 )
            { $etape=1; }

            // 2
            $a2 = DB::table('factures')->where('cli', $ref)->value("a2");
            if($a2!="" )
            { $etape=2; }

            // 3
            $a3 = DB::table('factures')->where('cli', $ref)->value("a3");
            if($a3!="" )
            { $etape=3; }

            // 4
            $a4 = DB::table('factures')->where('cli', $ref)->value("a3");
            if($a3!="" )
            { $etape=4; }

            // 5
            $a5 = DB::connection('mysql2')->table('lands')->rightjoin('ventes', 'ventes.ref', '=', 'lands.vente')->where('cod', $code)->value('landname'); 
            if($a5!="" )
            { $etape=5; }

            // 6
            $a6 = DB::table('land')->where('type', "reservation2")->where('cli', $ref)->count();
            if($a6!="" )
            { $etape=6; }

            // 7
            $a7 = DB::connection('mysql2')->table('ventes')->where('cod', $code)->value('salevillaname'); 
            if($a7!="" )
            { $etape=7; }

            // 8
            $a8 = DB::table('factures')->where('cli', $ref)->value("b2");
            if($a8!="" )
            { $etape=8; }

            // 9
            $a9 = DB::table('ptpma')->where('type', "acte2")->where('cli', $ref)->count();
            if($a9!="" )
            { $etape=9; }

            // 10
            $a10 = DB::table('factures')->where('cli', $ref)->value("b3");
            if($a10!="" )
            { $etape=10; }

            // 11
            $a11 = DB::table('land')->where('type', "construction2")->where('cli', $ref)->count();
            if($a11!="" )
            { $etape=11; }

            // 12
            $a12 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('send_catalog'); 
            if($a12!="" )
            { $etape=12; }

            // 13
            $a13 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('get_catalog'); 
            if($a13!="" )
            { $etape=13; }

            // 14
            $a14 = DB::table('design')->where('d', 1)->where('cli', $ref)->count();
            if($a14!="")
            { $etape=14; }

            // 15
            $a15 = DB::table('design')->where('d', 2)->where('cli', $ref)->count();
            if($a15!="")
            { $etape=15; }

            // 16
            $a16 = DB::table('design')->where('d', 3)->where('cli', $ref)->count();
            if($a16!="")
            { $etape=16; }

            // 17
            $a17 = DB::table('administration')->where('type', "terrain2")->where('cli', $ref)->count();
            if($a17!="")
            { $etape=17; }

            // 18
            $a18 = DB::table('administration')->where('type', "terrain")->where('cli', $ref)->count();
            if($a18!="")
            { $etape=18; }

            // 19
            $a19 = DB::table('administration')->where('type', "construction2")->where('cli', $ref)->count();
            if($a19!="")
            { $etape=19; }

            // 20
            $a20 = DB::table('factures')->where('cli', $ref)->value("c2");
            if($a20!="")
            { $etape=20; }

            // 21
            $a21 = DB::table('factures')->where('cli', $ref)->value("c3");
            if($a21!="")
            { $etape=21; }

            // 22
            $a22 = DB::table('cli_pic')->where('cli', $ref)->count();
            if($a22!=0)
            { $etape=22; }

            // 23
            $a23 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp12');
            if($a23!="")
            { $etape=23; }

            // 24
            $a24 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp21');
            if($a24!="")
            { $etape=24; }

            // 25
            $a25 = DB::table('factures')->where('cli', $ref)->value("d2");
            if($a25!="")
            { $etape=25; }

            // 26
            $a26 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp31');
            if($a26!="")
            { $etape=26; }

            // 27
            $a27 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp32');
            if($a27!="")
            { $etape=27; }

            // 28
            $a28 = DB::connection('mysql2')->table('architecture')->rightjoin('ventes', 'ventes.ref', '=', 'architecture.vente')->where('cod', $code)->value('meet');
            if($a28!="")
            { $etape=28; }

            // 29
            $a29 = DB::connection('mysql2')->table('progress')->rightjoin('ventes', 'ventes.ref', '=', 'progress.vente')->where('cod', $code)->value('dp4');
            if($a29!="")
            { $etape=29; }

            // 30
            $a30 = DB::table('factures')->where('cli', $ref)->value("e2");
            if($a30!="")
            { $etape=30; }

            // 31
            $a31 = DB::table('factures')->where('cli', $ref)->value("e3");
            if($a31!="")
            { $etape=31; }

            // 32
            $a32 = DB::connection('mysql2')->table('worksite')->rightjoin('ventes', 'ventes.ref', '=', 'worksite.vente')->where('cod', $code)->value("a36");
            if($a32!="")
            { $etape=32; }

            // 33
            $a33 = DB::table('factures')->where('cli', $ref)->value("f2");
            if($a33!="")
            { $etape=33; }

            // 34
            $a34 = DB::connection('mysql2')->table('worksite')->rightjoin('ventes', 'ventes.ref', '=', 'worksite.vente')->where('cod', $code)->value("a56");
            if($a34!="")
            { $etape=34; }

            // 35
            $a35 = DB::table('factures')->where('cli', $ref)->value("f3");
            if($a35!="")
            { $etape=35; }

            // 36
            $a36 = DB::connection('mysql2')->table('worksite')->rightjoin('ventes', 'ventes.ref', '=', 'worksite.vente')->where('cod', $code)->value("mise");
            if($a36!="")
            { $etape=36; }
            

            $newdata =  array (
              'ref' => $ref,
              'step' => $etape
            );

            array_push($steps, $newdata);



        }

        return view('steps', ['clis' => $clis, 'steps' => $steps ]);
    }

    public function clientAdd()
    {
        return view('clientAdd'); 
    }

    public function clientAdded(Request $req)
    {
        $ref = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $ref = $ref.$b;
        $fait=date("Y/m/d H:i:s");

        // Validate
        $nb = DB::table('clis')->where('username', $req->input('log'))->count();
        if($nb==0) {
            DB::table('clis')->insert(
            ['type' => 'user', 'ref' => $ref, 'username' => $req->input('log'), 'password' => Hash::make('123456'), 'civ' => $req->input('civ'), 'nom' => strtoupper($req->input('nom')), 'pre' => ucfirst(strtolower($req->input('pre'))), 'tel' => $req->input('tel'), 'mail' => $req->input('mail'), 'dat' => $fait, 'sent' => 0, 'sent_dat' => NULL , 'doc' => 1, 'code' => $req->input('code')  ]
            );
            session()->flash('Validation',"The client has been added successfully");
            return redirect('client'); 
        } else 
        { session()->flash('Danger',"The chosen identifier already exists!"); return redirect('clientAdd');  }

    }

    public function clientEdit($ref)
    {
        $clis = DB::table('clis')
        ->where('ref', $ref)
        ->get();
        return view('clientEdit', ['clis' => $clis  ]);
    }

    public function clientEdited(Request $req, $ref)
    {
        DB::table('clis')
        ->where('ref', $ref)
        ->update(['code' => $req->input('code'), 'username' => $req->input('username'), 'langue' => $req->input('langue'), 'civ' => $req->input('civ'), 'nom' => $req->input('nom'), 'pre' => $req->input('pre'), 'tel' => $req->input('tel'), 'mail' => $req->input('mail')]);  
        

        // Update in  sales
        $codeClient = DB::table('clis')->where('ref', $ref)->value('code');
        DB::connection('mysql2')
        ->table('ventes')
        ->where('cod', $codeClient)
        ->update([                
            'civ' => $req->input('civ'),
            'nom' => $req->input('nom'),
            'pre' => $req->input('pre'),
            'tel' => $req->input('tel'),
            'mail' => $req->input('mail'),
        ]);  

        if($req->input('pas1')!="" && $req->input('pas2')!="" && $req->input('pas1')==$req->input('pas2') )
        {
            DB::table('clis')
            ->where('ref', $ref)
            ->update(['password' =>  Hash::make($req->input('pas1'))  ]); 
        }
        
        $clis = DB::table('clis')
        ->where('ref', $ref)
        ->get();
        session()->flash('Validation',"The client has been successfully modified");
        return view('clientEdit', ['clis' => $clis, 'ref'=>$ref ]);
    }
    
    public function clientDelete($ref)
    {
        DB::table('clis')->where('ref', $ref)->delete();

        session()->flash('Suppression',"Customer has been successfully deleted");
        return redirect('client');
    }

    public function clientPhotos($ref)
    {   
        $photos = DB::table('cli_pic')
        ->where('cli', $ref)
        ->orderBy('dat', 'desc')
        ->paginate(12);

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        return view('clientPhotos', ['photos' => $photos, 'ref'=>$ref, 'client'=>$client ]);
    }

    public function clientPhotosAdd(Request $req, $ref)
    {   
        // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $images=array();
        if($files=$req->file('images')){
            foreach($files as $file){
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('public')->put($id.'.'.$extension,  File::get($file));
                DB::table('cli_pic')->insert(
                    ['ref' => $id, 'img' => $id.'.'.$extension, 'cli' => $ref, 'dat' => $fait ]
                );

            }
        }

        // Variables notification
        $da = date("Y-m-d");
        $page = "getPhotosDay/".$da; 
        $msg = "Nouvelles photos sont ajoutées";
        $cli = $ref;
        $langue = DB::table('clis')->where('ref', $cli)->value('langue');

        // Notification (Classic)***************************
        $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        DB::table('notification')->insert(
        ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Photos',
        'msg' => $msg,
        'cat' => "notification",
        'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 

        // ###### Notification (Email)***************************
        $email = DB::table('clis')->where('ref', $cli)->value('mail');
        \Mail::to($email)->send(new Notif($msg, $page, $langue) );


        return redirect()->route('clientPhotos', ['ref'=>$ref ])
        ->with('Validation','Photos are successfully added');
        
        $photos = DB::table('cli_pic')
        ->where('cli', $ref)
        ->orderBy('dat', 'desc')
        ->paginate(12);

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        return view('clientPhotos', ['photos' => $photos, 'ref'=>$ref, 'client'=>$client ]);
    }

    public function clientPhotosDelete($ref)
    {

        $clientref = DB::table('cli_pic')->where('ref', $ref)->value('cli');

        $client = DB::table('clis')->where('ref', $clientref)->value('civ')." ".DB::table('clis')->where('ref', $clientref)->value('nom')." ".DB::table('clis')->where('ref', $clientref)->value('pre');
        
        DB::table('cli_pic')->where('ref', $ref)->delete();

        $photos = DB::table('cli_pic')
        ->where('cli', $clientref)
        ->orderBy('dat', 'desc')
        ->paginate(12);

        session()->flash('Suppression',"Image has been successfully deleted");
        return view('clientPhotos', ['photos' => $photos, 'ref'=>$ref, 'client'=>$client ]);
    }


    public function doc()
    {
        $docs = DB::table('doc')
        ->orderBy('des', 'asc')
        ->get();
        return view('doc', ['docs' => $docs ]);
    }

    public function docAdd()
    {
        return view('docAdd'); 
    }

    public function docAdded(Request $req)
    {   
        
       // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $images=array();
        if($files=$req->file('images')){
            foreach($files as $file){
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('doc')->put($id.'.'.$extension,  File::get($file));

                DB::table('doc')->insert(
                    ['id' => 0, 'des' => $req->input('des'), 'doc' => $id.'.'.$extension, 'fait' => $fait ]
                );

            }
        }

        return redirect()->route('doc')
        ->with('Validation','Document was added successfully');
        
        $photos = DB::table('cli_pic')
        ->where('cli', $ref)
        ->orderBy('dat', 'desc')
        ->get();
    }


    public function docDelete($ref)
    {
        
        DB::table('doc')->where('id', $ref)->delete();

        $docs = DB::table('doc')
        ->orderBy('des', 'asc')
        ->get();

        session()->flash('Suppression',"Document has been deleted successfully");
        return view('doc', ['docs' => $docs]);
    }

    public function password()
    {
        return view('password');
    }

    public function passwordEdited(Request $req)
    {
        if ($req->input('pas2') == $req->input('pas1')) {
        DB::table('clis')
        ->where('username', Auth::user()->username)
        ->update(['password' => Hash::make($req->input('pas1')) ]);    
        session()->flash('Validation',"Password has been successfully changed");
        return view('password');   
        }   else {
        session()->flash('Erreur',"Passwords are not the same!");
        return view('password');
        }
    }
    
    
    
    public function clientNotification($mail)
    {   
        
        $details=[
            'titile'=>'mail from',
            'body'=>'yeees'

        ];
        \Mail::to($mail)->send(new Notification($details) );
        
        $fait=date("Y/m/d H:i:s");
        
         DB::table('clis')
            ->where('mail', $mail)
            ->update(['sent' =>  1, 'sent_dat' =>  $fait ]); 
        
        session()->flash('Validation',"The notification was sent successfully");
        return redirect('client');
    }
    
    public function docView($mail, $vf)
    {   
        
        
         DB::table('clis')
            ->where('mail', $mail)
            ->update(['doc' =>  $vf]); 
        
        session()->flash('Validation',"Operation performed");
        return redirect('client');
    }
    
    
    
    public function clientDocs($ref)
    {   
        $docs = DB::table('clidoc')
        ->where('cli', $ref)
        ->orderBy('fait', 'desc')
        ->paginate(20);

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        return view('clientDocs', ['docs' => $docs, 'ref'=>$ref, 'client'=>$client ]);
    }
    
    public function clientDocsAdd(Request $req, $ref)
    {   
        $des = $req->input('des');
        // NB ! Change fichier config/filesystems.php
        $input=$req->all();
        $images=array();
        if($files=$req->file('images')){
            foreach($files as $file){
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();
                Storage::disk('clidoc')->put($id.'.'.$extension,  File::get($file));

                DB::table('clidoc')->insert(
                    ['des' => $des, 'doc' => $id.'.'.$extension, 'fait' => $fait, 'cli' => $ref ]
                );

            }
        }
        
        $docs = DB::table('clidoc')
        ->where('cli', $ref)
        ->orderBy('fait', 'desc')
        ->paginate(12);

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        return view('clientDocs', ['docs' => $docs, 'ref'=>$ref, 'client'=>$client ])
        ->with('Validation','Files are added successfully');
    }
    
    
    public function clientDocsDelete($id, $ref)
    {
        
        DB::table('clidoc')->where('id', $id)->delete();
        
        $docs = DB::table('clidoc')
        ->where('cli', $ref)
        ->orderBy('fait', 'desc')
        ->paginate(12);

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        return view('clientDocs', ['docs' => $docs, 'ref'=>$ref, 'client'=>$client ])
        ->with('Suppression',"Document has been deleted successfully");
        
    }
    
    public function documents()
    {   
        $ref = Auth::user()->ref;
        $docs = DB::table('clidoc')
        ->where('cli', $ref)
        ->orderBy('fait', 'desc')
        ->paginate(12);

        $client = DB::table('clis')->where('ref', $ref)->value('civ')." ".DB::table('clis')->where('ref', $ref)->value('nom')." ".DB::table('clis')->where('ref', $ref)->value('pre');

        return view('documents', ['docs' => $docs, 'ref'=>$ref, 'client'=>$client ]);
    }
    



    // Form Add
    public function form_added(Request $req)
    {

        for ($i=1;$i<=75;$i++) {
          $vardyn = "v".$i;
          $$vardyn = $req->input($vardyn);
        }

        // Notifications
        $code = Auth::user()->code;
        $langue = DB::table('clis')->where('code', $code)->value('langue');
        function getEmails($tache) { $emailsTable = DB::table('emails')->where($tache, 1)->get(); $emails = array(); foreach ($emailsTable as $e) { array_push($emails, $e->mail); } return $emails; }
        $emails = getEmails('arch1');
        $msg=$code." - D0 : The form has been updated"; $page="design0";
        if(count($emails)!=0){ foreach($emails as $em) { if($em!='') { \Mail::to($em)->send(new Notif($msg, $page, $langue) ); } } }  


        $nb = DB::table('form')->where('cli', Auth::user()->ref)->count();
        if($nb==0) { 
            $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,8); $b = date("dmyHis"); $id = $id.$b;
            $fait=date("Y/m/d H:i:s");


            DB::table('form')
            ->insert([
                'ref' => $id,
                'cli' => Auth::user()->ref,

                'v1' => $v1,
                'v2' => $v2,
                'v3' => $v3,
                'v4' => $v4,
                'v5' => $v5,
                'v6' => $v6,
                'v7' => $v7,
                'v8' => $v8,
                'v9' => $v9,
                'v10' => $v10,

                'v11' => $v11,
                'v12' => $v12,
                'v13' => $v13,
                'v14' => $v14,
                'v15' => $v15,
                'v16' => $v16,
                'v17' => $v17,
                'v18' => $v18,
                'v19' => $v19,
                'v20' => $v20,

                'v21' => $v21,
                'v22' => $v22,
                'v23' => $v23,
                'v24' => $v24,
                'v25' => $v25,
                'v26' => $v26,
                'v27' => $v27,
                'v28' => $v28,
                'v29' => $v29,
                'v30' => $v30,

                'v31' => $v31,
                'v32' => $v32,
                'v33' => $v33,
                'v34' => $v34,
                'v35' => $v35,
                'v36' => $v36,
                'v37' => $v37,
                'v38' => $v38,
                'v39' => $v39,
                'v40' => $v40,

                'v41' => $v41,
                'v42' => $v42,
                'v43' => $v43,
                'v44' => $v44,
                'v45' => $v45,
                'v46' => $v46,
                'v47' => $v47,
                'v48' => $v48,
                'v49' => $v49,
                'v50' => $v50,

                'v51' => $v51,
                'v52' => $v52,
                'v53' => $v53,
                'v54' => $v54,
                'v55' => $v55,
                'v56' => $v56,
                'v57' => $v57,
                'v58' => $v58,
                'v59' => $v59,
                'v60' => $v60,

                'v61' => $v61,
                'v62' => $v62,
                'v63' => $v63,
                'v64' => $v64,
                'v65' => $v65,
                'v66' => $v66,
                'v67' => $v67,
                'v68' => $v68,
                'v69' => $v69,
                'v70' => $v70,

                'v71' => $v71,
                'v72' => $v72,
                'v73' => $v73,
                'v74' => $v74,
                'v75' => $v75,

                'vu' => 0,
                'fait' => $fait,
                'par' => Auth::user()->ref,
            ]); 

            // update options
            $cases = array("v72", "v74");
            foreach ($cases as $case) {
                DB::table('options')->where('sale', Auth::user()->ref)->where('case', $case)->delete();
                $options=$req->input($case);
                if($options) { 
                    for ($i=0; $i <count($options) ; $i++) { 
                        DB::table('options')->insert( ['sale' => Auth::user()->ref, 'case' => $case, 'val' => $options[$i] ] );
                    }
                }
            }  

            session()->flash('Validation',"Informations has been successfully updated");
            return back();
        } else {
            $ref = DB::table('form')->where('cli', Auth::user()->ref)->value('ref');
            DB::table('form')->where('ref', $ref)->update([ 

                'v1' => $v1,
                'v2' => $v2,
                'v3' => $v3,
                'v4' => $v4,
                'v5' => $v5,
                'v6' => $v6,
                'v7' => $v7,
                'v8' => $v8,
                'v9' => $v9,
                'v10' => $v10,

                'v11' => $v11,
                'v12' => $v12,
                'v13' => $v13,
                'v14' => $v14,
                'v15' => $v15,
                'v16' => $v16,
                'v17' => $v17,
                'v18' => $v18,
                'v19' => $v19,
                'v20' => $v20,

                'v21' => $v21,
                'v22' => $v22,
                'v23' => $v23,
                'v24' => $v24,
                'v25' => $v25,
                'v26' => $v26,
                'v27' => $v27,
                'v28' => $v28,
                'v29' => $v29,
                'v30' => $v30,

                'v31' => $v31,
                'v32' => $v32,
                'v33' => $v33,
                'v34' => $v34,
                'v35' => $v35,
                'v36' => $v36,
                'v37' => $v37,
                'v38' => $v38,
                'v39' => $v39,
                'v40' => $v40,

                'v41' => $v41,
                'v42' => $v42,
                'v43' => $v43,
                'v44' => $v44,
                'v45' => $v45,
                'v46' => $v46,
                'v47' => $v47,
                'v48' => $v48,
                'v49' => $v49,
                'v50' => $v50,

                'v51' => $v51,
                'v52' => $v52,
                'v53' => $v53,
                'v54' => $v54,
                'v55' => $v55,
                'v56' => $v56,
                'v57' => $v57,
                'v58' => $v58,
                'v59' => $v59,
                'v60' => $v60,

                'v61' => $v61,
                'v62' => $v62,
                'v63' => $v63,
                'v64' => $v64,
                'v65' => $v65,
                'v66' => $v66,
                'v67' => $v67,
                'v68' => $v68,
                'v69' => $v69,
                'v70' => $v70,

                'v71' => $v71,
                'v72' => $v72,
                'v73' => $v73,
                'v74' => $v74,
                'v75' => $v75,
            ]); 
            session()->flash('Validation',"Url has been successfully updated");

            // update options
            $cases = array("v72", "v74");
            foreach ($cases as $case) {
                DB::table('options')->where('sale', Auth::user()->ref)->where('case', $case)->delete();
                $options=$req->input($case);
                if($options) { 
                    for ($i=0; $i <count($options) ; $i++) { 
                        DB::table('options')->insert( ['sale' => Auth::user()->ref, 'case' => $case, 'val' => $options[$i] ] );
                    }
                }
            }  
            
            return back();
        }
    }



    // Delete File
    public function deleteFile($ref, $table, $champ)
    {
        DB::table($table)->where('ref', $ref)->delete();

        session()->flash('Validation',"File deleted");
        return back();
    }


    // Import All Photos
    public function importAllPhotos()
    {
        return view("importAllPhotos");
    }

    public function importAllPhotosAdded(Request $req)
    {
        $input=$req->all();
        $images=array();
        if($files=$req->file('images')){
            foreach($files as $file){
                $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
                $fait=date("Y/m/d H:i:s");
                $extension = $file->getClientOriginalExtension();

                $filenameWithExt    = $file->getClientOriginalName();
                $filename           = pathinfo($filenameWithExt, PATHINFO_FILENAME);

                $path = Storage::path($filename );

                Storage::disk('sample')->put($id.'.'.$extension,  File::get("C:\Users\abdel\OneDrive\Bureau\PhotosAllVillas2\MC-000\aaaa.jpg"));
                // DB::table('cli_pic')->insert(
                //     ['ref' => $id, 'img' => $id.'.'.$extension, 'cli' => $ref, 'dat' => $fait ]
                // );
            }
        }

        // // Variables notification
        // $da = date("Y-m-d");
        // $page = "getPhotosDay/".$da; 
        // $msg = "Nouvelles photos sont ajoutées";
        // $cli = $ref;

        // // Notification (Classic)***************************
        // $id = substr(str_shuffle("1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"),0,24); $b = date("dmyHis"); $id = $id.$b;
        // DB::table('notification')->insert(
        // ['ref' => $id,  'cli' => $cli,  'code' => $id, 'type' => 'Photos',
        // 'msg' => $msg,
        // 'cat' => "notification",
        // 'lu' => 0, 'fait' => $fait, 'par' => Auth::user()->ref ] ); 

        // // ###### Notification (Email)***************************
        // $email = DB::table('clis')->where('ref', $cli)->value('mail');
        // \Mail::to($email)->send(new Notif($msg, $page, $langue) );

        // session()->flash('yes',"Photos added successfully");
        // return back();
    }


    public function recap()
    {
        $clients = DB::table('clis')->get();
        foreach ($clients as $c) {
            DB::table('clis')->where('mail', $c->mail)->update([ 'email' => $c->mail ]); 
        }

        if (Auth::user()->type!='admin') { return redirect('dashboard');  }
        $clis = DB::table('clis')->where('type', '!=', 'admin')->orderBy('nom', 'asc')->get();

        $recaps = array (
          array(
                'a1' => '1', 'a2' => '1', 'a3' => '1', 'a4' => '1',
                'b1' => '1', 'b2' => '1', 'b3' => '1', 'b4' => '1', 'b5' => '1', 'b6' => '1', 'b7' => '1', 'b8' => '1',
                'c1' => '1', 'c2' => '1', 'c3' => '1', 'c4' => '1', 'c5' => '1', 'c6' => '1', 'c7' => '1', 'c8' => '1',
                'd1' => '1', 'd2' => '1', 'd3' => '1', 'd4' => '1', 'd5' => '1', 'd6' => '1',
                'e1' => '1', 'e2' => '1', 'e3' => '1', 'e4' => '1', 'e5' => '1', 'e6' => '1', 'e7' => '1', 'e8' => '1', 'e9' => '1',
                'f1' => '1', 'f2' => '1', 'f3' => '1', 'f4' => '1', 'f5' => '1', 'f6' => '1',
                'g1' => '1', 'g2' => '1', 'g3' => '1', 'g4' => '1', 'g5' => '1', 'g6' => '1', 'g7' => '1', 'g8' => '1', 'g9' => '1', 'g10' => '1', 'g11' => '1',
                'h1' => '1', 'h2' => '1', 'h3' => '1', 'h4' => '1', 'h5' => '1', 'h6' => '1', 'h7' => '1', 'h8' => '1', 'h9' => '1', 'h10' => '1', 'h11' => '1', 'h12' => '1', 'h13' => '1', 'h14' => '1', 'h15' => '1', 'h16' => '1', 'h17' => '1', 'h18' => '1', 'h19' => '1', 'h20' => '1', 'h21' => '1', 'h22' => '1', 'h23' => '1', 'h24' => '1'

            ),
        );

        foreach ($clients as $c) { 
            $etape=1;
            $ref = $c->ref;
            $code = $c->code;

            $b1 = DB::table('administration')->where('type', "reservation2")->where('cli', $ref)->count(); if($b1==0 ){ $b1='NO'; } else {  $b1='YES'; }
            $b2 = DB::table('administration')->where('type', "reservation")->where('cli', $ref)->count(); if($b2==0 ){ $b2='NO'; } else {  $b2='YES'; }
            $b3 = DB::table('administration')->where('type', "terrain2")->where('cli', $ref)->count(); if($b3==0 ){ $b3='NO'; } else {  $b3='YES'; }
            $b4 = DB::table('administration')->where('type', "terrain")->where('cli', $ref)->count(); if($b4==0 ){ $b4='NO'; } else {  $b4='YES'; }
            $b5 = DB::table('administration')->where('type', "quotation2")->where('cli', $ref)->count(); if($b5==0 ){ $b5='NO'; } else {  $b5='YES'; }
            $b6 = DB::table('administration')->where('type', "quotation")->where('cli', $ref)->count(); if($b6==0 ){ $b6='NO'; } else {  $b6='YES'; }
            $b7 = DB::table('administration')->where('type', "construction2")->where('cli', $ref)->count(); if($b7==0 ){ $b7='NO'; } else {  $b7='YES'; }
            $b8 = DB::table('administration')->where('type', "construction")->where('cli', $ref)->count(); if($b8==0 ){ $b8='NO'; } else {  $b8='YES'; }

            $c1 = DB::table('ptpma')->where('type', "construction2")->where('cli', $ref)->count(); if($c1==0 ){ $c1='NO'; } else {  $c1='YES'; }
            $c2 = DB::table('ptpma')->where('type', "construction")->where('cli', $ref)->count(); if($c2==0 ){ $c2='NO'; } else {  $c2='YES'; }
            $c3 = DB::table('ptpma')->where('type', "reservation2")->where('cli', $ref)->count(); if($c3==0 ){ $c3='NO'; } else {  $c3='YES'; }
            $c4 = DB::table('ptpma')->where('type', "reservation")->where('cli', $ref)->count(); if($c4==0 ){ $c4='NO'; } else {  $c4='YES'; }
            $c5 = DB::table('ptpma')->where('type', "acte2")->where('cli', $ref)->count(); if($c5==0 ){ $c5='NO'; } else {  $c5='YES'; }
            $c6 = DB::table('ptpma')->where('type', "acte")->where('cli', $ref)->count(); if($c6==0 ){ $c6='NO'; } else {  $c6='YES'; }
            $c7 = DB::table('ptpma')->where('type', "terrain2")->where('cli', $ref)->count(); if($c7==0 ){ $c7='NO'; } else {  $c7='YES'; }
            $c8 = DB::table('ptpma')->where('type', "terrain")->where('cli', $ref)->count(); if($c8==0 ){ $c8='NO'; } else {  $c8='YES'; }

            $d1 = DB::table('ptpma')->where('type', "construction2")->where('cli', $ref)->count(); if($d1==0 ){ $d1='NO'; } else {  $d1='YES'; }
            $d2 = DB::table('ptpma')->where('type', "construction")->where('cli', $ref)->count(); if($d2==0 ){ $d2='NO'; } else {  $d2='YES'; }
            $d3 = DB::table('ptpma')->where('type', "reservation2")->where('cli', $ref)->count(); if($d3==0 ){ $d3='NO'; } else {  $d3='YES'; }
            $d4 = DB::table('ptpma')->where('type', "reservation")->where('cli', $ref)->count(); if($d4==0 ){ $d4='NO'; } else {  $d4='YES'; }
            $d5 = DB::table('ptpma')->where('type', "acte2")->where('cli', $ref)->count(); if($d5==0 ){ $d5='NO'; } else {  $d5='YES'; }
            $d6 = DB::table('ptpma')->where('type', "acte")->where('cli', $ref)->count(); if($d6==0 ){ $d6='NO'; } else {  $d6='YES'; }

            $e1 = DB::table('design_pdf')->where('cli', $ref)->where('d', 1)->where('typ', 1)->orderBy('fait', 'desc')->count(); if($e1==0 ){ $e1='NO'; } else {  $e1='YES'; }
            $e2 = DB::table('design_pdf')->where('cli', $ref)->where('d', 1)->where('typ', 2)->orderBy('fait', 'desc')->count(); if($e2==0 ){ $e2='NO'; } else {  $e2='YES'; }
            $e3 = DB::table('design')->where('cli', $ref)->where('d', 1)->count(); if($e3==0 ){ $e3='NO'; } else {  $e3='YES'; }
            $e4 = DB::table('design_pdf')->where('cli', $ref)->where('d', 1)->where('typ', 1)->orderBy('fait', 'desc')->count(); if($e4==0 ){ $e4='NO'; } else {  $e4='YES'; }
            $e5 = DB::table('design_pdf')->where('cli', $ref)->where('d', 1)->where('typ', 2)->orderBy('fait', 'desc')->count(); if($e5==0 ){ $e5='NO'; } else {  $e5='YES'; }
            $e6 = DB::table('design')->where('cli', $ref)->where('d', 1)->count(); if($e6==0 ){ $e6='NO'; } else {  $e6='YES'; }
            $e7 = DB::table('design_pdf')->where('cli', $ref)->where('d', 1)->where('typ', 1)->orderBy('fait', 'desc')->count(); if($e7==0 ){ $e7='NO'; } else {  $e7='YES'; }
            $e8 = DB::table('design_pdf')->where('cli', $ref)->where('d', 1)->where('typ', 2)->orderBy('fait', 'desc')->count(); if($e8==0 ){ $e8='NO'; } else {  $e8='YES'; }
            $e9 = DB::table('design')->where('cli', $ref)->where('d', 1)->count(); if($e9==0 ){ $e9='NO'; } else {  $e9='YES'; }

            $f1 = DB::table('plan')->where('type', "reservation2")->where('cli', $ref)->count(); if($f1==0 ){ $f1='NO'; } else {  $f1='YES'; }
            $f2 = DB::table('plan')->where('type', "reservation")->where('cli', $ref)->count(); if($f2==0 ){ $f2='NO'; } else {  $f2='YES'; }
            $f3 = DB::table('plan')->where('type', "construction2")->where('cli', $ref)->count(); if($f3==0 ){ $f3='NO'; } else {  $f3='YES'; }
            $f4 = DB::table('plan')->where('type', "construction")->where('cli', $ref)->count(); if($f4==0 ){ $f4='NO'; } else {  $f4='YES'; }
            $f5 = DB::table('plan')->where('type', "terrain2")->where('cli', $ref)->count(); if($f5==0 ){ $f5='NO'; } else {  $f5='YES'; }
            $f6 = DB::table('plan')->where('type', "terrain")->where('cli', $ref)->count(); if($f6==0 ){ $f6='NO'; } else {  $f6='YES'; }

            $g1 = DB::table('construction')->where('cli', $ref)->value("a0"); if($g1=='' ){ $g1='NO'; } else {  $g1='YES'; }
            $g2 = DB::table('construction')->where('cli', $ref)->value("a1"); if($g2=='' ){ $g2='NO'; } else {  $g2='YES'; }
            $g3 = DB::table('construction')->where('cli', $ref)->value("a2"); if($g3=='' ){ $g3='NO'; } else {  $g3='YES'; }
            $g4 = DB::table('construction')->where('cli', $ref)->value("a3"); if($g4=='' ){ $g4='NO'; } else {  $g4='YES'; }
            $g5 = DB::table('construction')->where('cli', $ref)->value("a4"); if($g5=='' ){ $g5='NO'; } else {  $g5='YES'; }
            $g6 = DB::table('construction')->where('cli', $ref)->value("a5"); if($g6=='' ){ $g6='NO'; } else {  $g6='YES'; }
            $g7 = DB::table('construction')->where('cli', $ref)->value("a6"); if($g7=='' ){ $g7='NO'; } else {  $g7='YES'; }
            $g8 = DB::table('construction')->where('cli', $ref)->value("a7"); if($g8=='' ){ $g8='NO'; } else {  $g8='YES'; }
            $g9 = DB::table('construction')->where('cli', $ref)->value("a8"); if($g9=='' ){ $g9='NO'; } else {  $g9='YES'; }
            $g10 = DB::table('construction')->where('cli', $ref)->value("a9"); if($g10=='' ){ $g10='NO'; } else {  $g10='YES'; }
            $g11 = DB::table('construction')->where('cli', $ref)->value("a10"); if($g11=='' ){ $g11='NO'; } else {  $g11='YES'; }

            $h1 = DB::table('factures')->where('cli', $ref)->value("a1"); if($h1=='' ){ $h1='NO'; } else {  $h1='YES'; }
            $h2 = DB::table('factures')->where('cli', $ref)->value("a2"); if($h2=='' ){ $h2='NO'; } else {  $h2='YES'; }
            $h3 = DB::table('factures')->where('cli', $ref)->value("a3"); if($h3=='' ){ $h3='NO'; } else {  $h3='YES'; }
            $h4 = DB::table('factures')->where('cli', $ref)->value("a4"); if($h4=='' ){ $h4='NO'; } else {  $h4='YES'; }
            $h5 = DB::table('factures')->where('cli', $ref)->value("b1"); if($h5=='' ){ $h5='NO'; } else {  $h5='YES'; }
            $h6 = DB::table('factures')->where('cli', $ref)->value("b2"); if($h6=='' ){ $h6='NO'; } else {  $h6='YES'; }
            $h7 = DB::table('factures')->where('cli', $ref)->value("b3"); if($h7=='' ){ $h7='NO'; } else {  $h7='YES'; }
            $h8 = DB::table('factures')->where('cli', $ref)->value("b4"); if($h8=='' ){ $h8='NO'; } else {  $h8='YES'; }
            $h9 = DB::table('factures')->where('cli', $ref)->value("c1"); if($h9=='' ){ $h9='NO'; } else {  $h9='YES'; }
            $h10 = DB::table('factures')->where('cli', $ref)->value("c2"); if($h10=='' ){ $h10='NO'; } else {  $h10='YES'; }
            $h11 = DB::table('factures')->where('cli', $ref)->value("c3"); if($h11=='' ){ $h11='NO'; } else {  $h11='YES'; }
            $h12 = DB::table('factures')->where('cli', $ref)->value("c4"); if($h12=='' ){ $h12='NO'; } else {  $h12='YES'; }
            $h13 = DB::table('factures')->where('cli', $ref)->value("d1"); if($h13=='' ){ $h13='NO'; } else {  $h13='YES'; }
            $h14 = DB::table('factures')->where('cli', $ref)->value("d2"); if($h14=='' ){ $h14='NO'; } else {  $h14='YES'; }
            $h15 = DB::table('factures')->where('cli', $ref)->value("d3"); if($h15=='' ){ $h15='NO'; } else {  $h15='YES'; }
            $h16 = DB::table('factures')->where('cli', $ref)->value("d4"); if($h16=='' ){ $h16='NO'; } else {  $h16='YES'; }
            $h17 = DB::table('factures')->where('cli', $ref)->value("e1"); if($h17=='' ){ $h17='NO'; } else {  $h17='YES'; }
            $h18 = DB::table('factures')->where('cli', $ref)->value("e2"); if($h18=='' ){ $h18='NO'; } else {  $h18='YES'; }
            $h19 = DB::table('factures')->where('cli', $ref)->value("e3"); if($h19=='' ){ $h19='NO'; } else {  $h19='YES'; }
            $h20 = DB::table('factures')->where('cli', $ref)->value("e4"); if($h20=='' ){ $h20='NO'; } else {  $h20='YES'; }
            $h21 = DB::table('factures')->where('cli', $ref)->value("f1"); if($h21=='' ){ $h21='NO'; } else {  $h21='YES'; }
            $h22 = DB::table('factures')->where('cli', $ref)->value("f2"); if($h22=='' ){ $h22='NO'; } else {  $h22='YES'; }
            $h23 = DB::table('factures')->where('cli', $ref)->value("f3"); if($h23=='' ){ $h23='NO'; } else {  $h23='YES'; }
            $h24 = DB::table('factures')->where('cli', $ref)->value("f4"); if($h24=='' ){ $h24='NO'; } else {  $h24='YES'; }

            $newdata =  array (
              'a1' => $c->code,
              'a2' => $c->civ,
              'a3' => $c->nom,
              'a4' => $c->pre,

              'b1' => $b1,
              'b2' => $b2,
              'b3' => $b3,
              'b4' => $b4,
              'b5' => $b5,
              'b6' => $b6,
              'b7' => $b7,
              'b8' => $b8,

              'c1' => $c1,
              'c2' => $c2,
              'c3' => $c3,
              'c4' => $c4,
              'c5' => $c5,
              'c6' => $c6,
              'c7' => $c7,
              'c8' => $c8,

              'd1' => $d1,
              'd2' => $d2,
              'd3' => $d3,
              'd4' => $d4,
              'd5' => $d5,
              'd6' => $d6,

              'e1' => $e1,
              'e2' => $e2,
              'e3' => $e3,
              'e4' => $e4,
              'e5' => $e5,
              'e6' => $e6,
              'e7' => $e7,
              'e8' => $e8,
              'e9' => $e9,

              'f1' => $f1,
              'f2' => $f2,
              'f3' => $f3,
              'f4' => $f4,
              'f5' => $f5,
              'f6' => $f6,

              'g1' => $g1,
              'g2' => $g2,
              'g3' => $g3,
              'g4' => $g4,
              'g5' => $g5,
              'g6' => $g6,
              'g7' => $g7,
              'g8' => $g8,
              'g9' => $g9,
              'g10' => $g10,
              'g11' => $g11,

              'h1' => $h1,
              'h2' => $h2,
              'h3' => $h3,
              'h4' => $h4,
              'h5' => $h5,
              'h6' => $h6,
              'h7' => $h7,
              'h8' => $h8,
              'h9' => $h9,
              'h10' => $h10,
              'h11' => $h11,
              'h12' => $h12,
              'h13' => $h13,
              'h14' => $h14,
              'h15' => $h15,
              'h16' => $h16,
              'h17' => $h17,
              'h18' => $h18,
              'h19' => $h19,
              'h20' => $h20,
              'h21' => $h21,
              'h22' => $h22,
              'h23' => $h23,
              'h24' => $h24,
            );

            array_push($recaps, $newdata);
        }

        return view('recap', ['clis' => $clis, 'recaps' => $recaps ]);
    }



    public function holidays_total()
    {
        $clis = DB::table('clis')
        ->where('type', '!=', 'admin')
        ->where('code', '!=', '')
        ->orderBy('nom', 'asc')
        ->get();

        $totals = array ( array('code' => '1', 'nom' => '1', 'rai' => '1', 'cer' => '1', 'hol' => '1', 'de' => '1', 'a' => '1'), );

        foreach($clis as $c) {

            $ref =$c->ref;

            $a0 = DB::table('construction')->where('cli', $ref)->value("a0");
            $a1 = DB::table('construction')->where('cli', $ref)->value("a1");
            $a2 = DB::table('construction')->where('cli', $ref)->value("a2");
            $a3 = DB::table('construction')->where('cli', $ref)->value("a3");
            $a4 = DB::table('construction')->where('cli', $ref)->value("a4");
            $a5 = DB::table('construction')->where('cli', $ref)->value("a5");
            $a6 = DB::table('construction')->where('cli', $ref)->value("a6");
            $a7 = DB::table('construction')->where('cli', $ref)->value("a7");
            $a8 = DB::table('construction')->where('cli', $ref)->value("a8");
            $a9 = DB::table('construction')->where('cli', $ref)->value("a9");
            $a10 = DB::table('construction')->where('cli', $ref)->value("a10");

            $lyouma = date("Y-m-d");
            $z = date("Y-m-d");

            // rain
            if($a1!='') { $z = $a1; } else { $z = $lyouma; }
            if($a2!='') { $z = $a2; } else { $z = $lyouma; }
            if($a3!='') { $z = $a3; } else { $z = $lyouma; }
            if($a4!='') { $z = $a4; } else { $z = $lyouma; }
            if($a5!='') { $z = $a5; } else { $z = $lyouma; }
            if($a6!='') { $z = $a6; } else { $z = $lyouma; }
            if($a7!='') { $z = $a7; } else { $z = $lyouma; }
            if($a8!='') { $z = $a8; } else { $z = $lyouma; }
            if($a9!='') { $z = $a9; } else { $z = $lyouma; }
            if($a10!='') { $z = $a10; } else { $z = $lyouma; }
                
            $rai = DB::table('days')->where('typ', 'Rainy days')->whereBetween('dat', [$a0, $z])->count();
            $cer = DB::table('days')->where('typ', 'Ceremony days')->whereBetween('dat', [$a0, $z])->count();
            $hol = DB::table('days')->where('typ', 'Public Holidays')->whereBetween('dat', [$a0, $z])->count();


            $newdata =  array ( 'code' => $c->code, 'nom' => $c->civ.' '.$c->nom.' '.$c->pre, 'rai' => $rai, 'cer' => $cer, 'hol' => $hol, 'de' => $a0, 'a' => $z );
            array_push($totals, $newdata);
        }


        return view('holidays_total', ['totals' => $totals ]);
    }



    public static function getLogin($email)
    {
        $code = DB::table('clis')->where('mail', $email)->value('username');
        return "MC-000";
    }


}


