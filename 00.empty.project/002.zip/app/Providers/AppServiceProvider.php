<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Auth;
use DB;
use App\Http\Controllers\Cmd;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {


        view()->composer('*', function ($view)
        {                     

            if (Auth::check()) {

                $notification = DB::table('notification')
                ->where('cli', Auth::user()->ref)
                ->orderBy('fait', 'desc')
                ->get();              
                $view->with('notification', $notification );

                $noRead = DB::table('notification')
                ->where('cli', Auth::user()->ref)
                ->where('par', '!=', Auth::user()->ref)
                ->where('lu', 0)
                ->count();
                $view->with('noRead', $noRead );
                
                $urlWebSite = "https://villa.magnitudeconstruction.com";
                $view->with('urlWebSite', $urlWebSite );

                $urlWebSite2 = "https://monprojetbali.com";
                $view->with('urlWebSite2', $urlWebSite2 );

                $nbOldDocs = DB::table('clidoc')
                ->where('cli', Auth::user()->ref)
                ->count();
                $view->with('nbOldDocs', $nbOldDocs );

                $nbOldPics = DB::table('cli_pic')
                ->where('cli', Auth::user()->ref)
                ->where('dat', '<', '2022-01-06 00:00:00' )
                ->count();
                $view->with('nbOldPics', $nbOldPics );



                // Nom de la villa
                $nom_villa_Global = DB::connection('mysql2')->table('ventes')->where('cod', Auth::user()->code)->value('salevillaname');
                $view->with('nom_villa_Global', $nom_villa_Global );

                // Nom de PTPMA
                $nom_ptpma_Global = DB::connection('mysql2')->table('ptpma')->select('ptpmaname')->rightjoin('ventes', 'ventes.ref', '=', 'ptpma.vente')->where('cod', auth::user()->code)->value("ptpmaname");
                $view->with('nom_ptpma_Global', $nom_ptpma_Global );

                // Confirmed
                $confirmed_Global = DB::connection('mysql2')->table('ptpma')->select('confirmed')->rightjoin('ventes', 'ventes.ref', '=', 'ptpma.vente')->where('cod', auth::user()->code)->value("confirmed");
                $view->with('confirmed_Global', $confirmed_Global );

                // chat client
                $chat_msg = DB::table('chat')
                ->join('clis', 'clis.ref', '=', 'chat.via')
                ->orderBy('chat.fait','asc')->get();
                $view->with('chat_msg', $chat_msg );

                $chat_msg_nb = DB::table('chat')->join('clis', 'clis.ref', '=', 'chat.via')->where('to', Auth::user()->ref)->where('vu', 0)->count();
                $view->with('chat_msg_nb', $chat_msg_nb );

                // chat admin
                $chat_msg2 = DB::table('chat')
                ->join('clis', 'clis.ref', '=', 'chat.via')
                ->orderBy('chat.fait','desc')->get();
                $view->with('chat_msg2', $chat_msg2 );

                // chat admin nb no lu
                $msgs_no_lu = DB::table('chat')->where('to', 'Magnitude')->where('vu', 0)->count();
                $view->with('msgs_no_lu', $msgs_no_lu );

            }



            // Check activité
            // if (Auth::check()) {
            // $act = DB::connection('mysql2')->table('ventes')
            // ->where('cod', Auth::user()->code)
            // ->value('AccountActive');
            // if($act==0) { Auth::logout(); return redirect('login');  } }


        });
    }


    
}
